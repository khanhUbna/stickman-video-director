"""Portable, offline-media prototype delivery; excludes dependency caches."""
from pathlib import Path
import json,hashlib,zipfile,shutil,ast,re
B=Path(__file__).resolve().parent;O=B/'output';DEST=Path('/workspace/stickman-video-director/deliveries/rest-motion-trial-v1')
def main():
 q=json.loads((O/'QA.json').read_text());movie=O/'agile-motion-15s.mp4'
 assert q['sha256']==hashlib.sha256(movie.read_bytes()).hexdigest() and q['full_decode']=='pass'
 assert q['motion']['maximum_world_stance_drift']<1e-7 and q['motion']['maximum_shirt_grip_error']<1e-7
 caps=json.loads((B/'public/captions.json').read_text());assert len(caps)==6
 assert all(0<=c['start']<c['end']<=15 for c in caps)
 assert all(caps[i]['end']<=caps[i+1]['start']+.001 for i in range(len(caps)-1))
 for p in B.glob('*.py'):ast.parse(p.read_text())
 rights={'new_paid_API_calls':0,'narration':'Saved original-rate OpenAI alloy recording, previously authorized, excerpt only; voice-reuse.json records exact source SHA and trims','art':'Existing authorized channel painted identity and room plates; original local new prop/scene choreography','music_and_Foley':'Original locally synthesized score and contacts; no downloaded recording','font':'Archivo Black, OFL notice retained in fonts/','renderer':'Remotion 4.0.546 compositor plus project-local Python articulated painted actor pass; dependencies retain their own licenses','YouTube_upload':False}
 (B/'rights.json').write_text(json.dumps(rights,indent=2))
 files=[]
 for p in B.iterdir():
  if p.is_file() and (p.suffix in ['.py','.json','.md','.txt','.wav','.mp4'] or p.name=='LICENSE'):files.append(p)
 for folder in ['src','characters','fonts','art','public']:
  files.extend(p for p in (B/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not (folder=='public' and 'actors' in p.parts))
 files.extend(O/n for n in ['QA.json','motion-checks.json','motion-trace.json','sound-events.json','captions-en.srt'])
 with zipfile.ZipFile(O/'source-project.zip','w',zipfile.ZIP_DEFLATED,6) as z:
  for p in files:z.write(p,p.relative_to(B))
 with zipfile.ZipFile(O/'source-project.zip') as z:assert z.testzip() is None
 assert (O/'source-project.zip').stat().st_size<95*1024**2
 DEST.mkdir(parents=True,exist_ok=True)
 for n in ['agile-motion-15s.mp4','previous-vs-new-15s.mp4','QA.json','motion-checks.json','captions-en.srt','decoded-motion-board.jpg','source-project.zip']:
  shutil.copy2(O/n,DEST/n)
 for n in ['README.md','repair-notes.md','rights.json','voice-reuse.json']:shutil.copy2(B/n,DEST/n)
 manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in DEST.iterdir() if p.is_file() and p.name!='manifest.json'}
 (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({'delivery':str(DEST),'source_MiB':round((O/'source-project.zip').stat().st_size/1024**2,2),'files':len(manifest),'duration':q['duration_seconds'],'API_calls':0},indent=2),flush=True)
if __name__=='__main__':main()
