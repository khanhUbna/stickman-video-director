"""Original scene props, saved-voice excerpt, single-line captions and local sound."""
from pathlib import Path
import json,subprocess,wave,math,hashlib
import numpy as np
from PIL import Image,ImageDraw
from performance import shirt,STEPS
from rig import line,poly
from caption_renderer import CaptionRenderer,default_profile
B=Path(__file__).parent;P=B/'public';SR=48000;N=15*SR
def write(p,x):
 with wave.open(str(p),'wb') as w:w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(x,-.999,.999)*32767).astype('<i2').tobytes())
def add(bus,t,x,gain=1):
 a=round(t*SR);n=min(len(x),len(bus)-a)
 if n>0:bus[a:a+n]+=x[:n]*gain
def main():
 # Foreground furnishings are separate from the painted backdrop and actor pass.
 im=Image.new('RGBA',(2560,720));g=ImageDraw.Draw(im);dx=-58
 def p(points):return [(x+dx,y) for x,y in points]
 g.ellipse((300,550,1100,698),fill='#a2a28c',outline='#7b8677',width=3)
 g.ellipse((320,558,1080,690),outline='#c2bda2',width=2)
 poly(g,p([(488,460),(493,365),(522,344),(823,347),(852,372),(857,502),(488,502)]),'#bb856e','#78594a',4)
 for x in [515,675]:g.rounded_rectangle((x+dx,365,x+dx+144,467),20,fill='#c7937b',outline='#a77660',width=3)
 g.rounded_rectangle((487+dx,458,857+dx,503),16,fill='#d5aa8e',outline='#78594a',width=4)
 for x in [468,838]:g.rounded_rectangle((x+dx,420,x+dx+40,520),15,fill='#b78168',outline='#78594a',width=4)
 for x in [507,812]:line(g,[(x+dx,504),(x+dx,548)],'#705645',7)
 # Large, readable actual laundry pile; a destination with a visible consequence.
 for j,(x,y,a,s) in enumerate([(1840,507,-14,1.1),(1950,487,9,1.1),(1770,463,-8,1.0),(1860,433,14,1.1),(1970,404,-11,1.0),(1810,376,8,1.1),(1890,337,-8,1.0),(1790,299,12,.95),(1890,263,-15,1.1),(1840,219,9,.95)]):
  shirt(im,[x,y],s,a,['#b7c7b5','#d3b4a6','#ddd1b6','#9a99b3'][j%4])
 g=ImageDraw.Draw(im);poly(g,[(1695,480),(2055,480),(2015,590),(1735,590)],'#b89460','#71563c',5)
 for y in [499,518,537,556,575]:line(g,[(1703+(y-480)*.35,y),(2048-(y-480)*.35,y)],'#e0bb80',4)
 for x in range(1735,2030,26):line(g,[(x,486),(x-12 if x>1880 else x+12,584)],'#8d6c46',3)
 g.ellipse((1684,466,2067,494),fill='#c7a36a',outline='#71563c',width=5)
 # A few loose garments visibly overlap the rim, tying the pile to its container.
 shirt(im,[1840,469],1.05,-10,'#d4c3a6');shirt(im,[1940,480],.87,13,'#a7b9b0')
 im.save(P/'furniture.png')
 lay=Image.new('RGBA',(2560,720));dg=ImageDraw.Draw(lay);dg.rectangle((1243,0,1270,590),fill='#815e42');dg.rectangle((1237,0,1246,590),fill='#bd986c');dg.rectangle((1237,0,1280,28),fill='#9a7650');lay.save(P/'door-foreground.png')
 floor=Image.new('RGBA',(180,140));shirt(floor,[90,72],.55);floor.save(P/'floor-shirt.png')
 profile=default_profile('16:9',1280,720,'archivo-black');profile.update(font_size=39,stroke=3,side=64,baseline=677,band=[624,708],native_layout_reason='Native 1280x720 action stage; authored camera keeps feet and contacts above caption band.')
 cr=CaptionRenderer(B,'16:9',1280,720,profile);caps=[]
 for old in json.loads((B/'source-captions.json').read_text()):
  if old['beat'] not in ['01-02','01-03','01-04']:continue
  c={**old,'start':old['start']-5.82,'end':old['end']-5.82};idx=len(caps);c['image']=f'caption-{idx}.png';cr.raster(c['text'])[0].save(P/c['image']);caps.append(c)
 (P/'captions.json').write_text(json.dumps(caps,indent=2));(B/'caption-profile.json').write_text(json.dumps(profile,indent=2))
 def stamp(t):
  k=round(t*1000);return f'{k//3600000:02}:{k//60000%60:02}:{k//1000%60:02},{k%1000:03}'
 (B/'output/captions-en.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(caps))+'\n')
 # Old film offset is .2s. Movie time 5.82 corresponds to native WAV time 5.62.
 subprocess.run(['ffmpeg','-v','error','-y','-ss','5.62','-i',str(B/'source-voice.wav'),'-t','14.02','-ar',str(SR),'-ac','1',str(B/'output/voice-excerpt.wav')],check=True)
 with wave.open(str(B/'output/voice-excerpt.wav')) as w:src=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
 voice=np.zeros(N,np.float32);voice[:len(src)]=src;write(P/'voice-only.wav',voice)
 music=np.zeros(N,np.float32);fx=np.zeros(N,np.float32);rng=np.random.default_rng(151124);events=[]
 def pluck(f,d=.6):
  t=np.arange(round(d*SR),dtype=np.float32)/SR;return (np.sin(2*np.pi*f*t)+.15*np.sin(4*np.pi*f*t))*np.exp(-t*8)*np.minimum(1,t/.005)
 for i,t in enumerate(np.arange(.02,14.4,60/106/2)):
  if t>9.3 and i%4:continue
  m=[57,64,60,64,53,60,57,60][i%8];add(music,t,pluck(440*2**((m-69)/12)),.014)
 for side,a,b,_ in STEPS:
  tt=np.arange(round(.12*SR),dtype=np.float32)/SR;n=rng.normal(0,1,len(tt)).astype(np.float32);n=np.convolve(n,np.ones(7,dtype=np.float32)/7,'same')
  sig=(.5*n+.4*np.sin(2*np.pi*92*tt))*np.exp(-tt*40)*np.minimum(1,tt/.002)
  add(fx,b,sig,.085);events.append({'time':b,'kind':'foot_contact','side':side,'source':'Actual authored swing-end time'})
 for t,kind in [(.43,'sofa-contact'),(3.89,'shirt-grip'),(4.08,'shirt-lift')]:
  tt=np.arange(round(.24*SR),dtype=np.float32)/SR;n=rng.normal(0,1,len(tt)).astype(np.float32);n=np.convolve(n,np.ones(5,dtype=np.float32)/5,'same');add(fx,t,n*np.sin(np.pi*tt/.24)**2,.027);events.append({'time':t,'kind':kind,'source':'Original filtered-noise synthesis'})
 add(fx,9.53,pluck(146.83,.45),.065);events.append({'time':9.53,'kind':'pile-reveal','source':'Original short tonal reaction accent'})
 fade=np.minimum(1,(N-1-np.arange(N))/(SR*.50)).astype(np.float32);mix=(voice*.97+music+fx)*fade
 peak=float(np.abs(mix).max());mix*=min(1,.96/max(peak,1e-9));write(B/'output/mix-unmastered.wav',mix)
 r=subprocess.run(['ffmpeg','-hide_banner','-nostats','-i',str(B/'output/mix-unmastered.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'],check=True,capture_output=True)
 import re
 measured=json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1]);flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={measured[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/'output/mix-unmastered.wav'),'-af',flt,'-ar','48000','-ac','2',str(P/'soundtrack.wav')],check=True)
 (B/'output/sound-events.json').write_text(json.dumps(events,indent=2));(B/'voice-reuse.json').write_text(json.dumps({'source':'Previously accepted rest-guilt-long-v1 chapter-01 native alloy WAV','source_sha256':hashlib.sha256((B/'source-voice.wav').read_bytes()).hexdigest(),'native_trim_start_seconds':5.62,'native_trim_duration_seconds':14.02,'new_TTS_calls':0,'speed':1,'pitch_change':False,'paid_image_calls':0},indent=2))
 print('Foreground, native-rate reused voice, complete captions and original contact sound ready.',flush=True)
if __name__=='__main__':main()
