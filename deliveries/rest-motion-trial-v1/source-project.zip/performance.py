"""New 15s choreography. Explicit time-coded actions, not paragraph-length easing."""
from pathlib import Path
import json,math
import numpy as np
from PIL import Image,ImageDraw
import rig
from rig import ease,mix,rotate,actor,line,poly
B=Path(__file__).resolve().parent;FPS=30;D=15.;X=320.
def on(t,a,b):return ease((t-a)/(b-a))
def shirt(im,c,scale=.55,angle=0,color='#9a99b3'):
 tile=Image.new('RGBA',(150,108));g=ImageDraw.Draw(tile)
 poly(g,[(25,12),(6,19),(18,45),(35,67),(52,55),(51,98),(112,98),(110,55),(128,65),(143,44),(111,19),(99,12)],color,'#51556b',3)
 g.arc((59,4,94,34),0,180,fill='#51556b',width=3)
 rr,p=rig.transformed(tile,c,[75,54],scale,angle);im.alpha_composite(rr,p)

# Each foot owns a real ground contact. Swing moves only that foot and ends
# at its next fixed world-space contact; neither camera nor body owns stance.
STEPS=[
 ('left',1.78,2.05,655),('right',2.05,2.32,735),('left',2.32,2.59,815),('right',2.59,2.86,940),('left',2.86,3.13,870),
 ('right',6.70,7.05,1040),('left',7.05,7.40,1120),('right',7.40,7.75,1200),('left',7.75,8.10,1280),('right',8.10,8.45,1360),('left',8.45,8.80,1440),('right',8.80,9.15,1490),
 ('left',10.12,10.42,1385),('right',10.42,10.72,1435)]
def foot(side,t):
 x=525. if side=='left' else 578.
 for owner,a,b,end in STEPS:
  if owner!=side:continue
  if t>=b:x=end
  elif t>=a:
   u=(t-a)/(b-a);return np.array([x+(end-x)*ease(u),590-24*math.sin(math.pi*u)]),False
  else:break
 return np.array([x,590.]),True
def world_x(t):
 return 550+360*on(t,1.75,3.23)+540*on(t,6.65,9.30)-40*on(t,10.10,10.78)
def supporting_y(feet,view='front'):
 limits=[]
 for side,f in feet.items():
  root=X+rig.PACKS['hero']['views'][view]['legs'][side]['hip'][0]*rig.S
  dx=f[0]-root;reach=174.
  if abs(dx)>=reach:raise ValueError(('Unreachable leg staging',side,dx))
  limits.append(f[1]-math.sqrt(reach*reach-dx*dx))
 return max(limits)
def rest(hip,side,angle):return hip+rotate([-68 if side=='left' else 72,-6],angle)

def pose(t):
 wx=world_x(t);feetworld={};planted={}
 for side in ['left','right']:
  feetworld[side],planted[side]=foot(side,t)
 feet={s:f-[wx-X,0] for s,f in feetworld.items()}
 view='three_quarter' if 1.70<=t<3.25 or 6.65<=t<9.50 else 'front'
 support=supporting_y(feet,view)
 hip=np.array([X,max(418.,support)]);angle=0.;head=0.;expression='worried';wr={};held={};pd=None
 state='settle';walking=1.75<=t<3.23 or 6.65<=t<9.30
 if t<1.70:
  sit=on(t,.02,.43);rise=on(t,.98,1.53);seat=sit*(1-rise)
  hip=np.array([X-40*seat,418+62*seat]);angle=7*math.sin(math.pi*on(t,.98,1.53));head=-3-8*on(t,.55,.80)
  wr={'left':mix([X-70,412],[X-105,462],seat),'right':mix([X+72,412],[X+62,459],seat)}
  expression='relieved' if t<.62 else 'worried';state='sit' if t<.55 else 'notice' if t<.98 else 'rise'
 elif walking:
  state='walk_to_shirt' if t<4 else 'carry_to_laundry';angle=7*(on(t,1.75,1.95)*(1-on(t,3.00,3.23)) if t<4 else on(t,6.65,6.95)*(1-on(t,9.02,9.30)))
  swing=math.sin((t-(1.78 if t<4 else 6.70))*math.pi/(.27 if t<4 else .35))
  for side in ['left','right']:
   spec=rig.PACKS['hero']['views'][view]['arms'][side];root=hip+[0,6]+rotate((np.array(spec['socket'])+[0,92])*rig.S,angle)
   phase=swing if side=='right' else -swing
   wr[side]=root+rotate([(-13 if side=='left' else 13)+24*phase,112+5*math.cos(t*8)],angle)
  head=-3;expression='normal'
 elif 3.25<=t<4.70:
  bend=on(t,3.30,3.83)*(1-on(t,4.02,4.62));hip[1]+=100*bend;angle=-35*bend;head=5*bend;state='pickup'
  wr={s:rest(hip,s,angle) for s in ['left','right']}
 else:
  wr={s:rest(hip,s,angle) for s in ['left','right']}
  expression='normal' if t<9.50 else 'worried';state='one_shirt' if t<6.65 else 'basket_reaction'
  if t>=9.50:
   recoil=math.sin(math.pi*on(t,9.50,10.15));angle=-8*recoil;head=5*recoil-6*on(t,10.60,11.10)
   # The spare hand reacts; the other hand keeps supporting the same shirt.
   wr['right']=mix(rest(hip,'right',angle),hip+[100,-92],on(t,9.55,9.83)*(1-on(t,11.05,11.40)))
   wr['left']=rest(hip,'left',angle)
 if t>=3.25:
  # Garment center changes only after actual acquisition; hand shares the grip.
  lift=on(t,4.02,4.62);center=mix([851-wx+X,578],[X-60,390],lift)
  if walking and t>6:
   center=hip+[-60,-28+3*math.sin(t*5)]
  elif t>=4.70:center=hip+[-60,-28]
  grip=center+[0,-13];acquire=on(t,3.67,3.89)
  wr['left']=mix(wr.get('left',rest(hip,'left',angle)),grip,acquire)
  if t>=3.89:
   pd=lambda m,c=center:shirt(m,c,.55)
   held={'shirt_grip':{'arm':'left','point':grip}}
 im=Image.new('RGBA',(640,720))
 row=actor(im,hip,view=view,angle=angle,head_angle=head,expression=expression,feet=feet,wrists=wr,prop_draw=pd,held=held)
 for side in ['left','right']:row['legs'][side]['planted']=planted[side]
 row.update(time=t,state=state,world_x=wx,world_offset=wx-X,world_hip=(np.asarray(row['hip'])+[wx-X,0]).tolist())
 return im,row

def camera(t):
 if t<1.70:return {'x':110,'y':18,'z':1.10,'cut':'sit-notice'}
 if t<3.25:return {'x':110+95*on(t,1.70,3.15),'y':0,'z':1.04,'cut':'travel'}
 if t<4.70:return {'x':345,'y':70,'z':1.18,'cut':'contact'}
 if t<6.65:return {'x':375,'y':80,'z':1.20,'cut':'one-shirt'}
 if t<9.50:return {'x':205+825*on(t,6.90,9.45),'y':0,'z':1.04,'cut':'room-travel'}
 if t<10.15:return {'x':1030,'y':0,'z':1.04,'cut':'reveal'}
 return {'x':1110,'y':75,'z':1.20,'cut':'reaction'}

def build():
 (B/'public/actors').mkdir(parents=True,exist_ok=True)
 rows=[];frames=[]
 for i in range(round(D*FPS)):
  t=i/FPS;im,r=pose(t);im.save(B/f'public/actors/{i:04}.png');rows.append(r)
  frames.append({'x':r['world_x'],'camera':camera(t),'floorShirt':t<3.89,'state':r['state']})
  if i%90==0:print('Authored actor pose',i,flush=True)
 # Every consecutive planted foot is measured in world, not screen coordinates.
 drift=[]
 for a,b in zip(rows,rows[1:]):
  for side in ['left','right']:
   if a['legs'][side]['planted'] and b['legs'][side]['planted']:
    aa=np.asarray(a['legs'][side]['joints'][-1])+[a['world_offset'],0];bb=np.asarray(b['legs'][side]['joints'][-1])+[b['world_offset'],0];drift.append(float(np.linalg.norm(aa-bb)))
 assert max(drift)<1e-7,max(drift)
 (B/'public/performance.json').write_text(json.dumps(frames))
 (B/'output/motion-trace.json').write_text(json.dumps(rows))
 (B/'output/motion-checks.json').write_text(json.dumps({'frames':len(rows),'maximum_bone_error':max(r['bone_error'] for r in rows),'maximum_world_stance_drift':max(drift),'maximum_shirt_grip_error':max((e for r in rows for e in r['contacts'].values()),default=0),'sit_seconds':.41,'rise_seconds':.55,'pickup_bend_seconds':.53,'pickup_rise_seconds':.60,'footsteps':len(STEPS),'new_API_calls':0,'voice_time_stretch':False},indent=2))
 print('All 450 newly authored poses, world contacts and held shirt checked.',flush=True)
if __name__=='__main__':build()
