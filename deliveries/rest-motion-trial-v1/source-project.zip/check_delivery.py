"""Final decoded artifact checks and matched-narration comparison."""
from pathlib import Path
import subprocess,json,re,hashlib,wave
import numpy as np
from PIL import Image,ImageDraw
B=Path(__file__).parent;O=B/'output';M=O/'agile-motion-15s.mp4'
def run(a):return subprocess.run(a,check=True,capture_output=True)
def main():
 p=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(M)]).stdout)
 v=next(x for x in p['streams'] if x['codec_type']=='video');a=next(x for x in p['streams'] if x['codec_type']=='audio')
 assert int(v['nb_frames'])==450 and [v['width'],v['height']]==[1280,720]
 assert abs(float(v['duration'])-float(a['duration']))<.08
 run(['ffmpeg','-v','error','-i',str(M),'-f','null','-'])
 board=Image.new('RGB',(1280,820),'#f1e7cf');g=ImageDraw.Draw(board)
 times=[.15,.48,.80,1.35,2.15,2.85,3.55,3.93,4.58,5.65,7.55,8.85,9.70,10.40,11.20,14.20]
 for i,t in enumerate(times):
  r=run(['ffmpeg','-v','error','-ss',str(t),'-i',str(M),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-']);im=Image.fromarray(np.frombuffer(r.stdout,np.uint8).reshape(720,1280,3));im.save(O/f'decoded-{i:02}.jpg',quality=93);im.thumbnail((320,180));x=i%4*320;y=i//4*205;board.paste(im,(x,y));g.text((x+6,y+184),f'{t:.2f}s',fill='#233439')
 board.save(O/'decoded-motion-board.jpg',quality=94)
 raw=run(['ffmpeg','-v','error','-i',str(M),'-vn','-ar','48000','-ac','1','-f','f32le','-']);encoded=np.frombuffer(raw.stdout,'<f4')
 with wave.open(str(B/'public/voice-only.wav')) as w:voice=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
 n=min(len(voice),len(encoded));corr=float(np.corrcoef(voice[:n],encoded[:n])[0,1]);assert corr>.8,corr
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(M),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']);loud=json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1]);assert float(loud['input_tp'])<-.5
 # Comparator uses the same original narration range, not a speed-adjusted original.
 old=B/'reference-previous.mp4';seek='0'
 if not old.exists():old=Path('/workspace/scratch/rest-guilt-long-v1/output/why-you-feel-guilty-when-you-rest.mp4');seek='5.82'
 font=B/'fonts/ArchivoBlack.ttf'
 filt=f"[0:v]trim=duration=14.02,setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration=0.98,scale=640:360[old];[1:v]scale=640:360[new];[old][new]hstack=inputs=2,pad=1280:420:0:60:color=0x14252a,drawtext=fontfile={font}:text='PREVIOUS':fontsize=28:fontcolor=white:x=235:y=16,drawtext=fontfile={font}:text='NEW MOTION':fontsize=28:fontcolor=white:x=840:y=16[out]"
 run(['ffmpeg','-v','error','-y','-ss',seek,'-i',str(old),'-i',str(M),'-filter_complex',filt,'-map','[out]','-map','1:a:0','-t','15','-c:v','libx264','-preset','fast','-crf','20','-c:a','aac','-b:a','160k','-movflags','+faststart',str(O/'previous-vs-new-15s.mp4')])
 run(['ffmpeg','-v','error','-i',str(O/'previous-vs-new-15s.mp4'),'-f','null','-'])
 qa={'title':'Psychology Facts: faster authored motion trial','duration_seconds':float(p['format']['duration']),'dimensions':[1280,720],'frames':450,'fps':30,'full_decode':'pass','audio_video_duration_difference_seconds':abs(float(v['duration'])-float(a['duration'])),'sha256':hashlib.sha256(M.read_bytes()).hexdigest(),'compositor':'Remotion 4.0.546, system Chromium','performance':'New 450-pose physical choreography, rendered from the established articulated painted identity; not a replay of the old actions','motion':json.loads((O/'motion-checks.json').read_text()),'voice':json.loads((B/'voice-reuse.json').read_text()),'decoded_voice_correlation':corr,'loudness':loud,'decoded_review_samples':times,'comparison':'Same narration excerpt; new soundtrack only; previous picture held for final 0.98s to match the 15s trial. Neither performance nor voice is globally sped up.','review_scope':'Author source/decoded-frame and mechanical/signal checks. Independent creative review and real-time AV listening are not claimed. User trial approval is pending.','YouTube_upload':False}
 (O/'QA.json').write_text(json.dumps(qa,indent=2));print(json.dumps({'duration':qa['duration_seconds'],'frames':450,'voice_correlation':corr,'LUFS':loud['input_i'],'true_peak':loud['input_tp'],'full_decode':'pass'},indent=2))
if __name__=='__main__':main()
