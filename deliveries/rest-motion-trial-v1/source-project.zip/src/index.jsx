import React from 'react';
import {registerRoot, Composition, AbsoluteFill, Img, Audio, useCurrentFrame, staticFile} from 'remotion';
import performance from '../public/performance.json';
import captions from '../public/captions.json';

const Film = () => {
 const f=useCurrentFrame(); const t=f/30; const p=performance[f]; const c=p.camera;
 const cap=captions.find(x=>t>=x.start&&t<x.end);
 return <AbsoluteFill style={{backgroundColor:'#6b5443',overflow:'hidden'}}>
   <div style={{position:'absolute',width:2560,height:720,transformOrigin:'0 0',transform:`translate(${-c.x*c.z}px,${-c.y*c.z}px) scale(${c.z})`}}>
    <Img src={staticFile('living.png')} style={{position:'absolute',left:0,top:0,width:1280,height:720}}/>
    <Img src={staticFile('laundry.png')} style={{position:'absolute',left:1280,top:0,width:1280,height:720}}/>
    <Img src={staticFile('furniture.png')} style={{position:'absolute',left:0,top:0,width:2560,height:720}}/>
    {p.floorShirt && <Img src={staticFile('floor-shirt.png')} style={{position:'absolute',left:761,top:506,width:180,height:140}}/>}
    <Img src={staticFile(`actors/${String(f).padStart(4,'0')}.png`)} style={{position:'absolute',left:p.x-320,top:0,width:640,height:720}}/>
    <Img src={staticFile('door-foreground.png')} style={{position:'absolute',left:0,top:0,width:2560,height:720}}/>
   </div>
   {cap && <Img src={staticFile(cap.image)} style={{position:'absolute',inset:0,width:1280,height:720}}/>}
   <Audio src={staticFile('soundtrack.wav')}/>
 </AbsoluteFill>;
};
const Root=()=> <Composition id="Agile15" component={Film} durationInFrames={450} fps={30} width={1280} height={720}/>;
registerRoot(Root);
