import os,json,urllib.request,urllib.error,pathlib,concurrent.futures,wave,sys,hashlib,subprocess
P=pathlib.Path(__file__).parent;manifest=json.loads((P/'audio-manifest.json').read_text());KEY=os.environ['OPENAI_API_KEY'];prior=.042296
estimated=prior+sum(x['chars'] for x in manifest if not x['reused'])*15/1e6+12*.006
assert estimated<.50

def post(url,data,kind,ledger):
 req=urllib.request.Request('https://api.openai.com'+url,data=data,headers={'Authorization':'Bearer '+KEY,'Content-Type':kind})
 try:
  with urllib.request.urlopen(req,timeout=150) as r:return r.read()
 except urllib.error.HTTPError as e:
  ledger['state']='HTTP_error';ledger['http_status']=e.code;raise RuntimeError('OpenAI HTTP '+str(e.code)) from None
 except Exception as e:
  ledger['state']='ambiguous_network_failure_do_not_retry';raise RuntimeError(type(e).__name__) from None

def chunk(row):
 i=row['chunk'];stem=f'{i:02}';wav=P/'audio'/f'{stem}.wav';alignment=P/'audio'/f'{stem}-alignment.json';receipt=P/'audio'/f'{stem}-receipt.json';ledger=json.loads(receipt.read_text()) if receipt.exists() else {'chunk':i,'tts_model':'tts-1','voice':'alloy','characters':row['chars'],'speech_estimate_usd':0 if row['reused'] else row['chars']*15/1e6,'automatic_retries':False}
 if row['reused']:ledger['state']='reused_existing_opening'
 if not wav.exists():
  if 'state' in ledger and ledger['state'] not in ['not_started']:raise RuntimeError('Uncertain previous request; inspect before retrying chunk '+stem)
  ledger['state']='speech_request_in_flight';receipt.write_text(json.dumps(ledger,indent=2))
  try:data=post('/v1/audio/speech',json.dumps({'model':'tts-1','voice':'alloy','input':row['text'],'response_format':'wav','speed':1}).encode(),'application/json',ledger)
  except Exception:
   receipt.write_text(json.dumps(ledger,indent=2));raise
  wav.write_bytes(data);ledger['state']='speech_saved';receipt.write_text(json.dumps(ledger,indent=2));print('Speech saved',stem,flush=True)
 duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(wav)],text=True))
 ledger['duration']=duration;ledger['voice_sha256']=hashlib.sha256(wav.read_bytes()).hexdigest()
 if not alignment.exists():
  if ledger.get('alignment_state') in ['in_flight','ambiguous_network_failure_do_not_retry']:raise RuntimeError('Uncertain alignment request '+stem)
  boundary='fullFilmAudioBoundary';parts=[]
  for name,value in [('model','whisper-1'),('response_format','verbose_json'),('language','en'),('timestamp_granularities[]','word'),('prompt',row['text'][-1100:])]:parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+name+'"\r\n\r\n'+value+'\r\n').encode())
  parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="file"; filename="chapter.wav"\r\nContent-Type: audio/wav\r\n\r\n').encode()+wav.read_bytes()+b'\r\n');parts.append(('--'+boundary+'--\r\n').encode())
  ledger['alignment_state']='in_flight';receipt.write_text(json.dumps(ledger,indent=2))
  try:data=post('/v1/audio/transcriptions',b''.join(parts),'multipart/form-data; boundary='+boundary,ledger)
  except Exception:
   ledger['alignment_state']='ambiguous_network_failure_do_not_retry';receipt.write_text(json.dumps(ledger,indent=2));raise
  alignment.write_bytes(data);ledger['alignment_state']='saved';print('Alignment saved',stem,flush=True)
 ledger['alignment_estimate_usd']=0 if row['reused'] else duration/60*.006;ledger['state']='complete';receipt.write_text(json.dumps(ledger,indent=2));return {'chunk':i,'duration':duration,'estimated_usd':ledger['speech_estimate_usd']+ledger['alignment_estimate_usd']}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 rows=list(ex.map(chunk,manifest))
(P/'audio-generation-summary.json').write_text(json.dumps({'chunks':rows,'new_estimate_usd':sum(r['estimated_usd'] for r in rows),'prior_previews_estimate_usd':prior,'project_budget_usd':.50,'no_automatic_retries':True},indent=2));print('Finished',json.dumps(rows),flush=True)
