#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/task-avoidance-full
ffmpeg -v error -y -i output/film.mp4 -map 0:v:0 -map 0:a:0 -c:v copy -af loudnorm=I=-16:TP=-1.5:LRA=11,afade=t=out:st=508.65749999999986:d=0.8091666666667834 -ar 48000 -c:a aac -b:a 192k -movflags +faststart why-you-avoid-the-work-that-matters-most.mp4
ffmpeg -v error -i why-you-avoid-the-work-that-matters-most.mp4 -f null -
