from pathlib import Path
import urllib.request,json,os,concurrent.futures
p=Path(__file__).parent

def run(i):
 dest=p/'audio'/f'{i:02}-alignment-recheck.json'
 if dest.exists():return i,'cached'
 boundary='alignmentRecheckBoundary';parts=[]
 for name,value in [('model','whisper-1'),('response_format','verbose_json'),('language','en'),('timestamp_granularities[]','word')]:parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+name+'"\r\n\r\n'+value+'\r\n').encode())
 parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="file"; filename="chapter.wav"\r\nContent-Type: audio/wav\r\n\r\n').encode()+(p/'audio'/f'{i:02}.wav').read_bytes()+b'\r\n');parts.append(('--'+boundary+'--\r\n').encode())
 r=urllib.request.Request('https://api.openai.com/v1/audio/transcriptions',data=b''.join(parts),headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'multipart/form-data; boundary='+boundary})
 with urllib.request.urlopen(r,timeout=120) as x:dest.write_bytes(x.read())
 return i,json.loads(dest.read_text()).get('text')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:
 for r in e.map(run,[1,2,3]):print(r,flush=True)
