import fs from 'node:fs';import {keyState} from '/workspace/stickman-video-director/skills/directing-stickman-videos/scripts/autopilot-render.mjs';
const B='/workspace/scratch/task-avoidance-full',p=JSON.parse(fs.readFileSync(B+'/project.json'));let maxJoint=0,maxHand=0,maxLength=0,samples=0;
function ends(l,t){const v=keyState(l,t),a=v.angle||0,w=v.w;const root=[v.x-Math.sin(a)*w/32,v.y+Math.cos(a)*w/32];return {root,tip:[root[0]+w*Math.cos(a),root[1]+w*Math.sin(a)],length:w};}
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
for(let i=0;i<p.shots.length;i++){const s=p.shots[i];const roots=s.layers.filter(l=>l.id?.endsWith('-upperL')).map(l=>l.id.slice(0,-7));for(const root of roots){const find=n=>s.layers.find(l=>l.id===root+'-'+n);if(!find('foreL')||!find('handL'))throw Error('Incomplete rig '+root);for(let t=0;t<s.end-s.start;t+=1/p.fps){samples++;
 for(const [a,b] of [['upperL','foreL'],['upperR','foreR'],['thighL','shinL'],['thighR','shinR']])maxJoint=Math.max(maxJoint,dist(ends(find(a),t).tip,ends(find(b),t).root));
 for(const [a,b] of [['foreL','handL'],['foreR','handR']]){const h=keyState(find(b),t);maxHand=Math.max(maxHand,dist(ends(find(a),t).tip,[h.x+h.w/2,h.y+h.w*11/26]));}
 for(const n of ['upperL','foreL','upperR','foreR','thighL','shinL','thighR','shinR']){const l=find(n);const expected=l.keys[0].w;maxLength=Math.max(maxLength,Math.abs(ends(l,t).length-expected));}
 }}}
const report={samples,max_elbow_knee_gap_design_px:maxJoint,max_hand_gap_design_px:maxHand,max_bone_length_error_design_px:maxLength,pass:maxJoint<2&&maxHand<2&&maxLength<1e-6,limits:'Geometry only; does not establish natural gait, acting quality, final occlusion, sound or independent acceptance.'};fs.writeFileSync(B+'/rig-QA.json',JSON.stringify(report,null,2));console.log(report);if(!report.pass)process.exit(1);
