import fs from 'node:fs';import {createRequire} from 'node:module';import {execFileSync} from 'node:child_process';
const req=createRequire('/workspace/stickman-video-director/skills/directing-stickman-videos/package.json');const {createCanvas,GlobalFonts}=req('@napi-rs/canvas');
const B='/workspace/scratch/task-avoidance-full';fs.mkdirSync(B+'/art',{recursive:true});
if(fs.existsSync('/workspace/scratch/task-avoidance-color/art'))for(const f of fs.readdirSync('/workspace/scratch/task-avoidance-color/art'))if(f.endsWith('.png'))fs.copyFileSync('/workspace/scratch/task-avoidance-color/art/'+f,B+'/art/'+f);
const C={ink:'#24353c',gold:'#edbc3b',green:'#4d9d88',red:'#dc7c68',blue:'#719db0',paper:'#fdfdfc'};
GlobalFonts.registerFromPath('/workspace/stickman-video-director/skills/directing-stickman-videos/assets/fonts/Caveat.ttf','Hand');
function asset(n,w,h,f){let c=createCanvas(w,h),g=c.getContext('2d');g.lineWidth=3;g.strokeStyle=C.ink;g.fillStyle=C.ink;g.lineCap='round';g.lineJoin='round';f(g);fs.writeFileSync(`${B}/art/${n}.png`,c.toBuffer('image/png'));}
function line(g,a,col=C.ink,width=3){g.beginPath();g.lineWidth=width;g.strokeStyle=col;g.moveTo(...a[0]);for(const p of a.slice(1))g.lineTo(...p);g.stroke();g.lineWidth=3;g.strokeStyle=C.ink;}
function rect(g,x,y,w,h,fill=C.paper,r=6){g.beginPath();g.roundRect(x,y,w,h,r);g.fillStyle=fill;g.fill();g.stroke();}
function oval(g,x,y,rx,ry,fill=C.paper){g.beginPath();g.ellipse(x,y,rx,ry,0,0,2*Math.PI);g.fillStyle=fill;g.fill();g.stroke();}
function txt(g,s,x,y,size=30,color=C.ink){g.font=`${size}px Hand`;g.fillStyle=color;g.fillText(s,x,y);}
for(const [name,happy] of [['head-profile-worry',false],['head-profile-focused',true]])asset(name,150,150,g=>{oval(g,78,70,49,52);line(g,[[59,20],[48,8],[35,9]],C.ink,3);line(g,[[31,69],[18,80],[31,85]],C.ink,3);oval(g,47,65,3,6,C.ink);line(g,[[39,49],[56,happy?49:44]],C.ink,3);g.beginPath();g.moveTo(36,98);g.quadraticCurveTo(49,happy?109:87,64,96);g.stroke();});
asset('bone',128,8,g=>line(g,[[0,4],[128,4]],C.ink,3.4));
asset('hand',26,22,g=>oval(g,13,11,9,7));asset('shoe',46,18,g=>oval(g,23,9,21,6,'#d8e6e8'));
asset('chair',170,280,g=>{rect(g,63,20,83,135,'#dce9e8',18);rect(g,15,152,135,18,C.green,8);line(g,[[92,171],[92,249]]);line(g,[[92,249],[28,272]]);line(g,[[92,249],[151,272]]);oval(g,26,273,10,5);oval(g,153,273,10,5);});
asset('desk-stage',800,420,g=>{rect(g,50,10,300,145,'#e7eff0',3);line(g,[[200,10],[200,155]],'#b1c8c8',2);line(g,[[50,90],[350,90]],'#b1c8c8',2);for(let i=0;i<5;i++){g.fillStyle=i%2?'#bed1d2':'#d5e0db';g.fillRect(70+i*52,94-i*7,33,59+i*7);}rect(g,0,250,740,20,'#e8c291',3);line(g,[[36,270],[29,405]]);line(g,[[697,270],[705,405]]);rect(g,263,102,240,140,C.ink,5);rect(g,273,112,220,119,'#f3f5ef',1);txt(g,'PORTFOLIO',298,162,35);line(g,[[292,185],[451,185]],'#c3d0c9',3);rect(g,222,241,320,9,'#bccacc',3);rect(g,40,194,61,53,C.green,4);line(g,[[70,194],[44,149]],C.green,6);line(g,[[70,190],[95,142]],C.green,6);rect(g,566,214,109,32,C.gold,3);txt(g,'NEXT STEP',575,238,23);});
asset('kitchen-stage',800,420,g=>{rect(g,35,40,440,183,'#e3eee8',2);for(let x=35;x<475;x+=66)line(g,[[x,41],[x,223]],'#c3d6cb',1.4);for(let y=78;y<223;y+=45)line(g,[[35,y],[474,y]],'#c3d6cb',1.4);rect(g,0,250,740,21,'#e4ba80',3);rect(g,25,272,685,140,'#f3e5ce',2);for(let x=25;x<710;x+=228){line(g,[[x,273],[x,410]]);line(g,[[x+162,293],[x+188,293]],C.ink,4);}oval(g,358,248,105,13,'#d5e4e6');line(g,[[444,230],[444,174],[484,174],[484,207]],C.blue,5);rect(g,525,172,38,73,C.green,4);txt(g,'soap',528,213,19);rect(g,47,166,116,78,C.gold,5);txt(g,'UNOPENED',56,211,24);oval(g,225,238,38,10);});
asset('phone-large',200,350,g=>{rect(g,16,8,166,330,C.ink,20);rect(g,26,35,146,260,'#f2f5ef',3);line(g,[[75,22],[125,22]],'#e6ece6',3);oval(g,100,316,10,10,'#e7ede7');});
for(const mode of ['message','weather','apps'])asset('screen-'+mode,140,250,g=>{rect(g,1,1,137,247,mode==='weather'?'#e0edf0':'#eef3eb',1);if(mode==='message'){rect(g,8,20,122,31,C.green,3);txt(g,'MESSAGES',18,42,21,'#fff');rect(g,10,73,110,60,'#d6e6d9',4);txt(g,'Quick reply?',16,109,22);rect(g,22,151,107,45,'#f4e6b2',4);txt(g,'On it!',42,181,25);}if(mode==='weather'){txt(g,'TOMORROW',12,38,23);oval(g,70,102,26,26,C.gold);for(let i=0;i<8;i++){let a=i*Math.PI/4;line(g,[[70+34*Math.cos(a),102+34*Math.sin(a)],[70+42*Math.cos(a),102+42*Math.sin(a)]],C.gold,3);}txt(g,'Looks fine.',22,179,25);}if(mode==='apps'){txt(g,'BETTER APPS',12,33,24);for(let i=0;i<3;i++){rect(g,10,55+i*58,120,45,i%2?'#f5e2af':'#d0e5dc',4);txt(g,['Plan More','New Notes','Focus Now'][i],19,85+i*58,22);}}});
asset('cloth',85,42,g=>{rect(g,5,5,72,28,C.gold,4);line(g,[[16,14],[66,23]],'#c09b39',2);});
asset('paper',300,330,g=>{rect(g,18,13,265,300,'#fff8df',3);rect(g,34,35,233,45,C.gold,2);txt(g,'PROJECT ONE',55,67,32);for(let i=0;i<6;i++)line(g,[[40,112+i*28],[245-(i%2)*40,112+i*28]],'#d4cdb5',2);});
asset('rough-paper',300,330,g=>{rect(g,18,13,265,300,'#fff8df',3);txt(g,'A rough start…',43,65,33);line(g,[[40,104],[218,101],[237,110],[187,115]],C.ink,2);line(g,[[41,143],[237,149]],C.ink,2);line(g,[[40,181],[202,177]],C.ink,2);txt(g,'not perfect. still progress.',35,268,24,C.green);});
for(const rough of [false,true])asset(rough?'paper-work-rough':'paper-work',300,100,g=>{g.beginPath();g.moveTo(16,27);g.lineTo(228,9);g.lineTo(283,73);g.lineTo(56,94);g.closePath();g.fillStyle='#fff4d4';g.fill();g.stroke();for(let i=0;i<(rough?3:1);i++)line(g,[[66,43+i*13],[216-(i%2)*35,33+i*13]],i===0?C.green:C.ink,2);});
asset('note-next',260,180,g=>{rect(g,10,10,239,159,'#f9dd80',4);txt(g,'NEXT:',32,52,32);txt(g,'add one result',32,96,29);txt(g,'choose one image',32,133,27);});
asset('shelf-room',700,400,g=>{rect(g,30,35,160,300,'#e1ece9',3);rect(g,43,49,134,270,'#f2f4ec',2);oval(g,154,198,5,5,C.gold);rect(g,282,235,380,20,'#e5bb80',3);line(g,[[314,255],[314,375]]);line(g,[[633,255],[633,375]]);rect(g,544,175,54,56,C.green,5);line(g,[[568,175],[548,139]],C.green,5);line(g,[[569,173],[593,132]],C.green,5);txt(g,'OTHER ROOM',295,50,34,C.blue);});
asset('clock-face',300,300,g=>{oval(g,150,150,130,130,'#edf2eb');for(let i=0;i<12;i++){let a=i*Math.PI/6;line(g,[[150+111*Math.sin(a),150-111*Math.cos(a)],[150+120*Math.sin(a),150-120*Math.cos(a)]],C.ink,3);}txt(g,'10 MIN',105,225,28,C.green);});
asset('clock-hand',130,10,g=>line(g,[[0,5],[126,5]],C.red,5));
asset('pen',90,16,g=>{rect(g,4,4,70,8,C.blue,2);line(g,[[74,4],[87,8],[74,12]],C.ink,2);});
asset('check',150,150,g=>line(g,[[20,80],[57,115],[130,27]],C.green,10));
const img=(path,x,y,w,id,extra={})=>({type:'image',path:`art/${path}.png`,x,y,w,id,...extra});const text=(s,x,y,size=54)=>({type:'text',text:s,x,y,size,w:1120,color:C.ink});
const mix=(a,b,f)=>a+(b-a)*f,ptmix=(a,b,f)=>a.map((v,i)=>mix(v,b[i],f));
function solve(root,target,l1,l2,bend){let dx=target[0]-root[0],dy=target[1]-root[1],d=Math.hypot(dx,dy);if(d>l1+l2-.01)throw Error(`Unreachable limb ${JSON.stringify([root,target,l1,l2,d])}`);let a=Math.atan2(dy,dx),q=Math.acos(Math.max(-1,Math.min(1,(l1*l1+d*d-l2*l2)/(2*l1*d))));return [root[0]+l1*Math.cos(a+bend*q),root[1]+l1*Math.sin(a+bend*q)];}
function state(mode,t,span){let breath=Math.sin(t*2.5)*1.4;let N,P,H,L,R,FL,FR,expr='head-worry';
 if(['sit','write','awkward','finish','sit-down','tempted'].includes(mode)){
  let settle=mode==='sit-down'?Math.max(0,1-t/Math.min(.85,span)):0;
  N=[917,290-45*settle+breath];P=[960,435-25*settle];H=[899,237-45*settle+breath];
  L=[790+Math.sin(t*7)*5,407+Math.cos(t*7)*3];R=[848+Math.sin(t*6)*6,410+Math.cos(t*6)*3];FL=[863,565];FR=[1050,565];
  if(mode==='write'||mode==='awkward'){L=[795+Math.sin(t*5)*18,405+Math.cos(t*5)*2];R=[857,412];H[0]-=8;H[1]+=5;}
  if(mode==='tempted'){R=[1048+Math.sin(t*2)*8,379];H=[935,239+breath];}
  if(mode==='finish'){expr='head-proud';L=[802+Math.sin(t*6)*8,408];H[0]+=4;}
 }else if(mode==='scrub'){
  N=[886,315+Math.sin(t*3)*3];P=[960,432];H=[861,263+Math.sin(t*3)*3];L=[752+Math.sin(t*5)*32,419];R=[810+Math.sin(t*5)*17,415];FL=[864,565];FR=[1032,565];expr='head-proud';
 }else if(mode==='sofa'){N=[910,359+breath];P=[996,459];H=[884,310+breath];L=[831+Math.sin(t*2)*8,451];R=[987,445];FL=[842,555];FR=[1080,555];expr='head-worry';}else if(mode==='drive'){N=[925,306+breath];P=[994,444];H=[900,253+breath];L=[816+60*Math.cos(Math.PI+.20*Math.sin(t*2)),390+60*Math.sin(Math.PI+.20*Math.sin(t*2))];R=[816+60*Math.cos(-.97+.20*Math.sin(t*2)),390+60*Math.sin(-.97+.20*Math.sin(t*2))];FL=[858,558];FR=[1076,558];expr='head-profile-focused';}else if(mode==='present'){N=[927,296+breath];P=[945,431];H=[922,242+breath];L=[775+Math.sin(t*2)*14,330];R=[1008,391+Math.sin(t*2)*8];FL=[880,565];FR=[1014,565];expr='head-curious';}else if(mode==='phone'){
  N=[930,298+breath];P=[945,433];H=[910,246+breath];L=[851,374+Math.sin(t*2)*2];R=[866+Math.sin(t*6)*5,333+Math.cos(t*6)*4];FL=[880,565];FR=[1015,565];expr='head-curious';
 }else if(mode==='worry'){
  N=[926,300+breath];P=[949,435];H=[916+Math.sin(t*2)*3,247+breath];L=[876+Math.sin(t*2)*9,280+Math.cos(t*2)*5];R=[830+Math.sin(t*2)*15,410];FL=[884,565];FR=[1026,565];
 }else if(mode==='carry'){
  let f=t/span,x=905-85*f;N=[x,295+breath];P=[x+14,430];H=[x-16,242+breath];L=[x-70,364];R=[x+68,397+Math.sin(t*4)*18];FL=[x-52+Math.sin(t*5)*23,565-Math.max(0,Math.sin(t*5))*17];FR=[x+65-Math.sin(t*5)*23,565-Math.max(0,-Math.sin(t*5))*17];if(f>.8)L=[767+35*(f-.8)/.2,364-25*(f-.8)/.2];expr='head-curious';
 }else{
  N=[925,299+breath];P=[950,433];H=[913,247+breath];L=[800+Math.sin(t*2)*22,412];R=[995,403+Math.sin(t*3)*8];FL=[884,565];FR=[1020,565];expr=mode==='choose'?'head-curious':'head-worry';
 }
 let SL=[N[0]+(P[0]-N[0])*.13,N[1]+(P[1]-N[1])*.13],SR=[...SL];
 if(['sit','write','awkward','sit-down','tempted'].includes(mode))expr='head-profile-worry';if(['finish','scrub','carry'].includes(mode))expr='head-profile-focused';let HB=[H[0],H[1]+33];return {N,P,H,HB,L,R,FL,FR,SL,SR,EL:solve(SL,L,100,100,1),ER:solve(SR,R,100,100,-1),KL:solve(P,FL,91,103,-1),KR:solve(P,FR,91,103,1),expr};
}
function rig(mode,span,id){const samples=[];for(let t=0;t<span;t+=.15)samples.push({t,...state(mode,t,span)});samples.push({t:span,...state(mode,span,span)});const segs=[['neck','HB','N'],['torso','N','P'],['upperL','SL','EL'],['foreL','EL','L'],['upperR','SR','ER'],['foreR','ER','R'],['thighL','P','KL'],['shinL','KL','FL'],['thighR','P','KR'],['shinR','KR','FR']];const layers=[];
 for(const [name,a,b] of segs){let previous;const keys=samples.map(s=>{let dx=s[b][0]-s[a][0],dy=s[b][1]-s[a][1],angle=Math.atan2(dy,dx);if(previous!==undefined){while(angle-previous>Math.PI)angle-=2*Math.PI;while(angle-previous< -Math.PI)angle+=2*Math.PI;}previous=angle;let w=Math.hypot(dx,dy);let thickness=8*w/128;return {t:s.t,x:s[a][0]+Math.sin(angle)*thickness/2,y:s[a][1]-Math.cos(angle)*thickness/2,w,angle};});layers.push(img('bone',keys[0].x,keys[0].y,keys[0].w,id+'-'+name,{keys,...(['upperL','foreL','upperR','foreR'].includes(name)?{motion:{role:'actor',reason:mode==='scrub'?'Both arms follow a planted cloth as Maya scrubs the counter':mode==='phone'?'One hand supports the phone while the other taps its screen':mode==='write'||mode==='awkward'?'Writing hand makes strokes on the page while the other hand anchors it':mode==='carry'?'Maya carries the phone away while her whole body takes steps':mode==='worry'?'Maya brings a hand toward her face and hesitates over the task':'Arms carry the current purposeful reach, operation or typing action'}}:{})}));}
 for(const [n,k] of [['handL','L'],['handR','R']])layers.push(img('hand',0,0,26,id+'-'+n,{keys:samples.map(s=>({t:s.t,x:s[k][0]-13,y:s[k][1]-11}))}));
 for(const [n,k] of [['shoeL','FL'],['shoeR','FR']])layers.push(img('shoe',0,0,46,id+'-'+n,{keys:samples.map(s=>({t:s.t,x:s[k][0]-23,y:s[k][1]-8}))}));
 layers.push(img(samples[0].expr,0,0,110,id+'-head',{keys:samples.map(s=>({t:s.t,x:s.H[0]-55,y:s.H[1]-55}))}));layers.push(img('scarf',0,0,58,id+'-scarf',{keys:samples.map(s=>({t:s.t,x:s.N[0]-23,y:s.N[1]-1}))}));return {layers,samples};
}

export {B,C,asset,line,rect,oval,txt,img,text,rig,state};
