import fs from 'node:fs';import {B,C,img,text,rig} from './film-library.mjs';import {norm} from './build-captions.mjs';
const wd=JSON.parse(fs.readFileSync(B+'/words-full.json'));const words=wd.words,D=Math.ceil((wd.duration+.8)*30)/30;const cues=JSON.parse(fs.readFileSync(B+'/captions-draft.json'));let stream='',map=[];for(let i=0;i<words.length;i++){let n=norm(words[i].word);for(let j=0;j<n.length;j++)map.push(i);stream+=n;}
let cursor=0;const specs=fs.readFileSync(B+'/storyboard.txt','utf8').trim().split('\n').map((row,i)=>{let [marker,kind,mode,title]=row.split('|');let n=norm(marker),at=stream.indexOf(n,cursor);if(at<0)throw Error('Unmatched marker '+marker);cursor=at+1;return {marker,kind,mode:mode||null,title,start:words[map[at]].start,original_index:i};});specs[0].start=0;
for(let i=specs.length-2;i>0;i--)if(specs[i+1].start-specs[i].start<.8){specs[i-1].merged=(specs[i-1].merged||[]).concat(specs[i].marker);specs.splice(i,1);}
const chapterDefs=[['THE CLEAN KITCHEN','You have a presentation'],['MEET MAYA','Meet Maya'],['THE RELIEF LOOP','One influential account'],['NAME THE FRICTION','Not every delay'],['CHANGE THE FIRST MOVE',"Maya's plan says"],['GIVE THE FEELING A SEAT',"There's a catch"],['PLAN FOR THE OBSTACLE','A vague promise says'],['MAKE RETURNING EASIER','The next morning']];
const chapters=chapterDefs.map(([title,marker],i)=>{let at=stream.indexOf(norm(marker));return {chapter:i+1,title,start:words[map[at]].start};});chapters[0].start=0;
const shots=[],ledger=[];const panelKinds={loop:[0,1,2,3],stakes:[5,6,7],obstacles:[5,6,7],responses:[8,9,10],waiting:[0,13,8],'delay-choice':[8,2],options:[14,15,16],'verb-object':[8,0],decisions:[5,6,7,8],scope:[0,8],'plan-three':[11,12,13],'if-then':[11,12],experiment:[11,12,8],'viewer-action':[0,8],uncertainty:[5,8],notifications:[13,11]};
function transformRig(r,scale,dx,dy,id){return r.layers.map(l=>{let v={...l,id:id+'-'+l.id};if(l.path==='art/bone.png')v.keys=l.keys.map(k=>({t:k.t,x:k.x*scale+dx,y:k.y*scale+dy,w:k.w*scale,angle:k.angle}));else {v.w=l.w*scale;v.keys=l.keys.map(k=>({...k,x:k.x*scale+dx,y:k.y*scale+dy}));}return v;});}
function mirrorRig(r,scale,dx,dy,id){return r.layers.map(l=>{let v={...l,id:id+'-'+l.id};if(l.path==='art/bone.png'){v.keys=l.keys.map(k=>{let rootX=k.x-Math.sin(k.angle)*k.w/32,rootY=k.y+Math.cos(k.angle)*k.w/32;let angle=Math.PI-k.angle,w=k.w*scale;return {t:k.t,x:dx-rootX*scale+Math.sin(angle)*w/32,y:dy+rootY*scale-Math.cos(angle)*w/32,w,angle};});}else{v.w=l.w*scale;v.keys=l.keys.map(k=>({...k,x:dx-(k.x+l.w)*scale,y:dy+k.y*scale}));if(l.id.endsWith('-head'))v.path='art/head-profile-worry-right.png';if(l.id.endsWith('-scarf'))v.path='art/scarf-right.png';}return v;});}
for(let i=0;i<specs.length;i++){
 const s=specs[i],end=i+1<specs.length?specs[i+1].start:D,span=end-s.start,id='f'+i;let layers=[],foreground=[],mode=s.mode;
 const add=(a,x,y,w,name,extra={})=>{let l=img(a,x,y,w,id+'-'+name,extra);layers.push(l);return l;};
 const focal=(a,x,y,w,name,reason)=>add(a,x,y,w,name,{keys:[{t:0,x:x-28,y:y+15},{t:Math.min(1.2,span*.45),x,y},{t:Math.max(Math.min(1.2,span*.45)+.01,span),x,y}],motion:{role:'prop',reason}});
 const diagram=(indices)=>{let n=indices.length,w=n===4?230:265,left=n===4?75:n===3?145:230,gap=n===4?300:n===3?340:445;for(let j=0;j<n;j++){const t=j*span/(n+1),x=left+j*gap;add('icon-'+indices[j],x,248,w,'card'+j,{from:t,keys:[{t,x:x-23,alpha:0},{t:Math.min(span,t+.65),x,alpha:1},{t:span,x,y:248}],motion:{role:'information',reason:'The current explanatory relationship is built in spoken order; this card is a task, feeling, action or consequence'}});if(j<n-1)layers.push({type:'arrow',id:id+'-relation'+j,points:[[x+w+7,346],[x+gap-10,346]],color:C.green,lineWidth:4,from:t,keys:[{t,progress:0},{t:Math.min(span,Math.max(t+.2,(j+2)*span/(n+1))),progress:1}],motion:{role:'information',reason:'A connector develops the current causal, contrast or cue-action relationship'}});}};
 const deskKinds=['desk','rough','spreadsheet','evaluation','send-hesitate','temptation','urge-note','note','send'];
 if(deskKinds.includes(s.kind)&&mode){add('chair',925,283,170,'chair');add('desk-stage',170,155,800,'desk');}
 if(s.kind==='kitchen'||s.kind==='kitchen-rest'){add('kitchen-stage',170,170,800,'kitchen');if(s.kind==='kitchen-rest')focal('cloth',660,415,82,'resting-cloth','The cloth is set down as the story returns to the original avoided task');}
 if(s.kind==='role'){focal('story-role',130,230,540,'role','Maya’s fictional role and goal are introduced on a concrete portfolio card');}
 if(['folder','folder-open','folder-close','task'].includes(s.kind)){
  const x=420,y=260,w=360;const opening=s.kind==='folder'||s.kind==='folder-open';
  add('paper',465,215,220,'page',{keys:opening?[{t:0,y:318},{t:Math.min(1.2,span*.6),y:211},{t:span,y:211}]:[{t:0,y:211},{t:Math.min(1.2,span*.6),y:318},{t:span,y:318}],motion:{role:'prop',reason:opening?'A real project page is revealed from inside the portfolio':'The page disappears back into the folder as Maya avoids the task'}});
  add('folder-color',x,y,w,'folder');
 }
 if(s.kind==='projects'){for(let j=0;j<3;j++){let x=140+j*300,t=j*Math.min(.7,span*.22);add('project-card',x,228,250,'project'+j,{from:t,keys:[{t,x:x-28,y:252,alpha:0},{t:Math.min(span,t+.65),x,y:228,alpha:1},{t:span,x,y:228}],motion:{role:'prop',reason:'The three portfolio projects appear as distinct manageable pieces'}});}if(span>5)add('check',1010,330,95,'requirements-check',{from:span*.65,keys:[{t:span*.65,x:1010,y:365,alpha:0},{t:span*.82,x:1010,y:330,alpha:1},{t:span,x:1010,y:330}],motion:{role:'information',reason:'The complete three-project requirement receives a final check after the items are shown'}});}
 if(['message','weather','apps','inbox','interrupt'].includes(s.kind)){
  const screen=['weather','apps'].includes(s.kind)?s.kind:'message';add('phone-large',145,185,250,'phone-closeup');add('screen-'+screen,178,231,183,'screen');add('folder-color',480,326,165,'untouched-folder');focal('check',356,433,62,'small-win','A small phone task yields a visible win while the important folder stays unopened');
 }
 if(['calendar','calendar-pressure'].includes(s.kind)){
  add('calendar',160,185,430,'calendar');let count=s.kind==='calendar-pressure'?3:2;for(let j=0;j<count;j++){let x=665+j*82;add('calendar-card',x,242+j*32,210,'later'+j,{from:j*span/count,keys:[{t:j*span/count,y:300+j*32,alpha:0},{t:Math.min(span,j*span/count+.8),y:242+j*32,alpha:1},{t:span,y:242+j*32}],motion:{role:'prop',reason:'Later dates accumulate as the same important task is postponed'}});}if(s.kind==='calendar-pressure')layers.push(text('LESS TIME · MORE PRESSURE',650,490,38));
 }
 if(s.kind==='colleague'){
  add('project-card',480,281,230,'shared-result');const other=rig('present',span,id+'-colleague');layers.push(...transformRig(other,.82,-300,99,id+'-other'));layers.push(text('A RESULT FROM A COLLEAGUE',74,115,35));
 }
 if(s.kind==='spreadsheet')focal('spreadsheet',155,233,540,'sheet','Rows are reorganized instead of opening the portfolio');
 if(s.kind==='busy'){add('folder-color',145,243,370,'still-closed');add('clock-face',700,200,310,'clock');add('clock-hand',855,355,118,'time',{keys:[{t:0,angle:-1.5},{t:span,angle:3.3}],motion:{role:'information',reason:'Time passes while the important folder remains closed'}});}
 if(['thought','judgment','verdict'].includes(s.kind)){
  if(s.kind==='verdict'||s.kind==='judgment')focal('stamp',165,245,540,'judgment','An original judgment-stamp metaphor shows the work feeling like a verdict, not an actual employer review');else focal('folder-color',190,270,350,'task','Maya approaches the important folder and hesitates');
  if(s.kind==='verdict'){const stamp=layers.find(l=>l.id===id+'-judgment');stamp.keys=[{t:0,y:220,x:165},{t:span*.55,y:260,x:165},{t:span*.72,y:245,x:165},{t:span,y:245,x:165}];}
  if(s.kind==='thought')layers.push({type:'line',id:id+'-hesitation',points:[[568,354],[728,354]],color:C.red,lineWidth:4,keys:[{t:0,progress:0},{t:Math.max(.5,span-.4),progress:1}],motion:{role:'information',reason:'The gap between the task and Maya’s hand makes hesitation visible'}});
 }
 if(s.kind==='research'){focal('source-card',205,200,720,'source','The cited explanatory account is introduced as one perspective, not a universal cause');add('hourglass',985,275,155,'future-cost',{keys:[{t:0,y:292},{t:span*.5,y:265},{t:span,y:252}],motion:{role:'prop',reason:'The temporal cost symbol links immediate relief to the future self'}});}
 if(s.kind==='bills'||s.kind==='bill-now'||s.kind==='bill-later'){
  if(s.kind!=='bill-later')focal('bill-now',140,205,340,'now','The immediate emotional cost is presented as an original paper-bill metaphor');
  if(s.kind!=='bill-now')focal('bill-later',mode?400:715,205,340,'later','The delayed time-and-pressure cost is contrasted with the present cost');
  if(s.kind==='bills'&&span>3)layers.push({type:'arrow',id:id+'-deferral',points:[[535,364],[673,364]],color:C.red,lineWidth:5,keys:[{t:0,progress:0},{t:span-.4,progress:1}],motion:{role:'information',reason:'The choice shifts the cost from now to later'}});
 }
 if(panelKinds[s.kind])diagram(panelKinds[s.kind]);
 if(s.kind==='scope'||s.kind==='if-then'){const a=s.kind==='scope'?'scope-note':'ifthen-note';add(a,370,425,540,'concrete-boundary',{from:span*.55,keys:[{t:span*.55,y:462,alpha:0},{t:span*.82,y:425,alpha:1},{t:span,y:425}],motion:{role:'prop',reason:s.kind==='scope'?'A written three-sentence stopping boundary becomes concrete at the spoken contrast with finishing a website':'A physical breakfast-to-three-sentences cue card makes the if–then plan concrete'}});}

 if(s.kind==='fog')focal('fog',95,224,630,'fog','An unclear career goal is depicted as a fog bank rather than an executable action');
 if(s.kind==='one-project'){
  focal('one-page',mode?390:400,170,360,'project','One chosen project is isolated from the larger portfolio');if(!mode)focal('check',800,295,130,'selected','A single project is selected rather than all projects at once');
 }
 if(s.kind==='evaluation')focal('stamp',120,190,440,'private-versus-sent','The page is private until sending exposes it to evaluation');
 if(s.kind==='hourglass')focal('hourglass',440,190,340,'time','Time is spent polishing while the almost-finished work remains unsent');
 if(s.kind==='sofa'||s.kind==='night'){
  if(s.kind==='night'&&mode!=='sofa'){add('chair',925,283,170,'night-chair');add('night-desk',170,155,800,'night-work');add('paper-work-rough',650,380,210,'night-paper');}else{if(s.kind==='night')add('night-desk',80,150,650,'night-work');else focal('battery',145,245,450,'energy','Available energy is visibly limited after a working day');add('sofa',600,324,550,'sofa');}
 }
 if(s.kind==='meetings')focal('meetings',300,180,630,'meeting-load','The day’s meetings accumulate before the evening task begins');
 if(s.kind==='finish-line'){focal('finish-line',270,200,690,'finishline','An actual finish-line prop distinguishes a goal from a first move');if(s.marker.startsWith("That's not"))add('moustache',553,386,159,'fake-moustache',{from:span*.45,keys:[{t:span*.45,y:330,alpha:0},{t:span*.65,y:386,alpha:1},{t:span,y:386}],motion:{role:'prop',reason:'The finish line is revealed wearing a literal fake moustache at the joke’s payoff'}});}
 if(s.kind==='rough'){
  if(mode)add('paper-work-rough',650,380,210,'rough-page');else{focal('rough-paper',285,165,390,'rough-page','An imperfect written page is kept rather than discarded');layers.push(text('NOT IMPRESSIVE.',760,300,46),text('JUST WRITTEN.',760,390,46),{type:'line',id:id+'-new-ink',points:[[340,435],[580,431]],color:C.ink,lineWidth:3,keys:[{t:0,progress:0},{t:Math.max(.3,span-.4),progress:1}],motion:{role:'information',reason:'A real imperfect ink line is added to the rough draft instead of discarding it'}});}
 }
 if(['path','route'].includes(s.kind)){
  focal('route',260,175,760,'route','A visible path with a detour returns toward the goal rather than ending in a character judgment');add('check',935,428,65,'return-marker',{keys:[{t:0,x:350,y:476},{t:span*.4,x:500,y:246},{t:span*.7,x:745,y:246},{t:span,x:935,y:428}],motion:{role:'information',reason:'The path marker progresses through an obstacle and returns to the work'}});
 }
 if(['expenses','question','shoes'].includes(s.kind))focal(s.kind==='question'?'first-question':s.kind,mode?200:360,190,s.kind==='shoes'?520:450,'action-object','The specific spoken action has a recognizable object rather than an abstract instruction');
 if(s.kind==='clock'){
  add('clock-face',230,180,360,'clock');add('clock-hand',410,360,130,'clock-hand',{keys:[{t:0,angle:-1.5},{t:span,angle:2.2}],motion:{role:'information',reason:'A short work window is marked as an experiment, not a scientifically required threshold'}});focal('rough-paper',760,215,250,'attempt','The short work experiment creates an imperfect page');
 }
 if(s.kind==='breakfast')focal('breakfast',mode?120:270,190,650,'breakfast-cue','Breakfast becomes a concrete situational cue for the next action');
 if(s.kind==='car'){
  add('car',100,200,1050,'car');add('steering',721,295,190,'wheel');foreground.push(img('car-front',100,460,1100,id+'-car-front'));
 }
 if(s.kind==='urge-note')add('note-next',415,290,200,'urge-note',{keys:[{t:0,y:325},{t:span*.5,y:290},{t:span,y:285}],motion:{role:'prop',reason:'The urge is written down instead of acted on immediately'}});
 if(s.kind==='note'){
  if(mode)add('paper-work-rough',650,380,210,'work');focal('note-next',mode?390:430,mode?277:230,mode?235:430,'next-note','A specific next-action note is left to make returning easier');
 }
 if(s.kind==='carry'||s.kind==='doorway')add('shelf-room',135,164,700,'other-room');
 if(s.kind==='requirements')diagram([0,8,9]);
 if(s.kind==='links'){
  add('link-broken',120,230,500,'broken');focal('link-fixed',680,230,500,'fixed','The broken application link is repaired before sending');
 }
 if(s.kind==='send'){
  add('application-form',120,190,560,'application-form');add('envelope',474,441,128,'sent-envelope',{keys:[{t:0,x:474,y:441,alpha:0},{t:span*.3,x:474,y:441,alpha:1},{t:span,x:730,y:292}],motion:{role:'prop',reason:'The portfolio application is sent from its completed form; the outgoing envelope leads to the sent confirmation'}});
 }
 if(s.kind==='sent')focal('delivery',315,170,630,'sent','The outcome shown is an application sent; no job offer or testimonial is fabricated');
 if(s.kind==='support'){
  add('support-room',85,200,600,'support-room');const client=rig('sit',span,id+'-client');layers.push(...mirrorRig(client,.75,922,91.75,id+'-client-left'));const helper=rig('write',span,id+'-helper');for(const l of helper.layers){if(l.id.endsWith('-head'))l.path='art/head-helper.png';if(l.id.endsWith('-scarf'))l.path='art/scarf-helper.png';}layers.push(...transformRig(helper,.75,-180,91.75,id+'-helper-right'));focal('first-question',850,280,250,'explore-question','A concrete question sheet accompanies an illustrated support conversation; it is not a diagnosis');
 }
 if(mode){
  const r=rig(mode,span,id);layers.push(...r.layers);
  if(['desk','rough','urge-note','note'].includes(s.kind)&&['write','awkward','finish','sit'].includes(mode)){
   if(!['rough','note'].includes(s.kind))layers.push(img('paper-work-rough',650,380,210,id+'-writing-paper'));
   layers.push(img('pen',0,0,62,id+'-pen',{keys:r.samples.map(v=>({t:v.t,x:v.L[0]-43,y:v.L[1]-8,angle:-.2}))}));
  }
  if(['message','weather','apps','inbox','interrupt'].includes(s.kind))layers.push(img('phone-large',0,0,57,id+'-held-phone',{keys:r.samples.map(v=>({t:v.t,x:v.L[0]-25,y:v.L[1]-63}))}));
  if(s.kind==='kitchen')layers.push(img('cloth',0,0,74,id+'-cloth',{keys:r.samples.map(v=>({t:v.t,x:v.L[0]-37,y:v.L[1]-2}))}));
  if(s.kind==='carry'||s.kind==='doorway')layers.push(img('phone-large',0,0,57,id+'-carried-phone',{keys:r.samples.map(v=>({t:v.t,x:v.t>=span*.8?742:v.L[0]-25,y:v.t>=span*.8?301:v.L[1]-63}))}));
  if(s.kind==='temptation'){add('phone-stand',1032,348,58,'tempting-phone');}
 }
 layers.push(...foreground);if(s.title)layers.push(text(s.title,76,79,s.title.length>48?43:51));
 const chapter=chapters.filter(c=>c.start<=s.start+.01).at(-1);layers.push({...text(`${String(chapter.chapter).padStart(2,'0')} / ${chapter.title}`,77,30,25),color:'#778c8b'});
 if(!mode&&!layers.some(l=>l.motion))throw Error('No principal action in '+s.kind);
 shots.push({start:s.start,end,layers});ledger.push({...s,end,span,chapter:chapter.chapter,spoken:cues.filter(c=>c.start>=s.start&&c.start<end).map(c=>c.text).join(' '),picture_intent:s.kind,review:'pending actual full-film review'});
}
const sfx=[];
for(let i=0;i<specs.length;i++){const s=specs[i];if(['folder-open','folder-close','folder','note','one-project','projects'].includes(s.kind)&&i%2===0)sfx.push({time:s.start+.2,kind:'paper',gain:.024});if(['send','message','interrupt'].includes(s.kind))sfx.push({time:s.start+.15,kind:s.kind==='send'?'tap':'file',...(s.kind==='send'?{}:{path:'notification-original.wav'}),gain:s.kind==='send'?.04:.055});if(s.kind==='kitchen'&&i<3)sfx.push({time:s.start+.25,kind:'file',path:'cloth-original.wav',gain:.065});if(s.kind==='desk'&&s.mode==='write'&&i%3===0)sfx.push({time:s.start+.3,kind:'file',path:'typing-original.wav',gain:.05});}
const cuts=[];const verdict=specs.find(x=>x.kind==='verdict');if(verdict)cuts.push({start:verdict.start+.15,end:Math.min(verdict.start+1.15,D),reason:'Brief quiet makes the imagined judgment feel distinct without a horror sting',return_trigger:'The explanation of short-term mood repair'});
const project={version:1,style:'B1',width:1920,height:1080,fps:30,voice:{path:'narration-full.wav',lead:0,tail:D-wd.duration},captions:cues.map(({start,end,text})=>({start,end,text})),shots,music:{path:'music-original.wav',gain:.05},ambience:[{path:'room.wav',start:0,end:D,gain:.018}],sfx,audio_cuts:cuts,reference_review:{author_id:'codex-full-film-author',capability:{mode:'sample_target',environment:'Codex Cloud; approved one-minute B1 style, original story artwork and keyed limb rig; full review remains pending',limitations:[]}}};
fs.writeFileSync(B+'/project.json',JSON.stringify(project,null,2));fs.writeFileSync(B+'/shot-ledger.json',JSON.stringify(ledger,null,2));fs.writeFileSync(B+'/chapters-timing.json',JSON.stringify(chapters,null,2));fs.writeFileSync(B+'/sound-script.json',JSON.stringify({narrator:'OpenAI tts-1 alloy, native rate, existing opening reused unchanged',continuous_bed:'Original locally composed chord/pluck bed; timed section changes, no third-party recording',room:'Original low-level local noise',cues:sfx,cuts,coverage:ledger.map(s=>({start:s.start,end:s.end,spoken:s.spoken,bed:'continuous original bed except explicit cut',emotional_job:s.kind,priority:'Narration first; sparse causal effects below voice'})),rights:'All music, foley and effects locally synthesized or runtime MIT; fonts OFL; reference videos and research PDFs are not redistributed'},null,2));console.log({seconds:D,minutes:D/60,shots:shots.length,captions:cues.length,sfx:sfx.length});
