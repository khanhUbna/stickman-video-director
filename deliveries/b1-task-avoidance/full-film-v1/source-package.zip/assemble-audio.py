import pathlib,wave,json,re,subprocess,difflib
P=pathlib.Path(__file__).parent;rows=json.loads((P/'audio-manifest.json').read_text());sr=24000;allwords=[];chapters=[];offset=0;alltext=[]
with wave.open(str(P/'narration-full.wav'),'wb') as out:
 out.setparams((1,2,sr,0,'NONE','not compressed'))
 for row in rows:
  i=row['chunk'];wav=P/'audio'/f'{i:02}.wav'
  with wave.open(str(wav),'rb') as w:
   assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,sr)
   pcm=w.readframes(w.getnframes());duration=len(pcm)/2/sr
  chapters.append({'chunk':i,'start':offset,'end':offset+duration,'text':row['text']});out.writeframes(pcm)
  d=json.loads((P/'audio'/f'{i:02}-alignment.json').read_text())
  for wd in d['words']:allwords.append({'word':wd['word'],'start':offset+wd['start'],'end':offset+wd['end'],'chunk':i})
  offset+=duration;alltext.append(row['text'])
  if i<len(rows)-1:out.writeframes(b'\0\0'*3600);offset+=.15
(P/'words-full.json').write_text(json.dumps({'words':allwords,'duration':offset},indent=2));(P/'chunks-timing.json').write_text(json.dumps(chapters,indent=2));(P/'narration-full.txt').write_text('\n\n'.join(alltext))
def norm(s):
 s=re.sub(r'9[\s.:]*30','ninethirty',s.lower())
 for a,b in [('27','twentyseven'),('20','twenty'),('10','ten'),('3','three'),('2','two'),('1','one')]:s=re.sub(r'\b'+a+r'\b',b,s)
 return re.sub('[^a-z0-9]','',s)
errors=[]
for row in rows:
 expected=norm(row['text']);actual=norm(' '.join(w['word'] for w in allwords if w['chunk']==row['chunk']))
 if expected!=actual:
  diff=[(op,expected[a:b],actual[c:d]) for op,a,b,c,d in difflib.SequenceMatcher(None,expected,actual,autojunk=False).get_opcodes() if op!='equal'];errors.append({'chunk':row['chunk'],'diff':diff})
(P/'alignment-audit.json').write_text(json.dumps({'differences':errors,'duration':offset},indent=2));print('Duration',offset,'word count',len(allwords),'alignment differences',json.dumps(errors))
