import {asset,line,rect,oval,txt,C} from './film-library.mjs';
asset('sofa',650,340,g=>{rect(g,28,45,572,153,'#d7e8e3',35);rect(g,15,160,605,100,C.green,25);rect(g,48,180,238,62,'#e2ede4',20);rect(g,300,180,270,62,'#e2ede4',20);rect(g,0,110,68,160,C.green,24);rect(g,565,110,68,160,C.green,24);line(g,[[65,269],[54,321]]);line(g,[[574,269],[585,321]]);});
asset('night-desk',800,420,g=>{rect(g,50,10,300,145,C.ink,3);oval(g,290,47,19,19,'#f1d77b');for(let i=0;i<9;i++){let x=70+(i*83)%270,y=30+(i*31)%100;oval(g,x,y,1.2,1.2,'#d6e7e5');}rect(g,0,250,740,20,'#e8c291',3);line(g,[[36,270],[29,405]]);line(g,[[697,270],[705,405]]);rect(g,263,102,240,140,C.ink,5);rect(g,273,112,220,119,'#f3f5ef',1);txt(g,'ONE MORE THING?',281,172,29);rect(g,222,241,320,9,'#bccacc',3);rect(g,546,206,104,38,C.gold,5);txt(g,'9:30 PM',554,233,24);});
asset('calendar',400,360,g=>{rect(g,20,40,350,291,'#f6f3e7',10);rect(g,20,40,350,61,C.red,8);txt(g,'TOMORROW?',88,82,33,'#fff');for(let x=60;x<370;x+=70)line(g,[[x,102],[x,310]],'#c4cfcb',2);for(let y=148;y<331;y+=54)line(g,[[21,y],[369,y]],'#c4cfcb',2);for(let i=0;i<15;i++)txt(g,String(i+1),42+i%5*70,134+Math.floor(i/5)*54,23);});
asset('calendar-card',200,170,g=>{rect(g,8,8,182,150,'#faf5df',4);rect(g,8,8,182,39,C.red,4);txt(g,'LATER',54,36,26,'#fff');txt(g,'NOT TODAY',35,105,27);});
asset('project-card',260,290,g=>{rect(g,13,12,231,263,'#fff6d9',5);rect(g,30,33,196,47,C.gold,3);txt(g,'PROJECT',67,67,29);rect(g,31,105,193,83,'#dbe8e1',3);line(g,[[46,218],[213,218]],'#879d97',3);line(g,[[46,243],[177,243]],'#879d97',3);});
asset('one-page',300,330,g=>{rect(g,18,13,265,300,'#fff8df',4);txt(g,'ONE PROJECT',44,58,30);rect(g,38,78,225,85,'#d6e5dc',4);line(g,[[42,191],[247,191]],C.ink,3);line(g,[[42,223],[210,223]],C.ink,3);line(g,[[42,255],[233,255]],C.ink,3);});
asset('spreadsheet',550,340,g=>{rect(g,10,10,520,305,'#f1f4eb',7);rect(g,10,10,520,45,C.green,5);txt(g,'VERY IMPORTANT REORGANIZING',26,42,26,'#fff');for(let x=40;x<520;x+=90)line(g,[[x,57],[x,302]],'#b7cbc4',2);for(let y=95;y<315;y+=44)line(g,[[12,y],[528,y]],'#b7cbc4',2);rect(g,130,100,86,39,'#f5df93',1);rect(g,310,188,86,39,'#d5e5ed',1);});
asset('inbox',450,330,g=>{rect(g,12,14,420,300,'#edf3ed',7);rect(g,12,14,420,52,C.green,5);txt(g,'INBOX',48,51,35,'#fff');for(let i=0;i<4;i++){rect(g,30,87+i*50,35,23,'#f4d887',2);line(g,[[84,95+i*50],[397,95+i*50]],'#91a8a3',3);}});
asset('envelope',260,180,g=>{rect(g,13,25,228,135,'#e0eae8',5);line(g,[[15,27],[126,104],[240,27]],C.blue,4);line(g,[[16,157],[96,94]],C.blue,3);line(g,[[238,157],[158,94]],C.blue,3);});
asset('bill-now',330,330,g=>{rect(g,10,10,305,300,'#fbefc9',5);txt(g,'PAY NOW',86,57,36);line(g,[[35,80],[290,80]],C.gold,5);txt(g,'FEEL AWKWARD',44,142,32);txt(g,'for a little while',55,193,29);txt(g,'THE FIRST STEP',49,266,29,C.green);});
asset('bill-later',330,330,g=>{rect(g,10,10,305,300,'#f3ded6',5);txt(g,'PAY LATER',65,57,36);line(g,[[35,80],[290,80]],C.red,5);txt(g,'LESS TIME',72,132,32);txt(g,'MORE PRESSURE',41,179,31);txt(g,'PLUS THE SAME TASK',29,265,28,C.red);});
asset('finish-line',650,330,g=>{line(g,[[55,40],[55,300]],C.ink,5);line(g,[[593,40],[593,300]],C.ink,5);rect(g,56,55,537,118,C.gold,3);txt(g,'FINISH PORTFOLIO',104,109,44);for(let i=0;i<12;i++)rect(g,62+i*43,130,40,35,i%2?C.ink:C.paper,0);});
asset('fog',550,350,g=>{for(let i=0;i<7;i++)oval(g,85+i*57,143+Math.sin(i)*31,77,63,i%2?'#e8efea':'#dce7e5');txt(g,'WORK ON MY CAREER',82,163,42,C.blue);txt(g,'…where do I start?',154,286,31);});
asset('stamp',390,230,g=>{rect(g,15,35,355,145,'#f7e3db',6);txt(g,'NOT GOOD ENOUGH?',35,106,37,C.red);line(g,[[40,141],[338,141]],C.red,4);});
asset('battery',450,240,g=>{rect(g,25,55,350,145,'#e7eeea',12);rect(g,378,94,39,65,C.ink,4);rect(g,39,70,45,115,C.red,5);txt(g,'ENERGY',155,146,39);});
asset('meetings',520,330,g=>{rect(g,15,20,485,285,'#eff3ec',6);txt(g,'TODAY',180,61,40);for(let i=0;i<4;i++){rect(g,36,83+i*49,443,35,i%2?'#e8d4cb':'#cfe0dc',4);txt(g,['09:00  TEAM CALL','11:00  PROJECT REVIEW','14:00  ANOTHER CALL','16:30  FOLLOW-UP'][i],53,108+i*49,25);}});
asset('shoes',380,220,g=>{g.beginPath();g.moveTo(28,144);g.lineTo(35,82);g.lineTo(97,71);g.lineTo(130,131);g.lineTo(201,145);g.lineTo(217,180);g.lineTo(27,180);g.closePath();g.fillStyle='#e8b865';g.fill();g.stroke();line(g,[[51,114],[100,107]],C.ink,3);line(g,[[59,133],[110,124]],C.ink,3);g.beginPath();g.moveTo(165,126);g.lineTo(177,51);g.lineTo(238,49);g.lineTo(271,103);g.lineTo(343,128);g.lineTo(357,162);g.lineTo(217,164);g.stroke();});
asset('expenses',350,320,g=>{rect(g,12,12,325,289,'#fff5d9',5);txt(g,'EXPENSES',92,57,37);for(let i=0;i<4;i++){txt(g,['Rent','Food','Travel','Other'][i],40,111+i*46,29);line(g,[[181,105+i*46],[299,105+i*46]],'#8ea8a1',3);}});
asset('first-question',350,320,g=>{rect(g,12,12,325,289,'#eaf1eb',5);txt(g,'ONE QUESTION',63,61,36);txt(g,'What would help',55,139,32);txt(g,'me move forward?',48,185,32);txt(g,'?',156,267,70,C.green);});
asset('steering',190,190,g=>{oval(g,95,95,78,78,'#edf0e8');oval(g,95,95,16,16,C.ink);for(let i=0;i<3;i++){let a=i*2*Math.PI/3;line(g,[[95,95],[95+70*Math.cos(a),95+70*Math.sin(a)]],C.ink,5);}});
asset('car',900,400,g=>{rect(g,70,20,730,193,'#deebec',30);line(g,[[510,22],[510,212]],'#a3bfc0',3);g.fillStyle='#d8e4d7';g.fillRect(84,167,703,39);line(g,[[85,195],[790,195]],'#7d9b8f',4);rect(g,15,215,850,110,'#d7e6df',16);rect(g,166,150,171,119,'#e6ba79',25);txt(g,'DISCOMFORT',167,189,25);txt(g,'PASSENGER',180,232,24);});
asset('route',650,360,g=>{line(g,[[35,284],[179,284],[179,98],[420,98],[420,277],[601,277]],'#8baca7',16);line(g,[[35,284],[179,284],[179,98],[420,98],[420,277],[601,277]],C.paper,4);oval(g,35,284,14,14,C.gold);oval(g,601,277,17,17,C.green);txt(g,'A DETOUR IS NOT THE END',70,50,36);});
asset('breakfast',600,330,g=>{rect(g,20,205,551,18,'#e8bd84',4);line(g,[[54,223],[46,312]]);line(g,[[536,223],[543,312]]);oval(g,220,189,91,16,'#edf2e8');rect(g,175,118,96,67,'#f3cf83',12);line(g,[[185,141],[259,133]],'#bf9d63',2);oval(g,403,157,37,47,'#dce9e8');line(g,[[440,135],[465,135],[465,176],[439,176]],C.blue,4);txt(g,'AFTER BREAKFAST',135,57,40);});
asset('phone-stand',240,360,g=>{rect(g,32,11,173,320,C.ink,18);rect(g,43,42,151,239,'#e8f0e9',3);txt(g,'PING!',82,143,35,C.red);rect(g,56,193,126,49,'#f4df9e',4);txt(g,'reply now?',64,224,25);});
asset('hourglass',300,330,g=>{line(g,[[44,30],[254,30]],C.ink,9);line(g,[[44,300],[254,300]],C.ink,9);line(g,[[65,36],[65,75],[145,162],[65,251],[65,294]],C.blue,5);line(g,[[233,36],[233,75],[153,162],[233,251],[233,294]],C.blue,5);g.fillStyle='#efc85a';g.beginPath();g.moveTo(85,82);g.lineTo(215,82);g.lineTo(150,153);g.closePath();g.fill();g.beginPath();g.moveTo(82,281);g.lineTo(150,219);g.lineTo(216,281);g.closePath();g.fill();});
asset('support',600,360,g=>{rect(g,48,110,137,108,'#d8e7e1',18);rect(g,391,110,137,108,'#d8e7e1',18);line(g,[[79,218],[69,320]]);line(g,[[152,218],[163,320]]);line(g,[[419,218],[409,320]]);line(g,[[501,218],[512,320]]);oval(g,289,194,74,17,'#e7bd7e');line(g,[[289,212],[289,315]]);oval(g,119,68,35,35);oval(g,455,68,35,35);line(g,[[119,102],[119,202],[97,278]]);line(g,[[455,102],[455,202],[483,278]]);line(g,[[119,133],[192,180]]);line(g,[[455,133],[382,180]]);});
asset('link-broken',500,220,g=>{g.strokeStyle=C.red;g.lineWidth=12;g.beginPath();g.roundRect(25,50,177,92,40);g.stroke();g.strokeStyle=C.blue;g.beginPath();g.roundRect(294,50,177,92,40);g.stroke();line(g,[[220,74],[239,50]],C.red,5);line(g,[[244,106],[266,106]],C.red,5);line(g,[[222,135],[240,157]],C.red,5);});
asset('link-fixed',500,220,g=>{g.strokeStyle=C.green;g.lineWidth=12;g.beginPath();g.roundRect(75,50,215,92,40);g.stroke();g.beginPath();g.roundRect(206,50,215,92,40);g.stroke();});
asset('delivery',500,330,g=>{rect(g,30,35,430,235,'#e5efe7',10);txt(g,'APPLICATION SENT',73,98,46,C.green);line(g,[[180,169],[224,207],[322,127]],C.green,10);txt(g,'No outcome invented.',108,310,27);});
asset('story-role',430,280,g=>{rect(g,18,20,393,230,'#e7efec',8);txt(g,'MAYA',144,76,56,C.green);txt(g,'Marketing / a new role',52,135,34);txt(g,'Portfolio: 3 projects',69,194,34);});
asset('source-card',650,280,g=>{rect(g,15,15,617,240,'#eef1e9',7);rect(g,33,32,8,206,C.green,2);txt(g,'ONE EXPLANATORY ACCOUNT',67,70,34);txt(g,'Short-term mood repair',72,129,48);txt(g,'Sirois & Pychyl · 2013',79,198,31,C.blue);});
const icons=['TASK','DISCOMFORT','ESCAPE','RELIEF NOW','COST LATER','UNCERTAINTY','EVALUATION','LOW ENERGY','CLEAR ACTION','ROUGH DRAFT','REST / SUPPORT','CUE','ACTION','OBSTACLE','CONTINUE','STOP','ASK FOR HELP'];

asset('car-front',900,150,g=>{rect(g,14,1,865,82,'#c9ded7',16);oval(g,190,101,53,39,C.ink);oval(g,710,101,53,39,C.ink);line(g,[[40,40],[849,40]],'#8fafa4',3);});

asset('moustache',150,65,g=>{oval(g,49,31,34,17,C.ink);oval(g,103,31,34,17,C.ink);line(g,[[49,29],[14,20]],C.ink,8);line(g,[[103,29],[136,20]],C.ink,8);});
asset('scope-note',440,170,g=>{rect(g,10,10,418,148,'#f8dc83',6);txt(g,'STOP AFTER:',35,57,30);for(let i=0;i<3;i++)line(g,[[45,89+i*18],[180+i%2*25,89+i*18]],C.ink,3);txt(g,'3 ROUGH SENTENCES',211,115,23,C.ink);});
asset('ifthen-note',520,150,g=>{rect(g,8,8,500,133,'#e6efe5',5);txt(g,'AFTER BREAKFAST',23,49,27);oval(g,85,94,24,28,'#e3c18b');line(g,[[107,81],[125,81],[125,104],[107,104]],C.ink,3);line(g,[[205,82],[286,82],[269,65]],C.green,6);line(g,[[286,82],[269,99]],C.green,6);txt(g,'WRITE 3 SENTENCES',304,47,24);rect(g,350,66,102,60,'#fff4d1',3);for(let i=0;i<3;i++)line(g,[[364,81+i*15],[435,81+i*15]],C.ink,2);});
asset('application-form',560,370,g=>{rect(g,10,10,535,345,'#edf3eb',8);rect(g,10,10,535,55,C.green,6);txt(g,'PORTFOLIO APPLICATION',42,48,35,'#fff');for(let i=0;i<3;i++){rect(g,35,91+i*52,28,28,'#fff8d7',3);line(g,[[40,104+i*52],[47,111+i*52],[59,97+i*52]],C.green,3);txt(g,['Three projects attached','Results and images added','Portfolio link checked'][i],83,116+i*52,29);}rect(g,140,276,286,55,C.gold,7);txt(g,'SEND APPLICATION',170,313,30);});
asset('car-front',1200,150,g=>{g.fillStyle=C.paper;g.fillRect(0,0,1200,150);rect(g,14,1,1165,82,'#c9ded7',16);oval(g,250,101,53,39,C.ink);oval(g,1005,101,53,39,C.ink);line(g,[[40,40],[1149,40]],'#8fafa4',3);});
asset('support-room',600,360,g=>{rect(g,48,110,137,108,'#d8e7e1',18);rect(g,391,110,137,108,'#d8e7e1',18);line(g,[[79,218],[69,320]]);line(g,[[152,218],[163,320]]);line(g,[[419,218],[409,320]]);line(g,[[501,218],[512,320]]);oval(g,289,194,74,17,'#e7bd7e');line(g,[[289,212],[289,315]]);});
asset('head-helper',150,150,g=>{oval(g,78,70,49,52);line(g,[[50,21],[73,17],[93,24]],C.ink,3);line(g,[[32,71],[20,81],[33,84]],C.ink,3);oval(g,46,66,13,10,'#fdfdfc');line(g,[[59,65],[83,62]],C.ink,2);oval(g,45,66,3,5,C.ink);g.beginPath();g.moveTo(39,100);g.quadraticCurveTo(49,108,64,99);g.stroke();});
asset('scarf-helper',85,60,g=>{rect(g,4,6,67,16,C.blue,4);g.fillStyle=C.blue;g.beginPath();g.moveTo(49,21);g.lineTo(69,48);g.lineTo(47,44);g.closePath();g.fill();g.stroke();});
import {createRequire} from 'node:module';const req=createRequire('/workspace/stickman-video-director/skills/directing-stickman-videos/package.json');const sharp=req('sharp');
await sharp('/workspace/scratch/task-avoidance-full/art/head-profile-worry.png').flop().toFile('/workspace/scratch/task-avoidance-full/art/head-profile-worry-right.png');
await sharp('/workspace/scratch/task-avoidance-full/art/scarf.png').flop().toFile('/workspace/scratch/task-avoidance-full/art/scarf-right.png');
// Content-matched icons: each visual identifies the actual obstacle/action.
for(let i=0;i<icons.length;i++)asset('icon-'+i,300,240,g=>{
 rect(g,10,10,279,215,i%3===0?'#f7e4ae':i%3===1?'#d8e9e2':'#e9ddd8',9);
 const page=()=>{rect(g,105,40,94,95,'#fff8dc',4);for(let j=0;j<3;j++)line(g,[[117,65+j*20],[184,65+j*20]],C.ink,2);};
 if(i===0){rect(g,79,64,142,77,C.gold,5);rect(g,79,45,58,25,C.gold,4);}
 else if(i===1||i===3){oval(g,147,84,43,42);oval(g,132,78,2.5,5,C.ink);oval(g,162,78,2.5,5,C.ink);g.beginPath();g.moveTo(125,103);g.quadraticCurveTo(148,i===1?87:121,169,103);g.stroke();if(i===3)line(g,[[202,67],[213,78],[235,48]],C.green,4);}
 else if(i===2){rect(g,93,39,69,105,'#eef4eb',3);line(g,[[143,88],[228,88],[210,70]],C.green,6);line(g,[[228,88],[210,106]],C.green,6);}
 else if(i===4){page();txt(g,'LATER',113,96,23,C.red);}
 else if(i===5){oval(g,147,86,51,47,'#edf3ee');txt(g,'?',127,113,73,C.blue);}
 else if(i===6){page();oval(g,158,83,30,29,'#dcebed');line(g,[[180,105],[215,136]],C.blue,7);}
 else if(i===7){rect(g,62,56,166,70,'#eef4ed',8);rect(g,230,76,15,28,C.ink,2);rect(g,71,65,23,52,C.red,3);}
 else if(i===8){page();line(g,[[85,110],[101,124],[137,83]],C.green,6);}
 else if(i===9||i===12){page();line(g,[[170,117],[216,55]],C.blue,9);line(g,[[166,125],[170,117]],C.ink,3);}
 else if(i===10){rect(g,80,49,139,70,'#cde3d9',13);rect(g,65,99,169,32,C.green,8);line(g,[[84,132],[80,148]]);line(g,[[217,132],[221,148]]);}
 else if(i===11){oval(g,112,94,24,29,'#e7c18a');line(g,[[136,78],[155,78],[155,103],[136,103]],C.ink,3);oval(g,190,75,33,32,'#f8f4df');line(g,[[190,53],[190,75],[210,75]],C.blue,3);}
 else if(i===13){for(let j=0;j<3;j++)for(let k=0;k<3;k++)rect(g,76+k*50+(j%2)*12,45+j*30,47,28,'#dcae97',2);}
 else if(i===14){line(g,[[80,90],[218,90],[186,59]],C.green,9);line(g,[[218,90],[186,122]],C.green,9);}
 else if(i===15){rect(g,104,48,91,91,C.red,6);}
 else if(i===16){oval(g,112,66,23,23);oval(g,182,66,23,23);line(g,[[112,91],[112,136],[140,112]]);line(g,[[182,91],[182,136],[154,112]]);txt(g,'?',213,94,43,C.green);}
 txt(g,icons[i],28,184,31,C.ink);
});
