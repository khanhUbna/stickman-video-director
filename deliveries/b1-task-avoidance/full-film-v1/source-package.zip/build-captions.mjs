import fs from 'node:fs';import {createRequire} from 'node:module';const require=createRequire('/workspace/stickman-video-director/skills/directing-stickman-videos/package.json');const {createCanvas,GlobalFonts}=require('@napi-rs/canvas');
const B='/workspace/scratch/task-avoidance-full';GlobalFonts.registerFromPath('/workspace/stickman-video-director/skills/directing-stickman-videos/assets/fonts/NotoSans.ttf','Subtitle');const ctx=createCanvas(1280,720).getContext('2d');ctx.font='600 34px Subtitle';
const source=fs.readFileSync(B+'/narration-full.txt','utf8'),words=JSON.parse(fs.readFileSync(B+'/words-full.json')).words;
function norm(s){s=s.toLowerCase().replace(/9[\s.:]*30/g,'ninethirty');for(const [a,b] of [['27','twentyseven'],['30','thirty'],['20','twenty'],['10','ten'],['9','nine'],['3','three'],['2','two'],['1','one']])s=s.replace(new RegExp('\\b'+a+'\\b','g'),b);return s.replace(/[^a-z0-9]/g,'');}
const manual=[
["Somehow, the task you care about most becomes the one thing you cannot touch.",["Somehow, the task you care about most","becomes the one thing you cannot touch."]],
["and wants to apply for a role at a smaller company where she'd have more responsibility.",["and wants to apply for a role at a smaller company","where she'd have more responsibility."]],
["One influential account of procrastination focuses on short-term mood repair.",["One influential account of procrastination","focuses on short-term mood repair."]],
["A task brings up discomfort, and avoiding it can offer relief right now—even when the delay makes things worse later.",["A task brings up discomfort,","and avoiding it can offer relief right now—","even when the delay makes things worse later."]],
["For Maya, closing the folder removes the uncomfortable feeling for a moment.",["For Maya, closing the folder","removes the uncomfortable feeling for a moment."]],
["Answering an easy email gives her something better: a small, visible win.",["Answering an easy email","gives her something better:","a small, visible win."]],
["That doesn't mean her brain has carefully chosen to ruin her future.",["That doesn't mean her brain has carefully chosen","to ruin her future."]],
["This is one reason caring deeply can make a task harder to approach.",["This is one reason caring deeply","can make a task harder to approach."]],
["Now you're asking yourself to build an entirely new life at nine-thirty at night.",["Now you're asking yourself","to build an entirely new life","at nine-thirty at night."]],
["You only need a way to keep the feeling from automatically becoming an instruction to leave.",["You only need a way to keep the feeling","from automatically becoming an instruction to leave."]],
["And when you slip, adding an insult usually doesn't clarify the next step.",["And when you slip,","adding an insult usually doesn't clarify the next step."]],
["A complicated system can become another very impressive way to avoid beginning.",["A complicated system can become","another very impressive way to avoid beginning."]]
];const overrides=new Map(manual.map(([a,b])=>[norm(a),b]));const drafts=[],fallback=[];
function split(text){text=text.trim();if(!norm(text))return;if(overrides.has(norm(text))){for(const p of overrides.get(norm(text))){if(ctx.measureText(p).width>1080)throw Error('Manual cue too wide: '+p);drafts.push(p);}return;}if(ctx.measureText(text).width<=1080){drafts.push(text);return;}let points=[];for(const m of text.matchAll(/[,;:—]\s*|\s+(?:and|but|because|while|when|without|before|after|rather than|even when|or|so that)\s+/g)){let i=/^[,;:—]/.test(m[0])?m.index+1:m.index;let first=text.slice(0,i).trim(),second=text.slice(i).trim();if(first.length>=20&&second.length>=12&&ctx.measureText(first).width<=1080)points.push(i);}let cut=points.at(-1);if(!cut){let i=text.lastIndexOf(' ');while(i>0&&ctx.measureText(text.slice(0,i)).width>1080)i=text.lastIndexOf(' ',i-1);if(i<=0)throw Error('Unbreakable caption');cut=i;fallback.push(text);}
 split(text.slice(0,cut));split(text.slice(cut));}
for(const para of source.split(/\n\s*\n/))for(const x of new Intl.Segmenter('en',{granularity:'sentence'}).segment(para))split(x.segment);
let stream='',map=[];for(let i=0;i<words.length;i++){let n=norm(words[i].word);for(let k=0;k<n.length;k++)map.push(i);stream+=n;}
let pos=0;const captions=[];
for(const text of drafts){let n=norm(text);if(stream.slice(pos,pos+n.length)!==n)throw Error(`Alignment mismatch at ${pos}: ${text} vs ${stream.slice(pos,pos+n.length+40)}`);let a=map[pos],b=map[pos+n.length-1];captions.push({start:words[a].start,end:words[b].end,text,word_first:a,word_last:b,width:ctx.measureText(text).width});pos+=n.length;}
if(pos!==stream.length)throw Error('Uncovered speech words');
for(let i=0;i<captions.length;i++){let next=captions[i+1]?.start??509.3;captions[i].end=Math.min(next-.025,captions[i].end+.17);if(captions[i].end<=captions[i].start)throw Error('Collapsed cue: '+captions[i].text);}
fs.writeFileSync(B+'/captions-draft.json',JSON.stringify(captions,null,2));fs.writeFileSync(B+'/captions-review.txt',captions.map((c,i)=>`${String(i).padStart(3)} ${c.start.toFixed(2)}–${c.end.toFixed(2)} | ${c.text}`).join('\n'));fs.writeFileSync(B+'/caption-audit.json',JSON.stringify({cues:captions.length,actual_aligned_words:words.length,all_normalized_words_covered:true,max_width:Math.max(...captions.map(c=>c.width)),fallbacks_requiring_review:fallback},null,2));console.log({cues:captions.length,fallback});
export {norm};
