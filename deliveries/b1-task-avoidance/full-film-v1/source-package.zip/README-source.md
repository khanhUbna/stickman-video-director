# Full B1 film source — Why You Avoid the Work That Matters Most

English 16:9 production, approximately 8:29, in the richer B1 line-art style approved through one-minute-v4. User explicitly authorized the complete film and title after approving the one-minute candidate. Main project API ceiling USD 0.50; receipts contain estimates only, never credential values. No YouTube upload.

## Reproduce without paid calls

The package includes the assembled native-rate narration WAV, actual aligned word timing, original local music/effects, final art PNGs, editable generators, storyboard, shot ledger, captions, provenance and QA. Place it at /workspace/scratch/task-avoidance-full and the directing-stickman-videos checkout at /workspace/stickman-video-director. Use Node 20+, FFmpeg/FFprobe, and `npm ci` inside `skills/directing-stickman-videos`. Paths can be adjusted for another machine.

All needed art PNGs are included. film-library.mjs optionally refreshes unchanged assets from /workspace/scratch/task-avoidance-color/art if present. It does not require that directory when packaged assets are available. The base art source and story-specific design-assets.mjs regenerate the original assets; do not overwrite a valid project blindly. The generators contain no untrusted external scene code.

    node build-captions.mjs
    node design-assets.mjs
    node build-film.mjs
    node check-rig.mjs
    node export-full.mjs
    bash master-audio.sh

The exporter uses the renderer's full-film engine API to produce the file and full-length evidence following the user's explicit authorization. It does not invent a CLI approval file or an independent reviewer. The CLI's preview command is capped at 60 seconds, so it is not used to disguise a full-length export as an accepted preview. The generated full-film report remains technical/pending independent reference-effect review. User approval of the one-minute style is distinct from acceptance of unseen full-film material. No reference-equivalence claim is made from source, hashes or geometry alone.

The raw engine output is `output/film.mp4`; `why-you-avoid-the-work-that-matters-most.mp4` is the final delivery master after loudness normalization. Video packets are copied unchanged; speech is never speed- or pitch-shifted. These files have separate hashes. Do not apply pre-master evidence hashes to the post-master file or invent a listening/visual acceptance. QA documents exactly which inspections occurred.

## Audio and paid adapter

`generate-audio.py` is integration source, not required for offline reproduction. Seven new tts-1/alloy chunks were generated, plus actual Whisper timestamps. The earlier approved 31-second opening was reused unchanged. An initially faulty context-prompted transcript for three chunks was rechecked once without prompt; exact normalized source text now matches all aligned words. Audio was not regenerated for that repair. No automatic retries were made. The WAV streams have an unspecified RIFF frame count; actual duration is measured using ffprobe or real PCM payload, never the streaming header's sentinel length.

The already-assembled narration WAV contains native-rate original PCM and 150ms chapter breaths. `words-full.json` holds the corresponding actual offsets. Remaining raw chapter WAVs are not duplicated in this bundle; hashes/receipts preserve provenance. `assemble-audio.py` and adapters document the original assembly but are not needed when the included narration-full.wav and words-full.json are present.

Original music, room texture and action sounds were synthesized locally. The WAVs are provided; no model download or third-party track is needed. Sparse causal foley is spotted in sound-script.json, with a deliberate brief background cut at the imagined verdict. Narration stays the priority.

## Sources and rights

See research/claim-audit.md and youtube-description-draft.md. Author manuscripts for the 2013 mood-regulation account and 2014 self-compassion study were retrieved and inspected from their institutional repository. They are cited and cautiously paraphrased; their PDFs/figures are not redistributed. The causal limitations, practical-experiment nature of ten minutes/three sentences, fictional Maya and absence of an invented job offer are explicit.

Original art, code, locally synthesized music/foley; runtime MIT and bundled Caveat/Noto Sans OFL notices included. Voice is AI-generated. Reference clips, credentials, .env files, dependency directories and personal account data are excluded. Thumbnail and description are drafts for the creator's review, not a publication action.
