#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/task-avoidance-minute
# Offline rebuild with existing audio; do not run generate-audio.py to reproduce.
node build-minute.mjs
node /workspace/stickman-video-director/skills/directing-stickman-videos/scripts/autopilot.mjs preview "$PWD/project.json" --seconds 60
ffmpeg -v error -i output/preview.mp4 -map 0:v:0 -map 0:a:0 -c:v copy -af loudnorm=I=-16:TP=-1.5:LRA=11 -ar 48000 -c:a aac -b:a 192k -t 60 -movflags +faststart one-minute-v4.mp4
ffmpeg -v error -i one-minute-v4.mp4 -f null -
