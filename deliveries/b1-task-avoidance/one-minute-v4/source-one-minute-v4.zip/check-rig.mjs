import fs from 'node:fs';import {keyState} from '/workspace/stickman-video-director/skills/directing-stickman-videos/scripts/autopilot-render.mjs';
const B='/workspace/scratch/task-avoidance-minute',p=JSON.parse(fs.readFileSync(B+'/project.json'));let maxJoint=0,maxHand=0,maxLength=0,samples=0;
function ends(l,t){const v=keyState(l,t),a=v.angle||0,w=v.w;const root=[v.x-Math.sin(a)*w/32,v.y+Math.cos(a)*w/32];return {root,tip:[root[0]+w*Math.cos(a),root[1]+w*Math.sin(a)],length:w};}
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
for(let i=0;i<p.shots.length;i++){const s=p.shots[i],find=n=>s.layers.find(l=>l.id===`s${i}-${n}`);if(!find('upperL'))continue;for(let t=0;t<s.end-s.start;t+=1/p.fps){samples++;
 for(const [a,b] of [['upperL','foreL'],['upperR','foreR'],['thighL','shinL'],['thighR','shinR']])maxJoint=Math.max(maxJoint,dist(ends(find(a),t).tip,ends(find(b),t).root));
 for(const [a,b] of [['foreL','handL'],['foreR','handR']]){const h=keyState(find(b),t);maxHand=Math.max(maxHand,dist(ends(find(a),t).tip,[h.x+13,h.y+11]));}
 for(const [n,expected] of [['upperL',100],['foreL',100],['upperR',100],['foreR',100],['thighL',91],['shinL',103],['thighR',91],['shinR',103]])maxLength=Math.max(maxLength,Math.abs(ends(find(n),t).length-expected));
 }}
const report={samples,max_elbow_knee_gap_design_px:maxJoint,max_hand_gap_design_px:maxHand,max_bone_length_error_design_px:maxLength,pass:maxJoint<2&&maxHand<2&&maxLength<1e-6,limits:'Geometry only; does not establish natural gait, acting quality, final occlusion, sound or independent acceptance.'};fs.writeFileSync(B+'/rig-QA.json',JSON.stringify(report,null,2));console.log(report);if(!report.pass)process.exit(1);
