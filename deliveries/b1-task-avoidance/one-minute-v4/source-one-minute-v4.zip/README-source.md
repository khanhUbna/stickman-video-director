# One-minute B1 story preview v4

A new, self-contained one-minute English adaptation of Why You Avoid the Tasks You Care About Most, requested by the user before the long-form film. Not the finished 8–10 minute film. Narration is a fictional Maya scenario; “maybe” presents an explanatory possibility, not a universal causal claim. The ten-minute exercise is an illustration, not a validated treatment threshold. No invented statistics or guaranteed channel growth.

## Picture and editing

23 actual shots: desk introduction, bent kitchen scrubbing, a portfolio page revealed, hesitation, phone closeups, passing time, emotional friction, concrete next step, writing, carrying the phone away, sitting, an imperfect page, a next-step note and return to work. Fine line art, near-white faint grid, localized original colored props/backgrounds and consistent green scarf identity. Authored side-profile heads and distinct seated/bent/standing/carrying states. Timed two-bone IK with fixed arm and leg lengths and matching hand targets. See shot-ledger.json and rig-QA.json. Geometry checks cannot establish natural acting or contact after occlusion; inspect moving playback.

## Audio, captions and exact duration

162-word English narration, native OpenAI tts-1/alloy, 59.2125 seconds. Existing source is included; reuse it. Add 0.7875-second ending hold for exactly 60 seconds, without speeding or stretching speech. Whisper word timestamps are actual source-audio measurements, mapped to 36 semantic one-line cues. Source normalization handles “10”/“Ten” and next-step compounds. build-minute.mjs checks exact normalized speech-word coverage and rejects mismatches.

The runtime's output/preview.mp4 is the pre-master technical candidate. one-minute-v4.mp4 is the delivery candidate: identical video bitstream, original-speed mixed audio normalized with FFmpeg loudnorm to improve listening level. This is a separate file with separate hashes. Do not apply the pre-master report's video hash or reference acceptance to the mastered delivery. Independent reference-effect review and actual picture/sound approval remain pending. No fake independent review or acceptance was recorded.

## Reproduce offline

Use Node 20+, FFmpeg/FFprobe and the existing directing-stickman-videos Skill dependencies (npm ci inside skills/directing-stickman-videos). Restore the source at /workspace/scratch/task-avoidance-minute and the repo at /workspace/stickman-video-director. All required final PNG assets are included in art/. The builder optionally refreshes unchanged baseline artwork from /workspace/scratch/task-avoidance-color/art when that directory exists; it uses the packaged art when it does not. Adjust absolute workspace/repo paths if using a different machine. Use finish.sh; inspect existing outputs first rather than overwriting blindly. generate-audio.py is credential-free adapter source, not needed for offline reproduction and not part of finish.sh. It makes paid requests only when media is absent; do not run it without cost authorization.

## Rights and boundaries

Original locally drawn art and original locally synthesized chord/pluck bed and room noise, with no third-party music recording or copied melody. Procedural tap/paper effects from the repository's MIT runtime. Caveat and Noto Sans OFL notices included. Voice is AI-generated. Baseline reference videos are not redistributed. No secrets, .env, tokens or dependency caches. No YouTube publication.

Source package includes the pre-master manifest, original narration/audio, alignment, editable generator, art, original music/ambience, ledger, rig check, loudness finishing recipe and QA. This package is a technical candidate, not a guarantee of sample-equivalent aesthetics or audience retention.
