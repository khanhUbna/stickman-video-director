# B1 task avoidance — reconstructed sample v2

This is a 31-second English preview, not the finished 8–10 minute film. The earlier preview's audio/video files were absent after the cloud environment was restored, so this candidate was regenerated from the retained script with the user's approved fees and repository delivery request. It is a different recording/export and awaits review.

## Files and reuse

- project.json: B1 shared runtime manifest, exact asset paths, captions and native-rate voice.
- sample-voice.wav: already generated OpenAI tts-1/alloy speech; reuse unchanged.
- alignment.json: actual Whisper word timestamps. Build checks lexical caption coverage.
- build-sample.mjs: original art and manifest generation, Node 20+; uses the installed Skill dependencies.
- original-bed.wav and room.wav: original local synthesis, no third-party recording.
- openai-sample.py: credential-free integration source; do not run unless media is missing and API costs are authorized. It reads OPENAI_API_KEY from the environment and makes no automatic retries.

Use repository khanhUbna/stickman-video-director, baseline commit 2966a697361ce05faa74e0dbc36c07f8f331bab0. Install Node dependencies with npm ci in skills/directing-stickman-videos. The builder's paths refer to /workspace/scratch/task-avoidance and the installed Skill; adjust them for another machine. With packaged audio/assets present, no OpenAI call is needed. Run:

    node build-sample.mjs
    node /workspace/stickman-video-director/skills/directing-stickman-videos/scripts/autopilot.mjs preview /workspace/scratch/task-avoidance/project.json --seconds 40

Do not overwrite existing outputs without inspecting them. Full-film production requires the exact candidate's actual visual/audio approval and the Skill's independent reference-effect review. No acceptance or independent reviewer has been fabricated. B1 target comparison and complete listening remain pending; encoded diagnostics do not prove artistic equivalence.

## Rights and privacy

Original story art, original synthesized instrumental bed and room noise. Runtime procedural tap/paper SFX: repository MIT license. Bundled Caveat/Noto Sans: OFL licenses included. The speech is AI-generated. Baseline reference media are not redistributed. No API values, environment files, credentials or dependency cache are included.

## Research status

The retained full-film script and plan are drafts. Bibliography in research-notes.md contains leads that still require direct verification; publisher requests were blocked. An initially tried White Rose record 91754 was unrelated and is not evidence. No full-film scientific claims have been newly recorded in this preview. Official pricing was retrieved during the preceding run: tts-1 USD 15 per million characters, Whisper USD 0.006/min. Cost file contains estimates, not a billing invoice.
