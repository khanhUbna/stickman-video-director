# B1 production proposal — review draft, not production approval

Deliverable: English 8–10 minutes, native 16:9, 1920×1080 / 30fps. Narration: 1,293 words, estimated 8:20–9:35 at 135–155 words/minute. Actual TTS dictates editing; no rate stretching or filler to reach duration. Maya is an invented composite, not a participant or testimonial.

Voice proposal: OpenAI `tts-1`, `alloy`, native rate, no added style instruction. Sample determines suitability. Preserve accepted recordings; later chapters generated in manageable chunks with exact approved text. Request cost authorization before any synthesis. AI-generated voice disclosure in delivery notes/video description draft.

B1 look: near-white faint-grid paper, fine irregular black outlines; slender expressive figures with whole-body acting, warm yellow/red/green prop accents. Maya has a consistent small side hair tuft and round head, single-line torso/limbs; distinct gaze, posture and expressions across beats. Hand-lettered Caveat scene headings; Noto Sans 600 access captions, one semantic line, 34 units on 1280-wide design plane. Real screenshots only when readable and necessary; no invented research charts or illustrated UI passed off as actual footage.

## Scene sequences (provisional times)

Actual shot boundaries follow native speech and aligned words. Each sequence contains 4–7 shots, roughly 42–50 shots total. Within a shot, meaningful picture state develops at least every 2.5s; use acting, prop contact and sequential information, not camera drift or subtitle turnover. Approximate chapters are editorial planning only.

| Sequence | Approximate range | Shots / specific visual progression | Sound and transition |
|---|---|---|---|
| Clean kitchen | 0:00–0:42 | 1: presentation folder opens, career-opportunity note revealed; Maya reaches then withdraws. 2: dish cloth scrubs a plate as unopened folder remains in frame. 3: message/weather/app cards form a detour, hands operate each prop. 4: split view of task and emotion, question resolves to folder closeup. | Dry mouse click, cloth scrape, notification once; light original music bed. Paper match cut to portfolio. |
| Meet Maya | 0:42–1:43 | 5: desk and prospective role; 6: portfolio requirements revealed one at a time; 7: tomorrow notes pile; 8: colleague handoff and spreadsheet rearrangement; 9: shoulder/gaze/head closeup; 10: project page becomes an illustrated judgment stamp, clearly metaphorical. | Paper, pencil and chair foley. Reduce music for “verdict”; no horror sting. |
| Relief loop | 1:43–2:48 | 11: folder–discomfort–escape–relief loop develops in speech order; 12: email completion yields small tick; 13: two bills on counter with near/future costs; 14: calendar advances and pressure accumulates; 15: importance adds emotional stakes, no data graph. | Close click gives brief quiet; ticks restrained, rising but soft harmonic bed. Loop arrow carries into next diagram. |
| Name friction | 2:48–3:57 | 16: three different obstacles, revealed separately; 17: career fog becomes specific file; 18: private draft vs send-button hesitation; 19: depleted worker after meetings; 20: three matched responses; 21: missing-information waiting versus avoidance, visibly distinct. | Distinct paper/card sounds, no pop on every label. Rest beat drops rhythmic layer. |
| First move | 3:57–5:04 | 22: finish line wears fake mustache; 23: campaign folder → one project → three sentences; 24: “impressive” erased, “rough” retained; 25: expense list / question / shoes three brief environments; 26: nested decisions separate into one concrete action; 27: ten-minute timer introduced as experiment, with real options at end. | Small comic pencil squeak, keyboard taps at contact, soft timer click without repeated ticking. |
| Feeling passenger | 5:04–6:26 | 28: first sentence, dissatisfied face and reaching phone hand; 29: worry named without erasing text; 30: next sentence appears as hand types; 31: discomfort passenger remains seated while Maya steers; 32: insult stamp versus curious question; 33: detour map returns to path. | Pause rhythmic bed at phone reach, retain room tone; turn signal only during car metaphor, no road danger implied. |
| Cue and obstacle | 6:26–7:45 | 34: vague tomorrow balloon drifts; 35: breakfast cue, chair, phone placed in bedroom; 36: if–then link builds; 37: modest source card, no effect-size claim; 38: urge recorded on paper and sentence completed; 39: one cue/action/obstacle cards simplify overgrown planning machine. | Breakfast cup, distant phone vibration, pencil and keyboard. Bed becomes less busy as plan simplifies. |
| Return and ending | 7:45–9:00 | 40: rough page exists, awkward heading visible; 41: next-action note left on desk; 42: one week calendar and checked link; 43: full hand-to-send contact then delivery state, no fabricated job offer; 44: three viewer questions revealed; 45: support caveat framed calmly; 46: return to opening folder, Maya opens it while cloth rests. | Keyboard/send click; bed softens beneath support line. Resolve original theme; folder sound closes callback. |

## Exact 30-second sample scope

Use the opening narration from “You have a presentation…” through “What happens when I get close to this particular task?” (~80 words; native voice may run longer than 30s). After approval, synthesize the full opening chunk once, align it, then select a natural 30-second preview endpoint. No clipping mid-word; if exact content needs 32–35s, present that duration honestly or propose a script trim before recording. Sample includes voice, captions, original bed, causal SFX, distinct acting and prop interaction. No full-film authorization inferred from technical output.

## Audio and rights

Compose an original restrained instrumental bed locally (soft keyboard/mallet-like tones, no sample-library melody), with section variation and deliberate rests. Produce original foley/synthesized effects for paper, cloth, typing, clicks and timer; document generation method, files and hashes. Do not claim an external track is royalty free without its asset-specific license. Keep a rights manifest and bundled font licenses. Music/SFX remain below voice; inspect encoded loudness, true peak, joins, mono compatibility and intelligibility. No unauthorized third-party recordings or existing reference music in output.

## Cost proposal (USD; not yet authorized)

Provisional calculation using tts-1's historically published $15 / 1M input characters; live pricing page is network-blocked and must be rechecked before a charge. Script is ~7,815 narration characters: $0.117 for one full pass. Opening chunk ~600–750 characters: ~$0.009–0.012. If sample is retained in final, do not bill/generate it again. If replaced, count it separately.

Optional OpenAI whisper-1 transcription/alignment estimate at historical $0.006/minute: ~9 minutes = $0.054; 30-second sample ~$0.003. Verify timestamp granularity and captions against actual speech; no proportional text timings. Local alignment may avoid this charge if a suitable installed model is available; no substitute timing claimed yet.

Estimated initial total: ~$0.17–0.20. Proposed limits: sample stage $0.03; entire project including sample and bounded repairs $0.50. Stop before exceeding either approved cap. No billable image API planned: original layered art/code animation; if raster generation becomes necessary, propose cost before use. Local render, music composition and foley add $0 API cost; platform compute charges, taxes and currency conversion are not included. These are estimates, not a provider quote.

## Validation and delivery

Before sample production, inspect actual B1 baseline and character acting reference; compare real candidate playback, not only contact sheets. Sample and final each require independent reference-effect review; production author must not invent a reviewer/pass. Human independent review can accompany the user's sample review; do not represent technical checks as aesthetic approval.

Final checks: full FFmpeg decode, ffprobe duration/video/audio, beginning/middle/end and all-shot visual review, caption-word coverage and actual speech sync, one-line caption bounds, meaningful action gaps, source/license manifest, full mix review. Export MP4, SRT, VTT and source ZIP (script, sources, editable assets, timeline, cue ledger, licenses, QA and reproducible commands; exclude secrets and dependency caches).

Google Drive tools/auth are not available in this session. Do not claim upload, create a fake Drive link or make a folder public. User destination and an authenticated upload capability are required before Drive handoff. Local files can be delivered while this is resolved. No YouTube upload or publication is authorized.
