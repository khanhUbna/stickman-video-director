# Research and claim audit — direct source verification pending

All external source fetches below were blocked by proxy policy (403 CONNECT), not evaluated as missing publications. Bibliography and cautious paraphrases are supplied from established literature knowledge, not represented as newly read full text. Before recording factual narration, retrieve sources and verify author/title/year and the mapped claims; revise claims and return for approval if substantive changes are necessary. No invented statistics, direct quotations, neurological mechanism or causal inference from correlation is used.

1. Sirois, F. M., & Pychyl, T. A. (2013). Procrastination and the Priority of Short-Term Mood Regulation: Consequences for Future Self. Social and Personality Psychology Compass, 7(2), 115–127. https://doi.org/10.1111/spc3.12011
   Maps to chapters 3 and 6: emotion regulation/mood repair as one influential account, not universal cause. Do not claim caring necessarily causes avoidance.
2. Steel, P. (2007). The Nature of Procrastination: A Meta-Analytic and Theoretical Review of Quintessential Self-Regulatory Failure. Psychological Bulletin, 133(1), 65–94. https://doi.org/10.1037/0033-2909.133.1.65
   Maps to chapter 4: task aversiveness/delay and distinction between harmful delay and strategic waiting. Proposed examples are illustrations, not study observations.
3. Gollwitzer, P. M., & Sheeran, P. (2006). Implementation Intentions and Goal Achievement: A Meta-analysis of Effects and Processes. Advances in Experimental Social Psychology, 38, 69–119. https://doi.org/10.1016/S0065-2601(06)38002-1
   Maps to chapter 7: cue-action plans show average benefits across goals; no procrastination-specific guarantee or invented effect size.
4. Sirois, F. M. (2014). Procrastination and Stress: Exploring the Role of Self-compassion. Self and Identity, 13(2), 128–145. https://doi.org/10.1080/15298868.2013.763404
   Context for chapter 6; associations do not establish that compassion alone cures procrastination. Script frames it as a practical response, not a treatment claim.

Ten-minute window and rough-three-sentence exercise are editorial experiments, not thresholds demonstrated by these studies. Maya is a fictional composite. Explanatory passenger/bills/folder metaphors are not brain anatomy. Professional-support line avoids diagnosis.

Pricing source to verify: https://developers.openai.com/api/docs/pricing — fetch blocked. Cost plan marks rates provisional.

Connection evidence: network secret state ready and current, forwarding only api.openai.com; authenticated GET /v1/models/tts-1 returned HTTP 200 with model tts-1. No POST /audio/speech, paid generation or transcription was performed. Metadata success does not establish TTS synthesis permission, quota or billing readiness.
