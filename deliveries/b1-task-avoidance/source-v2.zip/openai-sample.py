import os,json,urllib.request,pathlib,sys,wave
p=pathlib.Path(__file__).parent
text=(p/'script-en.md').read_text().split('## 1. The clean kitchen')[1].split('Because sometimes')[0].strip()
(p/'sample-narration.txt').write_text(text)
if not (p/'sample-voice.wav').exists():
 req=urllib.request.Request('https://api.openai.com/v1/audio/speech',data=json.dumps({'model':'tts-1','voice':'alloy','input':text,'response_format':'wav','speed':1}).encode(),headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=90) as r:(p/'sample-voice.wav').write_bytes(r.read())
 except urllib.error.HTTPError as e:print('Speech HTTP',e.code);sys.exit(1)
 (p/'cost.json').write_text(json.dumps({'tts_model':'tts-1','voice':'alloy','characters':len(text),'speech_estimate_usd':len(text)*15/1e6,'version':'reconstructed sample v2; old audio unavailable after environment snapshot restore','authorization':'User approved sample cap USD 0.03 and full project cap USD 0.50; sample upload to selected GitHub repository authorized','previous_sample_estimate_usd':.010819,'automatic_retries':False},indent=2))
 print('Saved native-rate alloy speech')
else:print('Reuse existing speech')
if (p/'alignment.json').exists():sys.exit('Reuse existing word timestamps')
boundary='stickmanSampleBoundary';parts=[]
for name,value in [('model','whisper-1'),('response_format','verbose_json'),('language','en'),('timestamp_granularities[]','word')]:parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+name+'"\r\n\r\n'+value+'\r\n').encode())
parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="file"; filename="sample.wav"\r\nContent-Type: audio/wav\r\n\r\n').encode()+(p/'sample-voice.wav').read_bytes()+b'\r\n');parts.append(('--'+boundary+'--\r\n').encode())
req=urllib.request.Request('https://api.openai.com/v1/audio/transcriptions',data=b''.join(parts),headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'multipart/form-data; boundary='+boundary})
try:
 with urllib.request.urlopen(req,timeout=90) as r:(p/'alignment.json').write_bytes(r.read())
except urllib.error.HTTPError as e:print('Alignment HTTP',e.code);sys.exit(1)
print('Saved actual audio word timestamps')
