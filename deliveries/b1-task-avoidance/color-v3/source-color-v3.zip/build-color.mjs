import './build-base.mjs';
import fs from 'node:fs';import {createRequire} from 'node:module';const require=createRequire('/workspace/stickman-video-director/skills/directing-stickman-videos/package.json');const {createCanvas,GlobalFonts}=require('@napi-rs/canvas');
const base='/workspace/scratch/task-avoidance-color';const C={ink:'#23333b',navy:'#264758',gold:'#f0bb37',green:'#4a9c86',red:'#e37d66',blue:'#659bb0',paper:'#fdfdfc'};
GlobalFonts.registerFromPath('/workspace/stickman-video-director/skills/directing-stickman-videos/assets/fonts/Caveat.ttf','Hand');
function make(name,w,h,draw){const c=createCanvas(w,h),g=c.getContext('2d');g.strokeStyle=C.ink;g.fillStyle=C.ink;g.lineWidth=3;g.lineCap='round';g.lineJoin='round';draw(g);fs.writeFileSync(`${base}/art/${name}.png`,c.toBuffer('image/png'));}
function line(g,pts,color=C.ink,width=3){g.strokeStyle=color;g.lineWidth=width;g.beginPath();g.moveTo(...pts[0]);for(const p of pts.slice(1))g.lineTo(...p);g.stroke();g.strokeStyle=C.ink;g.lineWidth=3;}
function rect(g,x,y,w,h,fill,r=8){g.beginPath();g.roundRect(x,y,w,h,r);g.fillStyle=fill;g.fill();g.stroke();}
function oval(g,x,y,rx,ry,fill=C.paper){g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);g.fillStyle=fill;g.fill();g.stroke();}
function text(g,s,x,y,size=30,color=C.ink){g.font=`${size}px Hand`;g.fillStyle=color;g.fillText(s,x,y);}
make('office-color',650,310,g=>{
 rect(g,55,15,335,135,'#e8f0f1');line(g,[[222,16],[222,147]],'#a6bdc1',2);line(g,[[57,82],[388,82]],'#a6bdc1',2);
 for(let i=0;i<5;i++){g.fillStyle=i%2?'#b2c8ca':'#ccdad9';g.fillRect(76+i*58,90-i*6,38,55+i*6);}
 rect(g,18,175,605,18,'#e8ba79',3);line(g,[[46,193],[40,300]]);line(g,[[590,193],[598,300]]);
 rect(g,150,85,235,88,C.navy,4);rect(g,160,95,215,67,'#f1f5f2',1);text(g,'PRESENTATION',181,137,28);line(g,[[260,174],[260,184]]);
 rect(g,405,135,130,40,C.gold,4);text(g,'NEXT ROLE',419,164,25);
 rect(g,48,126,47,48,C.green,5);line(g,[[68,125],[52,94],[65,104]],C.green,5);line(g,[[69,124],[92,89],[83,100]],C.green,5);
 oval(g,555,148,19,25,'#c7dbe2');line(g,[[571,138],[588,138],[588,157],[572,157]]);
});
make('kitchen-color',650,330,g=>{
 rect(g,45,45,320,120,'#e4efeb',2);for(let x=65;x<350;x+=60)line(g,[[x,46],[x,162]],'#c4d8ce',1.5);for(let y=75;y<160;y+=35)line(g,[[46,y],[362,y]],'#c4d8ce',1.5);
 rect(g,20,162,605,22,'#e8ba79',3);rect(g,36,185,571,132,'#f6e7cd',2);for(let x=36;x<607;x+=190){line(g,[[x,186],[x,314]]);line(g,[[x+140,203],[x+160,203]],C.navy,4);}
 oval(g,330,162,91,13,'#d7e6e8');line(g,[[400,141],[400,104],[430,104],[430,127]],C.blue,5);
 rect(g,70,88,105,70,C.gold,4);text(g,'UNOPENED',77,129,22);oval(g,220,149,33,9,'#f4f6ee');
 rect(g,470,99,34,61,C.green,5);line(g,[[481,99],[481,86],[505,86]],C.green,4);text(g,'soap',473,137,16);
});
make('folder-color',360,280,g=>{rect(g,28,60,290,180,C.gold,8);rect(g,28,35,110,36,C.gold,5);rect(g,58,81,230,126,'#fff9e9',3);text(g,'THE BIG TASK',72,131,34);text(g,'still waiting...',83,174,28);rect(g,266,157,40,47,C.red,5);text(g,'!',280,190,32,'#fff');});
make('message-color',380,285,g=>{rect(g,20,30,330,208,'#e2eee7');rect(g,20,30,330,45,C.green);text(g,'ONE QUICK REPLY',43,61,28,'#fff');oval(g,61,113,16,16,C.gold);line(g,[[96,104],[309,104]],C.navy,5);line(g,[[96,124],[253,124]],'#9db6ab',4);rect(g,78,151,238,51,'#fff');text(g,'Thanks! Will do.',95,186,30);line(g,[[60,239],[60,262],[91,239]]);});
make('weather-color',380,285,g=>{rect(g,25,20,325,240,'#dcebf0');text(g,'TOMORROW',71,60,32,C.navy);oval(g,125,132,34,34,C.gold);for(let i=0;i<8;i++){const a=i*Math.PI/4;line(g,[[125+45*Math.cos(a),132+45*Math.sin(a)],[125+56*Math.cos(a),132+56*Math.sin(a)]],C.gold,4);}text(g,'A perfectly useful detour.',57,231,24);oval(g,229,159,44,21,'#f5f8f4');oval(g,208,148,23,22,'#f5f8f4');oval(g,239,140,30,25,'#f5f8f4');});
make('notes-color',380,285,g=>{rect(g,40,25,290,230,'#fff0bb');rect(g,40,25,290,40,C.gold);text(g,'THE PERFECT APP',63,55,30,C.navy);for(let i=0;i<4;i++){rect(g,67,91+i*34,15,15,C.green,2);line(g,[[96,98+i*34],[286,98+i*34]],i%2?C.blue:C.navy,3);}text(g,'researching ≠ starting',61,242,25);});
make('wall-color',400,320,g=>{for(let i=0;i<6;i++){rect(g,40+i*10,35+i*27,288,28,i%2?'#f4d4c9':'#d5e5e3',3);}text(g,'What is getting in the way?',30,277,29,C.navy);});
make('scarf',85,60,g=>{rect(g,4,6,67,16,C.green,4);g.fillStyle=C.green;g.beginPath();g.moveTo(49,21);g.lineTo(69,48);g.lineTo(47,44);g.closePath();g.fill();g.stroke();});
make('highlight',1070,54,g=>{g.fillStyle='#f5df9d';g.beginPath();g.moveTo(8,9);g.lineTo(1050,4);g.lineTo(1059,40);g.lineTo(3,49);g.closePath();g.fill();});
make('paper-action',230,200,g=>{rect(g,30,15,165,173,'#fff8dd',4);rect(g,45,33,135,24,C.green,2);text(g,'FIRST DRAFT',50,51,21,'#fff');for(let i=0;i<4;i++)line(g,[[48,82+i*22],[171-(i%2)*35,82+i*22]],'#768d91',2);});
const p=JSON.parse(fs.readFileSync(base+'/project.json'));for(const [i,s] of p.shots.entries()){
 const head=s.layers.find(x=>x.id==='head'+i),body=s.layers.find(x=>x.id==='body'+i),arm=s.layers.find(x=>x.id==='arm'+i),prop=s.layers.find(x=>x.id==='prop'+i),title=s.layers.find(x=>x.type==='text');
 const map=['office-color','kitchen-color','kitchen-color','message-color','weather-color','notes-color','folder-color','wall-color','folder-color'];prop.path='art/'+map[i]+'.png';prop.x=i===6||i===8?390:90;prop.y=i<3?236:230;prop.w=i<3?650:i===6||i===8?390:520;
 // Rearrange the same story cast rather than changing identity. Short object closeups alternate with full actor scenes.
 head.keys=[{t:0,angle:i===2?-.04:0},{t:Math.min(1.2,s.end-s.start),angle:i===2?.035:i===8?-.035:.025},{t:s.end-s.start,angle:0}];
 const scarf={type:'image',path:'art/scarf.png',id:'scarf'+i,x:817,y:324,w:65};s.layers.splice(s.layers.indexOf(body)+1,0,scarf);
 s.layers.unshift({type:'image',id:'highlight'+i,path:'art/highlight.png',x:72,y:101,w:i===8?1080:Math.min(1040,title.text.length*27),h:38});title.color=C.navy;
 if(i===0){const span=s.end-s.start;s.layers.push({type:'image',id:'document-reach',path:'art/paper-action.png',x:505,y:294,w:155,keys:[{t:0,y:333,alpha:0},{t:.7,y:300,alpha:1},{t:Math.min(1.5,span),y:280},{t:span,y:294}],motion:{role:'prop',reason:'The unopened presentation is brought forward as a concrete career opportunity'}});}
 if(i===6||i===8){prop.keys=[{t:0,x:390},{t:(s.end-s.start)*.45,x:426},{t:s.end-s.start,x:390}];prop.motion={role:'prop',reason:'The important folder approaches the hesitating hand and retreats, visualizing avoidance'};}
 if(i===7){const cross=s.layers.find(x=>x.id==='crossout');cross.color=C.red;cross.lineWidth=6;}
}
p.reference_review.capability.environment='Codex Cloud; user-requested richer B1 color accents; retained original-rate audio; independent visual review pending';
fs.writeFileSync(base+'/project.json',JSON.stringify(p,null,2));console.log('Color candidate created; existing audio reused; no API calls');
