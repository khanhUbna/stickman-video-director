"""Native landscape story animation; original scenery and local causal action."""
from pathlib import Path
from functools import lru_cache
import json,math,bisect,subprocess,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import draw as Q
B=Path(__file__).resolve().parent;O=B/'output';O.mkdir(exist_ok=True);W,H=1280,720;FPS=30
T=json.loads((B/'timeline.json').read_text());C=T['cues'];D=math.ceil(T['duration']*FPS)/FPS;START=[r['start'] for r in C]
CAP=json.loads((O/'captions.json').read_text());CS=[c['start'] for c in CAP];WORDS=json.loads((O/'words.json').read_text())['words']
INK=Q.INK;TEAL=Q.TEAL;GOLD=Q.GOLD;CREAM=Q.CREAM;BLUE=Q.BLUE;SOIL=Q.SOIL;CORAL=Q.CORAL
def txt(g,xy,s,n=28,c=INK,anchor='mm'):Q.text(g,xy,s,n,c,anchor)
def label(g,x,y,s,n=22,c=TEAL):
 width=Q.font(n).getlength(s);Q.box(g,(x-width/2-14,y-19,x+width/2+14,y+19),CREAM,INK,2,r=8);txt(g,(x,y),s,n,c)
def event(r,word,fraction=.5):
 return next((w['start'] for w in WORDS if w['cue']==r['id'] and w['word'].lower()==word.lower()),r['start']+r['duration']*fraction)
def backdrop(g,t,ground=480,soil=False):
 Q.box(g,(25,90,1255,612),'#e5f1ee',INK,3)
 Q.ell(g,(-180,340,850,1000),'#c7e0c2');Q.ell(g,(600,330,1550,1000),'#d9e8c7')
 Q.box(g,(26,ground,1254,611),SOIL if soil else '#d8c49c',r=0);Q.line(g,[(27,ground),(1253,ground)],'#5d866c',5)
 if soil:
  for j in range(50):
   x=40+(j*131)%1180;y=ground+12+(j*29)%max(10,int(590-ground));Q.ell(g,(x,y,x+7+(j%4)*3,y+3+(j%3)*2),'#9f8265')
def strike(g,x,top,bottom,on=True):
 if on:
  pts=[(x,top),(x-35,top+(bottom-top)*.28),(x+14,top+(bottom-top)*.30),(x-45,top+(bottom-top)*.64),(x+4,top+(bottom-top)*.60),(x,bottom)];Q.line(g,pts,INK,15);Q.line(g,pts,GOLD,9);Q.line(g,pts,'#fff1b3',3)
def paths(g,x,y,t,u=1,depth=240,span=400):
 raw=[[(0,0),(-.20,.13),(-.54,.20),(-1,.35)],[(0,0),(.18,.10),(.50,.22),(1,.33)],[(0,0),(-.12,.40),(-.02,.65),(-.26,1)],[(0,0),(.20,.40),(.45,.65),(.69,1)],[(0,0),(-.28,.33),(-.58,.62),(-.88,.88)]]
 out=[]
 for j,ps in enumerate(raw):
  ps=[(x+dx*span,y+dy*depth) for dx,dy in ps];out.append(ps);Q.line(g,Q.partial(ps,u),INK,12);Q.line(g,Q.partial(ps,u),GOLD,6)
  for k in [0,1]:
   p=Q.along(ps,((t*.30+j*.11+k*.45)%1)*u);Q.ell(g,(p[0]-4,p[1]-4,p[0]+4,p[1]+4),'#fff4c0')
 return out
@lru_cache(None)
def asset(name,width):
 im=Image.open(B/f'art/{name}.png').convert('RGBA');return im.resize((width,round(im.height*width/im.width)),Image.Resampling.LANCZOS)
CAST=[]
def cow(im,x,base,t,width=360,alarmed=False,travel=0,walking=False):
 spr=asset('cow-alarmed' if alarmed else 'cow-normal',width);s=width/400;xx=x;yy=base+1.7*s*math.sin(t*2);left=xx-width/2;top=yy-spr.height;g=ImageDraw.Draw(im)
 Q.ell(g,(x-width*.25,base+65*s,x+width*.47,base+83*s),'#9eb4a3')
 # Four separately solved chains; roots are inside the visible belly.
 records=[];supports=[]
 for j,f in enumerate([.40,.46,.74,.80]):
  root=np.array([left+f*width,top+.87*spr.height]);phase=(abs(travel)/(84*s)+(0 if j in [0,3] else .5))%1
  dx=84*s*(.3-phase);lift=0
  if phase>.6:dx=(-.3+.6*Q.ease((phase-.6)/.4))*84*s;lift=19*s*math.sin(math.pi*(phase-.6)/.4)
  foot=np.array([left+f*width+(dx if walking else (-9 if j%2 else 7)*s),base+72*s-(lift if walking else 0)]);ch=Q.ik(root,foot,57*s,1 if j<2 else -1);Q.line(g,ch,'#607079' if j%2==0 else INK,max(3,round(9*s)));Q.box(g,(foot[0]-9*s,foot[1]-3*s,foot[0]+12*s,foot[1]+9*s),INK,r=3);records.append(ch);supports.append(not walking or phase<=.6)
 tailroot=(left+.90*width,top+.59*spr.height);Q.line(g,[tailroot,(left+width+22*s,top+.58*spr.height),(left+width+35*s,top+.71*spr.height+14*s*math.sin(t*3))],INK,max(3,round(6*s)))
 im.alpha_composite(spr,Q.p((left,top)));CAST.append({'time':t,'cast':'cow','world_x':x,'travel':travel,'legs':[{'joints':ch.tolist(),'planted':supports[j]} for j,ch in enumerate(records)],'max_bone_error':max(abs(np.linalg.norm(ch[i+1]-ch[i])-57*s) for ch in records for i in [0,1])})
 return ImageDraw.Draw(im)
def sand(im,x,y,t,width=180,alarmed=False):
 spr=asset('sand-alarmed' if alarmed else 'sand-normal',width);g=ImageDraw.Draw(im);left=x-width/2;top=y-spr.height;scale=width/180
 Q.ell(g,(x-80*scale,y+47*scale,x+80*scale,y+65*scale),'#bbaa86')
 for k in [-1,1]:
  root=(x+k*15*scale,y-30*scale);foot=(x+k*29*scale,y+50*scale);ch=Q.ik(root,foot,46*scale,k);Q.line(g,ch,INK,5);Q.line(g,[foot,(foot[0]+13*scale,foot[1])],INK,6)
 for k in [-1,1]:
  root=(x+k*width*.33,y-spr.height*.43);hand=(x+k*width*.7,y-spr.height*.3+10*scale*math.sin(t*3+k));ch=Q.ik(root,hand,65*scale,k);Q.line(g,ch,INK,5);Q.ell(g,(hand[0]-6,hand[1]-6,hand[0]+6,hand[1]+6),CREAM,INK,2)
 im.alpha_composite(spr,Q.p((left,top)));return ImageDraw.Draw(im)
def car(g,cx,y,t,s=1,kind='closed',talk=False,circuit=False,windows=1,damage=0,moving=False):
 # Wheels stay attached to the same body; occupants are neutral diagrams.
 pts=[(cx-260*s,y+75*s),(cx-250*s,y-15*s),(cx-180*s,y-38*s),(cx-115*s,y-140*s),(cx+110*s,y-140*s),(cx+185*s,y-40*s),(cx+250*s,y-17*s),(cx+266*s,y+75*s)]
 if kind=='open':pts=[(cx-240*s,y+75*s),(cx-240*s,y-5*s),(cx+240*s,y-5*s),(cx+250*s,y+75*s)]
 Q.poly(g,pts,'#56a9bf',INK,5)
 if kind!='open':
  if kind=='convertible':Q.poly(g,[(cx-178*s,y-40*s),(cx-112*s,y-140*s),(cx+111*s,y-140*s),(cx+183*s,y-40*s)],'#e5f1ee',None)
  else:
   Q.poly(g,[(cx-160*s,y-43*s),(cx-100*s,y-124*s),(cx-12*s,y-124*s),(cx-12*s,y-43*s)],'#c3e6e8',INK,3);Q.poly(g,[(cx+5*s,y-43*s),(cx+5*s,y-124*s),(cx+100*s,y-124*s),(cx+162*s,y-43*s)],'#c3e6e8' if windows>.9 else '#e8f2e9',INK,3)
   if windows<.9:Q.poly(g,[(cx+5*s,y-43*s),(cx+5*s,y-43*s-80*s*windows),(cx+100*s,y-43*s-80*s*windows),(cx+162*s,y-43*s)],'#a9d8df',INK,2)
 Q.line(g,[(cx-10*s,y-35*s),(cx-10*s,y+55*s)],INK,3);Q.line(g,[(cx+26*s,y-25*s),(cx+52*s,y-25*s)],INK,4)
 for k in [-1,1]:
  x=cx+k*165*s;h=52*s;Q.ell(g,(x-52*s,y+68*s-h,x+52*s,y+68*s+h),INK);Q.ell(g,(x-29*s,y+39*s,x+29*s,y+97*s),'#a7bec0',INK,3)
  for j in range(5):
   a=(t*2 if moving else 0)+j*math.tau/5;Q.line(g,[(x,y+68*s),(x+22*s*math.cos(a),y+68*s+22*s*math.sin(a))],'#6e8f9b',max(2,round(3*s)))
  if damage>.2 and k==1:Q.line(g,[(x+35*s,y+40*s),(x+44*s,y+56*s),(x+35*s,y+75*s),(x+44*s,y+91*s)],CORAL,3)
 if talk:Q.face(g,cx,y-82*s,t,.7*s,True)
 elif circuit:
  Q.ell(g,(cx+35*s,y-113*s,cx+64*s,y-84*s),CREAM,INK,2);Q.line(g,[(cx+49*s,y-83*s),(cx+49*s,y-48*s),(cx+85*s,y-48*s)],INK,4)
 if circuit:
  for k in [-1,1]:
   path=[(cx,y-146*s),(cx+k*112*s,y-146*s),(cx+k*193*s,y-50*s),(cx+k*265*s,y-8*s),(cx+k*270*s,y+77*s),(cx+k*300*s,y+143*s)];Q.line(g,path,INK,13);Q.line(g,path,GOLD,7)
   for j in range(4):
    p=Q.along(path,(t*.4+j*.24)%1);Q.ell(g,(p[0]-4,p[1]-4,p[0]+4,p[1]+4),'#fff3b0')
def human(g,cx,base,s=1,current=0,t=0):
 Q.ell(g,(cx-38*s,base-323*s,cx+38*s,base-247*s),CREAM,INK,4);Q.box(g,(cx-31*s,base-225*s,cx+31*s,base-101*s),CREAM,INK,4,r=18);Q.line(g,[(cx,base-246*s),(cx,base-225*s)],INK,8)
 for pts in [[(cx-30*s,base-205*s),(cx-85*s,base-143*s),(cx-55*s,base-105*s)],[(cx+30*s,base-205*s),(cx+85*s,base-143*s),(cx+55*s,base-105*s)],[(cx-23*s,base-102*s),(cx-52*s,base-44*s),(cx-65*s,base)],[(cx+23*s,base-102*s),(cx+52*s,base-44*s),(cx+65*s,base)]]:Q.line(g,pts,INK,max(4,round(10*s)));Q.line(g,pts,CREAM,max(2,round(5*s)))
 for k in [-1,1]:Q.box(g,(cx+k*65*s-17*s,base-5*s,cx+k*65*s+22*s,base+11*s),TEAL,INK,2,r=4)
 ps=[(cx-65*s,base),(cx-52*s,base-44*s),(cx-23*s,base-102*s),(cx+23*s,base-102*s),(cx+52*s,base-44*s),(cx+65*s,base)]
 if current>0:
  Q.line(g,Q.partial(ps,current),GOLD,max(3,round(6*s)))
  for j in range(3):
   p=Q.along(ps,((t*.6+j*.3)%1)*current);Q.ell(g,(p[0]-3,p[1]-3,p[0]+3,p[1]+3),'#fff2b6')
 return ps
def shoe(g,x,y,s=1,col=TEAL):Q.poly(g,[(x-35*s,y-40*s),(x+8*s,y-40*s),(x+8*s,y-12*s),(x+45*s,y-8*s),(x+57*s,y+10*s),(x-38*s,y+10*s)],col,INK,4)
def glass(g,x,y,t,progress=1,face=False):
 ps=[[(x,y+140),(x+5,y+70),(x-10,y),(x+7,y-85),(x,y-150)],[(x-6,y+10),(x-75,y-32),(x-95,y-105)],[(x+3,y+65),(x+70,y+20),(x+102,y-45)]]
 for p in ps:Q.line(g,Q.partial(p,progress),'#546e70',25);Q.line(g,Q.partial(p,progress),'#9ac4bf',17);Q.line(g,Q.partial(p,progress),'#def0d8',5)
 if face:Q.face(g,x+2,y,t,.45,True)
def house(g,x,y,t,s=1,inside=False):
 Q.box(g,(x-230*s,y-95*s,x+230*s,y+170*s),'#f9e8c9',INK,4);Q.poly(g,[(x-260*s,y-95*s),(x,y-245*s),(x+260*s,y-95*s)],CORAL,INK,4)
 Q.box(g,(x-180*s,y-40*s,x-90*s,y+50*s),'#b1dbe1',INK,3);Q.line(g,[(x-135*s,y-40*s),(x-135*s,y+50*s)],CREAM,4);Q.box(g,(x+125*s,y+5*s,x+202*s,y+170*s),'#bb9873',INK,3)
 if inside:
  Q.box(g,(x-30*s,y+95*s,x+85*s,y+145*s),'#94b8a0',INK,3);Q.ell(g,(x-3*s,y-3*s,x+37*s,y+37*s),CREAM,INK,3);Q.box(g,(x+1*s,y+43*s,x+35*s,y+95*s),TEAL,INK,2);Q.line(g,[(x+5*s,y+95*s),(x-10*s,y+130*s),(x-10*s,y+163*s)],INK,6);Q.line(g,[(x+30*s,y+95*s),(x+60*s,y+128*s),(x+60*s,y+164*s)],INK,6)
  Q.line(g,[(x+30*s,y+54*s),(x+65*s,y+61*s),(x+80*s,y+35*s+4*s*math.sin(t*3))],INK,5)
def header(g,title,small=None):
 txt(g,(640,113),title,32,TEAL)
 if small:txt(g,(640,151),small,18,'#5b7f82')
def ground_face(g,x,y,t,talk=False,scale=1):Q.face(g,x,y,t,scale,talk)
def render_scene(im,t,r):
 g=ImageDraw.Draw(im);mode=r['scene'];u=t-r['start'];dur=r['visual_end']-r['start'];q=u/max(.1,dur);role=r['role'] if t<r['end'] else '';talk=role=='GROUND'
 if mode=='opening':
  backdrop(g,t);Q.cloud(g,340,190,t,.65);strike(g,350,245,480,u<.85);Q.box(g,(830,480,1250,595),'#8fa3a0',r=0)
  travel=126*Q.ease(u/3);g=cow(im,650+travel,475,t,300,False,travel=travel,walking=True);car(g,1040,490,t,.62);g=Q.bolt(im,330,418,t,155,'smug','shrug',True)
  if q>.33:label(g,720,230,'THE COW?',24)
  if q>.58:label(g,1040,305,'THE CAR?',24)
  if q>.76:Q.arrow(g,(480,520),(480,580),TEAL);label(g,630,565,'WHAT HAPPENS UNDER HERE?',23)
 elif mode in ['bolt_boast','bolt_not_storage','earth_core','reaction','ending_bolt']:
  backdrop(g,t,460,soil=True);g=Q.bolt(im,850,440,t,245,'alarmed' if mode=='reaction' else 'puzzled' if mode in ['earth_core','ending_bolt'] else 'smug','panic' if mode=='reaction' else 'shrug',True);ground_face(g,350,535,t,False,1.15)
  if mode=='earth_core':
   Q.ell(g,(140,145,440,420),'#a9ccba',INK,4);Q.ell(g,(185,190,395,385),'#d39b67',INK,3);Q.ell(g,(235,240,345,335),'#e3ba67',INK,3);Q.line(g,[(410,180),(145,410)],CORAL,7);label(g,270,440,'NO EXPRESS ELEVATOR',20)
  if mode=='reaction':header(g,'NOT JUST THE VISIBLE STRIKE')
 elif mode in ['ground_reply','soil_layers','no_experiment','ending_ground']:
  Q.box(g,(30,100,1250,610),SOIL,INK,3)
  for j in range(35):
   x=55+j*173%1160;y=150+j*43%420;Q.ell(g,(x,y,x+12,y+5),'#a58664')
  ground_face(g,540,335,t,talk,2);g=Q.bolt(im,1030,520,t,190,'puzzled','shrug',True)
  if mode=='ground_reply':
   Q.box(g,(160,190,305,350),'#bdcdca',INK,3);Q.box(g,(148,178,315,205),'#819e9e',INK,3);Q.line(g,[(140,165),(320,365)],CORAL,8)
  if mode=='soil_layers':
   for j,col in enumerate(['#d8b98c','#ae8f6e','#7f766b']):Q.box(g,(80,175+j*110,275,270+j*110),col,INK,3,r=0)
 elif mode=='air_channel':
  header(g,'THE GLOW IS AIR. CHARGE MOVES THROUGH IT.');Q.box(g,(60,180,1220,585),'#dcecf0',INK,3);strike(g,340,190,555,True)
  for j in range(22):
   xx=600+(j*47)%520;yy=220+(j*37)%280;radius=9+(4 if q>.4 else 0);Q.ell(g,(xx-radius,yy-radius,xx+radius,yy+radius),'#a5cfd4',INK,2)
  for j in range(8):
   yy=210+(t*130+j*43)%330;Q.ell(g,(333,yy-6,347,yy+6),GOLD,INK,2)
  if q>.4:Q.arrow(g,(450,350),(570,350),TEAL);label(g,870,545,'A CONDUCTING CHANNEL',24)
  g=Q.bolt(im,1120,535,t,155,'puzzled','point',True)
 elif mode=='pulse_clock':
  header(g,'A BRIEF PULSE — SHOWN SLOWLY');Q.box(g,(70,200,1210,520),'#e0eeeb',INK,3);Q.line(g,[(120,445),(1160,445)],INK,4)
  for j in range(3):
   xx=280+j*280;rise=Q.ease((u-j*.7)/.4);Q.line(g,[(xx-60,445),(xx-14,445),(xx,445-180*rise),(xx+14,445),(xx+60,445)],GOLD,9)
  cursor=120+1040*min(1,u/max(1,dur));Q.line(g,[(cursor,230),(cursor,485)],TEAL,3);Q.ell(g,(cursor-6,439,cursor+6,451),TEAL)
  label(g,640,565,'TIME EXPANDED FOR THE EXPLANATION',22)
  if q>.6:Q.ell(g,(970,185,1110,325),CREAM,INK,4);Q.line(g,[(1040,255),(1040,205)],INK,4);Q.line(g,[(1040,255),(1090,280)],INK,4);Q.line(g,[(960,185),(1120,330)],CORAL,7)
 elif mode in ['cutaway','branches','conductivity']:
  backdrop(g,t,300,soil=True);Q.cloud(g,500,175,t,.5);strike(g,500,200,300,True)
  if mode=='conductivity':
   for j,col in enumerate(['#d0ba96','#b8ad91','#8f9c93']):Q.box(g,(32,310+j*95,1248,400+j*95),col,r=0)
   Q.line(g,[(780,400),(1110,400)],'#657e83',20);label(g,1005,430,'BURIED CONDUCTOR',17)
   for j in range(24):
    x=650+j*61%520;y=330+j*31%180;Q.ell(g,(x,y,x+5,y+5),'#66aeb8')
   label(g,285,565,'GROUND PROPERTIES VARY',23)
  paths(g,500,300,t,Q.ease(u/3),270,500);label(g,910,145,'SCHEMATIC · SLOWED DOWN',18)
  if mode=='conductivity' and q>.45:
   pp=[(500,300),(720,365),(780,400),(1110,400)];Q.line(g,Q.partial(pp,Q.ease((q-.45)/.25)),GOLD,7)
   for j in range(3):
    pt=Q.along(pp,(t*.3+j*.3)%1);Q.ell(g,(pt[0]-4,pt[1]-4,pt[0]+4,pt[1]+4),'#fff1b3')
  if mode=='branches' and q>.5:Q.arrow(g,(1050,480),(1120,545),TEAL);label(g,900,575,'MULTIPLE ROUTES',22)
 elif mode=='energy':
  header(g,'CHARGE IS REDISTRIBUTED. ENERGY IS TRANSFERRED.');Q.box(g,(80,205,490,520),'#e4eeeb',INK,3)
  for j in range(18):
   xx=120+(j*19+u*23)%325;yy=250+(j%6)*38;Q.ell(g,(xx-6,yy-6,xx+6,yy+6),BLUE,INK,2)
  label(g,285,560,'CHARGE STILL EXISTS',22)
  start=event(r,'Electrical',.5)
  for j,(name,col) in enumerate([('LIGHT',GOLD),('HEAT',CORAL),('OTHER FORMS',TEAL)]):
   if t>start+j*.7:Q.arrow(g,(540,355),(800,230+j*130),col,8);label(g,1015,230+j*130,name,29,col)
 elif mode in ['sand_intro','sand_character']:
  backdrop(g,t,440);Q.box(g,(30,440,1250,610),'#e6d0a1',r=0)
  for j in range(45):
   x=40+j*97%1200;y=455+j*41%135;Q.ell(g,(x,y,x+5,y+3),'#c4ad78')
  g=sand(im,500,475,t,190,False);g=Q.bolt(im,970,450,t,245,'puzzled','shrug',True);label(g,340,220,'SILICA-RICH SAND',25)
 elif mode=='fuse':
  header(g,'SOMETIMES, SAND CAN FUSE INTO GLASS');Q.box(g,(50,185,1230,600),'#e9d8b1',INK,3)
  formed=event(r,'fulgurites',.5);progress=Q.ease((t-formed)/2.3)
  for j in range(120):
   x=330+j*67%650;y=210+j*37%355;col='#dcaa65' if t<formed else '#cdbf9d';Q.ell(g,(x,y,x+9,y+6),col)
  if t<formed:
   paths(g,650,190,t,Q.ease(u/2),350,250);label(g,965,230,'INTENSE LOCAL HEATING',21)
  else:glass(g,650,390,t,progress);label(g,970,550,'FULGURITE',28)
  g=sand(im,180,510,t,150,True)
 elif mode in ['fulgurite','glass_fragile','museum']:
  if mode=='museum' and t>event(r,'rewind',.35):
   backdrop(g,t,310,True);paths(g,600,310,t,Q.ease((t-event(r,'rewind',.35))/2),260,450);label(g,930,155,'BACK TO THE STRIKE',24)
  else:
   Q.box(g,(230,180,1050,590),'#edf2e6',INK,4);Q.box(g,(270,550,1010,590),'#9a9b7f',INK,3);glass(g,640,370,t,1,mode=='glass_fragile');label(g,640,140,'FULGURITE',32)
   if mode=='fulgurite':
    if q<.35:
     for k in range(3):
      x=330+k*120;Q.ell(g,(x-24,470,x+24,510),['#e3c58d','#bb9a73','#929c89'][k],INK,2)
     label(g,470,545,'MATERIAL + CONDITIONS',19)
    cx=float(Q.mix([1180],[965],u/2)[0]);Q.ell(g,(cx-85,240,cx+85,410),CREAM,INK,4);Q.line(g,[(cx+60,385),(cx+110,445)],INK,10);Q.ell(g,(cx-55,270,cx+55,380),'#b9d7c8',INK,4);Q.ell(g,(cx-30,295,cx+30,355),'#5f7776',INK,3)
    if q>.35:label(g,960,475,'SOME ARE HOLLOW',18)
   if mode=='glass_fragile':Q.line(g,[(650,300),(640+2*math.sin(t*4),330),(648,350)],'#5b7c7b',2);label(g,640,520,'FRAGILE',24,CORAL)
   if mode=='museum':label(g,640,520,'COOLED AFTERMATH — NOT STORED ELECTRICITY',20)
 elif mode in ['feet_question','two_feet']:
  backdrop(g,t,450,True);ground_face(g,380,535,t,talk,1.0);g=Q.bolt(im,970,455,t,190,'puzzled','point',True)
  if mode=='two_feet':
   shoe(g,450,420-55*(1-Q.ease(u/.6)),1.4,'#d6ad65');shoe(g,700,420-55*(1-Q.ease((u-.5)/.6)),1.4,'#7baeb6')
   if u>1.1:label(g,450,350,'A');label(g,700,350,'B');txt(g,(575,350),'≠',55)
 elif mode=='step_body':
  header(g,'TWO CONTACTS CAN BE AT DIFFERENT VOLTAGES');Q.box(g,(50,525,1230,610),SOIL,INK,3)
  if u>.25:Q.ell(g,(550,507,620,550),'#deb56b');label(g,575,580,'A',28)
  if u>1.05:Q.ell(g,(680,507,750,550),'#80b7bd');label(g,725,580,'B',28)
  human(g,650,530,1.0,Q.ease((t-event(r,'That',.5))/2),t)
  if u>1.9:txt(g,(650,580),'≠',43,TEAL)
  label(g,1030,155,'SIMPLIFIED · SLOWED DOWN',17)
  g=Q.bolt(im,255,490,t,190,'alarmed','panic',True)
 elif mode=='voltage_steps':
  header(g,'VOLTAGE DIFFERENCE BETWEEN CONTACT POINTS');Q.box(g,(120,200,1160,550),'#e3eeeb',INK,3)
  for j,(x,h,col) in enumerate([(340,240,'#d5ad67'),(940,100,'#7caeb6')]):
   hh=h*Q.ease((u-j*.8)/1.6);Q.box(g,(x-75,500-hh,x+75,500),col,INK,3,r=0);label(g,x,535,'A' if j==0 else 'B',26)
  if u>2.4:
   pp=[(420,360),(860,360)];Q.line(g,Q.partial(pp,Q.ease((u-2.4)/2)),INK,5)
   if u>4.4:
    Q.arrow(g,(470,330),(810,330),TEAL,6)
    for k in range(4):
     px=430+(t*90+k*105)%420;Q.ell(g,(px-5,355,px+5,365),GOLD)
    label(g,640,430,'A DIFFERENCE CAN DRIVE CURRENT',20)
  label(g,640,585,'ELECTRICAL LEVEL ANALOGY — NOT PHYSICAL HEIGHT',18)
 elif mode=='voltage_map':
  header(g,'POSITION MATTERS. NO UNIVERSAL SAFE RADIUS.');Q.box(g,(70,185,1210,590),'#d5b88c',INK,3)
  for j in range(7):
   rr=45+j*67;g.ellipse(Q.p((350-rr,380-rr*.45,350+rr,380+rr*.45)),outline=['#b98663','#bf966b','#c7a57b'][j%3],width=4)
  for k,(x,y) in enumerate([(430,330),(650,450)]):
   shift=float(Q.mix([0],[100 if k==0 else -90],(q-.25)/.4)[0]);dx=65 if q<.5 else 0;dy=25 if q<.5 else 60
   Q.ell(g,(x+shift-9,y-9,x+shift+9,y+9),TEAL,INK,2);Q.ell(g,(x+shift+dx-9,y+dy-9,x+shift+dx+9,y+dy+9),CORAL,INK,2);Q.line(g,[(x+shift,y),(x+shift+dx,y+dy)],INK,3)
  if q>.4:label(g,940,340,'DIFFERENT ARRANGEMENTS',20);label(g,940,400,'DIFFERENT POSSIBILITIES',20)
  label(g,640,560,'SCHEMATIC — NOT A SAFETY MAP',20)
 elif mode in ['cow_question','cow_span','cow_reply']:
  backdrop(g,t,480);g=cow(im,640,465,t,480,mode!='cow_reply');g=Q.bolt(im,1080,480,t,155,'alarmed' if mode!='cow_reply' else 'puzzled','shrug',True)
  if mode=='cow_span':
   on=event(r,'farther',.35)
   if t>on:
    reach=Q.ease((t-on)/1.5);Q.line(g,[(690-115*reach,555),(690+125*reach,555)],TEAL,5)
    if reach>.95:Q.arrow(g,(690,555),(575,555),TEAL,5);Q.arrow(g,(690,555),(815,555),TEAL,5);label(g,690,590,'A WIDER SPAN CAN MEAN A BIGGER DIFFERENCE',18)
   if t>event(r,'difference',.6):label(g,580,210,'A',30);label(g,815,210,'B',30);txt(g,(700,210),'≠',50,TEAL)
   human(g,240,550,.65,0,t);label(g,240,590,'NOT TO SCALE',17)
 elif mode=='side_flash':
  header(g,'MORE THAN ONE WAY TO BE AFFECTED')
  for j,title in enumerate(['DIRECT STRIKE','CONTACT','SIDE FLASH']):
   on=event(r,['direct','contact','side'][j],.2+j*.25);x=50+j*410;Q.box(g,(x,195,x+380,585),'#edf2e5' if t<on else '#dfead4',INK,3);label(g,x+190,225,title,23);human(g,x+210,535,.72,0,t)
   if t>on:
    if j==0:strike(g,x+210,260,330,True)
    elif j==1:Q.line(g,[(x+65,310),(x+65,525)],'#7b9290',14);Q.line(g,Q.partial([(x+70,390),(x+160,400)],Q.ease((t-on)/1.2)),GOLD,7)
    else:Q.line(g,[(x+70,525),(x+70,280)],'#7c6851',15);Q.ell(g,(x+15,265,x+130,370),'#83a885',INK,3);Q.line(g,Q.partial([(x+75,360),(x+145,390),(x+170,365),(x+190,385)],Q.ease((t-on)/1.2)),GOLD,8)
 elif mode in ['car_arrival','tires','car_face','tire_joke']:
  backdrop(g,t,480);Q.box(g,(30,500,1250,610),'#8b9f9c',r=0);cx=Q.mix([1100],[680],u/2)[0] if mode=='car_arrival' else 680;car(g,cx,405,t,1.0,talk=role=='CAR',moving=mode=='car_arrival' and u<2);g=Q.bolt(im,250,475,t,190,'puzzled','shrug',True)
  if mode=='tires':
   for x in [515,845]:txt(g,(x,545),'★',37,GOLD)
  if mode=='car_arrival' and u>2:txt(g,(750,205),'?',90,TEAL)
 elif mode=='car_shell':
  backdrop(g,t,550);Q.box(g,(30,500,1250,610),'#8b9f9c',r=0);header(g,'THE CONDUCTING SHELL CAN ROUTE CURRENT AROUND THE CABIN');car(g,670,400,t,1.0,circuit=u>1.3);strike(g,670,150,254,u>1.3);label(g,670,595,'ENCLOSED · HARD-TOPPED · METAL',21);label(g,1040,160,'SCHEMATIC · SLOWED DOWN',17)
 elif mode=='tire_gap':
  backdrop(g,t,530);Q.box(g,(30,500,1250,610),'#8b9f9c',r=0);header(g,'A TIRE IS NOT A MAGICAL RUBBER BARRIER');car(g,760,400,t,.9,damage=Q.ease((t-event(r,'damage',.65))/1.5)*.8);strike(g,760,150,260,True)
  Q.arrow(g,(230,160),(230,450),TEAL,5);label(g,235,505,'AIR GAP',22)
  if t>event(r,'damage',.65):label(g,780,585,'DAMAGE IS POSSIBLE',24,CORAL)
 elif mode=='vehicle_compare':
  header(g,'THE ENCLOSURE MATTERS')
  for j,(kind,title) in enumerate([('closed','CLOSED METAL HARDTOP'),('convertible','CONVERTIBLE'),('open','OPEN CART')]):
   cx=230+j*410;Q.box(g,(cx-190,205,cx+190,570),'#e4ede3',INK,3);car(g,cx,375,t,.57,kind=kind,windows=Q.ease((t-event(r,'Keep',.65))/.8));label(g,cx,525,title,16,TEAL if j==0 else CORAL);txt(g,(cx,235),'✓' if j==0 else '×',50,TEAL if j==0 else CORAL)
 elif mode in ['thunder_air','sound_wave']:
  header(g,'RAPIDLY HEATED AIR EXPANDS');Q.box(g,(50,185,1230,585),'#d9ecf1',INK,3);strike(g,430,200,550,True)
  heat=event(r,'heats',.3) if mode=='thunder_air' else r['start'];progress=Q.ease((t-heat)/2)
  for j in range(24):
   angle=j*2.4;rad=60+(j%5)*18+progress*130;xx=430+rad*math.cos(angle);yy=365+rad*.6*math.sin(angle);Q.ell(g,(xx-8,yy-8,xx+8,yy+8),CORAL if progress>.3 else BLUE,INK,2)
  for k in range(3):
   rr=80+((t*70+k*85)%300)*progress;g.arc(Q.p((430-rr,365-rr*.6,430+rr,365+rr*.6)),-70,70,fill=TEAL,width=4)
  Q.arrow(g,(780,365),(1030,365),TEAL,7);label(g,1030,450,'PRESSURE WAVE',23)
 elif mode=='air_joke':
  Q.box(g,(50,145,1230,600),'#dfeef0',INK,3);Q.cloud(g,860,310,t,1.0);g=Q.bolt(im,380,470,t,245,'puzzled','shrug',True)
 elif mode in ['shelter','inside_house','wait','ending_narrator']:
  backdrop(g,t,535);house(g,655,425,t,1.05,True);Q.cloud(g,230,210,t,.55)
  if mode=='inside_house':
   for j,(x,title) in enumerate([(195,'WINDOWS'),(640,'PLUMBING'),(1080,'CORDED EQUIPMENT')]):
    on=event(r,['windows','plumbing','corded'][j],.5+j*.12)
    if t>on:label(g,x,570,title,18,CORAL);txt(g,(x,520),'×',48,CORAL)
  elif mode=='wait':
   Q.ell(g,(1000,195,1180,375),CREAM,INK,4);Q.line(g,[(1090,285),(1090,215)],INK,5);a=-math.pi/2+math.pi*min(1,u/max(1,dur));Q.line(g,[(1090,285),(1090+65*math.cos(a),285+65*math.sin(a))],TEAL,5);label(g,1070,425,'AT LEAST 30 MIN',20);label(g,1010,468,'AFTER THE LAST THUNDER',18);label(g,1040,555,'TIME COMPRESSED',18)
  else:label(g,650,153,'HEAR THUNDER? GET INSIDE.',29)
  if mode=='ending_narrator':txt(g,(640,590),'Everyday questions. Animated answers.',22,TEAL)
 elif mode=='bad_shelters':
  header(g,'THESE DO NOT REPLACE PROPER SHELTER')
  for j,title in enumerate(['A TREE','OPEN-SIDED SHELTER','A FENCE']):
   x=55+j*410;Q.box(g,(x,195,x+380,580),'#e7ecdf',INK,3)
   if j==0:Q.line(g,[(x+190,505),(x+190,315)],'#7b6650',22);Q.ell(g,(x+90,260,x+290,400),'#8baa83',INK,4)
   elif j==1:
    for xx in [x+65,x+315]:Q.line(g,[(xx,330),(xx,510)],INK,10)
    Q.poly(g,[(x+45,330),(x+190,245),(x+335,330)],CORAL,INK,4)
   else:
    for xx in range(x+65,x+340,55):Q.line(g,[(xx,300),(xx,500)],'#7e8f89',12)
    Q.line(g,[(x+50,350),(x+335,350)],'#7e8f89',10);Q.line(g,[(x+50,425),(x+335,425)],'#7e8f89',10)
   on=event(r,['tree','open','fence'][j],j*.25)
   if t>on:Q.line(g,[(x+70,235),(x+315,510)],CORAL,8);Q.line(g,[(x+315,235),(x+70,510)],CORAL,8)
   label(g,x+190,550,title,19)
 else:raise ValueError(mode)
 return im
def frame(t,record=True):
 r=C[max(0,bisect.bisect_right(START,t)-1)];im=Image.new('RGBA',(W,H),CREAM);render_scene(im,t,r);g=ImageDraw.Draw(im)
 Q.box(g,(0,0,W,82),CREAM,r=0);txt(g,(35,27),'EVERYDAY, EXPLAINED',17,TEAL,'lm');txt(g,(1240,27),r['chapter'],17,TEAL,'rm');Q.line(g,[(35,61),(1245,61)],'#d4e0d4',3);Q.line(g,[(35,61),(35+1210*t/D,61)],TEAL,3)
 if t<3.5:txt(g,(640,70),'Lightning Hits the Ground. Then What?',20,INK)
 i=bisect.bisect_right(CS,t)-1
 if i>=0 and CAP[i]['start']<=t<CAP[i]['end']:
  c=CAP[i];width=Q.font(32).getlength(c['text']);assert width<=1120,(width,c['text']);Q.box(g,(640-width/2-18,644,640+width/2+18,704),INK,r=14);txt(g,(640,675),c['text'],32,CREAM);txt(g,(640,628),c['role'],12,TEAL)
 return im.convert('RGB')
def render():
 Q.TRACE.clear();CAST.clear()
 n=round(D*FPS);p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'picture.mp4')],stdin=subprocess.PIPE)
 for i in range(n):
  p.stdin.write(frame(i/FPS).tobytes())
  if i%450==0:print(f'Frame {i}/{n}',flush=True)
 p.stdin.close();assert p.wait()==0;(O/'mascot-motion.json').write_text(json.dumps(Q.TRACE));(O/'supporting-motion.json').write_text(json.dumps(CAST));(O/'shots.json').write_text(json.dumps([{'scene':r['scene'],'chapter':r['chapter'],'start':r['start'],'end':r['visual_end'],'cue':r['id']} for r in C],indent=2));print('Landscape picture saved',flush=True)
if __name__=='__main__':
 if len(sys.argv)>1:
  for j,r in enumerate(C):frame(r['start']+min(.8,r['duration']*.4)).save(O/f'shot-{j+1:02d}.jpg')
 else:render()
