from pathlib import Path
from functools import lru_cache
import math,json
import numpy as np
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parent
INK="#143b52";TEAL="#0d8196";GOLD="#ffd04c";YELLOW="#ffe887";CREAM="#fff9eb";BLUE="#45badb";SOIL="#bb9977";CORAL="#d97762"
TRACE=[]
def ease(u):
    u = max(0, min(1, float(u)))
    return u * u * (3 - 2 * u)

def mix(a, b, u):
    return np.asarray(a) * (1 - ease(u)) + np.asarray(b) * ease(u)

def p(x):
    return tuple((round(float(v)) for v in x))

def line(g, pts, c=INK, w=5):
    g.line([p(x) for x in pts], fill=c, width=w, joint='curve')

def box(g, bb, c, outline=None, w=3, r=14):
    g.rounded_rectangle(p(bb), radius=r, fill=c, outline=outline, width=w)

def ell(g, bb, c, outline=None, w=3):
    g.ellipse(p(bb), fill=c, outline=outline, width=w)

def poly(g, pts, c, outline=None, w=3):
    g.polygon([p(x) for x in pts], fill=c)
    if outline:
        line(g, pts + [pts[0]], outline, w)

@lru_cache(None)
def font(n):
    return ImageFont.truetype(str(B / 'fonts/DejaVuSans-Bold.ttf'), n)

def text(g, xy, s, n=50, c=INK, anchor='mm'):
    g.text(p(xy), s, font=font(n), fill=c, anchor=anchor)

def arrow(g, a, b, c=TEAL, w=6):
    a = np.array(a, float)
    b = np.array(b, float)
    v = b - a
    v /= max(0.01, np.linalg.norm(v))
    n = np.array([-v[1], v[0]])
    line(g, [a, b - v * 12], c, w)
    poly(g, [b, b - v * 22 + n * 11, b - v * 22 - n * 11], c)

def tag(g, x, y, s, n=27, c=TEAL):
    width = font(n).getlength(s)
    box(g, (x - width / 2 - 18, y - 24, x + width / 2 + 18, y + 24), CREAM, INK, 2)
    text(g, (x, y), s, n, c)

def along(pts, u):
    ls = [math.dist(a, b) for a, b in zip(pts, pts[1:])]
    d = max(0, min(1, u)) * sum(ls)
    for a, b, L in zip(pts, pts[1:], ls):
        if d <= L:
            return np.array(a) + (np.array(b) - a) * d / L
        d -= L
    return np.array(pts[-1])

def partial(pts, u):
    total = sum((math.dist(a, b) for a, b in zip(pts, pts[1:])))
    remaining = total * max(0, min(1, u))
    out = [pts[0]]
    for a, b in zip(pts, pts[1:]):
        L = math.dist(a, b)
        if remaining >= L:
            out.append(b)
            remaining -= L
        else:
            out.append(tuple(np.array(a) + (np.array(b) - a) * remaining / L))
            break
    return out

def ik(a, b, L, pole):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    v = b - a
    d = np.linalg.norm(v)
    assert 0.001 < d < 2 * L - 0.001, (d, L)
    v /= d
    mid = (a + b) / 2 + pole * np.array([-v[1], v[0]]) * math.sqrt(L * L - d * d / 4)
    return np.array([a, mid, b])

@lru_cache(None)
def spr(name, h):
    im = Image.open(B / f'art/{name}.png').convert('RGBA')
    return im.resize((round(im.width * h / im.height), h), Image.Resampling.LANCZOS)

def bolt(im, x, y, t, h=245, expr='smug', pose='shrug', record=False):
    s = h / 245
    imbody = spr(expr, h)
    width = imbody.width
    xx = x + 3 * s * math.sin(t * 2.5)
    yy = y + 3 * s * math.sin(t * 3)
    g = ImageDraw.Draw(im)
    ell(g, (x - 80 * s, y + 66 * s, x + 80 * s, y + 84 * s), '#a4b5ab')
    chains = []
    for k in [-1, 1]:
        hip = (xx - 10 * s + k * 14 * s, yy - 69 * s)
        foot = (x + k * 40 * s, y + 70 * s)
        ch = ik(hip, foot, 75 * s, -k)
        line(g, ch, INK, max(4, round(7 * s)))
        line(g, [foot, (foot[0] + 19 * s, foot[1] + 3 * s)], INK, max(5, round(8 * s)))
        chains.append((ch, 75 * s))
    for k in [-1, 1]:
        root = (xx + k * width * 0.31, yy - h * 0.47)
        if pose == 'panic':
            hand = (xx + k * 116 * s, yy - h * 0.95 + 6 * s * math.sin(t * 8 + k))
        elif pose == 'point' and k == 1:
            hand = (xx + 135 * s, yy - h * 0.66)
        elif pose == 'shrug':
            hand = (xx + k * 116 * s, yy - h * 0.56 + 7 * s * math.sin(t * 3 + k))
        else:
            hand = (xx + k * 108 * s, yy - h * 0.23 + 8 * s * math.sin(t * 2 + k))
        ch = ik(root, hand, 73 * s, k)
        line(g, ch, INK, max(4, round(7 * s)))
        ell(g, (hand[0] - 9 * s, hand[1] - 9 * s, hand[0] + 9 * s, hand[1] + 9 * s), CREAM, INK, max(2, round(3 * s)))
        chains.append((ch, 73 * s))
    im.alpha_composite(imbody, (round(xx - width / 2), round(yy - h)))
    if record:
        TRACE.append({'time': t, 'mascot': True, 'max_bone_error': max((abs(np.linalg.norm(ch[i + 1] - ch[i]) - L) for ch, L in chains for i in [0, 1])), 'feet': [[x - 40 * s, y + 70 * s], [x + 40 * s, y + 70 * s]]})
    return ImageDraw.Draw(im)

def face(g, x, y, t, s=1, talk=False):
    for k in [-1, 1]:
        cx = x + k * 44 * s
        ell(g, (cx - 18 * s, y - 24 * s, cx + 18 * s, y + 12 * s), CREAM, INK, 3)
        ell(g, (cx - 3 * s, y - 12 * s, cx + 9 * s, y + 5 * s), INK)
        line(g, [(cx - 20 * s, y - 39 * s), (cx + 18 * s, y - 35 * s)], INK, 5)
    if talk:
        ell(g, (x - 25 * s, y + 30 * s, x + 25 * s, y + (45 + 18 * abs(math.sin(t * 14))) * s), INK)
    else:
        line(g, [(x - 24 * s, y + 39 * s), (x + 24 * s, y + 40 * s)], INK, 5)

def cloud(g, x, y, t, s=1):
    for dx, dy, r in [(-85, 25, 70), (-20, -20, 90), (70, 5, 85), (125, 38, 55)]:
        ell(g, (x + (dx - r) * s, y + (dy - r) * s, x + (dx + r) * s, y + (dy + r) * s), '#87aab7', INK, 5)
    face(g, x + 15 * s, y + 10 * s, t, 0.65 * s, False)
