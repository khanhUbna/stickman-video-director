from pathlib import Path
import math,json,subprocess,wave,re,hashlib
import numpy as np
import animate as A
B=A.B;O=A.O;SR=48000;N=round(A.D*SR)
def run(args):return subprocess.run(args,check=True,capture_output=True)
def wav(path,x):
 with wave.open(str(path),'wb') as w:w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(x,-.98,.98)*32767).astype('<i2').tobytes())
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def measure(path):
 p=run(['ffmpeg','-hide_banner','-nostats','-i',str(path),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']);return json.loads(re.findall(rb'\{[^{}]+\}',p.stderr)[-1])
def main():
 voice=np.zeros(N,np.float32);music=np.zeros(N,np.float32);fx=np.zeros(N,np.float32);amb=np.zeros(N,np.float32);active=np.zeros(N,np.float32);rng=np.random.default_rng(221122)
 for r in A.C:
  with wave.open(str(B/r['file'])) as w:assert w.getframerate()==SR;x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
  x*=min(1.7,.13/max(.001,np.sqrt(np.mean(x*x))));a=round(r['start']*SR);voice[a:a+len(x)]+=x;active[max(0,a-2400):min(N,a+len(x)+5000)]=1
 wav(B/'audio/dialogue.wav',voice)
 def add(bus,at,x,gain):
  a=round(at*SR);n=min(len(x),N-a)
  if n>0:bus[a:a+n]+=x[:n]*gain
 def pluck(freq,dur=.85,glass=False):
  t=np.arange(round(dur*SR),dtype=np.float32)/SR;x=np.zeros(len(t),np.float32)
  for j in range(1,5):x+=np.sin(math.tau*freq*(j if not glass else [1,2.76,5.4,8.93][j-1])*t)*np.exp(-t*(5+j*1.5))/j**1.7
  return x*np.minimum(1,t/.008)
 # Six changing chapter palettes, newly composed; no library song/recording.
 chords=[[50,57,62,65],[46,53,58,62],[48,55,60,64],[45,52,57,60],[43,50,55,59],[50,57,62,66]]
 chapters=list(dict.fromkeys(r['chapter'] for r in A.C));chapter_times=[next(r['start'] for r in A.C if r['chapter']==c) for c in chapters]
 for j,at in enumerate(np.arange(.02,A.D,.47)):
  ch=max(0,int(np.searchsorted(chapter_times,at,side='right')-1));notes=chords[(ch+j//48)%len(chords)];note=notes[[0,2,1,3,2,1][j%6]]+(12 if j//32%2 else 0)
  if j%16 in [7,15] or (ch==3 and j%4==1):continue
  add(music,at,pluck(440*2**((note-69)/12),1.0,ch==2),.009 if ch in [3,5] else .013)
 for at in np.arange(0,A.D,3.76):
  note=chords[int(at/3.76)%6][0]-12;add(music,at,pluck(440*2**((note-69)/12),1.5),.012)
 ambience=[]
 for r in A.C:
  a=round(r['start']*SR);b=min(N,round(r['visual_end']*SR));n=b-a;tt=np.arange(n,dtype=np.float32)/SR;noise=rng.normal(0,1,n).astype(np.float32);low=np.convolve(noise,np.ones(29,np.float32)/29,'same');gain=.009 if r['chapter'] in ['THE MYSTERY','BENEATH THE GRASS','TWO POINTS OF CONTACT'] else .004
  fade=np.minimum(1,np.minimum(np.arange(n)/(SR*.08),(n-1-np.arange(n))/(SR*.1)));amb[a:b]+=low*gain*fade
  if r['scene']=='car_arrival':amb[a:b]+=.007*np.sin(math.tau*93*tt)*(1-np.clip((tt-1.5)/.5,0,1))
  ambience.append({'start':r['start'],'end':r['visual_end'],'scene':r['scene'],'source':'Original local filtered-noise room/outdoor bed','purpose':'Setting continuity, quieter for artifact/indoor scenes'})
 events=[]
 def event(at,dur,kind,gain=.03):
  tt=np.arange(round(dur*SR),dtype=np.float32)/SR
  if kind in ['strike_rumble','thunder_air']:
   noise=rng.normal(0,1,len(tt)).astype(np.float32);noise=np.convolve(noise,np.ones(27,np.float32)/27,'same');x=(noise+.3*np.sin(math.tau*65*tt)+.15*np.sin(math.tau*103*tt))*np.exp(-tt*3.5)
  elif kind=='hoof_contact':
   x=(rng.normal(0,1,len(tt)).astype(np.float32)*.22+.5*np.sin(math.tau*135*tt))*np.exp(-tt*45)
  elif kind=='glass_discovery':x=pluck(880,dur,True)
  else:x=np.sin(math.tau*(650*tt-220*tt*tt))*np.exp(-tt*25)
  x*=np.minimum(1,tt/.006);add(fx,at,x,gain);events.append({'time':at,'duration':dur,'kind':kind,'gain':gain,'source':'Original local cartoon synthesis','status':'final','listener':'Stylized medium/close perspective; not a field recording or physical sound simulation'})
 event(.22,1.5,'strike_rumble',.09)
 # Touchdowns follow the exact eased body travel and stance/swing phase.
 for target in [.25,.5,.75,1.0]:
  lo,hi=0.,1.
  for k in range(40):
   mid=(lo+hi)/2
   if A.Q.ease(mid)<target:lo=mid
   else:hi=mid
  event(A.C[0]['start']+(lo+hi)/2*3,.11,'hoof_contact',.027)
 for r in A.C:
  s=r['scene']
  if s=='pulse_clock':
   for j in range(3):event(r['start']+.2+j*.7,.1,'pulse_diagram_tick',.014)
  if s=='fuse':event(A.event(r,'fulgurites',.5),.8,'glass_discovery',.023)
  if s=='two_feet':event(r['start']+.6,.1,'foot_point_a',.018);event(r['start']+1.1,.1,'foot_point_b',.018)
  if s=='side_flash':
   for word in ['direct','contact','side']:event(A.event(r,word),.10,'mechanism_reveal',.016)
  if s=='thunder_air':event(A.event(r,'Thunder',.3),1.2,'thunder_air',.06)
  if s=='vehicle_compare':event(A.event(r,'Keep',.65)+.7,.12,'window_closed',.018)
  if s=='glass_fragile':event(r['start']+.15,.6,'glass_discovery',.018)
 # Brief music reduction leaves space for the final deadpan exchange.
 ending=next(r['start'] for r in A.C if r['scene']=='ending_bolt');music[round(ending*SR):]*=.45
 fade=np.minimum(1,(N-1-np.arange(N))/(SR*.7)).astype(np.float32);music*=fade*(1-.55*active);fx*=fade;amb*=fade
 for name,x in [('music-original',music),('foley-original',fx),('ambience-original',amb)]:wav(B/f'audio/{name}.wav',x)
 wav(B/'audio/mix.wav',voice+music+fx+amb);pre=measure(B/'audio/mix.wav');flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
 run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix.wav'),'-af',flt,'-ar',str(SR),'-ac','2',str(B/'audio/master.wav')])
 dst=O/'lightning-hits-the-ground-then-what.mp4';run(['ffmpeg','-v','error','-y','-i',str(O/'picture.mp4'),'-i',str(B/'audio/master.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','160k','-t',str(A.D),'-movflags','+faststart',str(dst)])
 (O/'captions-en.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(A.CAP))+'\n')
 (O/'captions-vi.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['vi']}" for i,c in enumerate(A.C))+'\n',encoding='utf-8-sig')
 (O/'chapters.txt').write_text('\n'.join(f"{int(t)//60}:{int(t)%60:02d} {c.title()}" for c,t in zip(chapters,chapter_times))+'\n')
 run(['ffmpeg','-v','error','-i',str(dst),'-f','null','-']);probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(dst)]).stdout);v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio');assert [v['width'],v['height'],v['r_frame_rate'],v['nb_frames']]==[1280,720,'30/1',str(round(A.D*30))];assert abs(float(v['duration'])-float(a['duration']))<.05
 mascots=json.loads((O/'mascot-motion.json').read_text());cows=json.loads((O/'supporting-motion.json').read_text());assert max(r['max_bone_error'] for r in mascots+cows)<1e-7
 post=measure(dst);assert float(post['input_tp'])<-.5
 qa={'title':A.T['title'],'duration':float(v['duration']),'dimensions':[1280,720],'fps':30,'frames':int(v['nb_frames']),'full_decode':'pass','audio_video_duration_match':'pass','active_spoken_blocks':len(A.C),'caption_cues':len(A.CAP),'caption_alignment':'Offline PocketSphinx acoustic forced alignment to saved native speech','new_tts_responses_saved':A.T['new_native_responses'],'reused_tts_responses':A.T['reused_responses'],'estimated_new_tts_usd':A.T['estimated_tts_usd'],'billing_verified':False,'new_image_calls':1,'image_billing':'Not exposed; supporting cast atlas only, prior Bolt reused','maximum_rig_bone_error':max(r['max_bone_error'] for r in mascots+cows),'loudness':post,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size,'research_access':'Direct NWS/USGS reads denied by environment proxy; no claim of source retrieval. Script uses established conceptual mechanisms and standard shelter guidance.','science_scope':json.loads((B/'story.json').read_text())['scientific_scope'],'review':{'author':'Source and decoded MP4 frames, mechanism/contact and caption checks','independent':'not performed','real_time_AV_listening':'not performed'},'youtube_upload':False};(O/'QA.json').write_text(json.dumps(qa,indent=2));(O/'probe.json').write_text(json.dumps(probe,indent=2));(O/'sound-rights.json').write_text(json.dumps({'music':'Original local six-chapter plucked arrangement; no third-party melody/recording','voices':A.T['voices'],'saved_native_audio':True,'ambience':ambience,'events':events,'rights':'Original local synthetic music/ambience/Foley, existing generated Bolt, one new generated supporting cast atlas and original scenery/diagrams; DejaVu font/license included. No third-party footage/recording extracted.'},indent=2));print(json.dumps(qa,indent=2),flush=True)
if __name__=='__main__':main()
