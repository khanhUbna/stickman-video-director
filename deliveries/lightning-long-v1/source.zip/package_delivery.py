from pathlib import Path
import json,hashlib,zipfile,shutil,ast,wave
B=Path(__file__).resolve().parent;O=B/'output';DEST=Path('/workspace/stickman-video-director/deliveries/lightning-long-v1')
def main():
 q=json.loads((O/'QA.json').read_text());movie=O/'lightning-hits-the-ground-then-what.mp4';h=hashlib.sha256(movie.read_bytes()).hexdigest();assert h==q['sha256'];review=json.loads((O/'decoded-review.json').read_text());assert review['sha256']==h;assert json.loads((O/'voice-presence-checks.json').read_text())['all_spoken_blocks_present']
 for p in B.glob('*.py'):ast.parse(p.read_text())
 t=json.loads((B/'timeline.json').read_text())
 for r in t['cues']:
  with wave.open(str(B/r['file'])) as w:assert abs(w.getnframes()/w.getframerate()-r['duration'])<.001
 # Include saved original audio and project-local artwork, not regenerated stems/intermediate films.
 with zipfile.ZipFile(O/'source.zip','w',zipfile.ZIP_DEFLATED,6) as z:
  for p in B.iterdir():
   if p.is_file() and p.suffix in ['.py','.md','.json','.txt']:z.write(p,p.relative_to(B))
  for folder in ['art','fonts','research']:
   for p in (B/folder).rglob('*'):
    if p.is_file() and p.name!='cow-matte-check.jpg':z.write(p,p.relative_to(B))
  for p in (B/'audio').iterdir():
   if p.is_file() and ((p.name[:2].isdigit() and p.suffix=='.wav' and not p.name.endswith('-16k.wav')) or p.name.endswith('-request.json') or p.name.endswith('-reuse.json') or p.name.endswith('-words.json')):z.write(p,p.relative_to(B))
  for name in ['captions.json','words.json','supporting-binding-checks.json']:z.write(O/name,Path('output')/name)
 with zipfile.ZipFile(O/'source.zip') as z:assert z.testzip() is None
 DEST.mkdir(parents=True,exist_ok=True)
 names=[movie.name,'captions-en.srt','captions-vi.srt','chapters.txt','QA.json','voice-presence-checks.json','decoded-review.json','supporting-binding-checks.json','sound-rights.json','shots.json','cover.jpg','source.zip']+[f'decoded-review-{i}.jpg' for i in range(1,5)]
 for name in names:shutil.copy2(O/name,DEST/name)
 for name in ['README.md','science-notes.md','script-en.txt','script-vi.txt','upload-text.txt','timeline.json']:shutil.copy2(B/name,DEST/name)
 manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in DEST.iterdir() if p.is_file() and p.name!='manifest.json'};(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2))
 print(json.dumps({'delivery':str(DEST),'duration':q['duration'],'video_MiB':round(q['bytes']/1024**2,2),'source_MiB':round((DEST/'source.zip').stat().st_size/1024**2,2),'active_spoken_blocks':q['active_spoken_blocks'],'full_decode':q['full_decode']},indent=2),flush=True)
if __name__=='__main__':main()
