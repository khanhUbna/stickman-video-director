from pathlib import Path
import json,re,wave,subprocess
from pocketsphinx import Decoder
from PIL import ImageFont
B=Path(__file__).resolve().parent;T=json.loads((B/'timeline.json').read_text());F=ImageFont.truetype(str(B/'fonts/DejaVuSans-Bold.ttf'),32)
def parts(text):
 # Prefer sentence/clause boundaries and connective phrases, never shrink captions.
 chunks=re.split(r'(?<=[.!?;])\s+|(?<=,)\s+',text);out=[]
 def cut(s):
  if F.getlength(s)<=1120:out.append(s);return
  options=[]
  for m in re.finditer(r'\s+(?:and|but|because|while|which|where|rather than|not|even|including|when|before|after|than|that)\s+',s,re.I):
   k=m.start();a=s[:k].strip();b=s[k:].strip()
   if a and b:options.append((abs(len(a)-len(b)),a,b))
  if options:
   _,a,b=min(options);cut(a);cut(b);return
  ws=s.split();line=''
  for w in ws:
   if line and F.getlength(line+' '+w)>1120:out.append(line);line=w
   else:line=(line+' '+w).strip()
  if line:out.append(line)
 for s in chunks:
  if s.strip():cut(s.strip())
 return out
CAP=[];ALL=[]
for r in T['cues']:
 cache=B/f"audio/{r['id']:02d}-words.json"
 if cache.exists():words=json.loads(cache.read_text())['words']
 else:
  dst=B/f"audio/{r['id']:02d}-16k.wav";subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/r['file']),'-ar','16000','-ac','1',str(dst)],check=True)
  tokens=re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",r['text']);d=Decoder(samprate=16000,loglevel='ERROR')
  for word,phones in {'fulgurites':'F AH L G Y ER AY T S','fulgurite':'F AH L G Y ER AY T'}.items():
   if not d.lookup_word(word):d.add_word(word,phones,update=True)
  missing=sorted({w.lower() for w in tokens if not d.lookup_word(w.lower())});assert not missing,(r['id'],missing)
  d.set_align_text(' '.join(w.lower() for w in tokens))
  with wave.open(str(dst)) as w:data=w.readframes(w.getnframes())
  d.start_utt();d.process_raw(data,full_utt=True);d.end_utt();segs=[s for s in d.seg() if s.word not in ['<sil>','<s>','</s>','[SPEECH]','[NOISE]']];assert len(segs)==len(tokens),(r['id'],len(segs),len(tokens))
  words=[]
  for token,s in zip(tokens,segs):
   assert re.sub(r'\(\d+\)$','',s.word)==token.lower()
   words.append({'word':token,'start':s.start_frame/100,'end':min(r['duration'],(s.end_frame+1)/100)})
  cache.write_text(json.dumps({'method':'Offline PocketSphinx forced alignment','words':words},indent=2))
 k=0
 for text in parts(r['text']):
  n=len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",text));ws=words[k:k+n];k+=n;CAP.append({'start':r['start']+ws[0]['start'],'end':min(r['end'],r['start']+ws[-1]['end']+.10),'text':text,'role':r['role'],'cue':r['id']})
 assert k==len(words),(r['id'],k,len(words));ALL.extend(dict(w,start=w['start']+r['start'],end=w['end']+r['start'],cue=r['id']) for w in words)
 print(f"Aligned {r['id']}/49",flush=True)
for i in range(len(CAP)-1):CAP[i]['end']=min(CAP[i]['end'],CAP[i+1]['start'])
(B/'output/captions.json').write_text(json.dumps(CAP,indent=2));(B/'output/words.json').write_text(json.dumps({'method':'Offline acoustic alignment to saved native speech','words':ALL},indent=2));print(json.dumps({'captions':len(CAP),'duration':T['duration']}),flush=True)
