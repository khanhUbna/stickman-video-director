from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,urllib.request,urllib.error,subprocess,wave,hashlib,shutil
B=Path(__file__).resolve().parent;S=json.loads((B/'story.json').read_text());OLD=Path('/workspace/scratch/lightning-short-v1');old=json.loads((OLD/'timeline.json').read_text()) if (OLD/'timeline.json').exists() else {'cues':[]};reusable={(r['role'],r['text']):r for r in old['cues']}
def one(r):
 i=r['id'];dst=B/f'audio/{i:02d}.wav';raw=B/f'audio/{i:02d}-api.wav';rec=B/f'audio/{i:02d}-request.json';reuse=False
 if not dst.exists() and (B/f'audio/{i:02d}-reuse.json').exists() and (r['role'],r['text']) not in reusable:raise RuntimeError(f'Saved reused cue {i} is missing; restore it from the source archive, do not revoice it')
 if not dst.exists() and (r['role'],r['text']) in reusable:
  src=OLD/reusable[(r['role'],r['text'])]['file'];shutil.copy2(src,dst);(B/f'audio/{i:02d}-reuse.json').write_text(json.dumps({'source':'lightning-short-v1','source_cue':reusable[(r['role'],r['text'])]['id'],'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'new_paid_call':False},indent=2));reuse=True
 if not dst.exists():
  if not raw.exists():
   if rec.exists():raise RuntimeError(f'Cue {i} already attempted; no automatic paid retry')
   rec.write_text(json.dumps({'model':'tts-1','voice':S['voices'][r['role']],'speed':1,'characters':len(r['text']),'estimated_usd':len(r['text'])*.000015,'state':'attempted','automatic_retry':False,'authorization':'User requested full English long film; estimated TTS cost USD 0.06 to 0.10 announced before call'},indent=2))
   req=urllib.request.Request('https://api.openai.com/v1/audio/speech',data=json.dumps({'model':'tts-1','voice':S['voices'][r['role']],'input':r['text'],'speed':1,'response_format':'wav'}).encode(),headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'application/json'})
   try:
    with urllib.request.urlopen(req,timeout=180) as resp:raw.write_bytes(resp.read())
   except urllib.error.HTTPError as e:
    d=json.loads(rec.read_text());d.update(state='failed',http_status=e.code);rec.write_text(json.dumps(d,indent=2));raise RuntimeError(f'Cue {i}: HTTP {e.code}; no retry or key logging') from None
   d=json.loads(rec.read_text());d.update(state='saved',sha256=hashlib.sha256(raw.read_bytes()).hexdigest());rec.write_text(json.dumps(d,indent=2))
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-ar','48000','-ac','1',str(dst)],check=True)
 reuse=reuse or (B/f'audio/{i:02d}-reuse.json').exists()
 with wave.open(str(dst)) as w:duration=w.getnframes()/w.getframerate()
 print(f"Cue {i}/49: {'reuse' if reuse else 'saved'} {duration:.2f}s",flush=True)
 return dict(r,file=str(dst.relative_to(B)),duration=duration,reused=reuse,voice=S['voices'][r['role']])
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=2) as p:rows=list(p.map(one,S['rows']))
 t=.12
 active=[r for r in rows if r['scene'] not in S.get('excluded_scenes',['many_paths','recap'])]
 answer=next(r for r in active if r['id']==8);active.remove(answer);answer['chapter']='THE MYSTERY';active.insert(3,answer)
 for r in active:
  r['start']=round(t,4);r['end']=round(t+r['duration'],4);r['visual_end']=round(t+max(r['duration']+.32,len(r['text'].split())/3.05+.25),4);t=r['visual_end']
  if r['scene'] in ['pulse_clock','fulgurite','voltage_map','car_shell']:t+=.65;r['visual_end']=round(t,4)
 duration=max(t+.8,300)
 active[-1]['visual_end']=duration
 doc={'title':S['title'],'duration':duration,'fps':30,'dimensions':[1280,720],'voices':S['voices'],'cues':active,'new_native_responses':sum(not r['reused'] for r in rows),'reused_responses':sum(r['reused'] for r in rows),'estimated_tts_usd':sum(len(r['text'])*.000015 for r in rows if not r['reused']),'billing_verified':False,'editorial_cuts':[r['id'] for r in rows if r not in active]}
 (B/'timeline.json').write_text(json.dumps(doc,indent=2));print(json.dumps({k:doc[k] for k in ['duration','new_native_responses','reused_responses','estimated_tts_usd']},indent=2),flush=True)
