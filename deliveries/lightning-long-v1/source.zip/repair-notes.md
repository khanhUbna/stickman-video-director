# Editorial and motion repair record

- The raw script has 49 recorded/reused dialogue blocks. Two redundant explanatory blocks (`many_paths`, `recap`) were removed from the final timeline, leaving 47 active blocks. Their paid audio was retained; no revoicing was used for the edit.
- The ground-current sentence was moved directly after the first Bolt/Ground exchange, starting at approximately 17.01 seconds. Existing speech was reused and re-aligned; the total running time did not increase.
- The initial cow animation used a body translation not tied to leg phase. It was replaced with one eased 126-unit travel shared by body and the four leg chains.
- Full decoded/motion review then found an initial neutral-to-walking stance change of 25.65 world pixels. An explicit `walking` state now selects the correct gait from zero travel, while stationary cow scenes preserve their own stance. The regression check covers consecutive planted feet in the actual final motion trace, not a separate disconnected skeleton. Exact final drift is in `decoded-review.json`.
- Parked wheel rotation was removed; wheel rotation is limited to the vehicle's actual arrival. Tire damage is an illustrative sidewall mark, not a tire/vehicle floating off the road.
- Diagram builds, contact points, current routes, comparison highlights and pressure-wave growth are staged against the saved narration. Source stills and decoded before/after samples are checked separately; these do not imply independent creative or real-time listening approval.
- Earlier local work products are retained for traceability and excluded from the final source zip's large media payload. No new generation call was needed for these corrections.
