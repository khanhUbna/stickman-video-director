from pathlib import Path
import json,subprocess,hashlib,wave
import numpy as np
from PIL import Image,ImageDraw
import animate as A
B=A.B;O=A.O;MOV=O/'lightning-hits-the-ground-then-what.mp4'
def decoded(t):
 r=subprocess.run(['ffmpeg','-v','error','-ss',str(t),'-i',str(MOV),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-'],check=True,capture_output=True);return Image.fromarray(np.frombuffer(r.stdout,np.uint8).reshape((720,1280,3)))
def main():
 samples=[]
 for phase,f in enumerate([.18,.78]):
  for page in range(2):
   sheet=Image.new('RGB',(1280,6*205),'white');g=ImageDraw.Draw(sheet)
   for j,r in enumerate(A.C[page*24:(page+1)*24]):
    at=r['start']+(r['visual_end']-r['start'])*f;im=decoded(at);im.save(O/f"decoded-{r['id']:02d}-{phase+1}.jpg",quality=90);im.thumbnail((320,180));x=j%4*320;y=j//4*205;sheet.paste(im,(x,y));g.text((x+5,y+182),f"{r['scene']} {at:.1f}s",fill='black');samples.append({'cue':r['id'],'scene':r['scene'],'time':at})
   sheet.save(O/f'decoded-review-{phase*2+page+1}.jpg',quality=94)
 decoded(1.2).save(O/'cover.jpg',quality=94)
 norm=lambda s:''.join(c.lower() for c in s if c.isalpha());assert norm(' '.join(c['text'] for c in A.CAP))==norm(' '.join(r['text'] for r in A.C));assert all(A.CAP[i]['end']<=A.CAP[i+1]['start']+.001 for i in range(len(A.CAP)-1));assert max(A.Q.font(32).getlength(c['text']) for c in A.CAP)<=1120
 cows=json.loads((O/'supporting-motion.json').read_text());drift=[]
 for a,b in zip(cows,cows[1:]):
  if b['time']-a['time']>1/30+.0001:continue
  for la,lb in zip(a['legs'],b['legs']):
   if la['planted'] and lb['planted']:drift.append(float(np.linalg.norm(np.asarray(la['joints'][-1])-lb['joints'][-1])))
 assert drift and max(drift)<1e-6,max(drift) if drift else 'No stance evidence'
 # Actual decoded audio, not just the existence of source WAVs.
 raw=subprocess.run(['ffmpeg','-v','error','-i',str(MOV),'-vn','-ar','48000','-ac','1','-f','f32le','-'],capture_output=True,check=True);encoded=np.frombuffer(raw.stdout,'<f4')
 with wave.open(str(B/'audio/dialogue.wav')) as w:voice=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
 bg=np.zeros(len(voice),np.float32)
 for name in ['music-original','foley-original','ambience-original']:
  with wave.open(str(B/'audio'/f'{name}.wav')) as w:bg+=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
 audio=[]
 for r in A.C:
  a=round(r['start']*48000);b=min(round(r['end']*48000),len(encoded),len(voice));x=encoded[a:b];v=voice[a:b];noise=bg[a:b];corr=float(np.corrcoef(v,x)[0,1]);db=float(20*np.log10(np.sqrt(np.mean(v*v))/max(1e-9,np.sqrt(np.mean(noise*noise)))));assert corr>.75,(r['id'],corr);audio.append({'cue':r['id'],'role':r['role'],'encoded_voice_correlation':corr,'dialogue_above_background_db':db})
 (O/'voice-presence-checks.json').write_text(json.dumps({'all_spoken_blocks_present':True,'segments':audio,'minimum_correlation':min(r['encoded_voice_correlation'] for r in audio),'qualification':'Signal presence/mix measurements, not independent listening or intelligibility approval'},indent=2))
 changes=[]
 for r in A.C:
  a=np.array(decoded(r['start']+(r['visual_end']-r['start'])*.18))[90:610];b=np.array(decoded(r['start']+(r['visual_end']-r['start'])*.78))[90:610];changes.append({'cue':r['id'],'scene':r['scene'],'main_picture_difference':float(np.abs(a.astype(float)-b).mean())})
 report={'sha256':hashlib.sha256(MOV.read_bytes()).hexdigest(),'decoded_samples':samples,'caption_text_coverage':'pass','caption_non_overlap':'pass','caption_single_line_width':'pass','cow_stance_max_world_foot_drift':max(drift),'picture_samples':changes,'review_scope':'Author source and actual decoded before/after frames, speech-presence and stance checks; no independent creative or full real-time AV listening review claimed.'};(O/'decoded-review.json').write_text(json.dumps(report,indent=2));print(json.dumps({'decoded_samples':len(samples),'all_dialogue_blocks_present':len(audio),'minimum_audio_correlation':min(r['encoded_voice_correlation'] for r in audio),'cow_stance_foot_drift':max(drift)},indent=2),flush=True)
if __name__=='__main__':main()
