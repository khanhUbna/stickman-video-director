"""Master the existing mix, decode-check it, and measure the encoded delivery."""
from pathlib import Path
import hashlib,json,re,subprocess
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parent;O=B/'output';V=O/'why-you-clean-instead-of-starting.mp4'
def run(cmd):return subprocess.run(cmd,check=True,capture_output=True)
def measure(p):
    r=run(['ffmpeg','-hide_banner','-nostats','-i',str(p),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'])
    return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
pre=measure(V)
flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true:print_format=json'
master=O/'mastered.mp4'
run(['ffmpeg','-v','error','-y','-i',str(V),'-map','0:v:0','-map','0:a:0','-c:v','copy','-af',flt,'-ar','48000','-c:a','aac','-b:a','192k','-movflags','+faststart',str(master)])
master.replace(V)
run(['ffmpeg','-v','error','-i',str(V),'-f','null','-'])
post=measure(V)
probe=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(V)]).stdout)
(O/'final-probe.json').write_text(json.dumps(probe,indent=2)+'\n')
project=json.loads((B/'project.json').read_text());words=json.loads((B/'words.json').read_text())['words']
normalize=lambda s:re.sub('[^a-z]','',s.lower())
script=(B/'script.txt').read_text()
assert normalize(' '.join(c['text'] for c in project['captions']))==normalize(script)
assert normalize(' '.join(w['word'] for w in words))==normalize(script)
v=next(s for s in probe['streams'] if s['codec_type']=='video')
assert(v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1080,1920,'30/1',798)
# Encoded 360px frames of every shot, not regenerated source frames.
contact=Image.new('RGB',(1080,5*665),'#e3e8e4');d=ImageDraw.Draw(contact)
for i,s in enumerate(project['shots']):
    t=(s['start']+s['end'])/2
    raw=run(['ffmpeg','-v','error','-ss',str(t),'-i',str(V),'-frames:v','1','-vf','scale=360:640','-f','rawvideo','-pix_fmt','rgb24','pipe:1']).stdout
    im=Image.frombytes('RGB',(360,640),raw);x=(i%3)*360;y=(i//3)*665;contact.paste(im,(x,y));d.text((x+8,y+644),f"{s['id']} | {t:.2f}s",fill='#24353c')
contact.save(O/'encoded-contact-sheet.jpg',quality=92)
qa={'status':'technical_checks_passed_user_review_pending','video_sha256':hashlib.sha256(V.read_bytes()).hexdigest(),'voice_sha256':hashlib.sha256((B/'voice.wav').read_bytes()).hexdigest(),'duration_seconds':float(probe['format']['duration']),'native_voice_seconds':26.575,'voice_speed':'1x; original WAV retained; final mix gain/loudness normalization only','dimensions':[1080,1920],'fps':30,'frames':798,'full_decode':'pass','approved_script_caption_word_coverage':'pass','acoustic_aligned_words':len(words),'caption_cues':len(project['captions']),'shots':len(project['shots']),'pre_master_loudness':pre,'final_loudness':post,'phone_size_source_paint':'See paint-QA.json; bounded native-safe-area/visibility and isolated local-motion checks','rig':'See rig-frame-QA.json; connected full-body limb/hand geometry checked at encoded frame times','encoded_contact_sheet':'15 actual decoded middle frames, one per shot','review_limits':['No independent creative review or end-to-end human listening/playback was performed; these remain user review.','Caveat is the licensed portable handwritten font, not pixel-identical to historical Apple Chalkboard.','Bounded pixel/geometry checks do not certify natural acting or artistic equivalence to the Skill references.'],'YouTube_upload':False,'paid_calls':{'tts':1,'alignment':0,'images':0,'estimated_tts_usd':0.006495,'automatic_paid_retries':0}}
assert float(post['input_tp'])<=-.9,post
assert -18<=float(post['input_i'])<=-13,post
(O/'QA.json').write_text(json.dumps(qa,indent=2)+'\n')
print(json.dumps({k:qa[k] for k in ['duration_seconds','dimensions','frames','full_decode','approved_script_caption_word_coverage','paid_calls']},indent=2));print('Final loudness',post['input_i'],'LUFS,',post['input_tp'],'dBTP')
