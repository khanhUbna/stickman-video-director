import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
const ROOT='/workspace/stickman-video-director/skills/directing-stickman-videos';
const req=createRequire(ROOT+'/package.json');
const {createCanvas,GlobalFonts}=req('@napi-rs/canvas');
const B=path.dirname(new URL(import.meta.url).pathname), A=B+'/art';fs.mkdirSync(A,{recursive:true});
const C={ink:'#24353c',gold:'#edbc3b',sage:'#4d9d88',red:'#dc7c68',blue:'#719db0',paper:'#fdfdfc'};
GlobalFonts.registerFromPath(ROOT+'/assets/fonts/Caveat.ttf','Hand');
function line(g,pts,col=C.ink,w=3.5){g.beginPath();g.strokeStyle=col;g.lineWidth=w;g.lineCap='round';g.lineJoin='round';g.moveTo(...pts[0]);for(const p of pts.slice(1))g.lineTo(...p);g.stroke();}
function box(g,x,y,w,h,col=C.paper,r=8){g.beginPath();g.roundRect(x,y,w,h,r);g.fillStyle=col;g.fill();g.strokeStyle=C.ink;g.lineWidth=3;g.stroke();}
function oval(g,x,y,rx,ry,col=C.paper){g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);g.fillStyle=col;g.fill();g.strokeStyle=C.ink;g.lineWidth=3.5;g.stroke();}
function txt(g,s,x,y,size=34,col=C.ink){g.font=`600 ${size}px Hand`;g.fillStyle=col;g.fillText(s,x,y);}
function asset(n,w,h,f){const c=createCanvas(w,h),g=c.getContext('2d');g.lineCap='round';g.lineJoin='round';f(g);fs.writeFileSync(`${A}/${n}.png`,c.toBuffer('image/png'));}
asset('bone',200,12,g=>line(g,[[0,6],[200,6]],C.ink,5));
asset('hand',40,32,g=>oval(g,20,16,15,10));
asset('shoe',70,28,g=>oval(g,35,14,31,10,'#d8e6e8'));
if(!fs.existsSync(A+'/scarf.png')) fs.copyFileSync('/workspace/scratch/channel-minute-reference/art/scarf.png',A+'/scarf.png');
for(const mood of ['worry','busy','proud','deflated','focus','relief','side'])asset('head-'+mood,220,220,g=>{
 oval(g,110,112,78,81);line(g,[[60,45],[47,23],[32,23]],C.ink,4);
 const side=['side','focus'].includes(mood),dx=side?25:0;
 oval(g,85+dx,106,5,10,C.ink);oval(g,132+dx,106,5,10,C.ink);
 if(mood==='worry'||mood==='deflated'){line(g,[[70+dx,83],[96+dx,74]],C.ink,4);line(g,[[120+dx,78],[146+dx,85]],C.ink,4);}
 else if(mood==='busy'||mood==='proud'){line(g,[[70,78],[96,82]],C.ink,4);line(g,[[120,82],[146,76]],C.ink,4);}
 else{line(g,[[70+dx,82],[96+dx,80]],C.ink,4);line(g,[[120+dx,81],[146+dx,79]],C.ink,4);}
 g.beginPath();g.strokeStyle=C.ink;g.lineWidth=4;g.moveTo(84+dx,148);
 g.quadraticCurveTo(110+dx,['busy','proud','relief'].includes(mood)?174:['worry','deflated'].includes(mood)?130:150,138+dx,148);g.stroke();
 if(mood==='worry')line(g,[[177,99],[184,116],[176,123]],C.blue,3);
});
asset('counter',530,470,g=>{box(g,3,23,520,32,'#e6bf8c',4);box(g,28,58,470,394,'#f2e6d2',5);for(const x of [184,340])line(g,[[x,60],[x,450]],'#bda98e',2);for(const x of [134,290,445])line(g,[[x,91],[x+22,91]],C.ink,4);box(g,440,0,36,22,C.sage,3);});
asset('tiles',530,370,g=>{box(g,3,3,520,360,'#eef5f0',3);for(let x=65;x<520;x+=65)line(g,[[x,4],[x,363]],'#cfdfd6',1.5);for(let y=63;y<360;y+=60)line(g,[[4,y],[523,y]],'#cfdfd6',1.5);});
asset('cloth',150,75,g=>{box(g,9,12,130,48,C.gold,8);line(g,[[25,25],[120,43]],'#bd9433',3);line(g,[[31,52],[121,53]],'#d4a83a',2);});
asset('dirty',470,100,g=>{for(const [x,y,r] of [[20,45,7],[75,65,5],[118,21,8],[170,55,6],[220,25,9],[290,65,5],[350,35,8],[430,50,6]]){g.fillStyle='#b2947a';g.beginPath();g.ellipse(x,y,r*1.7,r,0,0,Math.PI*2);g.fill();}});
asset('crumb',100,80,g=>{for(const [x,y,r] of [[25,42,9],[51,25,5],[66,49,7]]){g.fillStyle='#ab835a';g.beginPath();g.arc(x,y,r,0,Math.PI*2);g.fill();}});
asset('plate',210,210,g=>{oval(g,105,105,98,98,'#e4eee9');oval(g,105,105,75,75,C.paper);});
asset('rack',340,220,g=>{box(g,14,176,310,26,'#c4d7d5',5);for(let x=35;x<320;x+=40)line(g,[[x,174],[x,28],[x+12,14]],C.blue,5);line(g,[[12,202],[6,217]],C.ink,4);line(g,[[324,202],[333,217]],C.ink,4);});
asset('table',940,380,g=>{box(g,8,10,920,30,'#e8c79d',4);line(g,[[70,42],[55,370]],C.ink,5);line(g,[[866,42],[879,370]],C.ink,5);});
asset('laptop',820,610,g=>{box(g,60,12,700,445,'#d9e6e7',15);box(g,78,30,664,405,C.paper,5);g.beginPath();g.moveTo(60,458);g.lineTo(760,458);g.lineTo(815,580);g.lineTo(5,580);g.closePath();g.fillStyle='#cadadb';g.fill();g.stroke();for(let y=477;y<550;y+=22)for(let x=96;x<730;x+=47)box(g,x+(y-477)*-.2,y,36,12,'#edf2ef',2);box(g,331,547,155,23,'#e5ece7',3);});
asset('email-blank',650,380,g=>{box(g,3,3,640,367,C.paper,5);box(g,5,5,636,60,'#f8e6a7',3);txt(g,'Draft · Important email',24,48,34);line(g,[[22,93],[615,93]],'#bdccca',2);txt(g,'To: Alex',26,87,25,C.blue);box(g,480,302,132,45,'#e4eee9',5);txt(g,'Send',516,336,30);});
asset('keyboard',880,270,g=>{box(g,8,8,864,249,'#d5e2df',12);for(let y=35;y<190;y+=48)for(let x=35;x<840;x+=63)box(g,x,y,50,33,'#f5f6ee',4);box(g,240,213,390,27,'#f5f6ee',5);});
asset('chair',260,450,g=>{box(g,99,10,151,240,'#dbe9e4',22);box(g,15,250,228,28,C.sage,9);line(g,[[145,280],[145,405]],C.ink,5);line(g,[[145,405],[31,436]],C.ink,5);line(g,[[145,405],[241,437]],C.ink,5);});
asset('doorway',300,800,g=>{box(g,5,5,290,790,'#f0f4ee',3);box(g,23,23,250,770,C.paper,3);oval(g,245,425,6,6,C.gold);});
asset('shelf',380,350,g=>{line(g,[[8,290],[370,290]],C.ink,5);for(const [i,c] of [C.gold,C.blue,C.sage].entries()){box(g,50+i*90,80+i*20,64,205-i*20,c,4);}line(g,[[32,290],[32,338]],C.ink,4);line(g,[[338,290],[338,338]],C.ink,4);});

const norm=s=>s.toLowerCase().replace(/[^a-z]/g,'');
const words=JSON.parse(fs.readFileSync(B+'/words.json')).words;
const phrases=['Ever cleaned your entire room','to avoid one email?','The email takes five minutes.','Suddenly, your kitchen needs forty.','Sometimes, the easier task','offers a clear finish.','The important one','brings uncertainty.','What if they say no?','So try this:','open the draft.','Write one messy sentence.','You don\'t have to send it yet.','The goal isn\'t a perfect email.','It\'s a first move','you can actually make.','What\'s the five-minute task','you\'ve been avoiding?'];
let wi=0;
const captions=phrases.map(text=>{let target=norm(text),acc='',start=words[wi].start,end=start;while(acc!==target){let w=words[wi++];if(!w)throw Error('caption exhausted');acc+=norm(w.word);end=w.end;if(!target.startsWith(acc))throw Error(text+' '+acc);}return{start,end,text};});
if(wi!==words.length)throw Error('uncovered words');
captions.forEach((c,i)=>c.end=Math.min((captions[i+1]?.start??26.5)-.015,c.end+.13));
const D=Number(execFileSync('ffprobe',['-v','error','-show_entries','format=duration','-of','csv=p=0',B+'/voice.wav'],{encoding:'utf8'}));
const clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},lerp=(a,b,t)=>a+(b-a)*t;
const point=(a,b,t)=>a.map((n,i)=>lerp(n,b[i],t));
const img=(n,x,y,w,id,more={})=>({type:'image',path:`art/${n}.png`,x,y,w,id,...more});
const text=(s,x,y,size,id,color=C.ink)=>({type:'text',text:s,x,y,size,w:960,id,color});
function ik(a,b,l1,l2,bend){let dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy);if(d>l1+l2+.1||d<Math.abs(l1-l2))throw Error('unreachable '+JSON.stringify({a,b,d,l1,l2}));let theta=Math.atan2(dy,dx),q=Math.acos(Math.max(-1,Math.min(1,(l1*l1+d*d-l2*l2)/(2*l1*d))));return[a[0]+l1*Math.cos(theta+bend*q),a[1]+l1*Math.sin(theta+bend*q)];}
const rigQA=[];
function rig(id,span,state,mood='worry'){
 const samples=[];for(let t=0;t<span;t+=.08)samples.push({t,...state(t,span)});samples.push({t:span,...state(span,span)});
 for(const s of samples){s.EL=ik(s.N,s.L,190,185,1);s.ER=ik(s.N,s.R,190,185,-1);s.KL=ik(s.P,s.FL,175,180,-1);s.KR=ik(s.P,s.FR,175,180,1);s.HB=[s.H[0],s.H[1]+65];}
 const layers=[];
 for(const [n,a,b,len] of [['neck','HB','N',null],['body','N','P',null],['upperL','N','EL',190],['foreL','EL','L',185],['upperR','N','ER',190],['foreR','ER','R',185],['thighL','P','KL',175],['shinL','KL','FL',180],['thighR','P','KR',175],['shinR','KR','FR',180]]){
  let prev;const keys=samples.map(s=>{let dx=s[b][0]-s[a][0],dy=s[b][1]-s[a][1],ang=Math.atan2(dy,dx);if(prev!==undefined){while(ang-prev>Math.PI)ang-=2*Math.PI;while(ang-prev< -Math.PI)ang+=2*Math.PI;}prev=ang;const w=Math.hypot(dx,dy),hh=12*w/200;return {t:s.t,x:s[a][0]+Math.sin(ang)*hh/2,y:s[a][1]-Math.cos(ang)*hh/2,w,angle:ang};});
  if(len)rigQA.push({shot:id,limb:n,max_length_error:Math.max(...keys.map(k=>Math.abs(k.w-len)))});
  layers.push(img('bone',0,0,keys[0].w,id+'-'+n,{keys,...(['foreL','foreR'].includes(n)?{motion:{role:'actor',reason:'Connected arms perform the current reach, wipe, withdrawal or deliberate typing action'}}:{})}));
 }
 for(const [n,k] of [['left','L'],['right','R']])layers.push(img('hand',0,0,40,id+'-hand-'+n,{keys:samples.map(s=>({t:s.t,x:s[k][0]-20,y:s[k][1]-16}))}));
 for(const [n,k] of [['left','FL'],['right','FR']])layers.push(img('shoe',0,0,70,id+'-foot-'+n,{keys:samples.map(s=>({t:s.t,x:s[k][0]-35,y:s[k][1]-12}))}));
 layers.push(img('head-'+mood,0,0,200,id+'-head',{keys:samples.map(s=>({t:s.t,x:s.H[0]-100,y:s.H[1]-100}))}));
 layers.push(img('scarf',0,0,83,id+'-scarf',{keys:samples.map(s=>({t:s.t,x:s.N[0]-35,y:s.N[1]-4}))}));
 return {layers,samples};
}
function standing(t,span,mode='wipe'){
 const q=ease(t/span),sweep=Math.sin(t*4.2),lean=mode==='turn'?50*q:0;
 let N=[445+lean,800],P=[400+lean,1040],H=[430+lean,690],L=[655+sweep*65,1000],R=[625+sweep*45,990],FL=[325+lean,1330],FR=[510+lean,1330];
 if(mode==='hesitate'){L=point([560,1005],[595,970],ease(t/.6));R=point([550,1040],[562,1010],ease(t/.9));H=[430+q*14,690+q*16];}
 if(mode==='proud'){L=point([680,1000],[515,1160],ease(t/.65));R=point([625,1000],[625,1110],q);H=[430,690-12*Math.sin(q*Math.PI)];}
 if(mode==='deflate'){L=[535,1120+q*30];R=point([570,1020],[550,1140],q);H=[430-q*16,690+q*28];N=[445,800+q*12];}
 if(mode==='turn'){L=point([535,1120],[690,1000],ease(t/.65));R=point([560,1130],[575,1140],q);}
 return {N,P,H,L,R,FL,FR};
}
function seated(t,span,mode='type'){
 const q=ease(t/span),k=Math.sin(t*17),N=[650,905],P=[740,1110],H=[630,795],FL=[590,1395],FR=[900,1375];
 let L=[450+k*7,1090+Math.max(0,k)*10],R=[545-k*5,1100+Math.max(0,-k)*9];
 if(mode==='hover'){L=point([565,1120],[485,1092],ease(t/.5));R=point([590,1135],[553,1110],ease(t/.7));}
 if(mode==='open'){L=point([580,1100],[470,1090],ease(t/.55));R=point([565,1125],[530,1090],ease(t/.8));}
 if(mode==='relax'){H[1]-=q*25;N[1]-=q*18;}
 return{N,P,H,L,R,FL,FR};
}
const specs=[
 {start:0,end:1.36,id:'s01',kind:'hover',meaning:'One hand approaches the empty email, then pauses; the face turns uncertain.'},
 {start:1.36,end:2.90,id:'s02',kind:'escape',meaning:'Instead of replying, the character grabs the yellow cleaning cloth and turns away.'},
 {start:2.90,end:4.72,id:'s03',kind:'email',meaning:'A closeup reveals one small, still-empty email draft and a five-minute estimate.'},
 {start:4.72,end:7.10,id:'s04',kind:'wipe',meaning:'A supported cloth wipes a visibly dirty counter clean, matching the kitchen diversion.'},
 {start:7.10,end:8.69,id:'s05',kind:'plate',meaning:'Hands carry the last plate into the rack; a concrete task visibly completes.'},
 {start:8.69,end:10.45,id:'s06',kind:'crumb',meaning:'A large closeup follows the final crumb into the cloth; the counter is clean.'},
 {start:10.45,end:12.94,id:'s07',kind:'contrast',meaning:'The cloth lowers and the proud smile falls; the important email remains empty.'},
 {start:12.94,end:14.28,id:'s08',kind:'worry',meaning:'The face tightens and a hand hesitates; no actual rejection is invented.'},
 {start:14.28,end:15.55,id:'s09',kind:'setdown',meaning:'The character sets the cloth down, freeing both hands to return to the draft.'},
 {start:15.55,end:17.06,id:'s10',kind:'open',meaning:'A deliberate hand movement opens the email draft and reaches the keyboard.'},
 {start:17.06,end:18.48,id:'s11',kind:'type',meaning:'Fingers contact the keyboard and the first imperfect sentence appears progressively.'},
 {start:18.48,end:19.96,id:'s12',kind:'withdraw',meaning:'A finger approaches Send then withdraws; the email stays visibly marked Draft.'},
 {start:19.96,end:21.73,id:'s13',kind:'sentence',meaning:'The actual typed sentence remains, with a new keystroke instead of endless correction.'},
 {start:21.73,end:24.16,id:'s14',kind:'relax',meaning:'The shoulders release as the character continues typing; real progress replaces cleaning.'},
 {start:24.16,end:D,id:'s15',kind:'ending',meaning:'Close on ongoing deliberate typing and the unsent draft, leaving the spoken question to the viewer.'}
];
const shots=[],ledger=[];
function animated(n,id,samples,fn,w,role='prop',reason='The object follows the character contact through the action and visible result'){
 return img(n,0,0,w,id,{keys:samples.map(s=>({t:s.t,...fn(s)})),motion:{role,reason}});
}
function keyboardHand(id,span,from,to){return img('hand',0,0,100,id,{keys:[{t:0,x:from[0],y:from[1]},{t:span*.55,x:to[0],y:to[1]},{t:span,x:to[0]-18,y:to[1]+12}],motion:{role:'actor',reason:'The visible finger approaches the actual control then deliberately leaves it without sending'}});}
function emailFrame(id,x=180,y=610,w=850){return[img('laptop',x,y,w,id+'-laptop'),img('email-blank',x+w*.096,y+w*.068,w*.807,id+'-draft')];}
function sentenceLayers(id,span,x,y,size,initial='',typing=true){
 const sentence='Hi, could we talk about this?';let arr=[];
 if(!typing)arr.push(text(sentence,x,y,size,id+'-written'));
 else for(let i=0;i<sentence.length;i++){const from=(i/sentence.length)*Math.min(span*.88,1.3),to=i===sentence.length-1?span:((i+1)/sentence.length)*Math.min(span*.88,1.3);arr.push({...text(sentence.slice(0,i+1),x,y,size,id+'-letters-'+i),from,to});}
 arr.push({type:'line',id:id+'-caret',points:[[x+(typing?0:585),y+18],[x+(typing?0:585),y+65]],color:C.sage,lineWidth:3,keys:[{t:0,progress:.15},{t:span,progress:1}],motion:{role:'information',reason:'The insertion caret accompanies the genuinely growing email draft'}});
 return arr;
}
for(const spec of specs){const {start,end,id,kind}=spec,span=end-start;let layers=[],r;
 const add=(...l)=>layers.push(...l);
 if(['hover','open','relax'].includes(kind)){
  add(img('chair',735,900,260,id+'-chair'),img('table',120,1110,940,id+'-table'));
  // Side-on laptop: screen above the typing surface, character beside it.
  add(...emailFrame(id,120,780,520));
  r=rig(id,span,t=>seated(t,span,kind==='open'?'open':kind==='relax'?'relax':'hover'),kind==='hover'?'worry':'focus');add(...r.layers);
  if(kind==='hover')add(text('ONE EMAIL.',170,330,96,id+'-headline',C.gold));
  if(kind==='relax')add(...sentenceLayers(id,span,190,890,27,'',false));
 }
 if(kind==='escape'){
  add(img('doorway',790,620,250,id+'-door'),img('shelf',180,1050,340,id+'-shelf'));
  r=rig(id,span,t=>{let s=standing(t,span,'turn'),q=ease(t/span);s.N[0]+=q*95;s.P[0]+=q*95;s.H[0]+=q*95;s.FL[0]+=q*95;s.FR[0]+=q*95;s.L=point([350,1110],[660,1000],ease(t/.8));s.R=point([490,1130],[640,1020],q);return s},'busy');add(...r.layers);
  add(animated('cloth',id+'-cloth',r.samples,s=>({x:s.L[0]-65,y:s.L[1]-8}),130));
 }
 if(kind==='email'){
  add(text('FIVE MINUTES.',190,360,88,id+'-five',C.gold),...emailFrame(id,135,640,920));
  add(keyboardHand(id+'-hover',span,[740,1170],[680,1100]));
  add({type:'line',id:id+'-cursor',points:[[285,875],[285,930]],color:C.blue,lineWidth:4,keys:[{t:0,progress:.1},{t:span,progress:1}],motion:{role:'information',reason:'The empty draft awaits its first word while the hand stalls'}});
 }
 if(['wipe','contrast','setdown'].includes(kind)){
  add(img('tiles',575,600,460,id+'-tiles'),img('counter',575,980,470,id+'-counter'));
  if(kind==='wipe'){
   add(text('FORTY MINUTES?',180,345,88,id+'-forty',C.sage));
   for(let i=0;i<5;i++)add(img('dirty',590+i*66,970,80,id+'-dirt-'+i,{to:span*(.22+.15*i)}));
  }
  r=rig(id,span,t=>standing(t,span,kind==='wipe'?'wipe':kind==='contrast'?'deflate':'turn'),kind==='wipe'?'busy':kind==='contrast'?'deflated':'focus');add(...r.layers);
  if(kind==='wipe')add(animated('cloth',id+'-cloth',r.samples,s=>({x:s.L[0]-65,y:s.L[1]-12}),130));
  if(kind==='contrast'){
   add(animated('cloth',id+'-cloth',r.samples,s=>({x:s.L[0]-65,y:s.L[1]-10}),130));
   add(img('email-blank',655,650,330,id+'-still-empty')); // Actual untouched draft as story callback.
  }
  if(kind==='setdown')add(img('cloth',470,1100,130,id+'-cloth',{keys:[{t:0,x:470,y:1100},{t:span*.55,x:625,y:990},{t:span,x:625,y:990}],motion:{role:'prop',reason:'The held cloth is put down on the counter and remains there'}}));
 }
 if(kind==='plate'){
  add(img('tiles',130,500,910,id+'-tiles'),img('table',120,1250,940,id+'-ledge'),img('rack',680,950,310,id+'-rack'));
  add(img('plate',280,850,270,id+'-plate',{keys:[{t:0,x:280,y:950,angle:0},{t:span*.68,x:725,y:850,angle:-.15},{t:span,x:760,y:850,angle:-.15}],motion:{role:'prop',reason:'The last real plate is lifted and placed between drying-rack supports'}}));
  for(const [j,dx] of [[0,0],[1,220]])add(img('hand',260+dx,1100,75,id+'-plate-hand-'+j,{keys:[{t:0,x:260+dx,y:1100},{t:span*.68,x:705+dx,y:1000},{t:span,x:740+dx,y:1000}]}));
  // Forearms enter the closeup, following the supporting hands.
  for(const [j,dx] of [[0,0],[1,220]])add(img('bone',0,0,340,id+'-plate-arm-'+j,{keys:[{t:0,x:127+dx,y:1376,w:310.644,angle:-.991},{t:span*.68,x:572+dx,y:1276,w:310.644,angle:-.991},{t:span,x:607+dx,y:1276,w:310.644,angle:-.991}]}));
 }
 if(kind==='crumb'){
  add(img('tiles',145,550,885,id+'-tiles'),img('table',120,1180,940,id+'-ledge'),img('crumb',620,1085,130,id+'-crumb',{to:span*.57}));
  add(img('cloth',250,1070,250,id+'-cloth',{keys:[{t:0,x:250,y:1070},{t:span*.65,x:700,y:1070},{t:span,x:790,y:1080}],motion:{role:'prop',reason:'The final visible crumbs are physically swept away, leaving a clean surface'}}));
  add(img('hand',305,1005,145,id+'-hand',{keys:[{t:0,x:305,y:1005},{t:span*.65,x:755,y:1005},{t:span,x:845,y:1015}]}));
  add(img('bone',150,710,430,id+'-forearm',{keys:[{t:0,x:160,y:740,angle:.98},{t:span*.65,x:650,y:740,angle:1.1},{t:span,x:730,y:750,angle:1.1}]}));
 }
 if(kind==='worry'){
  add(img('head-worry',320,560,550,id+'-face',{keys:[{t:0,x:320,y:560},{t:span,x:340,y:585}]}),img('scarf',490,1050,200,id+'-scarf'));
  add(img('bone',595,1060,460,id+'-body',{angle:1.53}));
  add(img('hand',765,1025,96,id+'-face-hand',{keys:[{t:0,x:765,y:1125},{t:span,x:765,y:980}],motion:{role:'actor',reason:'The hand rises toward the pinched face as the character anticipates uncertainty'}}));
  const armSamples=[0,span*.5,span].map(t=>{const h=[813,1141-145*t/span],n=[590,1110];return {t,h,n,e:ik(n,h,190,185,1)}});
  for(const [part,a,b] of [['upper','n','e'],['fore','e','h']])add(img('bone',0,0,190,id+'-worry-'+part,{keys:armSamples.map(v=>({t:v.t,x:v[a][0],y:v[a][1],w:Math.hypot(v[b][0]-v[a][0],v[b][1]-v[a][1]),angle:Math.atan2(v[b][1]-v[a][1],v[b][0]-v[a][0])}))}));
 }
 if(['type','sentence','withdraw','ending'].includes(kind)){
  add(...emailFrame(id,130,485,940));
  add(...sentenceLayers(id,span,278,735,44,'',kind==='type'));
    if(kind==='ending'){
   const follow=kind==='sentence'?'I wanted to':'I wanted to ask...';
   for(let k=0;k<follow.length;k++){const from=k/follow.length*span*.8,to=k===follow.length-1?span:(k+1)/follow.length*span*.8;add({...text(follow.slice(0,k+1),278,810,42,id+'-next-'+k,C.blue),from,to});}
  }
  if(kind==='withdraw'){
   add(keyboardHand(id+'-send-hand',span,[790,950],[815,910]));
   // Last keys explicitly withdraw; no sent state or swoosh.
   layers.at(-1).keys=[{t:0,x:790,y:1000},{t:span*.35,x:815,y:910},{t:span,x:930,y:1150}];
  }else{
   for(let j=0;j<2;j++){const ks=[];for(let t=0;t<span;t+=.08)ks.push({t,x:365+j*350+Math.sin(t*7+j)*12,y:1080+Math.max(0,Math.sin(t*18+j))*13});ks.push({t:span,x:365+j*350,y:1080});add(img('hand',0,0,110,id+'-typing-'+j,{keys:ks,motion:{role:'actor',reason:'Fingers contact the keyboard in deliberate keystrokes as actual words appear or work continues'}}));}
  }
 }
 // Preserve natural scale: no global pan/zoom is used to earn motion coverage.
 const all=layers.map(l=>l.id);
 shots.push({id,start,end,layers,portrait:{intent:spec.meaning+' Native portrait arrangement keeps the whole action above the caption band.',regions:[{id:id+'-action',role:'contact',layer_ids:all,region:{x:95,y:260,w:1015,h:1400},intent:'The full character, hands, contact object and visible result remain legible within the phone stage.'}]}});
 ledger.push({...spec,spoken_text:captions.filter(c=>c.start<end&&c.end>start).map(c=>c.text).join(' '),view:kind,review:'authored; encoded review pending'});
}
const project={version:1,style:'B1',width:1080,height:1920,fps:30,voice:{path:'voice.wav'},shots,captions,music:{path:'music-original.wav',gain:.11},ambience:[{path:'room.wav',start:0,end:D,gain:.035}],sfx:[{time:1.7,kind:'paper',gain:.025},{time:4.95,kind:'file',path:'wipe.wav',gain:.16},{time:7.94,kind:'file',path:'plate.wav',gain:.12},{time:9.35,kind:'file',path:'wipe.wav',gain:.12},{time:14.95,kind:'paper',gain:.022},{time:15.90,kind:'tap',gain:.022},...[17.18,17.36,17.61,17.91,18.13,20.26,20.81,22.1,22.6,23.2,24.6,25.1,25.7].map(time=>({time,kind:'tap',gain:.012}))],reference_review:{author_id:'codex-short-author',capability:{mode:'sample_target',environment:'Codex Cloud; existing channel scarf/colors, original story-specific canvas art, connected IK rig, offline acoustic alignment, original synthesized score. No image generation calls.',limitations:[]}}};
fs.writeFileSync(B+'/project.json',JSON.stringify(project,null,2));fs.writeFileSync(B+'/shot-ledger.json',JSON.stringify(ledger,null,2));fs.writeFileSync(B+'/rig-QA.json',JSON.stringify({max_length_error:Math.max(...rigQA.map(q=>q.max_length_error)),limbs:rigQA},null,2));
console.log({duration:D,shots:shots.length,captions:captions.length,max_limb_error:Math.max(...rigQA.map(q=>q.max_length_error))});
