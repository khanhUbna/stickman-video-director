import fs from 'node:fs';
import {keyState} from '/workspace/stickman-video-director/skills/directing-stickman-videos/scripts/autopilot-render.mjs';
const B='/workspace/scratch/short-email-v1',p=JSON.parse(fs.readFileSync(B+'/project.json'));
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
function ends(l,t){let v=keyState(l,t),a=v.angle||0,w=v.w,h=12*w/200;let root=[v.x-Math.sin(a)*h/2,v.y+Math.cos(a)*h/2];return{root,tip:[root[0]+w*Math.cos(a),root[1]+w*Math.sin(a)],length:w};}
let maxJoint=0,maxHand=0,maxLength=0,frames=0;
for(const s of p.shots){let get=n=>s.layers.find(l=>l.id===s.id+'-'+n);if(!get('upperL'))continue;
 for(let t=0;t<s.end-s.start;t+=1/p.fps){frames++;
  for(const [a,b] of [['upperL','foreL'],['upperR','foreR'],['thighL','shinL'],['thighR','shinR']])maxJoint=Math.max(maxJoint,dist(ends(get(a),t).tip,ends(get(b),t).root));
  for(const [a,b] of [['foreL','hand-left'],['foreR','hand-right']]){let h=keyState(get(b),t);maxHand=Math.max(maxHand,dist(ends(get(a),t).tip,[h.x+20,h.y+16]));}
  for(const [n,len] of [['upperL',190],['foreL',185],['upperR',190],['foreR',185],['thighL',175],['shinL',180],['thighR',175],['shinR',180]])maxLength=Math.max(maxLength,Math.abs(ends(get(n),t).length-len));
 }
}
const qa={sampled_rig_frames:frames,max_joint_gap_design_units:maxJoint,max_hand_gap_design_units:maxHand,max_bone_length_error:maxLength,pass:maxJoint<2&&maxHand<2&&maxLength<1e-6,scope:'Connected full-body rigs at every encoded frame time; closeup-only arms and creative acting require separate visual review'};
fs.writeFileSync(B+'/rig-frame-QA.json',JSON.stringify(qa,null,2));console.log(qa);if(!qa.pass)process.exitCode=1;
