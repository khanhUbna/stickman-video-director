import fs from 'node:fs';
import {createRequire} from 'node:module';
import {loadProject} from '/workspace/stickman-video-director/skills/directing-stickman-videos/scripts/autopilot-core.mjs';
import {painter} from '/workspace/stickman-video-director/skills/directing-stickman-videos/scripts/autopilot-render.mjs';
const req=createRequire('/workspace/stickman-video-director/skills/directing-stickman-videos/package.json');
const {createCanvas}=req('@napi-rs/canvas');const B='/workspace/scratch/short-email-v1';
const p=loadProject(B+'/project.json'),draw=await painter(p);
const c=createCanvas(1440,5*665),g=c.getContext('2d');g.fillStyle='#e0e4e1';g.fillRect(0,0,c.width,c.height);
for(let i=0;i<p.shots.length;i++){const s=p.shots[i],t=(s.start+s.end)/2,x=(i%4)*360,y=Math.floor(i/4)*665;g.drawImage(draw(t),x,y,360,640);g.fillStyle='#22353c';g.font='16px sans-serif';g.fillText(`${s.id} ${t.toFixed(2)}s`,x+12,y+658);}
fs.writeFileSync(B+'/story-proof.png',c.toBuffer('image/png'));
