"""Original procedural score and Foley, no downloaded recordings or melody."""
from pathlib import Path
import hashlib,json,wave
import numpy as np
B=Path(__file__).resolve().parent
SR=48000;D=26.575
rng=np.random.default_rng(321901)
def save(name,a):
    a=np.clip(a,-.95,.95)
    with wave.open(str(B/name),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes((a*32767).astype('<i2').tobytes())
def pluck(freq,length=.65):
    t=np.arange(int(SR*length))/SR
    return (np.sin(2*np.pi*freq*t)+.20*np.sin(4*np.pi*freq*t)+.07*np.sin(6*np.pi*freq*t))*np.exp(-t*6)*np.minimum(1,t/.009)
N=int(SR*D);music=np.zeros(N)
chords=[[60,64,67],[57,60,64],[53,57,60],[55,59,62]]
beat=60/92
for i,at in enumerate(np.arange(.12,D-.25,beat/2)):
    chord=chords[int(at/(beat*4))%4];midi=chord[[0,2,1,2][i%4]]+(12 if i%8 in [3,7] else 0)
    note=pluck(440*2**((midi-69)/12),.72)*(.25 if at<10.45 else .13 if at<15.55 else .22)
    k=int(at*SR);n=min(len(note),N-k);music[k:k+n]+=note[:n]
for at in np.arange(.12,D,beat*4):
    midi=chords[int(at/(beat*4))%4][0]-12
    note=pluck(440*2**((midi-69)/12),1.3)*.17;k=int(at*SR);n=min(len(note),N-k);music[k:k+n]+=note[:n]
fade=np.minimum(1,np.arange(N)/(SR*.12))*np.minimum(1,(N-1-np.arange(N))/(SR*.45))
save('music-original.wav',music*fade)
noise=rng.normal(0,1,N);smooth=np.convolve(noise,np.ones(130)/130,mode='same')
save('room.wav',smooth*.16*fade)
t=np.arange(int(SR*.65))/SR
wipe=rng.normal(0,1,len(t));wipe=np.convolve(wipe,np.ones(10)/10,mode='same')
save('wipe.wav',wipe*.45*np.sin(np.pi*t/.65)**2)
t=np.arange(int(SR*.5))/SR
plate=sum(np.sin(2*np.pi*f*t)*np.exp(-t*d)*g for f,d,g in [(1030,18,.18),(1652,24,.10),(2341,33,.04)])*np.minimum(1,t/.002)
save('plate.wav',plate)
rights={'music-original.wav':{'creator':'Original procedural composition authored for this Short','source':'make_audio.py, seeded synthesis; no third-party melody or recording','use':'May synchronize, edit and redistribute in this video and its source package; no external library restrictions'},'room.wav':{'source':'Original seeded noise synthesis, make_audio.py'},'wipe.wav':{'source':'Original filtered-noise cloth illustration, make_audio.py'},'plate.wav':{'source':'Original additive synthesis of a light ceramic contact, make_audio.py'},'voice.wav':{'source':'OpenAI tts-1 alloy, authorized single speech request, native speed 1.0','AI_generated':True},'art':{'source':'Original canvas drawings in build-short.mjs, continuing the channel scarf asset from the existing source-one-minute-v4.zip','external_image_calls':0},'fonts':{'source':'Caveat, SIL Open Font License; notice included in source package'},'runtime_sfx':{'source':'Procedural tap/paper synthesis in repository MIT runtime'},'YouTube_upload':False}
for name in ['music-original.wav','room.wav','wipe.wav','plate.wav','voice.wav']:rights[name]['sha256']=hashlib.sha256((B/name).read_bytes()).hexdigest()
(B/'rights.json').write_text(json.dumps(rights,indent=2)+'\n')
print('Original score, room bed, cloth wipe and ceramic contact saved')
