import fs from 'node:fs';
import {spawn,execFileSync} from 'node:child_process';
import {once} from 'node:events';
import {loadProject,hashFile} from '/workspace/stickman-video-director/skills/directing-stickman-videos/scripts/autopilot-core.mjs';
import {painter} from '/workspace/stickman-video-director/skills/directing-stickman-videos/scripts/autopilot-render.mjs';
import {checkBStyleMotionPaint} from '/workspace/stickman-video-director/skills/directing-stickman-videos/scripts/b-style-quality.mjs';
import {checkBStylePortraitPaint} from '/workspace/stickman-video-director/skills/directing-stickman-videos/scripts/b-style-portrait-paint.mjs';
const B='/workspace/scratch/short-email-v1',out=B+'/output';fs.mkdirSync(out,{recursive:true});
const p=loadProject(B+'/project.json');
// Check actual native layout at 360px phone size; preserve native design units.
// Full-resolution encoded-frame checks are separate from these bounded checks.
const phone={...p,width:360,height:640},phoneDraw=await painter(phone);
console.log('Checking local action at phone size');
const motion=await checkBStyleMotionPaint(phone,phoneDraw);
console.log('Checking every native portrait layer at phone size');
const portrait=await checkBStylePortraitPaint(phone,phoneDraw);
fs.writeFileSync(out+'/paint-QA.json',JSON.stringify({motion,portrait,scope:'360x640 phone-size bounded source paint; separate encoded review required'},null,2));
if(process.argv.includes('--check-only'))process.exit();
const draw=await painter(p),count=Math.ceil(p.duration*p.fps),target=out+'/picture.mp4';
const ff=spawn('ffmpeg',['-v','error','-y','-f','rawvideo','-pix_fmt','rgba','-s',`${p.width}x${p.height}`,'-r',String(p.fps),'-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','18','-threads','3','-pix_fmt','yuv420p','-movflags','+faststart',target],{stdio:['pipe','ignore','pipe']});
let err='';ff.stderr.on('data',b=>err+=b);const complete=once(ff,'close');
for(let i=0;i<count;i++){const bytes=Buffer.from(draw(Math.min(p.duration-.00001,i/p.fps)).data());if(!ff.stdin.write(bytes))await once(ff.stdin,'drain');if(i%90===0)console.log(`Rendered ${i}/${count} frames`);}
ff.stdin.end();const [code]=await complete;if(code!==0)throw Error(err);
const args=['-v','error','-y','-i',target,'-i',B+'/voice.wav','-i',B+'/music-original.wav','-i',B+'/room.wav','-i',B+'/wipe.wav','-i',B+'/plate.wav'];
let filter='[1:a]apad,atrim=0:'+count/p.fps+'[voice];[2:a]volume=0.11[music];[3:a]volume=0.035[room];[4:a]asplit=2[w0][w1];[w0]volume=0.16,adelay=4950:all=1[wipe0];[w1]volume=0.12,adelay=9350:all=1[wipe1];[5:a]volume=0.12,adelay=7940:all=1[plate];';
// Original short keyboard transients, exactly matching the declared contact times.
const cues=[15.90,17.18,17.36,17.61,17.91,18.13,20.26,20.81,22.1,22.6,23.2,24.6,25.1,25.7];
for(let i=0;i<cues.length;i++)filter+=`aevalsrc=0.012*sin(2*PI*1700*t)*exp(-t*140):s=48000:d=0.045,adelay=${Math.round(cues[i]*1000)}:all=1[k${i}];`;
filter+='[voice][music][room][wipe0][wipe1][plate]'+cues.map((_,i)=>`[k${i}]`).join('')+`amix=inputs=${6+cues.length}:normalize=0:duration=first,alimiter=limit=0.89:level=false:latency=true[mix]`;
args.push('-filter_complex',filter,'-map','0:v:0','-map','[mix]','-c:v','copy','-c:a','aac','-b:a','192k','-t',String(count/p.fps),'-movflags','+faststart',out+'/why-you-clean-instead-of-starting.mp4');
execFileSync('ffmpeg',args,{stdio:['ignore','ignore','pipe']});
execFileSync('ffmpeg',['-v','error','-i',out+'/why-you-clean-instead-of-starting.mp4','-f','null','-'],{stdio:['ignore','ignore','pipe']});
function stamp(t,vtt=false){const ms=Math.round(t*1000);return `${String(Math.floor(ms/3600000)).padStart(2,'0')}:${String(Math.floor(ms/60000)%60).padStart(2,'0')}:${String(Math.floor(ms/1000)%60).padStart(2,'0')}${vtt?'.':','}${String(ms%1000).padStart(3,'0')}`;}
fs.writeFileSync(out+'/captions-en.srt',p.captions.map((c,i)=>`${i+1}\n${stamp(c.start)} --> ${stamp(c.end)}\n${c.text}\n`).join('\n'));
fs.writeFileSync(out+'/captions-en.vtt','WEBVTT\n\n'+p.captions.map(c=>`${stamp(c.start,true)} --> ${stamp(c.end,true)}\n${c.text}\n`).join('\n'));
fs.writeFileSync(out+'/render-report.json',JSON.stringify({video_sha256:hashFile(out+'/why-you-clean-instead-of-starting.mp4'),voice_sha256:hashFile(B+'/voice.wav'),frames:count,width:p.width,height:p.height,fps:p.fps,native_voice_seconds:p.voiceDuration,voice_rate:'unchanged 1x',full_decode:'pass',captions:p.captions.length,shots:p.shots.length,independent_review:'not performed',user_acceptance:'pending',note:'Project-local finishing using the installed Skill painter and its bounded motion/native-portrait validators; this does not claim independent sample-equivalence acceptance.'},null,2));
console.log('Encoded original-rate audio and captioned portrait MP4; full decode passed.');
