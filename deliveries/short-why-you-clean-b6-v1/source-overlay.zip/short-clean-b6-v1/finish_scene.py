from pathlib import Path
B=Path(__file__).resolve().parent;p=B/'scene.py';s=p.read_text().replace('from PIL import Image,ImageDraw,ImageFilter','from PIL import Image,ImageDraw,ImageFilter,ImageFont')
s=s.replace("'cloth':Image.open(c.base/'art/cloth.png').convert('RGBA')}","'cloth':Image.open(c.base/'art/cloth.png').convert('RGBA'),'font':str(c.base/'fonts/ArchivoBlack.ttf')}")
s=s.replace("if t<5.3+dx*.4:g.ellipse((470+dx*45,833,479+dx*45,838)","if t<5.3+dx*.4:g.ellipse((435+dx*12,833,442+dx*12,838)")
s=s.replace("g.line([(480,874),(480,1075)],fill='#766e56',width=2)","g.line([(480,874),(480,1075)],fill='#766e56',width=2)\n  if t>=10.45:\n   cloth=s['cloth'].copy();cloth.thumbnail((80,25),Image.Resampling.LANCZOS);im.alpha_composite(cloth,(436,824))")
helper='''\ndef email_detail(s,t):
 # An original illustrated draft, not a screenshot or an actual sent email.
 im=s['world'].crop((0,0,576,1024)).resize((720,1280),Image.Resampling.LANCZOS)
 shadow=Image.new('RGBA',im.size);g=ImageDraw.Draw(shadow);g.rounded_rectangle((42,268,683,837),radius=22,fill=(33,25,31,105));im=Image.alpha_composite(im,shadow.filter(ImageFilter.GaussianBlur(12)))
 g=ImageDraw.Draw(im);ink='#342b31';cream='#fff6df'
 g.rounded_rectangle((44,250,676,734),radius=16,fill='#81998d',outline=ink,width=5)
 g.rounded_rectangle((64,270,656,708),radius=7,fill=cream,outline=ink,width=3)
 g.rectangle((67,273,653,336),fill='#e9bf68');g.line((67,336,653,336),fill=ink,width=3)
 font=lambda size:ImageFont.truetype(s['font'],size)
 g.text((88,289),'Draft · Important email',font=font(23),fill=ink)
 g.text((88,355),'To: Alex',font=font(21),fill='#4d726a');g.line((88,392,630,392),fill='#acb7a1',width=2)
 message='Hi, could we talk about this?'
 n=round(len(message)*smooth((t-17.06)/1.30)) if t<18.48 else len(message)
 g.text((88,438),message[:n],font=font(23),fill=ink)
 follow='I wanted to ask...';n2=round(len(follow)*smooth((t-21.73)/2.25)) if t>=21.73 else 0
 if n2:g.text((88,500),follow[:n2],font=font(23),fill='#4d726a')
 text=follow[:n2] if t>=21.73 else message[:n];cy=500 if t>=21.73 else 438;cx=88+g.textlength(text,font=font(23))+4
 g.line((cx,cy,cx,cy+30),fill='#365f55',width=3)
 g.rounded_rectangle((516,631,631,681),radius=7,fill='#c5d5bd',outline=ink,width=2);g.text((538,644),'Send',font=font(21),fill=ink)
 g.polygon([(44,736),(676,736),(705,820),(15,820)],fill='#83968b',outline=ink,width=4)
 for row in range(3):
  for col in range(12):
   x=74+col*47-row*4;y=749+row*17;g.rounded_rectangle((x,y,x+36,y+11),radius=2,fill='#dce4cf',outline='#53665b',width=1)
 g.rounded_rectangle((279,804,442,815),radius=3,fill='#b9c8b2',outline=ink,width=1)
 if 18.48<=t<19.96:
  u=smooth((t-18.48)/1.20);x=590+55*u;y=662+105*u
  g.polygon([(x,y),(x+3,y+27),(x+11,y+19),(x+20,y+31),(x+26,y+27),(x+17,y+15),(x+30,y+13)],fill='#f5eedb',outline=ink,width=2)
 return im
'''
s=s.replace('\ndef frame(t,c):',helper+'\ndef frame(t,c):')
s=s.replace("s=_CACHE[key];r=s['r'];i=round(t*30);hero=s['hero']", "s=_CACHE[key];r=s['r'];i=round(t*30);hero=s['hero']\n if 15.55<=t<24.16:\n  return r.render_scene((720,1280),[],background=email_detail(s,t),frame_index=i)")
s=s.replace("mat=matrix(1.35,260 if kitchen else 450,1020 if kitchen else 900)","mat=matrix(1.35,260 if kitchen else 450,1020 if kitchen else 900)\n if 12.94<=t<14.28:mat=matrix(1.55,300,1100)")
s=s.replace("elif t<2.9:","elif kitchen and t>=10.45:\n  action='reach';phase=1-smooth((t-10.45)/.8)\n elif t<2.9:")
s=s.replace("action='reach';phase=.65+.12*math.sin((t-14.28)*4)","action='reach';phase=smooth((t-14.28)/1.0) if t<15.55 else 1-smooth((t-24.16)/1.3)")
s=s.replace("head_variant=None if kitchen and t<10.45 else 'worried'","head_variant=None if (kitchen and t<10.45) or t>=24.16 else 'worried'")
s=s.replace('allow_cut=(i in [0,87,142])','allow_cut=(i in [0,87,142,388,389,428,429,724,725]))'[:-1])
p.write_text(s);print('Full native scene authored; actual review still pending.')
