# B6 Short — Why You Clean Instead of Starting

Native 9:16, English, planned duration 26.7s. Reuse existing alloy speech and original local score; no new TTS. User requested a clothed moving stickman in B6, within the existing channel topic of everyday psychology/task avoidance.

New shared apartment painting: study left, doorway middle, kitchen right; warm matte paint, sage/gold accents. Character wears a green vest over a short-sleeved cream shirt, white asymmetric face and gray side-part hair. The painted package is a local adaptation of the installed kiosk_keeper art, not a newly invented rig or a claimed final channel mascot. A new worried expression preserves that identity. The original grin supports the comic satisfaction of cleaning.

Use the installed v2 neck/cuff/fixed-control limb compositor and single continuous painted stroke. Candidate control stroke is 4.8 local units at 180-unit head width, ratio 0.0267; this is an authoring setting, not an independently accepted match to Sample 1. No walking is claimed; standing and deliberate arm reaches are the tested scope. The cloth grip and its actual art share one contact transform.

First 7.1s: approach/withdraw from the email, an empty-draft detail cut, then cloth wiping. Full-story scene plan is a draft, not completed production. Test the actual preview before extending. Exact primary reference, runtime, fonts and helpers remain pinned by the initialized project. Do not infer sample equivalence, independent creative review or user approval from the automated test.
