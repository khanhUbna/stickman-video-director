"""New portrait everyday-psychology performance using the B6 audited compositor."""
import math
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
_CACHE={}
def smooth(x):x=max(0,min(1,x));return x*x*(3-2*x)
def matrix(scale,x,y):return np.array([[scale,0.,x],[0.,scale,y],[0.,0.,1.]])
def setup(c):
 r=c.puppet_runtime
 return {'r':r,'hero':r.Puppet(c.character_packages['hero'],'front','hero'),'world':Image.open(c.base/'art/apartment.png').convert('RGBA'),'cloth':Image.open(c.base/'art/cloth.png').convert('RGBA')}
def background(s,k,t):
 # The camera reveals different parts of a single wide painted apartment.
 world=s['world'];x=0 if k=='study' else 960
 im=world.crop((x,0,x+576,1024)).resize((720,1280),Image.Resampling.LANCZOS)
 if k=='kitchen':
  g=ImageDraw.Draw(im)
  # Foreground preparation island; its top supports the separately rendered cloth.
  g.rounded_rectangle((365,850,701,1086),radius=7,fill='#b8baa0',outline='#56443a',width=3)
  g.polygon([(355,841),(700,841),(710,864),(355,864)],fill='#c99c65',outline='#56443a',width=3)
  for dx in [0,1,2]:
   if t<5.3+dx*.4:g.ellipse((470+dx*45,833,479+dx*45,838),fill='#685044')
  g.line([(480,874),(480,1075)],fill='#766e56',width=2)
 shadow=Image.new('RGBA',im.size);g=ImageDraw.Draw(shadow);cx=450 if k=='study' else 260;cy=900 if k=='study' else 1020;g.ellipse((cx-57,cy-12,cx+65,cy+10),fill=(48,38,34,65));return Image.alpha_composite(im,shadow.filter(ImageFilter.GaussianBlur(8)))
def frame(t,c):
 key=(str(c.base),c.fingerprint)
 if key not in _CACHE:_CACHE[key]=setup(c)
 s=_CACHE[key];r=s['r'];i=round(t*30);hero=s['hero']
 if 2.9<=t<4.72:
  # Genuine prop-detail shot. The cast inventory declares no visible person here.
  im=s['world'].crop((240,290,500,752)).resize((720,1280),Image.Resampling.LANCZOS)
  return r.render_scene((720,1280),[],background=im,frame_index=i)
 kitchen=4.72<=t<14.28;k='kitchen' if kitchen else 'study';bg=background(s,k,t)
 mat=matrix(1.35,260 if kitchen else 450,1020 if kitchen else 900)
 targets={};props=[];action='rest';phase=1
 if kitchen and t<10.45:
  dt=t-4.72;action='reach';phase=1
  # Matched grip and prop share one physical owner timeline; both move together.
  x=437+math.sin(dt*3.3)*7;y=837
  timeline=r.ContactTimeline([{'t0':0,'t1':26.701,'state':'owner','holders':[{'actor_id':'hero','arm':'right','grip':[.2,.5]}],'paper_start':[x+24,y,0]}],paper_size=(80,25))
  contact=timeline.sample(t);targets=contact.targets['hero'];props=[r.PropFrame('cloth',contact,s['cloth'])]
 elif t<2.9:
  action='reach';phase=smooth(t/.8) if t<1.6 else 1-smooth((t-1.6)/1.1)
 elif t>=14.28:
  action='reach';phase=.65+.12*math.sin((t-14.28)*4)
 pose=hero.pose(action=action,phase=phase,placement=mat,wrist_targets=targets,arm_actions={'left':{'action':'reach' if kitchen else action,'phase':.9 if kitchen else phase},'right':{'action':action if kitchen else 'rest','phase':phase if kitchen else 1}},head_variant=None if kitchen and t<10.45 else 'worried',head_angle_deg=(3*math.sin(t*1.6)),frame_index=i,allow_cut=(i in [0,87,142]))
 return r.render_scene((720,1280),[pose],background=bg,props=props,frame_index=i)
