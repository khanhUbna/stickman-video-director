# Why You Clean Instead of Starting — B6 adaptation

This is the working B6 adaptation of the existing channel Short. Planned duration: 26.7s. The representative preview is 7.1s, not a finished full film. Existing alloy audio and local instrumental/SFX mix are reused; no new TTS or transcription call.

The clothed protagonist uses a local adaptation of the installed painted kiosk_keeper character (green vest/cream short sleeves), plus a new worried expression. A new apartment background supplies the study and kitchen. The new gesture/cloth contact uses the installed painted-puppet compositor with version-2 neck, sleeve and real visible-alpha checks. No external video generator is used.

## Restore the editable overlay

On a prepared machine with this same Skill checkout, initialize a fresh directory:

```bash
cd /workspace/stickman-video-director/skills/directing-stickman-videos
node scripts/autopilot.mjs init /workspace/scratch/short-clean-b6-v1 --style B6 --ratio 9:16
```

Then extract the source-overlay ZIP over that initialized directory. The ZIP intentionally omits the unchanged bundled engine and primary reference movie: init restores them from the installed Skill. Do not rerun prepare.py over fitted artwork; it records the initial preparation only.

```bash
export PYTHONPYCACHEPREFIX=/tmp/short-b6-python-cache
/workspace/.venvs/stickman/bin/python /workspace/scratch/short-clean-b6-v1/run.py validate /workspace/scratch/short-clean-b6-v1 --ratio 9:16
/workspace/.venvs/stickman/bin/python /workspace/scratch/short-clean-b6-v1/run.py preview /workspace/scratch/short-clean-b6-v1 --ratio 9:16 --trusted-code --seconds 7.1 --output outputs/new-preview
```

Choose a fresh output directory for each iteration. Keep original-alloy.wav and the word alignment; do not call TTS again. No API keys or credential files are included.

The exact preview still needs actual playback/listening, independent creative/reference review and the user's decision before full production. Automated neck/limb/contact checks and still-frame inspection do not establish Sample 1 equivalence. The current scene tail is planning code, not a reviewed full film. Do not publish to YouTube.
