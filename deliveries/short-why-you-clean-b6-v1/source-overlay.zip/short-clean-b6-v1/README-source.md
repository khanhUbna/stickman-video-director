# Current B6 editable overlay

The current 26.7s full-length review render implements the user's arm-visibility correction. Use scene.py, project.json, captions.json and the fitted characters/ package as the authoritative current inputs. User feedback accepted the earlier style subject to this correction; full-length user playback and independent creative/source review remain pending.

Restore on a prepared machine with the same installed Skill at /workspace/stickman-video-director. Initialize a fresh /workspace/scratch/short-clean-b6-v1 using:

    cd /workspace/stickman-video-director/skills/directing-stickman-videos
    node scripts/autopilot.mjs init /workspace/scratch/short-clean-b6-v1 --style B6 --ratio 9:16

Extract this overlay over that initialized directory. The unchanged engine/ and reference/ are intentionally omitted because init restores them from the installed Skill. Use the existing isolated checkout; no worktree is needed. Retain the provided original-alloy.wav and mix.wav. Do not call TTS or run historical preparation scripts over the fitted package.

    export PYTHONPYCACHEPREFIX=/tmp/short-b6-python-cache
    /workspace/.venvs/stickman/bin/python /workspace/scratch/short-clean-b6-v1/run.py validate /workspace/scratch/short-clean-b6-v1 --ratio 9:16
    /workspace/.venvs/stickman/bin/python /workspace/scratch/short-clean-b6-v1/run.py preview /workspace/scratch/short-clean-b6-v1 --ratio 9:16 --trusted-code --seconds 26.7 --output outputs/fresh-full-review

Use a fresh output folder each run. The full-length output uses preview/review status because no independent creative acceptance is fabricated. Do not record approve or user acceptance without actual supporting review.

For review-pack on this many cue transitions, the bundled tools/ffmpeg wrapper keeps exactly the same selected frame numbers while balancing the FFmpeg expression tree. It avoids the installed FFmpeg's long linear-sum parser limit; no frames or checks are removed. Prepend the tools directory to PATH only for that diagnostic operation. The wrapper is not used for the original animation encode.

Original procedural music/SFX and alloy audio come from the prior authorized project; no new speech, music subscription or outside recording was used. Apartment painting and worried expression were newly generated for this B6 adaptation. The garment/rig derives from the installed painted kiosk_keeper package. Archivo Black is supplied with its OFL notice. No YouTube upload or credential export occurred. A restored or re-rendered project must generate fresh review evidence for its actual fingerprints.
