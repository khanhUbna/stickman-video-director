from pathlib import Path
import subprocess,json,hashlib,re
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parent;O=B/'outputs/full-review-01';V=O/'preview.mp4'
def run(a):return subprocess.run(a,check=True,capture_output=True)
run(['ffmpeg','-v','error','-i',str(V),'-f','null','-'])
probe=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(V)]).stdout)
v=next(s for s in probe['streams'] if s['codec_type']=='video');assert(v['width'],v['height'],int(v['nb_read_frames']))==(720,1280,801)
report=json.loads((O/'report.json').read_text());assert report['technical_status']=='pass' and report['checked_frames']==801
orig=B/'audio/original-alloy.wav';assert hashlib.sha256(orig.read_bytes()).hexdigest()=='6490deaf933ddd504454f346d3ede31a5aff7605ef6a845e4c0d7d08669d62fd'
cues=json.loads((B/'captions.json').read_text());words=json.loads((B/'words.json').read_text())['words'];normalize=lambda s:re.sub('[^a-z]','',s.lower());assert normalize(' '.join(c['text'] for c in cues))==normalize(' '.join(w['word'] for w in words))
r=run(['ffmpeg','-hide_banner','-nostats','-i',str(V),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']);loud=json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
plan=json.loads((B/'formats/portrait.json').read_text());board=Image.new('RGB',(1080,4*665),'#e5e3d9');g=ImageDraw.Draw(board)
for i,s in enumerate(plan['shots']):
 t=(s['start']+s['end'])/2
 raw=run(['ffmpeg','-v','error','-ss',str(t),'-i',str(V),'-frames:v','1','-vf','scale=360:640','-f','rawvideo','-pix_fmt','rgb24','pipe:1']).stdout
 im=Image.frombytes('RGB',(360,640),raw);x=i%3*360;y=i//3*665;board.paste(im,(x,y));g.text((x+8,y+646),f"{s['id']} | {t:.2f}s",fill='#24313a')
board.save(O/'encoded-shot-sheet.jpg',quality=93)
run(['ffmpeg','-v','error','-y','-ss','6.0','-i',str(V),'-frames:v','1',str(O/'kitchen-arms-clear.png')])
qa={'status':'full_length_review_render_technical_pass','duration':float(probe['format']['duration']),'dimensions':[720,1280],'frames':801,'full_decode':'pass','original_alloy_sha256':hashlib.sha256(orig.read_bytes()).hexdigest(),'original_voice_reused_exactly':True,'caption_word_coverage':'pass','aligned_words':len(words),'semantic_cues':len(cues),'arm_poses_checked':report['arm_poses_checked'],'straight_legs_checked':report['straight_legs_checked'],'max_prop_contact_error_px':report['max_prop_contact_error_px'],'external_media_reads':report['external_media_reads'],'encoded_loudness':loud,'arm_visibility_revision':{'ink':'#17202b','stroke_local_units':5.6,'idle_left_arm':'Moved off cupboard seam and lifted above the caption band','source':'User reported one arm blended into the kitchen; earlier style was accepted subject to this correction'},'video_sha256':hashlib.sha256(V.read_bytes()).hexdigest(),'review_limits':['Independent creative/source comparison and continuous human playback/listening not performed; user review is pending.','Existing user feedback approved the earlier visual direction, not this unseen full-length render.','Technical geometry and alpha tests do not certify natural acting or equivalence to the B6 primary sample.'],'new_TTS_calls':0,'YouTube_upload':False}
(O/'QA.json').write_text(json.dumps(qa,indent=2)+'\n');(O/'stream-info.json').write_text(json.dumps(probe,indent=2)+'\n');print(json.dumps({k:qa[k] for k in ['duration','frames','full_decode','caption_word_coverage','arm_poses_checked','max_prop_contact_error_px']},indent=2));print('LUFS',loud['input_i'],'true peak',loud['input_tp'])
