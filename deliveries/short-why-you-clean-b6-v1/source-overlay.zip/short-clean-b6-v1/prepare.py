from pathlib import Path
import json,shutil,hashlib,subprocess
B=Path(__file__).resolve().parent;S=Path('/workspace/stickman-video-director/skills/directing-stickman-videos');old=Path('/workspace/scratch/short-email-v1')
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
pack=B/'characters/protagonist';shutil.copytree(S/'assets/b6/characters/kiosk_keeper',pack,dirs_exist_ok=True)
d=json.loads((pack/'package.json').read_text());d['binding_version']=2;d['views']={'front':d['views']['front']};v=d['views']['front'];v['neck_attachment']={'mount_polygon':[[-8,-255],[8,-255],[8,-252],[-8,-252]],'min_overlap_fraction':.70,'min_overlap_thickness':2.}
for arm in v['arms'].values():arm['ink_path']={'mode':'continuous','sag':9};arm['ink_width']=4.8
for leg in v['legs'].values():leg['ink_width']=4.8
save(pack/'package.json',d)
(B/'audio').mkdir(exist_ok=True);shutil.copy2(old/'voice.wav',B/'audio/original-alloy.wav')
subprocess.run(['ffmpeg','-v','error','-y','-i',str(old/'output/why-you-clean-instead-of-starting.mp4'),'-vn','-ar','48000','-ac','1',str(B/'audio/mix.wav')],check=True)
words=json.loads((old/'words.json').read_text())['words']
phrases=['Ever cleaned','your entire room','to avoid one email?','The email takes','five minutes.','Suddenly, your kitchen','needs forty.','Sometimes,','the easier task','offers a clear finish.','The important one','brings uncertainty.','What if they say no?','So try this:','open the draft.','Write one','messy sentence.',"You don't have to",'send it yet.',"The goal isn't",'a perfect email.',"It's a first move",'you can actually make.',"What's the five-minute task", "you've been avoiding?"]
import re
norm=lambda s:re.sub('[^a-z]','',s.lower());wi=0;cues=[]
for phrase in phrases:
 start=words[wi]['start'];acc=''
 while acc!=norm(phrase):
  w=words[wi];wi+=1;acc+=norm(w['word']);assert norm(phrase).startswith(acc),(phrase,acc)
 cues.append({'start':start,'end':w['end'],'text':phrase})
for i,c in enumerate(cues):c['end']=min(c['end']+.08,cues[i+1]['start']-.01 if i+1<len(cues) else 26.5)
save(B/'captions.json',cues);shutil.copy2(old/'words.json',B/'words.json')
shots=[]
for sid,a,b,desc in [('hesitate',0,2.9,'Clothed character reaches toward an empty email, then pulls the hand back.'),('draft',2.9,4.72,'Empty draft detail; no words have been written.'),('clean',4.72,10.45,'Character holds a real cloth with a calibrated grip and wipes a supported counter.'),('uncertain',10.45,14.28,'The unchanged email returns as the character lowers the cloth.'),('firstmove',14.28,19.96,'Return to the draft; the first sentence appears and stays unsent.'),('result',19.96,26.7,'Continue the first concrete action, preserving the unsent draft.')]:shots.append({'id':sid,'start':a,'end':b,'composition':'Native portrait; face above the action and fixed Archivo Black caption band. '+desc,'action':desc,'camera':'Purposeful room/prop detail cut, uniform character scale; no character warp.','transition':'Motivated hard cut on the narration beat.'})
plan=json.loads((B/'formats/portrait.json').read_text());plan['shots']=shots;plan['cast_inventory']=[{'id':'hero','role':'Everyday protagonist avoiding one important email','shot_ids':['hesitate','clean','uncertain','firstmove','result']}];save(B/'formats/portrait.json',plan)
save(B/'characters.json',{'schema':'b6-character-registry/1','actors':[{'id':'hero','package':'characters/protagonist','views':['front']}],'rigid_cast':[]})
save(B/'story.json',{'narration':' '.join(c['text'] for c in cues),'beats':shots,'status':'original approved narration reused; B6 picture is new'})
p=json.loads((B/'project.json').read_text());p.update(stage='authored',duration=26.7,voice={'path':'audio/mix.wav','sha256':hashlib.sha256((B/'audio/mix.wav').read_bytes()).hexdigest(),'speed':1,'source':'Previous authorized native alloy recording and original local score, reused; no new TTS'},review={'status':'preview_in_progress','art':'New apartment painting; locally adapted installed painted garment/head package','acting':'Calibrated new cloth contact, test before extending','sound':'Reused prior approved recording, no new voice calls'});p['inputs']+=['art/apartment.png','audio/original-alloy.wav','words.json'];save(B/'project.json',p)
print('Prepared B6 portrait source; no TTS calls.')
