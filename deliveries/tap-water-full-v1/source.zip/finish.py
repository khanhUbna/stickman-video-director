"""Original audio stems, subtitles, final encode and verifiable technical QA."""
from pathlib import Path
import json,math,wave,subprocess,re,hashlib
import numpy as np
import animate as A
B=A.B;O=A.O;SR=48000;D=math.ceil(A.D*A.FPS)/A.FPS;N=round(D*SR)
def wav(path,x):
 with wave.open(str(path),'wb') as w:
  channels=1 if x.ndim==1 else x.shape[1];w.setparams((channels,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(x,-.98,.98)*32767).astype('<i2').tobytes())
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def run(args):return subprocess.run(args,check=True,capture_output=True)
def loud(path):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(path),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']);return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
def main():
 rng=np.random.default_rng(17112026);voice=np.zeros(N,np.float32);active=np.zeros(N,np.float32)
 for r in A.C:
  with wave.open(str(B/'audio'/Path(r['file']).name)) as w:
   assert w.getframerate()==SR and w.getnchannels()==1;x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
  # Normalize line-level loudness for cast consistency without revoicing.
  rms=np.sqrt(np.mean(x*x));gain=min(1.7,.13/max(rms,.001));x*=gain
  a=round(r['start']*SR);b=a+len(x);voice[a:b]+=x;active[max(0,a-2400):min(N,b+6000)]=1
 wav(B/'audio/dialogue.wav',voice)
 music=np.zeros(N,np.float32);amb=np.zeros(N,np.float32);fx=np.zeros(N,np.float32);events=[]
 def event(at,dur,kind,gain=.04,freq=800):
  a=round(at*SR);n=min(round(dur*SR),N-a)
  if n<=0:return
  tt=np.arange(n,dtype=np.float32)/SR
  if kind in ['click','particle_pop','screen_contact']:sig=rng.normal(0,1,n).astype(np.float32)*np.exp(-tt*35)+.4*np.sin(math.tau*freq*tt)*np.exp(-tt*22)
  else:sig=np.sin(math.tau*(freq*tt-300*tt*tt))*np.exp(-tt*10)
  sig*=np.minimum(1,tt/.002);fx[a:a+n]+=gain*sig;events.append({'time':at,'duration':dur,'kind':kind,'gain':gain,'source':'original local synthesis','status':'final','purpose':'visible action contact / comic punctuation'})
 # Composed chord progression, light plucked melody with changing register and rests.
 chords=[[50,57,62,66],[47,54,59,62],[43,50,55,59],[45,52,57,61]]
 for j,at in enumerate(np.arange(0,D,.44)):
  if j%16 in [7,15]:continue
  chord=chords[(j//16)%4];note=chord[j%4]+(12 if (j//32)%2 else 0);freq=440*2**((note-69)/12)
  dur=.75;tt=np.arange(round(dur*SR),dtype=np.float32)/SR;sig=(np.sin(math.tau*freq*tt)+.17*np.sin(math.tau*freq*2*tt))*np.exp(-tt*7)*np.minimum(1,tt/.009);a=round(at*SR);n=min(len(sig),N-a);music[a:a+n]+=.012*sig[:n]
 # Scene beds follow place and machine state; none are third-party recordings.
 shots=[]
 for j,z in enumerate(A.GROUPS):
  start=0 if j==0 else A.C[z[0]-1]['start'];end=A.C[A.GROUPS[j+1][0]-1]['start'] if j+1<len(A.GROUPS) else D;a=round(start*SR);b=min(N,round(end*SR));tt=np.arange(b-a,dtype=np.float32)/SR
  noise=rng.normal(0,1,len(tt)).astype(np.float32);noise=np.convolve(noise,np.ones(19,dtype=np.float32)/19,'same');base=.012*noise
  if z[2] in ['lake','intake','screen','specks','floc','settle','filter','chlorine','head','valve','drain','bath','question','brush','return']:base+=.015*noise
  if z[2] in ['rotor','network','systems','tower']:base+=.005*np.sin(math.tau*112*tt)+.002*np.sin(math.tau*224*tt)
  fade=np.minimum(1,np.minimum(np.arange(len(tt))/(SR*.1),(len(tt)-1-np.arange(len(tt)))/(SR*.12)));amb[a:b]+=base*fade
  shots.append({'scene':z[2],'start':start,'end':end,'ambience':'designed water/room air; motor when visible running','source':'original local synthesis','listener':'medium distance, dry stylized cartoon','status':'final'})
 for cue,kind in [(15,'screen_contact'),(17,'comic_pluck'),(22,'particle_pop'),(28,'comic_pluck'),(35,'comic_pluck'),(48,'comic_pluck'),(65,'comic_pluck'),(66,'comic_pluck')]:event(A.C[cue-1]['end']+.08,.18,kind,.022)
 morning=A.C[39]['start']
 for delta in [.25,1.05,1.85]:event(morning+delta,.08,'click',.022,600)
 # Audible showers/laundry build as each appliance turns on.
 for delta in [.25,1.05,1.85]:
  a=round((morning+delta)*SR);b=round(A.C[41]['start']*SR);n=b-a
  if n>0:amb[a:b]+=.008*np.convolve(rng.normal(0,1,n).astype(np.float32),np.ones(11,dtype=np.float32)/11,'same')
 # Short music dropout lets the drain punchline land.
 quiet=round((A.C[65]['start']-.3)*SR);music[quiet:]*=.25
 fade=np.minimum(1,(N-1-np.arange(N))/(SR*.65)).astype(np.float32)
 music*=fade*(1-.48*active);amb*=fade*(1-.15*active);fx*=fade
 for name,x in [('music-original',music),('ambience-original',amb),('foley-original',fx)]:wav(B/f'audio/{name}.wav',x)
 mix=voice+music+amb+fx;wav(B/'audio/mix-unmastered.wav',mix)
 pre=loud(B/'audio/mix-unmastered.wav');flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
 run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix-unmastered.wav'),'-af',flt,'-ar',str(SR),'-ac','2',str(B/'audio/mix-mastered.wav')])
 dst=O/'where-your-tap-water-comes-from.mp4'
 run(['ffmpeg','-v','error','-y','-i',str(O/'picture.mp4'),'-i',str(B/'audio/mix-mastered.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(D),'-movflags','+faststart',str(dst)])
 subs=A.CAP;(O/'captions-en.srt').write_text('\n\n'.join(f"{j+1}\n{stamp(r['start'])} --> {stamp(r['end'])}\n{r['text']}" for j,r in enumerate(subs))+'\n')
 (O/'script-with-speakers.txt').write_text('\n\n'.join(r['role']+': '+r['text'] for r in A.C))
 (O/'sound-rights.json').write_text(json.dumps({'music':'Original locally composed plucked arrangement; no third-party recording','ambience_and_foley':'Original local synthesis; no library restrictions','dialogue':{'provider':'OpenAI','model':'tts-1','voices':A.DATA['voices'],'estimated_usd':A.DATA['estimate_usd'],'billing_verified':False,'saved_native_audio_reused_for_picture_changes':True},'scenes':shots,'events':events,'listening_review':'No real-time AV or independent listening review performed'},indent=2))
 run(['ffmpeg','-v','error','-i',str(dst),'-f','null','-']);probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(dst)]).stdout);v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
 assert [v['width'],v['height'],v['r_frame_rate']]==[1280,720,'30/1'];assert int(v['nb_frames'])==math.ceil(A.D*30);assert abs(float(v['duration'])-float(a['duration']))<.06
 assert all(subs[j]['end']<=subs[j+1]['start']+.001 for j in range(len(subs)-1));assert A.C[-1]['text']=='Next department.'
 post=loud(dst)
 qa={'duration':float(v['duration']),'frames':int(v['nb_frames']),'resolution':[1280,720],'fps':30,'full_decode':'pass','audio_video_duration_match':'pass','loudness':post,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'file_bytes':dst.stat().st_size,'scenes':len(A.GROUPS),'caption_cues':len(subs),'caption_timing':'Native line audio placements; multi-part captions apportioned within line','visual_review':'Author source storyboard and decoded final frames; see review sheets','independent_review':'not performed','real_time_AV_listening':'not performed','scope':'Simplified reservoir-fed town with treatment and elevated vented storage. Other supplies and direct pumped networks exist. Diagram not to scale; time compressed.','youtube_upload':False}
 assert float(post['input_tp'])<-.5
 (O/'QA.json').write_text(json.dumps(qa,indent=2));(O/'probe.json').write_text(json.dumps(probe,indent=2));print(json.dumps(qa,indent=2),flush=True)
if __name__=='__main__':main()
