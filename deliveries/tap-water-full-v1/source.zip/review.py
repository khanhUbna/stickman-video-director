from pathlib import Path
import json,subprocess,math,hashlib
import numpy as np
from PIL import Image,ImageDraw
import animate as A
B=A.B;O=A.O;movie=O/'where-your-tap-water-comes-from.mp4'
def decoded(t):
 p=subprocess.run(['ffmpeg','-v','error','-ss',str(t),'-i',str(movie),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True)
 return Image.fromarray(np.frombuffer(p.stdout,dtype=np.uint8).reshape((720,1280,3)))
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def main():
 samples=[]
 for j,z in enumerate(A.GROUPS):
  start=A.C[z[0]-1]['start'];end=A.C[A.GROUPS[j+1][0]-1]['start'] if j+1<len(A.GROUPS) else A.D
  for k,f in enumerate([.15,.5,.82]):
   at=start+(end-start)*f;im=decoded(at);dst=O/f'decoded-{j+1:02d}-{k+1}.jpg';im.save(dst,quality=88);samples.append({'scene':j+1,'phase':k+1,'time':at,'path':dst.name})
 for page in range(3):
  sheet=Image.new('RGB',(1280,8*205),'#ffffff');g=ImageDraw.Draw(sheet)
  group=[x for x in samples if x['phase']==page+1]
  for j,item in enumerate(group):
   im=Image.open(O/item['path']);im.thumbnail((320,180));x=j%4*320;y=j//4*205;sheet.paste(im,(x,y));g.text((x+7,y+183),f"{item['scene']:02} @ {item['time']:.1f}s",fill='black')
  sheet.save(O/f'decoded-review-{page+1}.jpg',quality=94)
 # Pixel motion is supporting evidence only, never a creative acceptance claim.
 local=[]
 for j,z in enumerate(A.GROUPS):
  start=A.C[z[0]-1]['start'];end=A.C[A.GROUPS[j+1][0]-1]['start'] if j+1<len(A.GROUPS) else A.D
  a=np.array(decoded(start+min(.7,(end-start)*.2)))[100:590];b=np.array(decoded(start+min(1.7,(end-start)*.8)))[100:590]
  diff=np.abs(a.astype(float)-b.astype(float));local.append({'scene':z[2],'picture_region_mean_pixel_difference':float(diff.mean()),'changed_picture_pixels':int(np.count_nonzero(np.max(diff,axis=2)>10))})
 vi=json.loads((B/'translations-vi.json').read_text());assert len(vi)==len(A.C)
 (O/'captions-vi.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(r['start'])} --> {stamp(r['end'])}\n{vi[i]}" for i,r in enumerate(A.C))+'\n',encoding='utf-8-sig')
 # Do not ship the old editorial SRT text as the current synchronized script.
 story=json.loads((B/'story.json').read_text());story.pop('srt',None);story['duration_actual_seconds']=A.D;story['ending']='Next department.';(B/'story.json').write_text(json.dumps(story,indent=2))
 (O/'decoded-motion-checks.json').write_text(json.dumps({'source_sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'samples':samples,'local_picture_checks':local,'qualification':'Pixel changes exclude subtitle band; they do not establish meaningful action, independent review or listening.'},indent=2))
 print(json.dumps({'decoded_samples':len(samples),'scenes':len(local),'minimum_changed_picture_pixels':min(x['changed_picture_pixels'] for x in local),'vietnamese_cues':len(vi)}),flush=True)
if __name__=='__main__':main()
