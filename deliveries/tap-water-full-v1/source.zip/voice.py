from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,json,urllib.request,urllib.error,subprocess,wave,hashlib
B=Path(__file__).resolve().parent
D=json.loads((B/'story.json').read_text())
VOICES={'DROP':'alloy','PUMP':'echo','TANK':'onyx','FILTER':'nova','TAP':'shimmer','DRAIN':'fable'}
def make(item):
 i,row=item; a,b,role,text=row
 dst=B/f'audio/{i:02d}.wav'; record=B/f'audio/{i:02d}-request.json'
 if not dst.exists():
  if record.exists():raise RuntimeError(f'Cue {i} already attempted; no automatic paid retry')
  record.write_text(json.dumps({'model':'tts-1','voice':VOICES[role],'text':text,'estimated_usd':len(text)*.000015,'state':'attempted','automatic_retry':False}))
  req=urllib.request.Request('https://api.openai.com/v1/audio/speech',data=json.dumps({'model':'tts-1','voice':VOICES[role],'input':text,'response_format':'wav','speed':1}).encode(),headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'application/json'})
  try:
   with urllib.request.urlopen(req,timeout=180) as r:dst.write_bytes(r.read())
  except urllib.error.HTTPError as e:raise RuntimeError(f'Cue {i}: HTTP {e.code}; no automatic retry') from None
  rec=json.loads(record.read_text());rec['state']='saved';rec['sha256']=hashlib.sha256(dst.read_bytes()).hexdigest();record.write_text(json.dumps(rec,indent=2))
 normalized=B/f'audio/{i:02d}-normalized.wav'
 if not normalized.exists():subprocess.run(['ffmpeg','-v','error','-y','-i',str(dst),'-ar','48000','-ac','1',str(normalized)],check=True)
 with wave.open(str(normalized)) as w:duration=w.getnframes()/w.getframerate()
 print(f'Voice cue {i}/66 saved: {duration:.2f}s',flush=True)
 return {'id':i,'role':role,'text':text,'file':str(normalized.relative_to(B)),'duration':duration,'editorial_start':a,'editorial_end':b,'voice':VOICES[role]}
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(make,enumerate(D['rows'],1)))
 shift=0;last=0
 for r in rows:
  r['start']=max(r['editorial_start']+shift,last+.10 if last else .12)
  r['end']=r['start']+r['duration']
  overflow=max(0,r['end']+.12-(r['editorial_end']+shift))
  shift+=overflow;last=r['end']
 total=max(225+shift,last+1)
 out={'title':D['title'],'duration':round(total,3),'fps':30,'dimensions':[1280,720],'cues':rows,'voices':VOICES,'estimate_usd':sum(len(r['text'])*.000015 for r in rows),'billing_verified':False,'new_tts_calls':66}
 (B/'timeline.json').write_text(json.dumps(out,indent=2));print(json.dumps({'duration':total,'estimate_usd':out['estimate_usd']}),flush=True)
