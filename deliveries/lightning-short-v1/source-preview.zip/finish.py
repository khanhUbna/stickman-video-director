from pathlib import Path
import json,subprocess,wave,math,re,hashlib
import numpy as np
import animate as A
B=A.B;O=A.O;SR=48000;N=round(A.D*SR)
def run(args):return subprocess.run(args,check=True,capture_output=True)
def wav(path,x):
 with wave.open(str(path),'wb') as w:w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(x,-.98,.98)*32767).astype('<i2').tobytes())
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def measure(path):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(path),'-af','loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-f','null','-']);return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
def main():
 real=not A.T.get('provisional',False);voice=np.zeros(N,np.float32);music=np.zeros(N,np.float32);fx=np.zeros(N,np.float32);active=np.zeros(N,np.float32);rng=np.random.default_rng(22112026)
 if real:
  for r in A.C:
   with wave.open(str(B/r['file'])) as w:x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
   x*=min(1.6,.13/max(.001,np.sqrt(np.mean(x*x))));a=round(r['start']*SR);voice[a:a+len(x)]+=x;active[max(0,a-2500):min(N,a+len(x)+5000)]=1
 def add(bus,at,x,gain):
  a=round(at*SR);n=min(len(x),N-a)
  if n>0:bus[a:a+n]+=x[:n]*gain
 # New original light plucked arrangement, with rests and a quieter safety ending.
 for j,at in enumerate(np.arange(0,A.D,.50)):
  if j%16 in [7,15]:continue
  chord=[[62,66,69],[59,62,66],[55,59,62],[57,61,64]][j//16%4];note=chord[j%3]+12;f=440*2**((note-69)/12);t=np.arange(round(.7*SR),dtype=np.float32)/SR;x=(np.sin(math.tau*f*t)+.18*np.sin(math.tau*f*2*t))*np.exp(-t*8)*np.minimum(1,t/.008);add(music,at,x,.017 if not real else .012)
 t=np.arange(N,dtype=np.float32)/SR;noise=rng.normal(0,1,N).astype(np.float32);low=np.convolve(noise,np.ones(41,np.float32)/41,'same');amb=low*.009;amb[round(A.C[7]['start']*SR):]*=.35
 events=[]
 def event(at,dur,kind,gain=.04):
  tt=np.arange(round(dur*SR),dtype=np.float32)/SR
  if kind=='single_strike':x=(np.sin(math.tau*64*tt)*.4+np.convolve(rng.normal(0,1,len(tt)).astype(np.float32),np.ones(23,np.float32)/23,'same'))*np.exp(-tt*4)
  else:x=(np.sin(math.tau*(700*tt-180*tt*tt))+.2*np.sin(math.tau*1400*tt))*np.exp(-tt*16)
  x*=np.minimum(1,tt/.008);add(fx,at,x,gain);events.append({'time':at,'duration':dur,'kind':kind,'source':'Original local stylized synthesis','purpose':'Visible strike / schematic reveal / shelter check mark'})
 event(.15,1.2,'single_strike',.085);event(A.C[1]['start']+.35,.16,'trash_can_correction',.020);event(A.C[4]['start']+.55,.16,'first_contact_reveal',.018);event(A.C[4]['start']+1,.16,'second_contact_reveal',.018);event(A.BODY_ON,.2,'current_path_reveal',.022);event(A.C[7]['start']+.15,.26,'shelter_check',.025)
 fade=np.minimum(1,(N-1-np.arange(N))/(SR*.4)).astype(np.float32);music*=fade*(1-.45*active);fx*=fade;amb*=fade
 for name,stem in [('dialogue',voice),('music-original',music),('foley-original',fx),('ambience-original',amb)]:wav(B/f'audio/{name}.wav',stem)
 wav(B/'audio/mix.wav',voice+music+fx+amb)
 pre=measure(B/'audio/mix.wav');target=-16 if real else -20;flt=f'loudnorm=I={target}:TP=-1.5:LRA=8:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
 run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix.wav'),'-af',flt,'-ar',str(SR),'-ac','2',str(B/'audio/master.wav')])
 name='where-does-lightning-go-short.mp4' if real else 'lightning-animation-preview-no-voice.mp4';dst=O/name
 run(['ffmpeg','-v','error','-y','-i',str(O/'picture.mp4'),'-i',str(B/'audio/master.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','160k','-t',str(A.D),'-movflags','+faststart',str(dst)])
 prefix='' if real else 'draft-'
 (O/f'{prefix}captions-en.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(A.CAP))+'\n')
 (O/f'{prefix}captions-vi.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['vi']}" for i,c in enumerate(A.C))+'\n',encoding='utf-8-sig')
 run(['ffmpeg','-v','error','-i',str(dst),'-f','null','-']);probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(dst)]).stdout);v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio');assert [v['width'],v['height'],v['nb_frames']]==[1080,1920,str(round(A.D*30))];assert abs(float(a['duration'])-float(v['duration']))<.05
 rows=json.loads((O/'motion.json').read_text());assert rows and max(r['max_bone_error'] for r in rows)<1e-7
 q={'title':A.T['title'],'stage':'finished export' if real else 'animation preview; narration blocked by HTTP 401','file':name,'duration':float(v['duration']),'dimensions':[1080,1920],'fps':30,'frames':int(v['nb_frames']),'full_decode':'pass','audio_video_duration_match':'pass','narration_present':real,'caption_timing':'Offline acoustic alignment' if real else 'Editorial estimates; NOT audio-aligned','max_mascot_bone_length_error':max(r['max_bone_error'] for r in rows),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size,'loudness':measure(dst),'review':{'author':'Source storyboard and decoded output frames','independent':'not performed','real_time_AV_listening':'not performed'},'research_access':'NWS/CDC direct access denied by environment proxy; not reported as verified source retrieval','science_scope':json.loads((B/'story.json').read_text())['science_scope'],'youtube_upload':False}
 (O/f'{prefix}QA.json').write_text(json.dumps(q,indent=2));(O/'sound-rights.json').write_text(json.dumps({'narration_present':real,'music':'Original local plucked composition','foley_and_ambience':'Original local synthesis, no third-party recording','events':events,'art':'One new transparent bolt expression atlas; mechanisms, soil and educational silhouette drawn locally','rights_note':'No third-party song, footage or human voice impersonation used'},indent=2));print(json.dumps(q,indent=2),flush=True)
if __name__=='__main__':main()
