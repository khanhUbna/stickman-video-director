from pathlib import Path
import json,subprocess,hashlib
import numpy as np
from PIL import Image,ImageDraw
import animate as A
B=A.B;O=A.O;real=not A.T.get('provisional',False);name='where-does-lightning-go-short.mp4' if real else 'lightning-animation-preview-no-voice.mp4';MOV=O/name
def frame(t):
 p=subprocess.run(['ffmpeg','-v','error','-ss',str(t),'-i',str(MOV),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True);return Image.fromarray(np.frombuffer(p.stdout,np.uint8).reshape((1920,1080,3)))
def main():
 samples=[]
 for phase,f in enumerate([.15,.8]):
  sheet=Image.new('RGB',(1080,1000),'white');g=ImageDraw.Draw(sheet)
  for j,(n,a,b) in enumerate(A.SCENES):
   t=a+(b-a)*f;im=frame(t);im.save(O/f'decoded-{j+1:02d}-{phase+1}.jpg',quality=90);im=im.resize((270,480),Image.Resampling.LANCZOS);x=j%4*270;y=j//4*500;sheet.paste(im,(x,y));g.text((x+6,y+482),f'{n} @ {t:.2f}s',fill='black');samples.append({'scene':n,'time':t})
  sheet.save(O/f'decoded-review-{phase+1}.jpg',quality=94)
 frame(.4).save(O/'cover-draft.jpg',quality=94)
 norm=lambda s:''.join(c.lower() for c in s if c.isalpha());assert norm(' '.join(c['text'] for c in A.CAP))==norm(' '.join(c['text'] for c in A.C));assert all(A.CAP[i]['end']<=A.CAP[i+1]['start']+.001 for i in range(len(A.CAP)-1))
 diffs=[]
 for n,a,b in A.SCENES:
  aa=np.array(frame(a+(b-a)*.15))[350:1320];bb=np.array(frame(a+(b-a)*.8))[350:1320];diffs.append({'scene':n,'picture_mean_pixel_difference':float(np.abs(aa.astype(float)-bb).mean())})
 (O/'decoded-review.json').write_text(json.dumps({'file':name,'narration_present':real,'sha256':hashlib.sha256(MOV.read_bytes()).hexdigest(),'samples':samples,'caption_text_coverage':'pass','caption_non_overlap':'pass','picture_checks':diffs,'limits':'Author decoded-frame inspection; sampled pixel motion is not semantic acceptance, independent review or real-time AV listening.'},indent=2));print(json.dumps({'scenes':len(A.SCENES),'decoded_samples':len(samples),'caption_coverage':'pass','narration_present':real}),flush=True)
if __name__=='__main__':main()
