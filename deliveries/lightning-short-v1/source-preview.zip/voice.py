from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,json,urllib.request,urllib.error,subprocess,wave,hashlib,sys,shutil
B=Path(__file__).resolve().parent;S=json.loads((B/'story.json').read_text())
def one(item):
 i,row=item;start,role,text,vi=row;raw=B/f'audio/{i:02d}-api.wav';dst=B/f'audio/{i:02d}.wav';rec=B/f'audio/{i:02d}-request.json'
 if not raw.exists():
  if rec.exists():
   status=json.loads((B/'auth-status.json').read_text()) if (B/'auth-status.json').exists() else {}
   if '--credential-update-confirmed' not in sys.argv or not status.get('completion_of_update_confirmed',False):raise RuntimeError(f'Cue {i} already attempted; no automatic paid retry')
   archive=B/'audio/attempt-history';archive.mkdir(exist_ok=True);j=1
   while (archive/f'{i:02d}-attempt-{j:02d}.json').exists():j+=1
   shutil.move(str(rec),str(archive/f'{i:02d}-attempt-{j:02d}.json'))
  rec.write_text(json.dumps({'model':'tts-1','voice':S['voices'][role],'speed':1,'characters':len(text),'estimated_usd':len(text)*.000015,'state':'attempted','automatic_retry':False,'authorization':'User requested a new full English Short. Speech cost below USD 0.01 announced before execution.'},indent=2))
  req=urllib.request.Request('https://api.openai.com/v1/audio/speech',data=json.dumps({'model':'tts-1','voice':S['voices'][role],'speed':1,'input':text,'response_format':'wav'}).encode(),headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'application/json'})
  try:
   with urllib.request.urlopen(req,timeout=180) as r:raw.write_bytes(r.read())
  except urllib.error.HTTPError as e:
   doc=json.loads(rec.read_text());doc.update(state='failed',http_status=e.code);rec.write_text(json.dumps(doc,indent=2));raise RuntimeError(f'Cue {i}: HTTP {e.code}; no retry or key logging') from None
  doc=json.loads(rec.read_text());doc.update(state='saved',sha256=hashlib.sha256(raw.read_bytes()).hexdigest());rec.write_text(json.dumps(doc,indent=2))
 if not dst.exists():subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-ar','48000','-ac','1',str(dst)],check=True)
 with wave.open(str(dst)) as w:duration=w.getnframes()/w.getframerate()
 print(f'Cue {i} saved: {duration:.2f}s',flush=True)
 return {'id':i,'role':role,'voice':S['voices'][role],'text':text,'vi':vi,'planned_start':start,'duration':duration,'file':str(dst.relative_to(B))}
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(one,enumerate(S['rows'],1)))
 end=-.2
 for r in rows:r['start']=max(r['planned_start'],end+.2);r['end']=r['start']+r['duration'];end=r['end']
 out={'title':S['title'],'duration':max(35,end+1.1),'fps':30,'dimensions':[1080,1920],'cues':rows,'voices':S['voices'],'estimated_tts_usd':sum(len(r['text'])*.000015 for r in rows),'billing_verified':False,'new_tts_calls':len(rows),'new_image_calls':1}
 (B/'timeline.json').write_text(json.dumps(out,indent=2));print(json.dumps({'duration':out['duration'],'estimate_usd':out['estimated_tts_usd']},indent=2),flush=True)
