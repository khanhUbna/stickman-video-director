"""Native portrait explanatory animation. No network, no speech generation."""
from pathlib import Path
from functools import lru_cache
import json,math,subprocess,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parent;O=B/'output';W,H=1080,1920;FPS=30
T=json.loads((B/'timeline.json').read_text());C=T['cues'];D=math.ceil(T['duration']*FPS)/FPS;CAP=json.loads((O/'caption-cues.json').read_text());WORDS=json.loads((O/'words.json').read_text())['words']
INK='#143b52';TEAL='#0d8196';GOLD='#ffd04c';YELLOW='#ffe887';CREAM='#fff9eb';BLUE='#45badb';SOIL='#bb9977';CORAL='#d97762'
def ease(u):u=max(0,min(1,float(u)));return u*u*(3-2*u)
def mix(a,b,u):return np.asarray(a)*(1-ease(u))+np.asarray(b)*ease(u)
def p(x):return tuple(round(float(v)) for v in x)
def line(g,pts,c=INK,w=5):g.line([p(x) for x in pts],fill=c,width=w,joint='curve')
def box(g,bb,c,outline=None,w=3,r=14):g.rounded_rectangle(p(bb),radius=r,fill=c,outline=outline,width=w)
def ell(g,bb,c,outline=None,w=3):g.ellipse(p(bb),fill=c,outline=outline,width=w)
def poly(g,pts,c,outline=None,w=3):
 g.polygon([p(x) for x in pts],fill=c)
 if outline:line(g,pts+[pts[0]],outline,w)
@lru_cache(None)
def font(n):return ImageFont.truetype(str(B/'fonts/DejaVuSans-Bold.ttf'),n)
def text(g,xy,s,n=50,c=INK,anchor='mm'):g.text(p(xy),s,font=font(n),fill=c,anchor=anchor)
def arrow(g,a,b,c=TEAL,w=6):
 a=np.array(a,float);b=np.array(b,float);v=b-a;v/=max(.01,np.linalg.norm(v));n=np.array([-v[1],v[0]]);line(g,[a,b-v*12],c,w);poly(g,[b,b-v*22+n*11,b-v*22-n*11],c)
def tag(g,x,y,s,n=27,c=TEAL):
 width=font(n).getlength(s);box(g,(x-width/2-18,y-24,x+width/2+18,y+24),CREAM,INK,2);text(g,(x,y),s,n,c)
def along(pts,u):
 ls=[math.dist(a,b) for a,b in zip(pts,pts[1:])];d=max(0,min(1,u))*sum(ls)
 for a,b,L in zip(pts,pts[1:],ls):
  if d<=L:return np.array(a)+(np.array(b)-a)*d/L
  d-=L
 return np.array(pts[-1])
def partial(pts,u):
 total=sum(math.dist(a,b) for a,b in zip(pts,pts[1:]));remaining=total*max(0,min(1,u));out=[pts[0]]
 for a,b in zip(pts,pts[1:]):
  L=math.dist(a,b)
  if remaining>=L:out.append(b);remaining-=L
  else:out.append(tuple(np.array(a)+(np.array(b)-a)*remaining/L));break
 return out
def ik(a,b,L,pole):
 a=np.asarray(a,float);b=np.asarray(b,float);v=b-a;d=np.linalg.norm(v);assert .001<d<2*L-.001,(d,L);v/=d;mid=(a+b)/2+pole*np.array([-v[1],v[0]])*math.sqrt(L*L-d*d/4);return np.array([a,mid,b])
@lru_cache(None)
def spr(name,h):
 im=Image.open(B/f'art/{name}.png').convert('RGBA');return im.resize((round(im.width*h/im.height),h),Image.Resampling.LANCZOS)
TRACE=[]
def bolt(im,x,y,t,h=245,expr='smug',pose='shrug',record=False):
 # y is the body bottom; feet are independently fixed in the world.
 s=h/245;imbody=spr(expr,h);width=imbody.width;xx=x+3*s*math.sin(t*2.5);yy=y+3*s*math.sin(t*3);g=ImageDraw.Draw(im)
 ell(g,(x-80*s,y+66*s,x+80*s,y+84*s),'#a4b5ab')
 chains=[]
 for k in [-1,1]:
  hip=(xx-10*s+k*14*s,yy-69*s);foot=(x+k*40*s,y+70*s);ch=ik(hip,foot,75*s,-k);line(g,ch,INK,max(4,round(7*s)));line(g,[foot,(foot[0]+19*s,foot[1]+3*s)],INK,max(5,round(8*s)));chains.append((ch,75*s))
 for k in [-1,1]:
  root=(xx+k*width*.31,yy-h*.47)
  if pose=='panic':hand=(xx+k*116*s,yy-h*.95+6*s*math.sin(t*8+k))
  elif pose=='point' and k==1:hand=(xx+135*s,yy-h*.66)
  elif pose=='shrug':hand=(xx+k*116*s,yy-h*.56+7*s*math.sin(t*3+k))
  else:hand=(xx+k*108*s,yy-h*.23+8*s*math.sin(t*2+k))
  ch=ik(root,hand,73*s,k);line(g,ch,INK,max(4,round(7*s)));ell(g,(hand[0]-9*s,hand[1]-9*s,hand[0]+9*s,hand[1]+9*s),CREAM,INK,max(2,round(3*s)));chains.append((ch,73*s))
 im.alpha_composite(imbody,(round(xx-width/2),round(yy-h)))
 if record:TRACE.append({'time':t,'mascot':True,'max_bone_error':max(abs(np.linalg.norm(ch[i+1]-ch[i])-L) for ch,L in chains for i in [0,1]),'feet':[[x-40*s,y+70*s],[x+40*s,y+70*s]]})
 return ImageDraw.Draw(im)
def face(g,x,y,t,s=1,talk=False):
 for k in [-1,1]:
  cx=x+k*44*s;ell(g,(cx-18*s,y-24*s,cx+18*s,y+12*s),CREAM,INK,3);ell(g,(cx-3*s,y-12*s,cx+9*s,y+5*s),INK);line(g,[(cx-20*s,y-39*s),(cx+18*s,y-35*s)],INK,5)
 if talk:ell(g,(x-25*s,y+30*s,x+25*s,y+(45+18*abs(math.sin(t*14)))*s),INK)
 else:line(g,[(x-24*s,y+39*s),(x+24*s,y+40*s)],INK,5)
def cloud(g,x,y,t,s=1):
 for dx,dy,r in [(-85,25,70),(-20,-20,90),(70,5,85),(125,38,55)]:ell(g,(x+(dx-r)*s,y+(dy-r)*s,x+(dx+r)*s,y+(dy+r)*s),'#87aab7',INK,5)
 face(g,x+15*s,y+10*s,t,.65*s,False)
def field(g,t,ground=780,soil=True):
 box(g,(35,385,1025,1315),'#e2f0ee',INK,3)
 ell(g,(-270,650,800,1300),'#c3dfc2');ell(g,(460,630,1430,1320),'#d4e6c1')
 box(g,(36,ground,1024,1314),SOIL,r=0);line(g,[(37,ground),(1023,ground)],'#507b65',9)
 for j in range(46):
  x=60+(j*83)%930;y=ground+35+(j*61)%max(50,int(1260-ground));ell(g,(x,y,x+10+(j%4)*4,y+6+(j%3)*3),'#a78868')
def discharge(g,t,x=350,y=780,on=True):
 pts=[(x+30,475),(x-32,575),(x+24,591),(x-48,697),(x+2,686),(x,y)]
 if on:line(g,pts,INK,21);line(g,pts,GOLD,13);line(g,pts,'#fff3b2',4)
def current_paths(g,t,origin=(350,720),u=1,travel=0):
 x,y=origin;paths=[[(x,y),(x-80,y+35),(x-195,y+45),(80,y+92)],[(x,y),(x+80,y+18),(x+220,y+40),(x+350,y+78),(950,y+90)],[(x,y),(x-45,y+100),(x-15,y+195),(x-110,y+300),(x-130,y+450)],[(x,y),(x+72,y+120),(x+170,y+200),(x+250,y+330),(x+360,y+460)],[(x,y),(x-95,y+100),(x-210,y+185),(100,y+280)]]
 for j,path in enumerate(paths):
  line(g,partial(path,u),INK,14);line(g,partial(path,u),GOLD,8)
  if u>.01:
   for k in [0,1]:
    at=((travel*.3+k*.43+j*.1)%1)*u;c=along(path,at);ell(g,(c[0]-6,c[1]-6,c[0]+6,c[1]+6),'#fff5c4')
 return paths
def shoe(g,x,y,col=TEAL,scale=1):
 s=scale;poly(g,[(x-54*s,y-65*s),(x+13*s,y-65*s),(x+13*s,y-18*s),(x+62*s,y-12*s),(x+78*s,y+14*s),(x-58*s,y+14*s)],col,INK,5);line(g,[(x-54*s,y+8*s),(x+72*s,y+8*s)],CREAM,5)
def human(g,t,body_current=0):
 # Neutral educational silhouette, not a depicted outdoor experiment.
 ell(g,(465,380,615,530),CREAM,INK,6);box(g,(480,565,600,825),CREAM,INK,6,r=40);line(g,[(540,530),(540,570)],INK,12)
 for pts in [[(490,615),(405,740),(440,815)],[(590,615),(680,740),(645,815)],[(500,815),(453,930),(420,1040)],[(580,815),(627,930),(660,1040)]]:line(g,pts,INK,20);line(g,pts,CREAM,10)
 shoe(g,420,1045,TEAL,.7);shoe(g,660,1045,TEAL,.7)
 path=[(420,1040),(453,930),(500,815),(580,815),(627,930),(660,1040)]
 if body_current>0:
  line(g,partial(path,body_current),GOLD,10)
  for k in range(3):
   q=along(path,((t*.65+k*.3)%1)*body_current);ell(g,(q[0]-5,q[1]-5,q[0]+5,q[1]+5),'#fff4bc')
 return path
SCENES=[('hit',0,C[1]['start']),('ground',C[1]['start'],C[2]['start']),('spread',C[2]['start'],C[3]['start']),('where',C[3]['start'],C[4]['start']),('feet',C[4]['start'],C[5]['start']),('body',C[5]['start'],C[6]['start']),('reaction',C[6]['start'],C[7]['start']),('shelter',C[7]['start'],D)]
def scene_at(t):return next(s for s in SCENES if s[1]<=t<s[2]+1e-8)
BODY_ON=next(w['start'] for w in WORDS if w['cue']==6 and w['word'].lower()=='that')
def shelter(g,t,u):
 box(g,(145,600,935,1270),'#fff0d3',INK,7);poly(g,[(90,605),(540,390),(990,605)],'#da9078',INK,7)
 box(g,(200,720,365,900),'#94cdd8',INK,5);line(g,[(282,720),(282,900)],CREAM,7);line(g,[(200,810),(365,810)],CREAM,7)
 box(g,(725,730,880,1255),'#c5a576',INK,5);ell(g,(744,1000,760,1016),GOLD,INK,2)
 # Seated occupant stays inside, away from the window and outer doorway.
 box(g,(450,1070,690,1190),'#a0c0ae',INK,4);line(g,[(470,1190),(470,1240)],INK,8);line(g,[(660,1190),(660,1240)],INK,8)
 ell(g,(505,860,605,960),CREAM,INK,5);box(g,(515,970,600,1080),TEAL,INK,4);line(g,[(530,1075),(505,1150),(505,1230)],INK,10);line(g,[(585,1075),(630,1145),(645,1230)],INK,10)
 wave=7*math.sin(t*3);line(g,[(600,992),(655,1000),(685,950+wave)],INK,9);ell(g,(676,940+wave,694,958+wave),CREAM,INK,3)
 face(g,555,911,t,.43,False);tag(g,540,680,'SUBSTANTIAL BUILDING',29)
 ell(g,(825,450,925,550),'#4b9e7e',INK,4);line(g,[(848,499),(871,519),(906,477)],CREAM,10)
def frame(t,record=True):
 s=scene_at(t);name,a,b=s;u=t-a;im=Image.new('RGBA',(W,H),CREAM);g=ImageDraw.Draw(im)
 role=next((r['role'] for r in C if r['start']<=t<r['end']),'')
 text(g,(510,100),'EVERYDAY, EXPLAINED',28,TEAL)
 if name=='hit':
  text(g,(510,235),'IT HIT THE GROUND...',62);text(g,(510,327),'NOW WHAT?',91,TEAL);field(g,t);cloud(g,320,460,t,.7);discharge(g,t,350,780,t<.85)
  if .35<t<1.4:
   rr=30+40*ease((t-.35)/1.05);g.arc(p((350-rr,780-rr*.2,350+rr,780+rr*.2)),0,360,fill=CORAL,width=5)
  g=bolt(im,790,705,t,255,'smug','shrug',record)
 elif name=='ground':
  text(g,(510,245),'NOT A TRASH CAN.',65,TEAL);box(g,(40,395,1015,1310),SOIL,INK,5);face(g,350,780,t,2.2,role=='GROUND')
  box(g,(650,450,820,645),'#c0d1cf',INK,4);box(g,(635,430,835,465),'#819c9f',INK,4)
  for x in [685,735,785]:line(g,[(x,485),(x,610)],'#819c9f',6)
  line(g,[(630,420),(840,655)],CORAL,11);g=bolt(im,790,1150,t,245,'puzzled','shrug',record)
 elif name=='spread':
  text(g,(510,245),'IT SPREADS OUT.',75,TEAL);field(g,t,700);cloud(g,360,460,t,.65);discharge(g,t,350,700,True);current_paths(g,t,(350,700),ease(u/3),u)
  tag(g,510,1275,'BRIEF PULSE · SLOWED DOWN',27);g=bolt(im,835,615,t,155,'puzzled','point',record)
 elif name=='where':
  text(g,(510,245),'WHERE YOU STAND...',66,TEAL);field(g,t,920);discharge(g,t,130,920,True)
  for x,col in [(435,'#e7b665'),(755,'#78b4b9')]:ell(g,(x-110,875,x+110,970),col,INK,3);shoe(g,x,905,col,.9)
  tag(g,430,1040,'POINT A');tag(g,750,1040,'POINT B');g=bolt(im,230,1200,t,190,'puzzled','point',record)
 elif name=='feet':
  text(g,(510,245),'...BOTH FEET.',80,TEAL);box(g,(40,900,1025,1300),SOIL,INK,5)
  ya=900-160*(1-ease(u/.55));yb=900-180*(1-ease((u-.45)/.55));shoe(g,380,ya,'#dca956',1.5);shoe(g,730,yb,'#7dbbc0',1.5)
  if u>.55:tag(g,375,1060,'VOLTAGE A',28)
  if u>1:tag(g,740,1060,'VOLTAGE B',28)
  if u>1.08:text(g,(550,680),'A ≠ B',112,TEAL)
  tag(g,510,1235,'DIFFERENT POINTS CAN DIFFER',26)
 elif name=='body':
  text(g,(510,245),'DIFFERENT VOLTAGES',61,TEAL);box(g,(45,1045,1020,1320),SOIL,INK,4)
  if u>.25:ell(g,(355,1010,490,1080),'#e5bb76')
  if u>1.05:ell(g,(590,1010,730,1080),'#8cbfc3')
  human(g,t,ease((t-BODY_ON)/2.0))
  if u>.25:tag(g,385,1140,'A',42)
  if u>1.05:tag(g,705,1140,'B',42)
  if u>1.9:text(g,(545,1140),'≠',74,TEAL)
  tag(g,520,1275,'SIMPLIFIED · SLOWED DOWN',26);g=bolt(im,170,1210,t,155,'alarmed','panic',record)
 elif name=='reaction':
  text(g,(510,245),'NOT JUST THE',73,TEAL);text(g,(510,335),'STRIKE POINT.',73,TEAL);field(g,t,780);face(g,350,1010,t,1.6,False);g=bolt(im,730,730,t,280,'alarmed','panic',record)
 else:
  text(g,(510,235),'HEAR THUNDER?',73);text(g,(510,327),'GET INSIDE.',85,TEAL);shelter(g,t,u)
  if u>3.8:text(g,(510,1340),'More everyday mysteries →',29,TEAL)
 g=ImageDraw.Draw(im);cue=next((c for c in CAP if c['start']<=t<c['end']),None)
 if cue:
  width=font(48).getlength(cue['text']);assert width<920,(width,cue['text']);box(g,(510-width/2-23,1410,510+width/2+23,1500),INK,r=20);text(g,(510,1455),cue['text'],48,CREAM);text(g,(510,1370),cue['speaker'],23,TEAL)
 line(g,[(80,1560),(940,1560)],'#cfddd2',5);line(g,[(80,1560),(80+860*t/D,1560)],TEAL,5)
 return im.convert('RGB')
def render():
 p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'picture.mp4')],stdin=subprocess.PIPE)
 for i in range(round(D*FPS)):
  p.stdin.write(frame(i/FPS).tobytes())
  if i%180==0:print(f'Frame {i}/{round(D*FPS)}',flush=True)
 p.stdin.close();assert p.wait()==0;(O/'motion.json').write_text(json.dumps(TRACE));(O/'shots.json').write_text(json.dumps(SCENES,indent=2))
if __name__=='__main__':
 if len(sys.argv)>1:
  for j,(s,a,b) in enumerate(SCENES):frame((a+b)/2).save(O/f'shot-{j+1:02d}.jpg')
 else:render()
