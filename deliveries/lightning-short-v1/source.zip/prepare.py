from pathlib import Path
import json,re,wave,subprocess
B=Path(__file__).resolve().parent;O=B/'output';S=json.loads((B/'story.json').read_text());O.mkdir(exist_ok=True)
real=(B/'timeline.json').exists() and not json.loads((B/'timeline.json').read_text()).get('provisional',False)
if real:T=json.loads((B/'timeline.json').read_text())
else:
 rows=[];end=-.2
 for i,(at,role,text,vi) in enumerate(S['rows'],1):
  start=max(at,end+.2);duration=len(text.split())/2.8+.15;end=start+duration;rows.append({'id':i,'role':role,'voice':S['voices'][role],'text':text,'vi':vi,'start':start,'end':end,'duration':duration,'file':f'audio/{i:02d}.wav'})
 T={'title':S['title'],'duration':max(35,end+1.1),'fps':30,'dimensions':[1080,1920],'cues':rows,'provisional':True,'narration_present':False,'timing':'Editorial estimates; missing narration. Not audio-aligned.'};(B/'timeline.json').write_text(json.dumps(T,indent=2))
PARTS=[['I hit the ground.','Job done?'],["The ground isn't",'a trash can.'],['During the strike,','current spreads','through and along the ground.'],['So where you stand','matters?'],['And where both feet stand.'],['Your feet can touch places','at different voltages.','That difference can drive','current through your body.'],['That escalated quickly.'],['Hear thunder?','Get inside','a substantial building.']]
tokens=lambda s:re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",s)
CAP=[];WORDS=[]
for r,parts in zip(T['cues'],PARTS):
 ts=tokens(r['text']);words=[]
 if real:
  from pocketsphinx import Decoder
  dst=B/f"audio/{r['id']:02d}-16k.wav";subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/r['file']),'-ar','16000','-ac','1',str(dst)],check=True);d=Decoder(samprate=16000,loglevel='ERROR');missing=[w for w in ts if not d.lookup_word(w.lower())];assert not missing,missing;d.set_align_text(' '.join(t.lower() for t in ts))
  with wave.open(str(dst)) as w:data=w.readframes(w.getnframes())
  d.start_utt();d.process_raw(data,full_utt=True);d.end_utt();segs=[s for s in d.seg() if s.word not in ['<sil>','<s>','</s>','[SPEECH]','[NOISE]']];assert len(segs)==len(ts)
  for t,s in zip(ts,segs):words.append({'word':t,'start':r['start']+s.start_frame/100,'end':min(r['end'],r['start']+(s.end_frame+1)/100)})
 else:
  for i,t in enumerate(ts):words.append({'word':t,'start':r['start']+r['duration']*i/len(ts),'end':r['start']+r['duration']*(i+1)/len(ts)})
 k=0
 for text in parts:
  n=len(tokens(text));chunk=words[k:k+n];k+=n;CAP.append({'start':chunk[0]['start'],'end':min(r['end'],chunk[-1]['end']+.06),'text':text,'speaker':r['role']})
 assert k==len(words);WORDS.extend([dict(w,cue=r['id']) for w in words])
for i in range(len(CAP)-1):CAP[i]['end']=min(CAP[i]['end'],CAP[i+1]['start'])
(O/'caption-cues.json').write_text(json.dumps(CAP,indent=2));(O/'words.json').write_text(json.dumps({'method':'Offline acoustic alignment' if real else 'Editorial estimates, NOT audio-aligned','words':WORDS},indent=2));print(json.dumps({'narration_present':real,'seconds':T['duration'],'captions':len(CAP)}),flush=True)
