from pathlib import Path
import json,subprocess,hashlib,re
import numpy as np
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parent;O=B/'outputs/full-review-v2-01';D=B/'delivery';V=D/'why-you-clean-b6-v2.mp4'
def run(a):return subprocess.run(a,check=True,capture_output=True)
def rows(p):return [json.loads(l) for l in p.read_text().splitlines()]
new=rows(O/'limb-frames.jsonl')
def stats(data):
 data=[r for r in data if 5.35<=r['frame']/30<=9.5];hip=[];shoulder=[];wrist=[];feet={s:[] for s in ['left','right']}
 for r in data:
  legs=r['legs'];hip.append(np.mean([l['hip'] for l in legs],axis=0))
  arm=next(a for a in r['arms'] if a['side']=='right');shoulder.append(arm['screen_nodes'][0]);wrist.append(arm['screen_nodes'][-1])
  for l in legs:feet[l['side']].append(l['ankle'])
 return {'sampled_frames':len(data),'hip_horizontal_span_px':float(np.ptp(np.array(hip)[:,0])),'shoulder_horizontal_span_px':float(np.ptp(np.array(shoulder)[:,0])),'wrist_horizontal_span_px':float(np.ptp(np.array(wrist)[:,0])),'max_ankle_drift_px':max(float(np.max(np.linalg.norm(np.array(v)-v[0],axis=1))) for v in feet.values())}
a=json.loads((B/'comparison-baseline-v1.json').read_text())['stats'];b=stats(new);assert b['hip_horizontal_span_px']>25 and b['max_ankle_drift_px']<1e-6
ratios=[l['actual_length']/l['authored_stance_length'] for r in new for l in r.get('legs',[])];assert min(ratios)>=.92 and max(ratios)<=1.08
assert all(not r['errors'] and not r['contact_errors'] or not r['errors'] and max(r['contact_errors'])<1e-6 for r in new)
probe=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(V)]).stdout);v=next(s for s in probe['streams'] if s['codec_type']=='video');assert int(v['nb_read_frames'])==801
run(['ffmpeg','-v','error','-i',str(V),'-f','null','-'])
words=json.loads((B/'words.json').read_text())['words'];cues=json.loads((B/'captions.json').read_text());norm=lambda x:re.sub('[^a-z]','',x.lower());assert norm(' '.join(x['word'] for x in words))==norm(' '.join(x['text'] for x in cues))
plan=json.loads((B/'formats/portrait.json').read_text());sheet=Image.new('RGB',(1080,4*665),'#e5e3d9');g=ImageDraw.Draw(sheet)
for i,s in enumerate(plan['shots']):
 t=(s['start']+s['end'])/2;raw=run(['ffmpeg','-v','error','-ss',str(t),'-i',str(V),'-frames:v','1','-vf','scale=360:640','-pix_fmt','rgb24','-f','rawvideo','pipe:1']).stdout
 im=Image.frombytes('RGB',(360,640),raw);x=i%3*360;y=i//3*665;sheet.paste(im,(x,y));g.text((x+8,y+645),f"{s['id']} | {t:.2f}s",fill='#24313a')
sheet.save(D/'encoded-shot-sheet.jpg',quality=93)
report=json.loads((O/'report.json').read_text());audio=json.loads((D/'audio-finishing.json').read_text())
qa={'status':'technical_pass_full_length_review_pending','duration':float(probe['format']['duration']),'dimensions':[720,1280],'frames':801,'full_decode':'pass','native_report':'outputs/full-review-v2-01/report.json','native_rig_status':report['technical_status'],'arm_poses_checked':report['arm_poses_checked'],'straight_legs_checked':report['straight_legs_checked'],'max_prop_contact_error_px':report['max_prop_contact_error_px'],'new_vs_old_wipe_performance':{'scope':'5.35–9.5s; world static; actual audited actor nodes, not whole-frame pixel changes','v1':a,'v2':b},'bounded_planted_leg_length_ratio':[min(ratios),max(ratios)],'caption_word_coverage':'pass','spoken_words':len(words),'new_TTS_calls':0,'picture_stream_unchanged_after_audio_finish':audio['picture_stream_unchanged'],'video_sha256':hashlib.sha256(V.read_bytes()).hexdigest(),'loudness':audio['loudness'],'capability_limits':['Supported standing body/hip lean with independently planted feet; this is not a walking or seated-pose system.','Front and three-quarter views use an actual authored cut, not manufactured continuous turn art.','Motion/geometry metrics and stills do not certify natural acting or independent creative/source equivalence. Full human viewing/listening remains pending.'],'YouTube_upload':False}
key_frames=[]
for row in new:
 t=row['frame']/30
 if any(a<=t<b for a,b in [(17.06,18.48),(19.96,21.73),(24.16,26.7)]):
  arm=next(a for a in row['arms'] if a['side']=='right');x,y=arm['screen_nodes'][-1];key_frames.append(max(425-x,x-443,821.5-y,y-827,0))
assert key_frames and max(key_frames)<1e-6
qa['keyboard_contact']={'audited_frames':len(key_frames),'actual_key_rectangle':[425,821.5,443,827],'maximum_wrist_outside_key_px':max(key_frames),'limits':'Geometry anchor on a drawn key; not a subjective acting verdict.'}
(D/'QA.json').write_text(json.dumps(qa,indent=2)+'\n');print(json.dumps(qa['new_vs_old_wipe_performance'],indent=2));print('Full decode and original-script coverage passed.')
