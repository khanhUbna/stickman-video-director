"""Reuse the untouched speech; sync original local Foley to V2 actions. No API."""
from pathlib import Path
import subprocess,json,re,hashlib,math
B=Path(__file__).resolve().parent;O=B/'outputs/full-review-v2-01';D=B/'delivery';D.mkdir(exist_ok=True)
def run(args):return subprocess.run(args,check=True,capture_output=True)
def measure(p):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(p),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'])
 return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
args=['ffmpeg','-v','error','-y','-i',str(B/'audio/original-alloy.wav'),'-i',str(B/'audio/stems/music-original.wav'),'-i',str(B/'audio/stems/room.wav'),'-i',str(B/'audio/stems/wipe.wav')]
wipes=[5.12,5.75,6.45,7.15,7.85,8.55,9.25]
f='[0:a]apad,atrim=0:26.7[voice];[1:a]volume=0.11,apad,atrim=0:26.7[music];[2:a]volume=0.035,apad,atrim=0:26.7[room];[3:a]asplit='+str(len(wipes))+''.join(f'[w{i}]' for i in range(len(wipes)))+';'
for i,t in enumerate(wipes):f+=f'[w{i}]volume=0.10,adelay={round(t*1000)}:all=1[wp{i}];'
keys=[]
for n in range(40):
 t=17.06+(0.5+2*n)/7
 if any(a<=t<b for a,b in [(17.06,18.48),(19.96,26.7)]) and n%2==0:keys.append(t)
for i,t in enumerate(keys):f+=f'aevalsrc=0.012*sin(2*PI*1700*t)*exp(-t*140):s=48000:d=0.045,adelay={round(t*1000)}:all=1[k{i}];'
tracks=['voice','music','room']+[f'wp{i}' for i in range(len(wipes))]+[f'k{i}' for i in range(len(keys))]
f+=''.join('['+t+']' for t in tracks)+f'amix=inputs={len(tracks)}:normalize=0:duration=first,alimiter=limit=0.89:level=false:latency=true[mix]'
raw=B/'audio/mix-v2-unmastered.wav';run(args+['-filter_complex',f,'-map','[mix]','-ar','48000','-ac','1','-t','26.7',str(raw)])
pre=measure(raw);flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
master=B/'audio/mix-v2.wav';run(['ffmpeg','-v','error','-y','-i',str(raw),'-af',flt,'-ar','48000','-ac','1','-t','26.7',str(master)])
movie=D/'why-you-clean-b6-v2.mp4';run(['ffmpeg','-v','error','-y','-i',str(O/'preview.mp4'),'-i',str(master),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','26.7','-movflags','+faststart',str(movie)])
def picture_hash(p):return run(['ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-c','copy','-f','hash','-hash','sha256','-']).stdout.decode().strip()
a=picture_hash(O/'preview.mp4');b=picture_hash(movie);assert a==b
run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-']);post=measure(movie)
manifest={'finishing':'Audio-only remux of the native audited B6 picture; native report is preserved unmodified.','native_report':'outputs/full-review-v2-01/report.json','native_mp4_sha256':hashlib.sha256((O/'preview.mp4').read_bytes()).hexdigest(),'delivery_sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'encoded_picture_stream_sha256':a,'picture_stream_unchanged':True,'speech_sha256':hashlib.sha256((B/'audio/original-alloy.wav').read_bytes()).hexdigest(),'new_TTS_calls':0,'original_speech_speed':1,'wipe_cues':wipes,'keyboard_cues':keys,'plate_or_send_sfx':False,'loudness':post,'full_decode':'pass','independent_creative_review':'pending actual viewing/listening'}
(D/'audio-finishing.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Audio aligned; original speech retained; encoded picture stream unchanged.');print('LUFS',post['input_i'],'true peak',post['input_tp'])
