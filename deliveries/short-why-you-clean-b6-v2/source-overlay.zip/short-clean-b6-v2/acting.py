"""Reusable supported-stance acting. No gait, seated pose or body warping claimed."""
import math
import numpy as np

def ease(x):x=max(0.,min(1.,x));return x*x*(3-2*x)
def envelope(t,keys):
 if t<=keys[0][0]:return keys[0][1]
 for (a,x),(b,y) in zip(keys,keys[1:]):
  if t<=b:return x+(y-x)*ease((t-a)/(b-a))
 return keys[-1][1]
def supported_lean(scale,x,y,dx=0.,angle=0.):
 a=math.radians(angle);cs,sn=math.cos(a),math.sin(a);px,py=0.,-92.
 # A rigid body about its hips; ankles are separately planted in world space.
 return np.array([[scale*cs,-scale*sn,x+dx+scale*(px-cs*px+sn*py)],[scale*sn,scale*cs,y+scale*(py-sn*px-cs*py)],[0.,0.,1.]])
def wipe(t):
 # Preparation, decisive strokes, slowing finish and deliberate placement.
 w=envelope(t,[(4.72,-.4),(5.1,0),(5.35,-1),(6.05,1),(6.75,-1),(7.45,1),(8.15,-1),(8.85,1),(9.5,-.6),(9.85,0),(10.45,0)])
 return {'dx':16*w,'angle':2*w,'phase':ease((t-4.72)/.38),'head':4.,'lift':envelope(t,[(4.72,0),(5.1,0),(5.35,-8),(5.6,0),(9.85,0),(10.08,-6),(10.45,0)])}
def approach(t,start,end):
 u=ease((t-start)/(end-start));return {'dx':-8+18*u,'angle':-1.2+3.2*u,'phase':u,'head':-3+8*u}
def recoil(t,start,end):
 u=ease((t-start)/(end-start));return {'dx':10-18*u,'angle':2-3.2*u,'phase':1-u,'head':5-9*u}
def typing(t):
 # Small rhythmic contact pulses, not whole-actor camera shake.
 q=math.sin((t-17.06)*math.pi*7);press=max(0.,q)
 return {'dx':9+1.2*q,'angle':1.4+.2*q,'phase':1.,'head':4.,'press':press}
def planted(view,scale,x,y):
 return {side:[x+scale*leg['ankle'][0],y+scale*leg['ankle'][1]] for side,leg in view.legs.items()}
def point(mat,p):return (mat@np.r_[p,1.])[:2]
