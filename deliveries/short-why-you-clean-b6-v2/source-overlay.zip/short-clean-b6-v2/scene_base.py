"""New portrait everyday-psychology performance using the B6 audited compositor."""
import math
import numpy as np
from PIL import Image,ImageDraw,ImageFilter,ImageFont
_CACHE={}
def smooth(x):x=max(0,min(1,x));return x*x*(3-2*x)
def matrix(scale,x,y):return np.array([[scale,0.,x],[0.,scale,y],[0.,0.,1.]])
def setup(c):
 r=c.puppet_runtime
 return {'r':r,'hero':r.Puppet(c.character_packages['hero'],'front','hero'),'world':Image.open(c.base/'art/apartment.png').convert('RGBA'),'cloth':Image.open(c.base/'art/cloth.png').convert('RGBA'),'font':str(c.base/'fonts/ArchivoBlack.ttf')}
def background(s,k,t):
 # The camera reveals different parts of a single wide painted apartment.
 world=s['world'];x=0 if k=='study' else 960
 im=world.crop((x,0,x+576,1024)).resize((720,1280),Image.Resampling.LANCZOS)
 if k=='kitchen':
  g=ImageDraw.Draw(im)
  # Foreground preparation island; its top supports the separately rendered cloth.
  g.rounded_rectangle((365,850,701,1086),radius=7,fill='#b8baa0',outline='#56443a',width=3)
  g.polygon([(355,841),(700,841),(710,864),(355,864)],fill='#c99c65',outline='#56443a',width=3)
  for dx in [0,1,2]:
   if t<5.3+dx*.4:g.ellipse((435+dx*12,833,442+dx*12,838),fill='#685044')
  g.line([(480,874),(480,1075)],fill='#766e56',width=2)
  if t>=10.45:
   cloth=s['cloth'].copy();cloth.thumbnail((80,25),Image.Resampling.LANCZOS);im.alpha_composite(cloth,(436,824))
 shadow=Image.new('RGBA',im.size);g=ImageDraw.Draw(shadow);cx=450 if k=='study' else 260;cy=900 if k=='study' else 1020;g.ellipse((cx-57,cy-12,cx+65,cy+10),fill=(48,38,34,65));return Image.alpha_composite(im,shadow.filter(ImageFilter.GaussianBlur(8)))
def email_detail(s,t,transparent=False):
 # An original illustrated draft, not a screenshot or an actual sent email.
 im=Image.new('RGBA',(720,1280)) if transparent else s['world'].crop((550,0,1126,1024)).resize((720,1280),Image.Resampling.LANCZOS)
 shadow=Image.new('RGBA',im.size);g=ImageDraw.Draw(shadow);g.rounded_rectangle((42,268,683,837),radius=22,fill=(33,25,31,105));im=Image.alpha_composite(im,shadow.filter(ImageFilter.GaussianBlur(12)))
 g=ImageDraw.Draw(im);ink='#342b31';cream='#fff6df'
 g.rounded_rectangle((44,250,676,734),radius=16,fill='#81998d',outline=ink,width=5)
 g.rounded_rectangle((64,270,656,708),radius=7,fill=cream,outline=ink,width=3)
 g.rectangle((67,273,653,336),fill='#e9bf68');g.line((67,336,653,336),fill=ink,width=3)
 font=lambda size:ImageFont.truetype(s['font'],size)
 g.text((88,289),'Draft · Important email',font=font(23),fill=ink)
 g.text((88,355),'To: Alex',font=font(21),fill='#4d726a');g.line((88,392,630,392),fill='#acb7a1',width=2)
 message='Hi, could we talk about this?'
 n=round(len(message)*smooth((t-17.06)/1.30)) if t<18.48 else len(message)
 g.text((88,438),message[:n],font=font(23),fill=ink)
 follow='I wanted to ask...';n2=round(len(follow)*smooth((t-21.73)/2.25)) if t>=21.73 else 0
 if n2:g.text((88,500),follow[:n2],font=font(23),fill='#4d726a')
 text=follow[:n2] if t>=21.73 else message[:n];cy=500 if t>=21.73 else 438;cx=88+g.textlength(text,font=font(23))+4
 g.line((cx,cy,cx,cy+30),fill='#365f55',width=3)
 g.rounded_rectangle((516,631,631,681),radius=7,fill='#c5d5bd',outline=ink,width=2);g.text((538,644),'Send',font=font(21),fill=ink)
 g.polygon([(44,736),(676,736),(705,820),(15,820)],fill='#83968b',outline=ink,width=4)
 for row in range(3):
  for col in range(12):
   x=74+col*47-row*4;y=749+row*17;g.rounded_rectangle((x,y,x+36,y+11),radius=2,fill='#dce4cf',outline='#53665b',width=1)
 g.rounded_rectangle((279,804,442,815),radius=3,fill='#b9c8b2',outline=ink,width=1)
 if 18.48<=t<19.96:
  u=smooth((t-18.48)/1.20);x=590+55*u;y=662+105*u
  g.polygon([(x,y),(x+3,y+27),(x+11,y+19),(x+20,y+31),(x+26,y+27),(x+17,y+15),(x+30,y+13)],fill='#f5eedb',outline=ink,width=2)
 return im

def frame(t,c):
 key=(str(c.base),c.fingerprint)
 if key not in _CACHE:_CACHE[key]=setup(c)
 s=_CACHE[key];r=s['r'];i=round(t*30);hero=s['hero']
 if 15.55<=t<24.16:
  return r.render_scene((720,1280),[],background=email_detail(s,t),frame_index=i)
 if 2.9<=t<4.72:
  # Genuine prop-detail shot. The cast inventory declares no visible person here.
  im=s['world'].crop((240,290,500,752)).resize((720,1280),Image.Resampling.LANCZOS)
  return r.render_scene((720,1280),[],background=im,frame_index=i)
 kitchen=4.72<=t<14.28;k='kitchen' if kitchen else 'study';bg=background(s,k,t)
 mat=matrix(1.35,260 if kitchen else 450,1020 if kitchen else 900)
 if 12.94<=t<14.28:mat=matrix(1.55,300,1100)
 targets={};props=[];action='rest';phase=1
 if kitchen and t<10.45:
  dt=t-4.72;action='reach';phase=1
  # Matched grip and prop share one physical owner timeline; both move together.
  x=437+math.sin(dt*3.3)*7;y=837
  timeline=r.ContactTimeline([{'t0':0,'t1':26.701,'state':'owner','holders':[{'actor_id':'hero','arm':'right','grip':[.2,.5]}],'paper_start':[x+24,y,0]}],paper_size=(80,25))
  contact=timeline.sample(t);targets=contact.targets['hero'];props=[r.PropFrame('cloth',contact,s['cloth'])]
 elif kitchen and t>=10.45:
  action='reach';phase=1-smooth((t-10.45)/.8)
 elif t<2.9:
  action='reach';phase=smooth(t/.8) if t<1.6 else 1-smooth((t-1.6)/1.1)
 elif t>=14.28:
  action='reach';phase=smooth((t-14.28)/1.0) if t<15.55 else 1-smooth((t-24.16)/1.3)
 pose=hero.pose(action=action,phase=phase,placement=mat,wrist_targets=targets,arm_actions={'left':{'action':'reach' if kitchen else action,'phase':.9 if kitchen else phase},'right':{'action':action if kitchen else 'rest','phase':phase if kitchen else 1}},head_variant=None if (kitchen and t<10.45) or t>=24.16 else 'worried',head_angle_deg=(3*math.sin(t*1.6)),frame_index=i,allow_cut=(i in [0,87,142,388,389,428,429,724,725]))
 return r.render_scene((720,1280),[pose],background=bg,props=props,frame_index=i)
