# B6 V2 editable overlay

The authoritative files are scene.py, acting.py, scene_base.py, project.json, the native portrait plan, character packages and audio. Keep original-alloy.wav: do not regenerate speech. The channel workflow is included as channel-animation.md.

On the same installed Skill version, initialize a fresh /workspace/scratch/short-clean-b6-v2:

    cd /workspace/stickman-video-director/skills/directing-stickman-videos
    node scripts/autopilot.mjs init /workspace/scratch/short-clean-b6-v2 --style B6 --ratio 9:16

Extract the overlay over that directory. Init supplies the unchanged engine/ and primary reference/ movie, which are omitted from the ZIP. Use the existing isolated checkout, not a new worktree. Set the external Python cache path to avoid the import audit treating bytecode-cache probes as authored dependencies:

    export PYTHONPYCACHEPREFIX=/tmp/short-b6-python-cache
    /workspace/.venvs/stickman/bin/python /workspace/scratch/short-clean-b6-v2/run.py validate /workspace/scratch/short-clean-b6-v2 --ratio 9:16
    /workspace/.venvs/stickman/bin/python /workspace/scratch/short-clean-b6-v2/run.py preview /workspace/scratch/short-clean-b6-v2 --ratio 9:16 --trusted-code --seconds 26.7 --output outputs/fresh-native-review

The included finishing/QA scripts default to outputs/full-review-v2-01; use that directory on a clean rebuild or change the script path intentionally. finish_audio_v2.py derives delivery/why-you-clean-b6-v2.mp4 from that audited picture, retains the untouched voice, retimes original local Foley, and verifies identical encoded picture-stream hashes. check_motion_v2.py checks delivery decode, caption word coverage, actual body/foot geometry, key contacts and the stored measured V1 baseline. It uses comparison-baseline-v1.json rather than requiring the old workspace.

The final audio is a documented post-production remux. Preserve the original native report and its native MP4 identity; never replace its video hash with the delivery hash or pretend a new independent review passed. New source/art/audio or a new render requires fresh evidence and actual viewing/listening. tools/ffmpeg only balances a long diagnostic select expression without changing its selected frame set when generating review packs.

This character has tested supported standing/lean/reach/wipe/typing actions and a front/three-quarter cut. Its planted legs use bounded length corrections, not a gait. Walking, running, seated poses and continuous turns remain unsupported until separately authored and tested. No YouTube upload or new paid model call is authorized by this archive.
