"""V2: whole-body supported acting and actual keyboard/cloth interaction."""
import math
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import scene_base as base
import acting
_CACHE={}

def setup(c):
 s=base.setup(c);s['previous_shot']=None
 # One physical cloth timeline owns every held/released transform.
 r=s['r'];view=c.character_packages['hero'].views['front'];arm=view.arms['right']
 nominal=r.forward_kinematics(arm,r.PoseLibrary.sample(arm,'reach',1))[2]
 identity=acting.supported_lean(1.35,260,1020)
 def xy(t):
  p=acting.wipe(t);m=acting.supported_lean(1.35,260,1020,p['dx'],p['angle']);delta=acting.point(m,nominal)-acting.point(identity,nominal)
  return [437+float(delta[0]),837+p['lift']]
 times=[5.1]+[i/30 for i in range(154,314) if 5.1<i/30<10.45]+[10.45]
 start=xy(5.1);events=[{'t0':0,'t1':5.1,'state':'release','holders':[],'paper_start':[start[0]+24,start[1],0]}]
 for a,b in zip(times,times[1:]):
  x,y=xy(a);xx,yy=xy(b);events.append({'t0':a,'t1':b,'state':'owner','holders':[{'actor_id':'hero','arm':'right','grip':[.2,.5]}],'paper_start':[x+24,y,0],'paper_end':[xx+24,yy,0]})
 end=xy(10.45);events.append({'t0':10.45,'t1':26.701,'state':'release','holders':[],'paper_start':[end[0]+24,end[1],0]})
 s['cloth_timeline']=r.ContactTimeline(events,paper_size=(80,25));s['cloth_xy']=xy
 return s

def world(s,k,t):
 x=960 if k=='kitchen' else 550
 im=s['world'].crop((x,0,x+576,1024)).resize((720,1280),Image.Resampling.LANCZOS)
 g=ImageDraw.Draw(im)
 if k=='kitchen':
  g.rounded_rectangle((365,850,701,1086),radius=7,fill='#b8baa0',outline='#56443a',width=3)
  g.polygon([(355,841),(700,841),(710,864),(355,864)],fill='#c99c65',outline='#56443a',width=3)
  g.line((480,874,480,1075),fill='#766e56',width=2)
  # Dirty marks disappear only after the surface-contact cloth crosses them.
  reached=0.
  if t>=5.6:
   reached=max(s['cloth_xy'](u)[0]+49 for u in np.arange(5.6,min(t,10.45)+.017,1/30))
  for xx in [455,478,502]:
   if xx>reached:g.ellipse((xx,833,xx+7,838),fill='#685044')
 else:
  g.polygon([(355,841),(700,841),(710,864),(355,864)],fill='#c99c65',outline='#56443a',width=3)
  g.line((380,864,371,1032),fill='#56443a',width=8);g.line((680,864,690,1032),fill='#56443a',width=8)
  device=base.email_detail(s,t,transparent=True).crop((10,240,710,840)).resize((350,300),Image.Resampling.LANCZOS)
  im.alpha_composite(device,(350,550))
  if t>=17.06:
   press=acting.typing(t)['press']
   if press>.5:ImageDraw.Draw(im).rounded_rectangle((426,822,443,827),radius=1,fill='#d8b861',outline='#657664',width=1)
 shadow=Image.new('RGBA',im.size);g=ImageDraw.Draw(shadow);g.ellipse((202,1008,323,1028),fill=(48,38,34,65));return Image.alpha_composite(im,shadow.filter(ImageFilter.GaussianBlur(7)))

def frame(t,c):
 key=(str(c.base),c.fingerprint)
 if key not in _CACHE:_CACHE[key]=setup(c)
 s=_CACHE[key];r=s['r'];i=round(t*30);hero=s['hero']
 shot=next(q for q in c.plan['shots'] if q['start']<=t<q['end']);sid=shot['id'];cut=s['previous_shot']!=sid;s['previous_shot']=sid
 if sid in ['draft','open','unsent','detail-result']:
  return r.render_scene((720,1280),[],background=base.email_detail(s,t),frame_index=i)
 kitchen=sid in ['clean','uncertain','worry'];view_id='three_quarter' if sid=='ending' else 'front';hero.set_view(view_id,allow_cut=cut)
 x=274 if view_id=='three_quarter' else 260;scale=1.35;y=1020;pose={'dx':0.,'angle':0.,'phase':1.,'head':0.}
 if sid=='hesitate':pose=acting.approach(t,0,.9) if t<1.36 else acting.recoil(t,1.36,2.75)
 elif sid=='clean':pose=acting.wipe(t)
 elif sid=='uncertain':pose=acting.recoil(t,10.45,11.4)
 elif sid=='worry':pose={'dx':-10.,'angle':-1.5,'phase':0.,'head':-5+2*acting.ease((t-12.94)/1.34)}
 elif sid=='firstmove':pose=acting.approach(t,14.28,15.4)
 elif sid in ['keyboard','result','ending']:pose=acting.typing(t)
 mat=acting.supported_lean(scale,x,y,pose['dx'],pose['angle']);v=hero.character.views[view_id];feet=acting.planted(v,scale,x,y)
 bg=world(s,'kitchen' if kitchen else 'study',t);targets={};props=[];phase=pose['phase']
 right_action='reach';right_phase=phase
 if sid in ['clean','uncertain','worry']:
  contact=s['cloth_timeline'].sample(t);props=[r.PropFrame('cloth',contact,s['cloth'],front_limb_parts=('hero:arm:right:forearm',) if t>=10.45 else ())]
  if t<5.1:
   fk=r.forward_kinematics(v.arms['right'],r.PoseLibrary.sample(v.arms['right'],'reach',phase))[2];wr=acting.point(mat,fk);goal=np.array(s['cloth_xy'](5.1))
   q=acting.ease((t-4.94)/.16);targets['right']=(wr*(1-q)+goal*q).tolist()
  elif t<10.45:targets.update(contact.targets['hero'])
  else:right_phase=1-acting.ease((t-10.45)/.75)
 else:
  fk=r.forward_kinematics(v.arms['right'],r.PoseLibrary.sample(v.arms['right'],'reach',phase))[2];wr=acting.point(mat,fk)
  goal=np.array([437.,824.5+pose.get('press',0)*1.4])
  if sid=='hesitate':q=acting.ease((t-.65)/.25) if t<1.36 else 1-acting.ease((t-1.36)/.8)
  elif sid=='firstmove':q=acting.ease((t-15.1)/.3)
  else:q=1.
  targets['right']=(wr*(1-q)+goal*q).tolist()
 result=hero.pose(action='reach',phase=right_phase,placement=mat,wrist_targets=targets,
  arm_actions={'left':{'action':'reach','phase':.9},'right':{'action':right_action,'phase':right_phase}},
  head_variant=None if sid in ['clean','result','ending'] else 'worried',head_angle_deg=pose['head'],ankle_targets=feet,frame_index=i,allow_cut=cut)
 return r.render_scene((720,1280),[result],background=bg,props=props,frame_index=i)
