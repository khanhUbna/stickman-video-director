"""Decode evidence from the actual final MP4; never substitute source stills."""
from pathlib import Path
import json,subprocess,hashlib
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parent;O=B/'output';E=O/'review';E.mkdir(exist_ok=True);T=json.loads((B/'timeline.json').read_text());movie=O/'why-your-evenings-keep-disappearing.mp4';font=ImageFont.truetype(str(B/'fonts/ArchivoBlack.ttf'),16)
records=[]
for s in T['shots']:
 t=s['start']+(s['end']-s['start'])*.58;p=E/f"shot-{s['id']}.jpg"
 subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(movie),'-frames:v','1','-q:v','2',str(p)],check=True)
 records.append({'shot':s['id'],'setting':s['setting'],'action':s['action'],'time':round(t,3),'path':str(p.relative_to(B))})
for page in range(2):
 board=Image.new('RGB',(1280,10*205),'#25353a');g=ImageDraw.Draw(board)
 for k,r in enumerate(records[page*40:page*40+40]):
  im=Image.open(B/r['path']);im.thumbnail((320,180));x=k%4*320;y=k//4*205;board.paste(im,(x,y));g.text((x+7,y+183),r['shot']+' '+r['action'],font=font,fill='white')
 board.save(O/f'encoded-storyboard-{page+1}.jpg',quality=93)
detail_specs=[('01-02',.96,'landed-walk'),('02-04',.58,'shoe-contact'),('02-06',.50,'pour-contact'),('04-09',.6,'brush-contact'),('05-03',.32,'guitar-acquire'),('05-03',.55,'guitar-lift'),('05-04',.58,'guitar-play'),('06-02',.72,'phone-placement'),('06-02',.76,'phone-release'),('07-06',.58,'friend-greeting'),('07-07',.96,'two-landed-walkers'),('08-10',.75,'ending')]
for sid,q,name in detail_specs:
 s=next(s for s in T['shots'] if s['id']==sid);t=s['start']+(s['end']-s['start'])*q;p=E/f'detail-{name}.png'
 subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(movie),'-frames:v','1',str(p)],check=True);records.append({'shot':sid,'time':round(t,3),'detail':name,'path':str(p.relative_to(B))})
s=next(s for s in T['shots'] if s['id']=='05-03')
subprocess.run(['ffmpeg','-v','error','-y','-ss',str(s['start']),'-i',str(movie),'-t','24','-c:v','libx264','-crf','20','-preset','fast','-c:a','aac','-b:a','128k','-movflags','+faststart',str(O/'movement-preview.mp4')],check=True)
(B/'review-evidence.json').write_text(json.dumps({'final_movie_sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'source':'Actual final MP4 decoded with FFmpeg','frames':records,'limits':'Decoded frames and excerpts are inspection artifacts; no independent reviewer or real-time agent AV listening is inferred.'},indent=2))
print('Decoded all 80 shots, native contact/stop details and final-derived movement excerpt.',flush=True)
