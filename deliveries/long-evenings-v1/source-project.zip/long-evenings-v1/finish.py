"""Fingerprint source, verify every chapter/chain, master audio and export MP4."""
from pathlib import Path
import json,subprocess,re,hashlib,math
import numpy as np
import film
B=Path(__file__).resolve().parent;O=B/'output';T=film.T;FPS=30;D=T['duration'];FP=film.fingerprint()
def run(args):return subprocess.run(args,check=True,capture_output=True)
def measure(p):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(p),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'])
 return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
reports=[];rows=[];count=0
for i in range(1,9):
 d=json.loads((O/f'chapter-{i:02d}-motion.json').read_text());assert d['fingerprint']==FP,('stale chapter',i);assert d['first_frame']==count,(i,d['first_frame'],count);count=d['last_frame_exclusive'];reports.append(d);rows.extend(d['actor_frames'])
assert count==round(D*FPS),(count,D*FPS)
bone=max(r['bone_error'] for r in rows);assert bone<1e-8
contacts={};stance=[];walk_stops=[];previous={};coverage={s['id']:set() for s in T['shots']}
for r in sorted(rows,key=lambda r:(r['t'],r['who'])):
 coverage[r['shot']].add(r['who']);assert set(r['arms'])==set(r['legs'])=={'left','right'}
 for name,err in r['contacts'].items():contacts[name]=max(contacts.get(name,0),err)
 old=previous.get(r['who']);previous[r['who']]=r
 if old is not None and r['shot']==old['shot'] and r['t']-old['t']<.04:
  for side in ['left','right']:
   if old['legs'][side]['planted'] and r['legs'][side]['planted']:stance.append(float(np.linalg.norm(np.asarray(old['legs'][side]['joints'][-1])-r['legs'][side]['joints'][-1])))
 s=next(s for s in T['shots'] if s['id']==r['shot']);q=(r['t']-s['start'])/(s['end']-s['start'])
 if s['action'] in ['walk','walk_pair','arrive'] and q>=.90:
  assert all(r['legs'][side]['planted'] for side in ['left','right']),(r['shot'],r['who'],'unlanded stop')
  walk_stops.append(r['t'])
assert max(stance,default=0)<1e-5,max(stance)
for name,err in contacts.items():assert err<(13.001 if name=='guitar_strings' else 1e-5),(name,err)
for s in T['shots']:
 expected=set() if s['action'] in ['clock','guitar_stand'] else ({'hero','friend'} if s['action'] in ['meet','walk_pair'] else {'hero'})
 assert coverage[s['id']]==expected,(s['id'],coverage[s['id']],expected)
try:film.rig.ik([0,0],[400,0],[80,80],1,'injected unreachable target')
except ValueError:negative=True
else:raise AssertionError('Invalid reach was accepted')
print('All chapters fresh; all chains/contacts/stops verified.',flush=True)
concat=O/'concat.txt';concat.write_text(''.join("file '"+str((O/f'chapter-{i:02d}-picture.mp4').resolve())+"'\n" for i in range(1,9)))
pre=measure(B/'audio/mix-unmastered.wav');flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
master=B/'audio/mix-mastered.wav';run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix-unmastered.wav'),'-af',flt,'-ar','48000','-ac','2',str(master)])
movie=O/'why-your-evenings-keep-disappearing.mp4'
run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(master),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-t',str(D),'-movflags','+faststart',str(movie)])
probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)]).stdout)
run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-']);post=measure(movie)
v=next(x for x in probe['streams'] if x['codec_type']=='video');a=next(x for x in probe['streams'] if x['codec_type']=='audio')
assert [v['width'],v['height'],v['r_frame_rate'],v['codec_name'],v['pix_fmt']]==[1280,720,'30/1','h264','yuv420p']
assert int(v['nb_frames'])==round(D*FPS)
assert abs(float(v['duration'])-float(a['duration']))<.08
assert movie.stat().st_size<95*1024**2,'GitHub branch delivery file must remain below 100 MiB'
assert float(post['input_tp'])<=-.5,post
ledger=json.loads((B/'audio/voice-ledger.json').read_text())
qa={'title':"Why Your Evenings Keep Disappearing",'duration_seconds':float(probe['format']['duration']),'dimensions':[1280,720],'native_design':'16:9, separately staged landscape, not a crop/stretch of the Short','fps':30,'frames':int(v['nb_frames']),'full_decode':'pass','audio_video_duration_difference_seconds':abs(float(v['duration'])-float(a['duration'])),'file_bytes':movie.stat().st_size,'sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'source_fingerprint':FP,'narrative':{'chapters':8,'shots':len(T['shots']),'settings':sorted(set(s['setting'] for s in T['shots'])),'action_families':len(set(s['action'] for s in T['shots'])),'script_words':len(json.loads((B/'words.json').read_text())['words']),'copied_or_looped_short_footage':False},'motion':{'renderer':'Project-local articulated extension, not a modified/certified installed B6 runtime','actor_frames_checked':len(rows),'four_chains_per_actor_frame':True,'maximum_fixed_bone_error_pixels':bone,'maximum_consecutive_planted_foot_drift_pixels':max(stance,default=0),'contact_max_errors_pixels':contacts,'landed_walk_stop_actor_frames_checked':len(walk_stops),'unreachable_target_negative_test':negative,'cast_coverage':{k:sorted(v) for k,v in coverage.items()}},'captions':{'language':'English','cues':len(film.CUES),'single_line':True,'word_coverage':'Exact normalized script coverage','alignment':'Offline acoustic PocketSphinx chapter words, actual audio offsets','profile':T['caption_profile']},'sound':{'narrator':'OpenAI tts-1 / alloy','native_voice_seconds':sum(c['duration'] for c in ledger['chapters']),'speed':1,'new_tts_requests':8,'estimated_tts_usd':ledger['estimated_usd'],'billing_verified':False,'new_paid_transcription_requests':0,'new_image_API_requests':0,'music_and_Foley':'Original local synthesis; footsteps tied to rendered contacts','loudness':post},'review':{'technical_checks':'Complete decode, frame/stream checks, per-frame drawn-chain geometry, authored contact points, every cast/shot and landed stops','author_visual_review':'Native source action stills and separately decoded final frames, recorded in visual-review.md','independent_creative_review':'not available','real_time_audiovisual_listening_by_agent':'not performed; automated measurements are not listening approval','installed_B6_35_subcheck_reference_acceptance':'not claimed for the project-local action extension','user_approval':'pending actual user viewing'},'YouTube_upload':False}
(O/'QA.json').write_text(json.dumps(qa,indent=2)+'\n');(O/'probe.json').write_text(json.dumps(probe,indent=2))
print(json.dumps({'duration':qa['duration_seconds'],'frames':qa['frames'],'size_MB':round(movie.stat().st_size/1e6,2),'LUFS':post['input_i'],'true_peak':post['input_tp'],'actor_frames':len(rows),'bone_error':bone,'planted_foot_drift':max(stance),'caption_cues':len(film.CUES)},indent=2),flush=True)
