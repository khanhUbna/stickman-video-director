"""Original continuous long-form score and event-linked Foley. No external media."""
from pathlib import Path
import wave,json,math,sys
import numpy as np
B=Path(__file__).resolve().parent;T=json.loads((B/'timeline.json').read_text());SR=48000;N=round(T['duration']*SR)
def read(p):
 with wave.open(str(B/p)) as w:
  assert w.getframerate()==SR and w.getnchannels()==1
  return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
def write(p,a):
 with wave.open(str(B/p),'wb') as w:
  w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(a,-.98,.98)*32767).astype('<i2').tobytes())
def add(bus,at,note,gain=1):
 k=round(at*SR);nn=min(len(note),len(bus)-k)
 if k>=0 and nn>0:bus[k:k+nn]+=note[:nn]*gain
def pluck(f,length=.85):
 t=np.arange(round(length*SR),dtype=np.float32)/SR
 return (np.sin(2*np.pi*f*t)+.22*np.sin(4*np.pi*f*t)+.06*np.sin(6*np.pi*f*t))*np.exp(-t*5)*np.minimum(1,t/.007)
def base():
 if (B/'audio/voice-assembled.wav').exists() and (B/'audio/music-original.wav').exists() and (B/'audio/room-original.wav').exists():print('Reuse original assembled voice/music/room',flush=True);return
 voice=np.zeros(N,dtype=np.float32)
 for c in T['chapters']:add(voice,c['start'],read(c['path']))
 write('audio/voice-assembled.wav',voice);del voice
 music=np.zeros(N,dtype=np.float32);rng=np.random.default_rng(744912)
 progressions=[[[57,60,64],[53,57,60],[55,59,62],[52,55,59]],[[60,64,67],[57,60,64],[53,57,60],[55,59,62]]]
 for ci,c in enumerate(T['chapters']):
  stop=T['chapters'][ci+1]['start'] if ci+1<len(T['chapters']) else T['duration'];beat=60/(74+ci%3*2);progression=progressions[0 if ci<4 else 1]
  for i,at in enumerate(np.arange(c['start']+.02,stop-.2,beat/2)):
   chord=progression[int((at-c['start'])/(beat*4))%4];m=chord[[0,2,1,2,0,1,2,1][i%8]]+(12 if i%16 in [7,15] else 0)
   gain=.015*(.85 if ci in [2,6] else 1)*(1+.08*math.sin(i*.71));add(music,at,pluck(440*2**((m-69)/12)),gain)
  for i,at in enumerate(np.arange(c['start']+.02,stop-.3,beat*4)):
   m=progression[i%4][0]-12;add(music,at,pluck(440*2**((m-69)/12),1.5),.018)
 fade=np.minimum(1,np.arange(N)/(SR*.3))*np.minimum(1,(N-1-np.arange(N))/(SR*1.3));music*=fade.astype(np.float32)
 write('audio/music-original.wav',music);del music
 # Stationary, quiet room tone with a seed; generated locally, not downloaded.
 room=rng.normal(0,.0016,N).astype(np.float32);room=np.convolve(room,np.ones(24,dtype=np.float32)/24,mode='same');room*=fade.astype(np.float32);write('audio/room-original.wav',room)
 print('Assembled native-rate narration and original continuous score/room.',flush=True)
def finish():
 base();fx=np.zeros(N,dtype=np.float32);rng=np.random.default_rng(426925);events=[]
 def event(at,kind,amp=.04,d=.1):
  t=np.arange(round(d*SR),dtype=np.float32)/SR;noise=rng.normal(0,1,len(t)).astype(np.float32);noise=np.convolve(noise,np.ones(9,dtype=np.float32)/9,mode='same')
  f=115 if kind in ['step','seat','bag','laptop_close'] else 670
  sig=(noise*.35+.45*np.sin(2*np.pi*f*t))*np.exp(-t*(35 if kind=='step' else 55))*np.minimum(1,t/.003)
  add(fx,at,sig,amp);events.append({'time':round(at,4),'kind':kind,'source':'Original local additive/filtered-noise synthesis'})
 def rustle(at,kind,d=.3,amp=.017):
  t=np.arange(round(d*SR),dtype=np.float32)/SR;noise=rng.normal(0,1,len(t)).astype(np.float32);noise=np.convolve(noise,np.ones(5,dtype=np.float32)/5,mode='same')
  add(fx,at,noise*np.sin(np.pi*t/d)**2,amp);events.append({'time':round(at,4),'kind':kind,'source':'Original seeded filtered-noise synthesis'})
 rows=[]
 for ci in range(1,9):
  p=B/f'output/chapter-{ci:02d}-motion.json'
  if not p.exists():raise RuntimeError(f'Actual motion trace missing for chapter {ci}; do not synthesize placeholder footsteps')
  rows.extend(json.loads(p.read_text())['actor_frames'])
 prior={}
 for row in sorted(rows,key=lambda r:r['t']):
  who=row['who'];old=prior.get(who);prior[who]=row
  if old is None or old['shot']!=row['shot'] or row['t']-old['t']>.04:continue
  act=next(s['action'] for s in T['shots'] if s['id']==row['shot'])
  if act not in ['walk','arrive','walk_pair']:continue
  for side in ['left','right']:
   if not old['legs'][side]['planted'] and row['legs'][side]['planted']:event(row['t'],'step',.045 if who=='hero' else .028)
 for s in T['shots']:
  a=s['action'];start=s['start'];length=s['end']-start;at=lambda q:start+length*q
  if a=='phone_place':event(at(.72),'phone_on_wood',.055)
  elif a=='phone_pickup':event(at(.16),'phone_pickup',.025)
  elif a in ['sit_phone','sit_book']:event(at(.60),'seat',.035)
  elif a=='bag':rustle(at(.3),'bag_fabric',.35,.025)
  elif a=='close_laptop':event(at(.78),'laptop_close',.05)
  elif a in ['book','sit_book']:rustle(at(.49),'page_turn',.35,.022)
  elif a=='notebook':rustle(at(.4),'pen_on_paper',length*.30,.012)
  elif a=='shoes':rustle(at(.5),'laces',.5,.024)
  elif a=='fold':rustle(at(.45),'fold_fabric',.55,.024)
  elif a=='guitar_case':event(at(.23),'case_latch',.04);rustle(at(.50),'case_open',.4,.015)
  elif a=='guitar_pickup':event(at(.32),'instrument_pickup',.028)
  elif a=='pour':
   t=np.arange(round(length*.43*SR),dtype=np.float32)/SR;v=rng.normal(0,1,len(t)).astype(np.float32);v=np.convolve(v,np.ones(13,dtype=np.float32)/13,mode='same');add(fx,at(.27),v*np.sin(np.pi*np.arange(len(t))/len(t))*.026);events.append({'time':at(.27),'kind':'water_pour','source':'Original filtered-noise synthesis at actual tilted-spout interval'})
  elif a in ['wash','wipe','cook','paint']:
   for tt in np.arange(at(.22),at(.80),.8):rustle(tt,a+'_contact',.25,.012)
  elif a=='dishes':event(at(.80),'plate_on_counter',.035)
  if a=='guitar':
   for j,tt in enumerate(np.arange(start+.02,s['end']-.18,.78)):
    chord=[52,57,60,64,69] if j%8<4 else [48,55,60,64,67]
    if s['chapter']==8 and j==2:chord[2]=61
    for k,m in enumerate(chord):add(fx,tt+k*.011,pluck(440*2**((m-69)/12),.95),.017)
    events.append({'time':round(tt,4),'kind':'guitar_string_stroke','source':'Original synthesized acoustic string gesture, tied to visible stroke period'})
 # Voice remains center and original-rate; backing is deliberately subordinate.
 voice=read('audio/voice-assembled.wav');music=read('audio/music-original.wav');room=read('audio/room-original.wav')
 for s in T['shots']:
  if s['action']=='guitar':music[round(s['start']*SR):round(s['end']*SR)]*=.45
 fade=np.minimum(1,np.arange(N)/(SR*.12))*np.minimum(1,(N-1-np.arange(N))/(SR*.9));fx*=fade.astype(np.float32)
 write('audio/foley-original.wav',fx);mix=voice*.94+music+room+fx;write('audio/mix-unmastered.wav',mix)
 (B/'audio/sound-events.json').write_text(json.dumps(events,indent=2));print('Original full-film Foley and voice-led mix saved; events',len(events),flush=True)
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='base':base()
 else:finish()
