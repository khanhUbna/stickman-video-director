"""Native landscape long-form film: original scene ledger, articulated acting."""
from pathlib import Path
from functools import lru_cache
import bisect,json,math,sys,subprocess,os,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import rig,props,sets
from rig import actor,rotate,ease,mix,ip,line,poly
from caption_renderer import CaptionRenderer
B=Path(__file__).resolve().parent;T=json.loads((B/'timeline.json').read_text());SHOTS=T['shots'];STARTS=[s['start'] for s in SHOTS];FPS=30;D=T['duration'];CUES=json.loads((B/'captions.json').read_text());CSTARTS=[c['start'] for c in CUES]
CR=CaptionRenderer(B,'16:9',1280,720,T['caption_profile']);FONT=str(B/'fonts/ArchivoBlack.ttf')
def at(t):return SHOTS[max(0,min(len(SHOTS)-1,bisect.bisect_right(STARTS,t)-1))]
def tex(g,xy,text,n=20,fill='#43564d'):g.text(xy,text,font=ImageFont.truetype(FONT,n),fill=fill)
def smoothpulse(q):return math.sin(math.pi*max(0,min(1,q)))
def onset(q,a,b):return ease((q-a)/(b-a))
def actual_table(im,x,y=430,w=205):sets.table(ImageDraw.Draw(im),x,y,w)
def target(hip,side,angle=0):return np.asarray(hip)+rotate([-68 if side=='left' else 72,-6],angle)
def physical_clock(im,q,late=True):
 g=ImageDraw.Draw(im);x,y=940,167;r=54;g.ellipse((x-r,y-r,x+r,y+r),fill='#efe4cb',outline='#7b624e',width=4)
 hour=(18+5.9*ease(q)) if late else 18.5
 for a,l,w in [(hour/12*2*math.pi,26,4),(hour%1*2*math.pi,39,2)]:line(g,[(x,y),(x+math.sin(a)*l,y-math.cos(a)*l)],'#594f46',w)
 for k in range(12):
  a=k/12*2*math.pi;xx=x+math.sin(a)*44;yy=y-math.cos(a)*44;g.ellipse((xx-1.5,yy-1.5,xx+1.5,yy+1.5),fill='#7b624e')
def stage(t,s,collect=True):
 scene=s['setting'];act=s['action'];elapsed=t-s['start'];span=s['end']-s['start'];q=min(.999999,max(0,elapsed/span));night=scene in ['living','hobby','kitchen','bedroom'] and (s['chapter'] in [1,3,4,7] or act in ['regret','lamp','clock'])
 im=sets.background(scene,night).copy();sets.moving_world(im,scene,elapsed,night);g=ImageDraw.Draw(im)
 x=720. if scene=='kitchen' else 650.;hip=np.array([x,418.]);view='front';angle=0.;head=0.;expr='normal';wr={};feet=None;walk=None;poles={};held={};pd=None;post=[];rows=[]
 if (s['chapter']==1 and act in ['sit_phone','phone_place','email','regret']) or (s['chapter']==3 and act in ['email','cook','phone_pickup']) or (s['chapter']==4 and act in ['wash','dishes','fold','wipe']):expr='worried'
 if scene in ['living','bedroom']:physical_clock(im,q,act=='clock')
 if act in ['clock','guitar_stand']:
  if act=='clock':
   # A physical object insert: fast clock hands against an evening room, then
   # a readable landing; no actor is claimed in the inventory for this shot.
   im=im.filter(ImageFilter.GaussianBlur(2));g=ImageDraw.Draw(im);cx,cy=635,275;r=185
   g.ellipse((cx-r,cy-r,cx+r,cy+r),fill='#eee1c4',outline='#795e49',width=10)
   h=18+5.9*onset(q,.10,.75)
   for a,l,w in [(h/12*2*math.pi,94,10),(h%1*2*math.pi,144,6)]:line(g,[(cx,cy),(cx+math.sin(a)*l,cy-math.cos(a)*l)],'#564c43',w)
   for k in range(12):
    a=k/12*2*math.pi;xx=cx+math.sin(a)*159;yy=cy-math.cos(a)*159;line(g,[(xx,yy),(xx+math.sin(a)*8,yy-math.cos(a)*8)],'#795e49',4)
   props.phone(im,[920,421],angle=-9,scroll=q*5)
  else:
   props.stand(im,740,580);props.guitar(im,[740,475],50,.50)
   props.book(im,[940,434],opening=.15);g=ImageDraw.Draw(im);tex(g,(1080,110),'',20)
  return im,rows
 if act in ['walk','arrive','walk_pair']:
  direction=-1 if s['chapter'] in [3,7] and act=='walk' else 1
  start=930. if direction<0 else 270.;end=390. if direction<0 else 850.
  # End on a complete stride, so both feet are planted during the final hold.
  distance=math.floor(abs(end-start)/125)*125
  travel=distance*onset(q,.06,.88);x=start+direction*travel;view='three_quarter' if direction>0 else 'front'
  hip=np.array([x,rig.walking_hip_y(x,travel,direction,'hero',view)]);walk=(travel,direction)
  swing=math.sin(travel/125*2*math.pi)
  wr={'left':hip+[-70+17*swing,-5+5*swing],'right':hip+[73-17*swing,-5-5*swing]};head=2
  if act=='arrive':
   # The carried bag is tied to the actual right-hand handle.
   wr['right']=hip+[70,-4];bc=wr['right']+[0,45];pd=lambda m,bc=bc:props.bag(m,bc);held['bag_handle']={'arm':'right','point':bc+[0,-45]}
  if act=='walk_pair':
   other=hip+[-220,0];other[1]=rig.walking_hip_y(other[0],travel+62.5,direction,'friend',view);swing2=math.sin((travel+62.5)/125*2*math.pi)
   rows.append(actor(im,other,view=view,who='friend',walk=(travel+62.5,direction),wrists={'left':other+[-70+15*swing2,-7],'right':other+[72-15*swing2,-7]},head_angle=2))
 elif act in ['sit_phone','scroll','regret','stand','sit_book']:
  seat=onset(q,.12,.62) if act in ['sit_phone','sit_book'] else (1-onset(q,.15,.75) if act=='stand' else 1)
  hip=np.array([650-40*seat,418+62*seat]);angle=10*smoothpulse(onset(q,.12,.62)) if act in ['sit_phone','sit_book'] else 3
  feet={'left':[625,590],'right':[678,590]};head=5
  if act=='regret':expr='worried';head=3-9*onset(q,.25,.65)
  if act=='sit_book':
   bc=hip+[0,-33];wr={'left':bc+[-48,17],'right':bc+[48,17]};pd=lambda m,bc=bc:props.book(m,bc,1,onset(q,.35,.75));held={'book_left':{'arm':'left','point':bc+[-48,17]},'book_right':{'arm':'right','point':bc+[48,17]}}
  else:
   pc=hip+[57,-80];wr['right']=pc+rotate([12,19],-7);wr['left']=target(hip,'left',angle)
   if act=='scroll':wr['left']=pc+[-16,5-8*math.sin(elapsed*4.1)]
   pd=lambda m,pc=pc:props.phone(m,pc,-7,scroll=elapsed*.5);held['phone_grip']={'arm':'right','point':pc+rotate([12,19],-7)}
 elif act in ['phone_pickup','phone_place']:
  actual_table(im,x+80,430,185);u=onset(q,.15,.72)
  if act=='phone_pickup':
   pc=mix([x+130,425],[x+65,338],u);angle=8*(1-u);head=4
   pa=88-96*u;wr['right']=pc+rotate([12,19],pa);wr['left']=target(hip,'left',angle);pd=lambda m,pc=pc,pa=pa:props.phone(m,pc,pa,scroll=elapsed*.25);held['phone_grip']={'arm':'right','point':pc+rotate([12,19],pa)}
  else:
   angle=8*u;hip[1]+=8*u;pc=mix([x+65,338],[x+130,425],u);grip=pc+rotate([12,19],88*u)
   wr['right']=grip if q<.74 else mix([x+130,425]+rotate([12,19],88),[x+76,410],onset(q,.74,.98))
   wr['left']=target(hip,'left',angle)
   pd=lambda m,pc=pc,u=u:props.phone(m,pc,88*u,face=u<.8)
   if q<.74:held['phone_grip']={'arm':'right','point':grip}
  feet={'left':[x-25,590],'right':[x+28,590]}
 elif act=='bag':
  actual_table(im,x+55,480,160);u=onset(q,.12,.60);angle=4*smoothpulse(u)
  handle=mix([x+85,416],[x+73,362],u);wr['right']=handle;wr['left']=target(hip,'left',angle);bc=handle+[0,45]
  pd=lambda m,bc=bc:props.bag(m,bc,-3);held['bag_handle']={'arm':'right','point':bc+[0,-45]};head=3
 elif act in ['email','notebook','close_laptop']:
  actual_table(im,x-20,430,380)
  if act=='email':
   g=ImageDraw.Draw(im);poly(g,[(x+3,414),(x+150,414),(x+164,430),(x-4,430)],'#a4b4a9','#5a7064',2)
   for yy in [417,423]:
    for xx in range(int(x+8),int(x+145),14):g.rectangle((xx,yy,xx+8,yy+3),fill='#dce2cf')
   pulse=math.sin(elapsed*12);wr={'left':[x+5,410+2*pulse],'right':[x+92,411-2*pulse]};head=5
   g.rounded_rectangle((835,255,1048,335),5,fill='#e8e8d6');tex(g,(852,273),'One more reply...',18);tex(g,(852,303),'Draft saved' if q>.65 else 'Typing',17,'#688174')
  elif act=='notebook':
   u=onset(q,.18,.80);props.paper(im,[x+65,424],u);wr={'left':[x+3,414],'right':[x+48+45*u,405]};head=7;post.append(('pen',wr['right'],[wr['right'][0]+6,424]))
  else:
   u=onset(q,.15,.78);hip[0]+=14*u;hip[1]+=5*u;angle=8*u;feet={'left':[x-25,590],'right':[x+28,590]}
   lidtop=274+136*u;g=ImageDraw.Draw(im);poly(g,[(x+90,lidtop),(x+277,lidtop),(x+277,414),(x+90,414)],'#879c91','#4e665a',3);poly(g,[(x+83,414),(x+284,414),(x+300,432),(x+73,432)],'#a7b8a6','#4e665a',3)
   wr['right']=[x+120,lidtop+4];wr['left']=target(hip,'left',angle);head=4
 elif act in ['pour','cook','wash','wipe','dishes','fold']:
  u=onset(q,.15,.8);angle=3*smoothpulse(u);head=5;wr['left']=target(hip,'left',angle)
  if act=='pour':
   mc=hip+[-28,-25];tilt=-24*math.sin(math.pi*u);handle=hip+[72,-73];kc=handle-rotate([35,5],tilt)
   wr={'left':mc+[23,0],'right':handle};pd=lambda m,mc=mc,kc=kc,tilt=tilt:(props.mug(m,mc),props.kettle(m,kc,tilt))
   held={'mug_handle':{'arm':'left','point':mc+[23,0]},'kettle_handle':{'arm':'right','point':kc+rotate([35,5],tilt)}}
   if .27<q<.7:post.append(('water',kc+rotate([-43,-7],tilt),mc+[0,-24]))
  elif act=='cook':
   center=hip+[90,-10];props.pot(im,center);phase=elapsed*3.8;wr['right']=center+[9*math.cos(phase),-55+3*math.sin(phase)];post.append(('spoon',wr['right'],center+[8*math.cos(phase),-3]))
   gg=ImageDraw.Draw(im)
   for k in range(3):
    v=(elapsed*.35+k*.3)%1;xx=center[0]-20+k*19+3*math.sin(v*4);yy=center[1]-28-36*v
    gg.arc((xx-5,yy-9,xx+5,yy+9),90,270,fill=(229,222,200,round(125*(1-v))),width=2)
  elif act=='wash':
   center=hip+[16,-15];wr['left']=center+[-24,0];wr['right']=center+[19*math.sin(elapsed*3.4),-5];pd=lambda m,center=center,u=u:props.plate(m,center,round(3*(1-u)));post.append(('sponge',wr['right'],None));held['plate_support']={'arm':'left','point':center+[-24,0]}
  elif act=='wipe':
   hip[1]+=12;actual_table(im,x+55,440,220);xx=x+90+35*math.sin(elapsed*3);wr['right']=[xx,430];post.append(('cloth',wr['right'],None))
   g=ImageDraw.Draw(im)
   for i in range(3):
    if q<.3+i*.17:g.ellipse((x+95+i*19,425,x+100+i*19,428),fill='#8e7251')
  elif act=='dishes':
   actual_table(im,x+55,440,240);center=mix([x+15,385],[x+100,425],u);wr['right']=center+[20,-2];wr['left']=target(hip,'left',angle)
   for j in range(3):props.plate(im,[x+135,431-j*4])
   pd=lambda m,center=center:props.plate(m,center);held['plate_grip']={'arm':'right','point':center+[20,-2]}
  else:
   actual_table(im,x-15,440,315);wr={'left':[x-12,410],'right':[x+90-50*u,424]};g=ImageDraw.Draw(im)
   poly(g,[(x-15,415),(x+105-55*u,415),(x+112-55*u,439),(x-15,439)],'#a0b2b1','#57716c',2)
   line(g,[(x+45,415),(x+45,439)],'#7d9390',2)
 elif act in ['book','paint']:
  if act=='book':
   bc=hip+[0,-38];wr={'left':bc+[-48,17],'right':bc+[48,17]};pd=lambda m,bc=bc:props.book(m,bc,1,onset(q,.3,.65));head=6
   held={'book_left':{'arm':'left','point':bc+[-48,17]},'book_right':{'arm':'right','point':bc+[48,17]}}
  else:
   g=ImageDraw.Draw(im);cx=x+205;line(g,[(cx-65,580),(cx,230),(cx+65,580)],'#7b6348',6)
   g.rectangle((cx-70,220,cx+72,398),fill='#efe4c9',outline='#927a57',width=4)
   u=onset(q,.12,.85);pts=[np.array([cx-46,252]),np.array([cx-24,285]),np.array([cx+21,362])]
   end=mix(pts[0],pts[1],u*2) if u<.5 else mix(pts[1],pts[2],(u-.5)*2);wr['right']=end+[-68,35];wr['left']=hip+[-48,-23]
   g.ellipse((x-66,385,x-20,409),fill='#b9a27d',outline='#7f6b4c',width=2)
   if u>0:line(g,[pts[0],end] if u<.5 else [pts[0],pts[1],end],'#7f9c89',10)
   post.append(('brush',wr['right'],end));head=4
 elif act in ['guitar','guitar_pickup','guitar_case']:
  props.stand(im,x+90,580);poles['left']=-1
  if act=='guitar_case':
   gc=np.array([x+173,474]);props.guitar(im,gc,50,.46);u=onset(q,.20,.8);angle=4*u;grip=np.array([x+105-45*u,405.]);wr['right']=grip;wr['left']=target(hip,'left',angle)
   g=ImageDraw.Draw(im);poly(g,[(x+180,228),(grip[0]+4,240),(grip[0]+4,562),(x+180,570)],'#927b5c','#4b4e42',4);g.ellipse((grip[0]-7,398,grip[0]+7,413),fill='#c1af82',outline='#574f3e',width=2);head=3
  else:
   if act=='guitar_pickup':
    acquire=onset(q,.08,.32);lift=onset(q,.32,.9);hip[1]=418+40*acquire*(1-lift);angle=15*acquire*(1-onset(q,.7,.96));head=-5*(1-lift)
    gc=mix([x+90,473],[x+20,388],lift);ga=50*(1-lift);gs=.45+.17*lift
   else:
    acquire=lift=1;pulse=math.sin(elapsed*2*math.pi/.78);hip[0]+=2*pulse;hip[1]-=max(0,pulse);feet={'left':[x-25,590],'right':[x+28,590]};angle=.8*pulse;head=2*pulse;gc=hip+[20,-30];ga=pulse;gs=.62
   grips={side:np.asarray(gc)+rotate(np.asarray(p)*gs,ga) for side,p in {'left':[-185,-157],'right':[0,-10]}.items()}
   for side in ['left','right']:wr[side]=mix(target(hip,side,angle),grips[side],acquire)
   if act=='guitar':wr['right']+=rotate([0,13*math.sin(elapsed*2*math.pi/.78)],ga)
   pd=lambda m,gc=gc,ga=ga,gs=gs:props.guitar(m,gc,ga,gs)
   if acquire>=1-1e-9:
    held={'guitar_fret':{'arm':'left','point':grips['left']},'guitar_strings':{'arm':'right','point':grips['right'],'tolerance':13.0001}}
 elif act=='shoes':
  # Supported bend: hips lower, torso rotates as one rigid painted volume,
  # hands meet a real shoe while both soles remain fixed in world space.
  u=smoothpulse(onset(q,.08,.9));hip=np.array([x,418+107*u]);angle=59*u;head=-8*u
  feet={'left':[x-25,590],'right':[x+59,590]};sh=np.array([x+59,576.]);props.shoe(im,sh)
  wr['left']=target(hip,'left',angle);normal=target(hip,'right',angle);wr['right']=mix(normal,sh+[0,-10],onset(u,.8,.99));head-=2
  post.append(('laces',sh,q))
 elif act=='stretch':
  u=smoothpulse(onset(q,.12,.9));wr['left']=mix(target(hip,'left'),hip+[-135,-223],u);wr['right']=mix(target(hip,'right'),hip+[135,-223],u);head=-5*u;angle=-2*u
 elif act=='window':
  # A hand reaches the actual window-side curtain; the unused arm rests.
  x=440.;hip=np.array([x,418.]);u=onset(q,.15,.72);head=-3-3*u
  wr={'left':hip+[-68,-6],'right':mix(hip+[72,-6],hip+[-10,-104],u)}
  g=ImageDraw.Draw(im);edge=415+15*u;poly(g,[(edge,70),(470,70),(470,350),(edge,350)],'#ddcbab','#b19a7a',2)
 elif act=='call':
  x=620.;hip=np.array([x,418.]);u=onset(q,.1,.55);pc=mix(hip+[-65,-40],hip+[-115,-158],u)
  wr['left']=pc+rotate([0,20],8);wr['right']=target(hip,'right');pd=lambda m,pc=pc:props.phone(m,pc,8);head=-3;held['phone_grip']={'arm':'left','point':pc+rotate([0,20],8)}
 elif act=='meet':
  x=540.;hip=np.array([x,418.]);u=smoothpulse(onset(q,.15,.85));wr['right']=mix(target(hip,'right'),hip+[110,-150],u);head=2*u
  other=np.array([870.,418.]);rows.append(actor(im,other,who='friend',wrists={'left':mix(other+[-68,-6],other+[-110,-150],u),'right':other+[72,-6]},head_angle=-3*u))
 elif act=='lamp':
  g=ImageDraw.Draw(im);lamp=np.array([x+130,333.]);line(g,[(lamp[0],lamp[1]),(lamp[0],433)],'#846d50',5);poly(g,[(lamp[0]-32,lamp[1]-40),(lamp[0]+32,lamp[1]-40),(lamp[0]+45,lamp[1]+14),(lamp[0]-45,lamp[1]+14)],'#ead3a0' if q<.60 else '#b0a892','#917b58',3)
  u=smoothpulse(onset(q,.1,.9));wr['right']=mix(target(hip,'right'),lamp+[0,30],u);head=2
 else:raise ValueError('Unknown action '+act)
 if act not in ['walk','arrive','walk_pair'] and feet is None:feet={'left':[x-25,590],'right':[x+28,590]}
 rows.append(actor(im,hip,view,angle,head,expr,feet,wr,walk,'hero',poles,pd,held))
 # Material-specific foreground contacts follow the exact hand used by the rig.
 g=ImageDraw.Draw(im)
 for kind,a,b in post:
  if kind in ['pen','spoon','brush']:
   line(g,[a,b],'#6b604b',4)
   if kind=='brush':g.ellipse((b[0]-3,b[1]-3,b[0]+3,b[1]+3),fill='#7f9c89')
  elif kind=='water':line(g,[a,b],'#b4d3d7',3)
  elif kind in ['sponge','cloth']:
   g.rounded_rectangle((a[0]-12,a[1]-3,a[0]+12,a[1]+4),3,fill='#e1c471',outline='#a68a46',width=1)
  elif kind=='laces':
   phase=math.sin(b*8*math.pi);line(g,[a+[-8,-9],a+[0,-14-3*phase],a+[9,-8]],'#e3d8bd',2)
 return im,rows

def frame(t,caption=True,collect=True):
 s=at(t);im,rows=stage(t,s,collect)
 # Native landscape camera variations: purposeful action/detail reframes only.
 # Reframes are not counted as actor motion or claimed to be depth dollies.
 if s['action'] in ['notebook','wash','pour','paint']:
  q=(t-s['start'])/(s['end']-s['start']);z=.035*math.sin(math.pi*q);dx=round(1280*z/2);dy=round(720*z/2)
  if dx>0:im=im.crop((dx,dy,1280-dx,720-dy)).resize((1280,720),Image.Resampling.LANCZOS)
 # One restrained chapter label, no full-screen lecture cards.
 c=T['chapters'][s['chapter']-1]
 if c['start']<=t<c['start']+3:
  g=ImageDraw.Draw(im);g.rounded_rectangle((34,23,34+min(920,len(c['title'])*14+50),62),8,fill=(241,231,207,235));tex(g,(48,32),c['title'],22)
 if caption:
  i=bisect.bisect_right(CSTARTS,t)-1
  if i>=0 and t<CUES[i]['end']:
   if len(CR.cache)>7:CR.cache.clear()
   im=Image.alpha_composite(im,CR.raster(CUES[i]['text'])[0])
 return im.convert('RGB'),rows

def fingerprint():
 h=hashlib.sha256()
 paths=[B/n for n in ['film.py','rig.py','props.py','sets.py','timeline.json','captions.json','caption_renderer.py','fonts/ArchivoBlack.ttf','art/guitar.png']]+sorted((B/'characters').rglob('*.png'))+sorted((B/'characters').rglob('package.json'))
 for p in paths:h.update(str(p.relative_to(B)).encode());h.update(p.read_bytes())
 return h.hexdigest()
def render(ci):
 c=T['chapters'][ci-1];start=0 if ci==1 else c['start'];end=T['chapters'][ci]['start'] if ci<len(T['chapters']) else D
 # Global frame indices make chapter concatenation exact, without fractional gaps.
 first=round(start*FPS);last=round(end*FPS);pout=B/f'output/chapter-{ci:02d}-picture.mp4';report=B/f'output/chapter-{ci:02d}-motion.json';fp=fingerprint()
 if pout.exists() and report.exists() and json.loads(report.read_text()).get('fingerprint')==fp:
  print(f'Chapter {ci}: reuse matching picture/trace',flush=True);return str(pout)
 proc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','22','-maxrate','900k','-bufsize','1800k','-pix_fmt','yuv420p','-threads','1','-movflags','+faststart',str(pout)],stdin=subprocess.PIPE)
 records=[]
 try:
  for i in range(first,last):
   t=i/FPS;im,rows=frame(t,True,True);proc.stdin.write(im.tobytes())
   for r in rows:records.append({'t':round(t,6),'shot':at(t)['id'],**r})
   if (i-first)%450==0:print(f'Chapter {ci}: {i-first}/{last-first} frames',flush=True)
  proc.stdin.close();assert proc.wait()==0
 except BaseException:
  proc.stdin.close();proc.wait();raise
 report.write_text(json.dumps({'chapter':ci,'fingerprint':fp,'first_frame':first,'last_frame_exclusive':last,'frames':last-first,'actor_frames':records}));print(f'Chapter {ci}: picture and actual-chain trace saved',flush=True)
 return str(pout)
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='stills':
  for s in SHOTS:
   t=s['start']+(s['end']-s['start'])*.58
   try:im,_=frame(t,True,True);im.save(B/f"output/story-{s['id']}.jpg",quality=88)
   except Exception as e:print(s['id'],s['action'],str(e),flush=True)
  print('Story still sampling completed.',flush=True)
 elif len(sys.argv)>1 and sys.argv[1]=='scan':
  errors=[]
  for s in SHOTS:
   for q in [0,.08,.16,.25,.32,.45,.58,.70,.82,.92,.999]:
    t=s['start']+(s['end']-s['start'])*q
    try:frame(t,False,True)
    except Exception as e:errors.append((s['id'],s['action'],q,str(e)))
  (B/'output/preflight.json').write_text(json.dumps({'errors':errors,'samples':len(SHOTS)*11},indent=2));print(json.dumps(errors,indent=2),flush=True)
 else:render(int(sys.argv[1]))
