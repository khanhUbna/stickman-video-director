"""Original long-form narration and native landscape action ledger."""
from pathlib import Path
import json,re
B=Path(__file__).resolve().parent
# Every entry is one distinct narrative shot: setting, concrete action, exact VO.
CHAPTERS=[
('The evening that never arrives',[
('office','bag',"At three in the afternoon, you already know what you want tonight. Get home. Make dinner. Finally do something for yourself."),
('street','walk',"Maybe play the guitar. Maybe read the book you bought a month ago. Nothing impressive. Just an evening that feels like yours."),
('entry','arrive',"Then you get home, drop your bag, and reach for your phone. Five minutes before you start. You have earned that much."),
('living','sit_phone',"One clip becomes another. You check a message, then something else. When you finally look up, the room has gone dark."),
('living','clock',"There is still enough time to stay awake. Somehow, there is no longer enough time to begin the thing you wanted."),
('hobby','guitar_stand',"The guitar is exactly where you left it. The book is still closed. You feel tired, disappointed, and strangely cheated."),
('bedroom','phone_place',"All day, you were waiting for this. Now you are going to bed without feeling like you ever arrived."),
('office','email',"Tomorrow, you will probably make the same promise. Tonight will be different. But a promise is not much help against a familiar evening."),
('living','regret',"So what keeps happening between getting your time back and actually getting to live in it? It is worth looking closer."),
('entry','bag',"Because the answer may have less to do with laziness, and more to do with how your evening begins.")]),
('The easiest thing is not always the thing you wanted',[
('living','phone_pickup',"Look at the first choice waiting for you. Your phone is already there. It takes one hand and almost no preparation."),
('hobby','guitar_case',"The guitar asks for a few steps. Open the case. Tune the strings. Remember where you stopped. Maybe sound bad for a while."),
('living','book',"The book asks you to find your place and pay attention. A walk asks you to stand back up and put your shoes on."),
('entry','shoes',"After a demanding day, those small beginnings can feel surprisingly large. The easiest option gets a head start before you have chosen anything."),
('living','scroll',"And that easy option does not have a natural finish. There is always another clip, another reply, another thing you might have missed."),
('kitchen','pour',"Making tea ends with tea. Playing a song ends with a song. A feed can keep offering a next step without offering an ending."),
('living','clock',"That does not make every minute on your phone a mistake. Sometimes a funny video or a conversation is exactly what you need."),
('living','phone_place',"The question is whether you picked the activity, or whether it simply stayed in your hand long enough to become your evening."),
('hobby','guitar',"A useful comparison is not productive versus unproductive. It is whether you feel glad that this is how you spent the time."),
('living','stand',"But changing the phone habit alone may miss something important. Sometimes the workday is still following you around the room.")]),
('Your body came home before your attention did',[
('office','email',"You leave the building, but an unfinished conversation comes with you. So does the message you did not answer, and tomorrow's deadline."),
('street','walk',"On the way home, you rehearse what you should have said. At dinner, you remember one more thing you promised to send."),
('kitchen','cook',"Now there is a saucepan in front of you, but part of your attention is still sitting in a meeting that ended hours ago."),
('living','phone_pickup',"You check work for reassurance. A new message appears. You answer it, then notice another. The evening quietly opens a second shift."),
('entry','notebook',"If your job allows it, try giving tomorrow a place to wait. Before you finish work, write down what is still open."),
('office','notebook',"Then give the most important loose end a next step. Not finish the project. Something specific, like ask Alex for the missing numbers."),
('office','close_laptop',"You are not solving every problem tonight. You are leaving yourself a clear place to resume, instead of carrying the whole thing home."),
('entry','bag',"Put the note with your work things. Close the bag. Let that small physical ending mark the end you are trying to make."),
('living','window',"It will not erase every worried thought. If one returns, you can notice it without immediately turning it into another work session."),
('living','stretch',"Leaving work and feeling away from work are different experiences. Your evening needs room for the second one, too.")]),
('The trap of earning your evening',[
('kitchen','wash',"There is another way to lose the night without opening a feed. You decide you can relax as soon as everything else is finished."),
('kitchen','dishes',"First the dishes. Then the laundry. Then that shelf you keep meaning to sort. Each finished thing reveals another unfinished thing."),
('laundry','fold',"Some of those jobs are necessary. The problem is expecting your home to reach a perfect stopping point before you are allowed to have one."),
('living','book',"You finally sit down, open a book, and remember the counter. Now you are reading the same paragraph while arguing with yourself."),
('kitchen','wipe',"So you get up to clean it. The counter looks better. Your evening gets shorter. The feeling that you should be doing more stays."),
('entry','notebook',"Instead, decide what actually needs to happen tonight. One load of laundry may matter. Reorganizing every drawer can probably wait."),
('kitchen','cook',"This is not permission to ignore the people who depend on you. It is a way to separate a real responsibility from an endless improvement project."),
('living','sit_book',"Try leaving one harmless thing unfinished while you do something you enjoy. Not as a reward. As another legitimate part of being alive."),
('hobby','paint',"You do not need a perfect room to make something. You do not need an impressive result to enjoy making it."),
('living','regret',"But even when you stop demanding a perfect evening, you can still make it difficult to enter a good one.")]),
('Make the first movement smaller',[
('hobby','guitar_case',"Imagine that tomorrow you promise yourself an hour of guitar practice. By the time dinner ends, that hour sounds like another appointment."),
('hobby','guitar_stand',"Now imagine a different invitation. The guitar is out of its case. The song you like is ready. You only have to pick it up."),
('hobby','guitar_pickup',"The first movement is smaller, and it leads somewhere you already wanted to go. You have changed the beginning, not raised the stakes."),
('hobby','guitar',"Play one familiar song. Stop there if you want. An invitation stops feeling like an invitation when you secretly turn it into a test."),
('living','book',"For reading, put the book where you actually sit. For drawing, leave a page ready. For a walk, put the shoes by the door."),
('entry','shoes',"You are making a desired action easier to reach at the moment you are tired. You are not waiting to become a different person."),
('street','walk',"And choose something you honestly want. A hobby you think you should have can become another job wearing a more interesting name."),
('hobby','paint',"Maybe you want to paint badly. Maybe you want to cook slowly. Maybe you want to hear a friend's voice without doing anything else."),
('park','call',"The point is not to collect better habits. It is to give the evening a destination that means something to you."),
('living','phone_place',"Once that destination is clear, you can change the small things that keep sending you somewhere else.")]),
('A different first ten minutes',[
('entry','arrive',"Here is an experiment for your next ordinary evening. Before you get home, choose the first small thing you want to do."),
('entry','phone_place',"Give your phone a landing place that is not your hand. A shelf, a charger, a bag. Somewhere you can still reach it when needed."),
('kitchen','pour',"Then make a transition you can actually repeat. Pour some water. Change your clothes. Stand by the window. Let arriving be an event."),
('living','stretch',"You do not have to fill this moment with self improvement. You are simply putting a little space between the workday and whatever happens next."),
('hobby','guitar_pickup',"Now try the thing you chose. One song. A few pages. A short walk. Keep the beginning small enough to be believable tonight."),
('park','walk',"After a little while, you can decide again. Continue, change activities, or stop. The experiment is about choosing, not proving endurance."),
('living','sit_phone',"You might still choose a show or your phone afterward. That can be a perfectly good evening when it is the evening you meant to have."),
('living','phone_place',"If losing track of time bothers you, decide what stopping looks like before you begin. One episode gives you a clearer boundary than just a bit."),
('living','book',"Notice how you feel afterward. More settled? More connected? Still drained? Treat that as information about this particular night, not a grade."),
('bedroom','lamp',"Some evenings will need sleep more than they need another activity. Choosing an early night can be a real choice, too.")]),
('When the evening really is not yours',[
('street','walk',"There is a limit to all of this. Sometimes your free time disappears because there was very little free time to begin with."),
('kitchen','cook',"A late shift, a long commute, caring for someone, a second job. You cannot rearrange a phone and make those hours come back."),
('laundry','fold',"If that is your situation, advice about a perfect evening can sound like another person asking you to do more with less."),
('living','regret',"So lower the demand. The goal does not have to be a transformed life by Thursday. Start by noticing what is actually available."),
('kitchen','pour',"Maybe there are a few quiet minutes with a warm drink. Maybe there is one song while dinner cooks. Small does not mean imaginary."),
('park','meet',"And sometimes the useful change is shared. A conversation about dividing a task. Asking for help. Protecting a small pocket of time together."),
('park','walk_pair',"You do not have to turn every source of exhaustion into a personal failure. Your circumstances matter, and support matters."),
('entry','notebook',"If a change is possible, make it concrete. Which task can move? Who can share it? Which expectation could you stop carrying alone?"),
('living','window',"There may be no tidy answer tonight. You can be honest about that, without deciding you have failed at having a life."),
('bedroom','lamp',"Rest is not another competition. And a video cannot know the full weight of the day you just carried home.")]),
('The evening you actually remember',[
('office','close_laptop',"So tomorrow, do not promise yourself a completely new personality at six o'clock. Try making one clear ending to the workday."),
('entry','bag',"Leave a next step for the work that remains. Bring your body home, and give your attention a chance to catch up."),
('entry','phone_place',"Put the phone somewhere deliberate. Let one harmless chore wait. Make the first movement toward something you want easier to begin."),
('hobby','guitar_pickup',"Then do that small thing before your evening becomes a long conversation about what you might do later."),
('hobby','guitar',"You may play the wrong note. You may read three pages. You may walk around one block and decide that is enough."),
('park','walk',"None of that has to become a routine worth showing anyone. It only has to be a part of the day you were present for."),
('living','sit_book',"A good evening is not always busy, and it does not always leave you energized. Sometimes it simply feels like you were there."),
('living','clock',"The clock will keep moving either way. The difference is whether you only notice the time when it is nearly gone."),
('bedroom','lamp',"Tonight, before you pick something up out of habit, pause for a moment. Ask yourself what you actually want this part of your life to feel like."),
('living','window',"You spent the day waiting to get home. Give yourself one moment that lets you feel you have finally arrived.")])]

def build():
 chapters=[];alltext=[]
 for ci,(name,rows) in enumerate(CHAPTERS):
  beats=[{'id':f'{ci+1:02d}-{i+1:02d}','setting':scene,'action':action,'text':text,'continuity':'Illustrative narrative shot; explicit scene/time cuts, preserve hands and support within each action'} for i,(scene,action,text) in enumerate(rows)]
  text='\n\n'.join(b['text'] for b in beats)
  chapters.append({'id':ci+1,'title':name,'text':text,'beats':beats})
  (B/f'audio/chapter-{ci+1:02d}.txt').write_text(text+'\n');alltext.append(text)
 story={'title':'Why Your Evenings Keep Disappearing','working_title':'Why Your Free Time Does Not Feel Like Yours','language':'English','ratio':'16:9','dimensions':[1280,720],'voice':{'model':'tts-1','voice':'alloy','speed':1},'chapters':chapters,'scope':'New long-form story, not a loop or slowed version of the Short','claims_policy':'Everyday illustrative explanations; no medical diagnosis, universal dopamine claims, numerical productivity guarantees or invented study results'}
 (B/'story.json').write_text(json.dumps(story,indent=2)+'\n');(B/'script.txt').write_text('\n\n'.join(alltext)+'\n')
 print(json.dumps({'chapters':len(chapters),'shots':sum(len(c['beats']) for c in chapters),'words':len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",' '.join(alltext))),'characters':sum(len(c['text']) for c in chapters),'estimated_tts_usd':sum(len(c['text']) for c in chapters)*15/1e6,'max_characters_per_request':max(len(c['text']) for c in chapters)},indent=2))
if __name__=='__main__':build()
