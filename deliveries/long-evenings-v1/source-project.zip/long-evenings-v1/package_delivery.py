"""Prepare reviewable delivery, archive saved narration and scan for credentials."""
from pathlib import Path
import json,hashlib,zipfile,shutil,os
B=Path(__file__).resolve().parent;R=Path('/workspace/stickman-video-director');O=B/'output';D=R/'deliveries/long-evenings-v1';D.mkdir(parents=True,exist_ok=True)
Q=json.loads((O/'QA.json').read_text());V=O/'why-your-evenings-keep-disappearing.mp4'
assert hashlib.sha256(V.read_bytes()).hexdigest()==Q['sha256']
rights={'narration':{'provider':'OpenAI','model':'tts-1','voice':'alloy','speed':1,'AI_generated':True,'new_requests':8,'estimated_usd':.151095,'account_billing_verified':False,'source':'Saved chapter-01.wav through chapter-08.wav; never regenerate on a picture revision'},'music_room_and_Foley':{'source':'Original seeded local synthesis in sound.py; no downloaded melody or recording','use':'Supplied for synchronization, editing, redistribution and use with the user\u2019s film','events':'audio/sound-events.json'},'character_art':{'source':'Existing channel protagonist painted B6 assets; installed parcel_runner artwork reused as a supporting friend','license_notice':'Existing source LICENSE included; no new image API calls'},'new_sets_props_and_motion':{'source':'Original local sets.py, props.py, film.py and rig.py; separately staged native landscape','scope':'New project-local action extension; installed standing-only B6 compositor unchanged'},'font':{'name':'Archivo Black','license':'SIL Open Font License; notice included in fonts'},'YouTube_upload':False}
(B/'rights.json').write_text(json.dumps(rights,indent=2)+'\n')
checkpoint={'title':Q['title'],'stage':'complete_long_film_exported_for_user_viewing','duration_seconds':Q['duration_seconds'],'native_format':'1280x720 / 16:9 / 30 fps','chapters':8,'shots':80,'new_TTS_requests':8,'new_image_API_requests':0,'source_fingerprint':Q['source_fingerprint'],'independent_creative_acceptance':'not claimed','real_time_AV_listening_by_agent':'not performed','YouTube_upload':False,'next':'User viewing; corrections reuse the saved narration and original sound'}
(B/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
(B/'characters.json').write_text(json.dumps({'hero':{'package':'characters/protagonist','views':['front','three_quarter']},'friend':{'package':'characters/friend','views':['front','three_quarter']},'note':'Actual actor/shot coverage is verified in QA.json; these are project-local bindings, not an installed runtime approval.'},indent=2))
desc=(B/'description.txt').read_text().replace('CHAPTERS\nSee the supplied chapters.txt for timestamps matched to the finished video.','CHAPTERS\n'+(O/'chapters.txt').read_text().strip());(D/'description.txt').write_text(desc)
for n in ['why-your-evenings-keep-disappearing.mp4','captions-en.srt','captions-en.vtt','chapters.txt','QA.json','encoded-storyboard-1.jpg','encoded-storyboard-2.jpg','movement-preview.mp4']:shutil.copy2(O/n,D/n)
for n in ['README.md','script.txt','rights.json','checkpoint.json','visual-review.md','review-evidence.json','repair-history.md']:shutil.copy2(B/n,D/n)
shutil.copy2(B/'audio/voice-ledger.json',D/'voice-and-cost.json')
with zipfile.ZipFile(D/'source-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in B.rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts:continue
  rel=p.relative_to(B);name=p.name
  if rel.parts[0]=='audio':
   keep=(name.startswith('chapter-') and (name.endswith('.txt') or name.endswith('-words.json') or name.endswith('-request.json') or (name.endswith('.wav') and not name.endswith('-api.wav') and not name.endswith('-16k.wav')))) or name in ['voice-ledger.json','sound-events.json']
   if not keep:continue
  if rel.parts[0]=='art' and name.startswith('set-'):continue # Reproducible native set code included.
  if rel.parts[0]=='output':
   keep=name in ['QA.json','probe.json','preflight.json','rejected-walk-stop.png','rejected-walk-stop.mp4'] or name.endswith('-motion.json') or (len(rel.parts)>1 and rel.parts[1]=='review' and name.startswith('detail-'))
   if not keep:continue
  z.write(p,str(Path('long-evenings-v1')/rel))
secret=os.environ.get('OPENAI_API_KEY','')
for p in D.iterdir():
 if p.suffix in ['.md','.json','.txt','.srt','.vtt'] and secret and secret.encode() in p.read_bytes():raise RuntimeError('Secret scan failed')
with zipfile.ZipFile(D/'source-project.zip') as z:
 assert z.testzip() is None
 for name in z.namelist():
  if Path(name).suffix in ['.py','.json','.txt','.md'] and secret and secret.encode() in z.read(name):raise RuntimeError('Archive secret scan failed')
assert (D/'source-project.zip').stat().st_size<95*1024**2
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in D.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'}
(D/'SHA256SUMS.txt').write_text(''.join(f'{h}  {n}\n' for n,h in sorted(manifest.items())))
print(json.dumps({'video_MB':round(V.stat().st_size/1e6,2),'source_MB':round((D/'source-project.zip').stat().st_size/1e6,2),'credential_scan':'clean','archive_integrity':'pass','delivery':str(D)},indent=2),flush=True)
