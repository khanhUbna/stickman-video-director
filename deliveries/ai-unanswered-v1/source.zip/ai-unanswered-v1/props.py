from pathlib import Path
import math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import rig
from rig import poly,line
INK=rig.INK
def basket(im,c,fill=0,scale=1):
 g=ImageDraw.Draw(im);x,y=c;w=55*scale;h=54*scale
 g.arc((x-w*.8,y-h*1.3,x+w*.8,y+h*.1),180,360,fill='#5f4027',width=round(7*scale))
 poly(g,[(x-w,y-h*.38),(x+w,y-h*.38),(x+w*.76,y+h*.65),(x-w*.76,y+h*.65)],'#b68043','#583c28',4)
 for j in range(5):
  yy=y-h*.25+j*h*.18;line(g,[(x-w*.9,yy),(x+w*.9,yy)],'#684a2b',2)
 for j in range(-3,4):line(g,[(x+j*w*.24,y-h*.3),(x+j*w*.19,y+h*.58)],'#d0a36d',2)
 if fill:
  for j in range(6):
   xx=x+(j%3-1)*w*.46;yy=y-h*.35-(j//3)*h*.21;g.ellipse((xx-12*scale,yy-11*scale,xx+12*scale,yy+11*scale),fill=['#aa422d','#c38932','#7d983d'][j%3],outline='#513d27',width=2)

def bowl(im,c,amount=0):
 g=ImageDraw.Draw(im);x,y=c;g.pieslice((x-48,y-21,x+48,y+36),0,180,fill='#b77f48',outline='#583c28',width=4);g.ellipse((x-48,y-18,x+48,y+13),fill='#d1a572',outline='#583c28',width=4)
 for j in range(amount):
  xx=x-24+(j%3)*24;yy=y-5-(j//3)*8;g.ellipse((xx-10,yy-8,xx+10,yy+7),fill='#a84d2b',outline='#65371f',width=2)

def berry(im,c,r=13):
 g=ImageDraw.Draw(im);x,y=c;g.ellipse((x-r,y-r,x+r,y+r),fill='#ad3d37',outline='#573222',width=3);line(g,[(x,y-r),(x+3,y-r-9)],'#62532a',3)

def fish(im,c,angle=0,scale=1):
 g=ImageDraw.Draw(im);c=np.array(c);pts=[[-35,0],[-18,-14],[15,-12],[29,0],[15,13],[-18,13]];pts=[c+rotate(np.array(v)*scale,angle) for v in pts];poly(g,pts,'#a4b5a0','#3e574e',3);poly(g,[c+rotate(np.array(v)*scale,angle) for v in [[-30,0],[-47,-14],[-47,15]]],'#829884','#3e574e',3);x,y=c+rotate([17*scale,-3*scale],angle);g.ellipse((x-3,y-3,x+3,y+3),fill=INK)

def bundle(im,c,scale=1):
 g=ImageDraw.Draw(im);x,y=c
 for j in range(3):
  yy=y+(j-1)*12*scale;line(g,[(x-49*scale,yy-7),(x+49*scale,yy+7)],'#68492d',round(12*scale));line(g,[(x-43*scale,yy-9),(x+41*scale,yy+5)],'#a47a4c',3)
 line(g,[(x-8*scale,y-23*scale),(x-12*scale,y+22*scale)],'#d9bc85',5);line(g,[(x+9*scale,y-21*scale),(x+5*scale,y+24*scale)],'#d9bc85',5)

def slate(im,c,n=0,angle=0,blank=False):
 tile=Image.new('RGBA',(180,145));g=ImageDraw.Draw(tile);poly(g,[(10,18),(155,7),(173,120),(20,139)],'#c8a178','#694c36',5)
 if not blank:
  for j in range(min(n,15)):
   x=31+(j%5)*25;y=37+(j//5)*30;line(g,[(x,y),(x-5,y+19)],'#644936',4)
 rr,pos=rig.transformed(tile,c,[90,72],1,angle);im.alpha_composite(rr,pos)

def stool(im,x,y=832):
 g=ImageDraw.Draw(im);g.ellipse((x-55,y-13,x+55,y+18),fill='#9b714b',outline='#553e2c',width=4)
 for dx in [-35,35]:line(g,[(x+dx,y+12),(x+dx*1.1,890)],'#634a32',10)

def ripple(im,c,t,r=35):
 g=ImageDraw.Draw(im);x,y=c;rr=r+12*math.sin(t*3);g.arc((x-rr,y-rr*.22,x+rr,y+rr*.22),0,350,fill='#c8d8c5',width=3)
