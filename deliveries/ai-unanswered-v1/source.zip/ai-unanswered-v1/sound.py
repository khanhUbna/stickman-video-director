"""Original score and physically timed local Foley. No library music."""
from pathlib import Path
import json,math,wave
import numpy as np
B=Path(__file__).resolve().parent;T=json.loads((B/'timeline.json').read_text());SR=48000;N=round(T['duration']*SR)
def read(path):
 with wave.open(str(B/path)) as w:
  assert w.getframerate()==SR and w.getsampwidth()==2
  return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,w.getnchannels()).mean(axis=1).astype(np.float32)/32768
def write(path,a):
 with wave.open(str(B/path),'wb') as w:w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(a,-.98,.98)*32767).astype('<i2').tobytes())
def add(bus,at,note,gain=1):
 k=round(at*SR);n=min(len(note),len(bus)-k)
 if k>=0 and n>0:bus[k:k+n]+=note[:n]*gain
def pluck(f,d=.8):
 t=np.arange(round(d*SR),dtype=np.float32)/SR;return (np.sin(2*np.pi*f*t)+.28*np.sin(4*np.pi*f*t)+.10*np.sin(6*np.pi*f*t))*np.exp(-t*5)*np.minimum(1,t/.006)
def main():
 rng=np.random.default_rng(171126);mix=np.zeros(N,np.float32)
 for ch in T['chapters']:add(mix,ch['start'],read(ch['path']),.94)
 music=np.zeros(N,np.float32)
 for ch in T['chapters']:
  ci=ch['id'];beat=60/(70 if ci in [1,2,3] else 74);minor=ci<4;chords=[[50,53,57],[46,50,53],[48,52,55],[45,48,52]] if minor else [[53,57,60],[48,52,55],[50,53,57],[46,50,53]]
  for j,at in enumerate(np.arange(ch['start']+.1,ch['end']-.2,beat/2)):
   chord=chords[(j//8)%4];m=chord[[0,2,1,2,0,1,2,1][j%8]];gain=.010 if ci==5 else .014;add(music,at,pluck(440*2**((m-69)/12)),gain)
   if j%8==0:add(music,at,pluck(440*2**(((m-12)-69)/12),1.5),.018)
   if j%4==0:
    tt=np.arange(round(.17*SR),dtype=np.float32)/SR;hit=np.sin(2*np.pi*(105*tt-130*tt*tt))*np.exp(-tt*27);add(music,at,hit,.009)
 fade=np.minimum(1,np.arange(N)/SR*.3)*np.minimum(1,(N-np.arange(N))/(SR*1.6));music*=fade.astype(np.float32);mix+=music;write('audio/music-original.wav',music);del music
 fx=np.zeros(N,np.float32);events=[]
 def event(at,kind,amp=.035,d=.16):
  t=np.arange(round(d*SR),dtype=np.float32)/SR;noise=rng.normal(0,1,len(t)).astype(np.float32);noise=np.convolve(noise,np.ones(7,np.float32)/7,mode='same');f=95 if kind=='footstep' else 160 if kind=='axe_wood' else 420;sig=(noise*.7+.25*np.sin(2*np.pi*f*t))*np.exp(-t*(30 if kind=='footstep' else 20))*np.minimum(1,t/.004);add(fx,at,sig,amp);events.append({'time':round(at,4),'kind':kind,'source':'Original locally synthesized tone and filtered noise'})
 prior={}
 for ci in range(1,6):
  trace=json.loads((B/f'output/chapter-{ci:02d}-motion.json').read_text())
  for r in trace['actor_frames']:
   old=prior.get(r['who']);prior[r['who']]=r
   if not old or old['shot']!=r['shot'] or r['t']-old['t']>.04:continue
   if r['action'] not in ['walk_edge','leave_question','fork_walk','food_path','choose_walk','butterfly_follow']:continue
   for side in ['left','right']:
    if not old['legs'][side]['planted'] and r['legs'][side]['planted']:event(r['t'],'footstep',.034,.09)
 for s in T['shots']:
  at=lambda q:s['start']+(s['end']-s['start'])*q;a=s['action']
  if a in ['eye_question','silent_eye','question_stone','touch_stone']:event(at(.70),'stone_touch',.021)
  if a=='set_cup':event(at(.70),'clay_on_stone',.038,.19)
  if a=='signal_travel':
   tt=np.arange(SR,dtype=np.float32)/SR;note=np.sin(2*np.pi*(430*tt+50*tt*tt))*np.sin(np.pi*tt)**2;add(fx,at(.25),note,.009);events.append({'time':at(.25),'kind':'illustrative_signal_music_cue','note':'Musical illustration, not sound propagating through a vacuum'})
  if s['setting']=='cave':
   n=round((s['end']-s['start'])*SR);noise=rng.normal(0,.003,n).astype(np.float32);noise=np.convolve(noise,np.ones(9,np.float32)/9,mode='same');add(fx,s['start'],noise);events.append({'time':s['start'],'kind':'soft_fire_ambience','duration':s['end']-s['start'],'source':'Original seeded filtered noise'})
 write('audio/foley-original.wav',fx);mix+=fx;mix[-SR:]*=np.linspace(1,0,SR,dtype=np.float32);write('audio/mix-unmastered.wav',mix)
 (B/'audio/sound-events.json').write_text(json.dumps(events,indent=2));print('Original score and Foley:',len(events),'events',flush=True)
if __name__=='__main__':main()
