"""Map actual offline words to native shots and one-line semantic captions."""
from pathlib import Path
import json,re,math,hashlib,wave
from caption_renderer import CaptionRenderer,default_profile
B=Path(__file__).resolve().parent;FPS=30
story=json.loads((B/'story.json').read_text());voices=json.loads((B/'audio/voice-ledger.json').read_text())['chapters']
profile=default_profile('16:9',1280,720,'archivo-black')
profile.update(font_size=39,stroke=3,side=64,baseline=677,band=[624,708],native_layout_reason='Separately authored 1280x720 landscape stage: floor at 590, hands/props above 480, fixed one-line captions below all principal body/prop actions; native landscape framing, not a crop of the Short.')
cr=CaptionRenderer(B,'16:9',1280,720,profile)
shots=[];cues=[];chapters=[];offset=0.;allwords=[];alltext=[]
norm=lambda s:re.sub('[^a-z]','',s.lower())
for chapter,voice in zip(story['chapters'],voices):
 words=json.loads((B/f"audio/chapter-{chapter['id']:02d}-words.json").read_text())['words'];wi=0;localbeats=[]
 for beat in chapter['beats']:
  tokens=list(re.finditer(r"[A-Za-z]+(?:'[A-Za-z]+)?",beat['text']));start_i=wi
  for tok in tokens:
   assert norm(tok.group())==norm(words[wi]['word']),(chapter['id'],tok.group(),words[wi]);wi+=1
  ws=words[start_i:wi];localbeats.append({**beat,'start':offset+ws[0]['start'],'end':offset+ws[-1]['end'],'chapter':chapter['id']})
  # Prefer sentence punctuation, acoustic pauses and clause starts; preserve
  # phrasal verbs and avoid leaving articles/prepositions dangling.
  chunks=[];i=0
  while i<len(tokens):
   feasible=[];last=i
   for j in range(i+1,len(tokens)+1):
    left=tokens[i].start();right=tokens[j].start() if j<len(tokens) else len(beat['text']);s=beat['text'][left:right].strip()
    box=cr.font.getbbox(s,anchor='ms',stroke_width=profile['stroke']*3)
    if (box[2]-box[0])/3>1280-2*profile['side']:break
    if len(s)>58:break
    last=j;prev=beat['text'][tokens[j-1].end():right]
    if re.search(r'[.!?;,]',prev) or j==len(tokens):feasible.append((j,3))
    elif j<len(tokens) and tokens[j].group().lower() in ['and','but','because','when','while','before','after','instead','without','until','if','then'] and len(s)>=20:feasible.append((j,2))
    elif j<len(tokens) and ws[j]['start']-ws[j-1]['end']>.20:feasible.append((j,2))
   if not feasible:
    j=last
    while j>i+1 and tokens[j-1].group().lower() in ['a','an','the','to','of','for','with','your','their','this','that','as','on','at','in']:j-=1
   else:j=max(feasible,key=lambda x:(x[1],x[0]))[0]
   if 0<len(tokens)-j<3:
    j=max(i+1,len(tokens)-3)
    while j>i+1 and tokens[j-1].group().lower() in ['a','an','the','to','of','for','with','your','their','this','that','as','on','at','in']:j-=1
   assert j>i,(i,last)
   right=tokens[j].start() if j<len(tokens) else len(beat['text']);s=beat['text'][tokens[i].start():right].strip()
   cr.raster(s);cr.cache.clear();cues.append({'start':offset+ws[i]['start'],'end':offset+ws[j-1]['end'],'text':s,'beat':beat['id']});i=j
  alltext.append(beat['text'])
 assert wi==len(words)
 for i,b in enumerate(localbeats):
  b['start']=offset if i==0 else (localbeats[i-1]['end']+b['start'])/2
  b['end']=offset+voice['duration'] if i+1==len(localbeats) else (b['end']+localbeats[i+1]['start'])/2
 shots.extend(localbeats);chapters.append({'id':chapter['id'],'title':chapter['title'],'start':offset,'speech_duration':voice['duration'],'end':offset+voice['duration']+.65,'path':voice['path']})
 allwords.extend([{**w,'start':w['start']+offset,'end':w['end']+offset,'chapter':chapter['id']} for w in words]);offset+=voice['duration']+.65
# Make exact continuous coverage and permit a deliberate final action/sound tail.
for i,s in enumerate(shots):s['end']=shots[i+1]['start'] if i+1<len(shots) else math.ceil((offset+1.35)*FPS)/FPS
shots[0]['start']=0;duration=shots[-1]['end'];chapters[-1]['end']=duration
for i,c in enumerate(cues):c['end']=min(c['end']+.10,cues[i+1]['start'] if i+1<len(cues) else duration)
timeline={'duration':duration,'fps':FPS,'width':1280,'height':720,'caption_profile':profile,'chapters':chapters,'shots':shots}
(B/'timeline.json').write_text(json.dumps(timeline,indent=2));(B/'captions.json').write_text(json.dumps(cues,indent=2));(B/'words.json').write_text(json.dumps({'method':'Offline acoustic alignment, actual chapter offsets','words':allwords},indent=2))
def stamp(t,sep=','):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}{sep}{ms%1000:03}'
(B/'output/captions-en.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(cues))+'\n')
(B/'output/captions-en.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f"{stamp(c['start'],'.')} --> {stamp(c['end'],'.')}\n{c['text']}" for c in cues)+'\n')
def yt(t):return f'{int(t)//60}:{int(t)%60:02}'
(B/'output/chapters.txt').write_text('\n'.join(yt(c['start'])+' '+c['title'] for c in chapters)+'\n')
assert norm(' '.join(c['text'] for c in cues))==norm(' '.join(alltext))
print(json.dumps({'duration_seconds':duration,'shots':len(shots),'caption_cues':len(cues),'word_coverage':'exact','native_format':'1280x720 landscape'},indent=2))
