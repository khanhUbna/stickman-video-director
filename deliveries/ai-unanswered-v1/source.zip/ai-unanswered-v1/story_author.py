"""Original narrative; source SRT studied for broad rhetorical techniques only."""
from pathlib import Path
import json,re
B=Path(__file__).resolve().parent
CHAPTERS=[('The machine that answered everything',[
('ridge','eye_question','Koa asked AI whether he was alone in the universe. It gave him an answer that sounded beautiful. Then he asked a much harder question: how do you know?'),
('ridge','silent_eye','The blue eye went quiet. This machine had helped him find food and prepare for winter. Koa tapped the stone. Maybe it needed more power.'),
('ridge','walk_edge','But this was not one missing fact. Some questions need evidence we do not have. Some need a test we have not agreed on. And some are waiting for a decision, not a discovery.'),
('space','three_questions','To see the difference, follow one caveman through three questions. Each one takes something away from the machine. By the end, it gives something back to him.')]),
('Is anyone out there?',[
('ridge','sky_point','Koa looked above the valley. Every light seemed like a place. If the sky contained so many places, why had nobody knocked on his cave?'),
('space','star_depart','The machine could describe distant stars and worlds. But describing where life might survive is different from finding something alive.'),
('space','planet_compare','Imagine three planets. One has an ocean. Another has familiar chemicals. A third has both. Which one has life? Those clues make the question interesting. They do not finish it.'),
('tide','alien_possible','An ocean could be empty. Life could exist beneath ice. A living world could have nobody building fires, sending messages, or wondering about the neighbors.'),
('space','signal_travel','And a message is not an instant conversation. Light needs time to cross space. A signal could be traveling while its sender changes, disappears, or never learns that anyone heard it.'),
('ridge','listen_stars','The night above Koa looked silent. But silence might mean nobody was there. It might mean they were too far away, too quiet, or speaking in a way he had not learned to notice.'),
('space','data_window','More intelligence can help us search. It can find patterns we miss and suggest better experiments. It cannot honestly turn an uncollected measurement into an observed fact.'),
('ridge','empty_cup','Koa held a cup beneath the sky and found no rain inside it. That did not prove the valley had no water. It proved something much smaller about one cup, in one place, at one moment.'),
('ridge','question_stone','The machine could offer possibilities. What would make one of them an answer was evidence. So Koa stopped asking it to sound certain, and asked what they should look for.')]),
('Is anybody inside the machine?',[
('cave','warm_hands','Back at the fire, a different question arrived. Koa held his hands near the flames. The machine could estimate the heat. Could it feel the warmth?'),
('cave','heat_measure','It might describe a burning finger, predict a cry, and say the right comforting words. None of those observations, by itself, settles whether there is an experience inside.'),
('cave','shadow_play','Think of a shadow on a cave wall. Make a hand into a bird and the shadow flaps. You understand why it moves. But movement alone does not tell you that the shadow wants to fly.'),
('cave','mirror_face','That does not prove a machine could never feel anything. It shows why behavior and inner experience are not simply the same question.'),
('space','brain_network','With people, we connect reports of experience to brains, bodies, and shared biology. Researchers study those connections. Explaining how information moves is important; explaining why it feels like anything remains deeply contested.'),
('cave','two_cups','A very convincing sentence is evidence that a system can produce that sentence. Whether it is also evidence of feeling depends on a theory and tests we can defend.'),
('cave','touch_stone','Koa placed a hand against the cool stone. The eye brightened. He felt less alone. That feeling was real in Koa. It did not automatically tell him what was happening inside the machine.'),
('cave','leave_question','The honest answer was not a dramatic yes, or a permanent no. It was that we do not have a generally accepted test that settles subjective experience in an artificial system.')]),
('What should a life be for?',[
('dawn','fork_walk','By morning, Koa had one question left. If the machine could help him do almost anything, what should he spend his life doing?'),
('dawn','food_path','It could propose a bigger store of food. More security. Fewer hungry evenings. Those were good reasons to work. They were not the only things he cared about.'),
('dawn','friend_invite','Nim was waiting beside the river. There was a tool to repair. A place they had never explored. An afternoon that nobody had assigned a purpose to yet.'),
('dawn','choice_slates','Koa asked the machine to choose. It could rank the options, but first it needed to know what mattered most: safety, discovery, time with Nim, or something else.'),
('cave','goal_change','Change the goal, and the best answer can change. The same intelligence can optimize a longer workday or a freer afternoon. Intelligence alone does not decide which life is worth wanting.'),
('dawn','listen_friend','A machine can help you compare consequences and notice contradictions. Friends, experience, and reflection can change your mind too. That is different from finding a single life purpose hidden inside a calculation.'),
('dawn','set_cup','Koa had hoped for an answer that would spare him the risk of choosing. Instead, he found a question nobody else could completely take away from him.'),
('dawn','choose_walk','He asked Nim whether the river path was safe. He asked the machine about the weather. Then he put the stone down and chose to go.')]),
('Three kinds of not knowing',[
('space','evidence_return','These are three different limits. A question about other life asks for evidence. A question about experience asks what would count as evidence. A question about purpose also asks what we value.'),
('space','future_tools','Future tools may transform the first question. New theories may change the second. Better conversations may change the third. None of that requires pretending the answers are already settled.'),
('ridge','cup_return','The problem is not that AI has nothing useful to say. It is that a fluent answer can hide the difference between knowing, guessing, and choosing.'),
('dawn','butterfly_follow','Koa once thought a powerful machine would make his questions disappear. Instead, it helped him ask better ones. He still had food to find, a friend to listen to, and a world to explore.'),
('ridge','last_stars','That night, he looked up again. Maybe someone else was doing the same thing. He did not know. And for once, he did not need a machine to pretend.'),
('dawn','final_pair','Which question would you ask a machine that could answer almost anything? Before you trust its answer, try one more: what would make us know it was true?')])]
def build():
 chapters=[]
 for ci,(name,rows) in enumerate(CHAPTERS,1):
  beats=[{'id':f'{ci:02d}-{j:02d}','setting':s,'action':a,'text':t,'primary_information':'Original question-led fiction; distinguish evidence, subjective experience and values'} for j,(s,a,t) in enumerate(rows,1)];txt='\n\n'.join(b['text'] for b in beats);chapters.append({'id':ci,'title':name,'text':txt,'beats':beats});(B/f'audio/chapter-{ci:02d}.txt').write_text(txt+'\n')
 story={'title':"3 Questions Even AI Can't Answer",'language':'English','ratio':'16:9','dimensions':[1280,720],'fps':30,'genre':'Original fictional frame with explanatory science/philosophy; no claim of permanent AI incapacity','chapters':chapters}
 (B/'story.json').write_text(json.dumps(story,indent=2));(B/'script.txt').write_text('\n\n'.join(c['text'] for c in chapters)+'\n');chars=sum(len(c['text']) for c in chapters);words=len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",' '.join(c['text'] for c in chapters)));print(json.dumps({'chapters':len(chapters),'shots':sum(len(c['beats']) for c in chapters),'words':words,'characters':chars,'tts_estimate_usd':chars*15/1e6},indent=2))
if __name__=='__main__':build()
