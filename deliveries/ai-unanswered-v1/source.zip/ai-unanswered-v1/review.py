"""Evidence decoded from final MP4; distinguish actual review from source plans."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,hashlib,subprocess
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parent;O=B/'output';E=O/'review';E.mkdir(exist_ok=True);T=json.loads((B/'timeline.json').read_text());MOV=O/'3-questions-even-ai-cant-answer.mp4'
def one(item):
 sid,t,name=item;p=E/(name+'.jpg');subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(MOV),'-frames:v','1','-q:v','2',str(p)],check=True,capture_output=True);return {'shot':sid,'time':round(t,4),'file':str(p.relative_to(B))}
def main():
 specs=[(s['id'],s['start']+(s['end']-s['start'])*.58,'shot-'+s['id']) for s in T['shots']];details=[('01-01','stone-touch'),('02-03','planets'),('02-05','signal'),('03-03','shadow'),('04-06','friend-contact'),('04-07','cup-placement'),('04-08','pair-walk')]
 for sid,name in details:
  s=next(s for s in T['shots'] if s['id']==sid)
  for q in [.1,.35,.65,.95]:specs.append((sid,s['start']+(s['end']-s['start'])*q,f'{name}-{q:.2f}'))
 with ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(one,specs))
 for page in range(2):
  selected=records[page*20:min(35,(page+1)*20)];im=Image.new('RGB',(1280,5*205),'#192232');g=ImageDraw.Draw(im)
  for j,r in enumerate(selected):
   x=j%4*320;y=j//4*205;a=Image.open(B/r['file']);a.thumbnail((320,180));im.paste(a,(x,y));s=next(s for s in T['shots'] if s['id']==r['shot']);g.text((x+4,y+183),r['shot']+' '+s['action'],fill='white')
  im.save(O/f'encoded-storyboard-{page+1}.jpg',quality=92)
 for sid,name in details:
  rs=[r for r in records if name in r['file']];im=Image.new('RGB',(1280,720))
  for j,r in enumerate(rs):im.paste(Image.open(B/r['file']).resize((640,360)),(j%2*640,j//2*360))
  im.save(E/f'{name}-sequence.jpg',quality=92)
 (B/'review-evidence.json').write_text(json.dumps({'movie_sha256':hashlib.sha256(MOV.read_bytes()).hexdigest(),'source':'Decoded actual final movie','frames':records,'limits':'Frame sequences do not constitute full real-time AV listening or independent creative approval'},indent=2));print('Final-video evidence frames:',len(records),flush=True)
if __name__=='__main__':main()
