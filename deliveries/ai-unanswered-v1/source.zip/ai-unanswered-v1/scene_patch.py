"""Scoped repair: physically put the AI stone down before choosing to walk.

Only shot 04-08 changes. The original shared scene module is unchanged so
all other chapter movies retain their verified source fingerprint.
"""
import bisect,hashlib,math
from pathlib import Path
import numpy as np
from PIL import ImageDraw,Image
import film
from rig import actor,mix
ORIGINAL_FRAME=film.frame
def patch_hash():return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def grips(center):
 spr=film.asset('ai-stone',195);alpha=np.asarray(spr.getchannel('A'));row=round(spr.height*.35);edges=np.flatnonzero(alpha[row]>96);base=np.asarray(center)-np.array(spr.size)/2
 return {'left':base+[int(edges[0])+2,row],'right':base+[int(edges[-1])-2,row]}
def frame(t,caption=True,collect=True):
 s=next(s for s in film.T['shots'] if s['start']<=t<s['end']+.000001)
 if s['action']!='choose_walk':return ORIGINAL_FRAME(t,caption,collect)
 q=(t-s['start'])/(s['end']-s['start']);p=film.p;im=film.BG['dawn'].copy();film.ambience(im,'dawn',t);rows=[]
 # The cup from the preceding shot stays on its original support.
 film.ledge(im,1160,790);film.cup(im,[1160,735])
 center=mix([1080.,642.],[1080.,792.5],p(q,.30,.65));g=grips(center);lower=p(q,.30,.65);release=p(q,.65,.75);rise=p(q,.73,.83)
 hy=725+70*lower*(1-rise);h=np.array([1040.,hy]);w={side:g[side] for side in g}
 for side in w:w[side]=mix(w[side],film.normal(h,side),release)
 def add(who,hip,wr,walk=None,feet=None,head=0,held=None,prop=None):
  r=actor(im,hip,who=who,wrists=wr,walk=walk,feet=feet,head_angle=head,held=held,prop_draw=prop,occlude_forearms=('left','right') if prop else ());rows.append({'t':round(t,5),'shot':s['id'],'action':s['action'],**r})
 if q<.83:
  add('koa',h,w,feet={'left':[1015,890],'right':[1077.5,890]},head=3,held={side+'_AI_stone':{'arm':side,'point':g[side]} for side in g} if q<.65 else None,prop=lambda m:film.stamp(m,'ai-stone',center,195))
 else:
  # Start from the same uncrossed stance: travel phase .5 gives matching
  # world-space support points, so rising/first step do not slide the feet.
  d=312.5*p(q,.83,.997);x=1040+d;travel=312.5+d;y=film.rig.walking_hip_y(x,travel,1,'koa');hh=np.array([x,y]);sw=math.sin(travel/125*math.pi*2);wr={'left':hh+[-67+15*sw,-14],'right':hh+[70-15*sw,-14]};film.stamp(im,'ai-stone',center,195);add('koa',hh,wr,walk=(travel,1),head=-2)
 d=312.5*p(q,.80,.997);travel=312.5+d;x=1370+d;y=film.rig.walking_hip_y(x,travel,1,'nim');nh=np.array([x,y]);sw=math.sin(travel/125*math.pi*2);add('nim',nh,{'left':nh+[-67+15*sw,-14],'right':nh+[70-15*sw,-14]},walk=(travel,1),head=2)
 width=1830*(1-.022*p(q,.55,.95));height=width*9/16;left=1290-width/2;out=im.crop(tuple(round(v) for v in [left,180,left+width,180+height])).resize((1280,720),Image.Resampling.LANCZOS)
 if caption:
  i=bisect.bisect_right(film.CSTART,t)-1
  if i>=0 and t<film.CUES[i]['end']:
   if len(film.CR.cache)>7:film.CR.cache.clear()
   out=Image.alpha_composite(out,film.CR.raster(film.CUES[i]['text'])[0])
 if collect:film.ROWS.extend(rows)
 return out.convert('RGB')
