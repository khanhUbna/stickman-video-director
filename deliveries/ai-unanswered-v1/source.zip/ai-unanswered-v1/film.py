"""Original AI-questions story: painted cast, physical actions and animated diagrams.
Project-local compositor retained from the user-reviewed channel production.
"""
from pathlib import Path
from functools import lru_cache
import json,math,bisect,subprocess,hashlib,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import rig,props
from rig import actor,rotate,mix,ease,line,poly
from caption_renderer import CaptionRenderer
B=Path(__file__).resolve().parent;O=B/'output';T=json.loads((B/'timeline.json').read_text());FPS=30;WORLD=(2400,1200);INK=rig.INK
BG={k:Image.open(B/f'art/{k}.png').convert('RGBA').resize(WORLD,Image.Resampling.LANCZOS) for k in ['ridge','space','tide','cave','dawn']}
ART={k:Image.open(B/f'art/{k}.png').convert('RGBA') for k in ['ai-stone','ocean','red','cloud','butterfly','cup','flame']}
CUES=json.loads((B/'captions.json').read_text());CSTART=[c['start'] for c in CUES];CR=CaptionRenderer(B,'16:9',1280,720,T['caption_profile']);ROWS=[]
def p(q,a=0,b=1):return ease((q-a)/(b-a))
@lru_cache(maxsize=28)
def font(n):return ImageFont.truetype(str(B/'fonts/ArchivoBlack.ttf'),n)
@lru_cache(maxsize=100)
def asset(name,width):
 im=ART[name];return im.resize((width,round(im.height/im.width*width)),Image.Resampling.LANCZOS)
def stamp(im,name,center,width,angle=0):
 spr=asset(name,round(width));rr,pos=rig.transformed(spr,center,np.array(spr.size)/2,angle=angle);im.alpha_composite(rr,pos)
def stone(im,x=1250,base=815,t=0,bright=True):
 spr=asset('ai-stone',195);im.alpha_composite(spr,(round(x-spr.width/2),round(base-spr.height)))
 if bright:
  # Small breathing illumination stays bound to the painted eye.
  lay=Image.new('RGBA',(110,70));g=ImageDraw.Draw(lay);v=.5+.5*math.sin(t*2.8);g.ellipse((24,12,86,58),fill=(40,225,238,round(12+18*v)));lay=lay.filter(ImageFilter.GaussianBlur(12));im.alpha_composite(lay,(round(x-55),round(base-spr.height*.64-35)))
def cup(im,c,width=104):stamp(im,'cup',c,width)
def cupgrip(c,width=104):return np.array(c)+[width*.38,width*.04]
def stone_contact(x=1250,base=815):
 spr=asset('ai-stone',195);alpha=np.asarray(spr.getchannel('A'));row=round(spr.height*.25);edge=int(np.flatnonzero(alpha[row]>96)[0]);return np.array([x-spr.width/2+edge+2,base-spr.height+row])
def normal(h,side,angle=0):return np.asarray(h)+rotate([-66 if side=='left' else 70,-14],angle)
def rest(h,angle=0):return {s:normal(h,s,angle) for s in ['left','right']}
def fire(im,t,x=810,y=840,width=95):
 # Pose-independent hand-painted flame: transform matches the stone ring.
 for j in range(6):
  xx=x+(j-2.5)*22;yy=y+6*math.cos(j);ImageDraw.Draw(im).ellipse((xx-18,yy-8,xx+18,yy+10),fill='#807665',outline=INK,width=3)
 stamp(im,'flame',[x,y-48-3*math.sin(t*4)],width,2*math.sin(t*3))
def label(im,xy,text,size=43,color='#f8e7c7'):
 ImageDraw.Draw(im).text(xy,text,font=font(size),fill=color,stroke_width=2,stroke_fill='#252b3d',anchor='mm')
def ledge(im,x,y=790,w=125):
 g=ImageDraw.Draw(im);poly(g,[(x-w/2,y-12),(x+w/2,y-12),(x+w*.42,y+19),(x-w*.47,y+24)],'#a99172','#5b4d3d',4)
def ambience(im,setting,t):
 g=ImageDraw.Draw(im)
 if setting in ['ridge','space']:
  for j in range(13):
   x=110+j*173;y=75+(j*91)%330;r=1+(.5+.5*math.sin(t*1.8+j))*1.8;g.ellipse((x-r,y-r,x+r,y+r),fill='#ebddca')
 if setting in ['dawn','tide']:
  for j in range(5):props.ripple(im,(980+j*140,720+(j%2)*12),t+j,32)

def frame(t,caption=True,collect=True):
 s=next(s for s in T['shots'] if s['start']<=t<s['end']+.000001);q=(t-s['start'])/(s['end']-s['start']);a=s['action'];setting=s['setting'];im=BG[setting].copy();ambience(im,setting,t);rows=[];cx=1200.;width=1500.;cy=180.;top=None
 if setting=='cave':fire(im,t,880 if a in ['warm_hands','heat_measure'] else 810,810 if a in ['warm_hands','heat_measure'] else 840)
 def put(who,x,y=725,wr=None,angle=0,head=0,expr='normal',feet=None,walk=None,prop=None,held=None,occlude=()):
  r=actor(im,[x,y],who=who,wrists=wr,angle=angle,head_angle=head,expression=expr,feet=feet,walk=walk,prop_draw=prop,held=held,occlude_forearms=occlude);rows.append({'t':round(t,5),'shot':s['id'],'action':a,**r});return r
 def walking(who,start,distance=312.5,direction=1,carry=False,begin=.06,end=.92):
  d=distance*p(q,begin,end);x=start+direction*d;y=rig.walking_hip_y(x,d,direction,who);h=np.array([x,y]);sw=math.sin(d/125*2*math.pi);wr={'left':h+[-67+15*sw,-14],'right':h+[70-15*sw,-14]};prop=None;held=None
  if carry:
   c=h+[47,-66];gr=cupgrip(c);wr['right']=gr;prop=lambda m:cup(m,c);held={'cup_handle':{'arm':'right','point':gr}}
  return put(who,x,y,wr=wr,walk=(d,direction),expr='normal',head=-2,prop=prop,held=held,occlude=('right',) if carry else ())
 if a in ['eye_question','silent_eye','question_stone','touch_stone']:
  cx=1190;width=1240;cy=315;h=np.array([1050.,725.]);w=rest(h);target=stone_contact();stone(im,1250,t=t,bright=a!='silent_eye' or q<.30)
  progress=p(q,.12,.70);w['right']=mix(normal(h,'right'),target,progress)
  expr='shocked' if a in ['eye_question','silent_eye'] and q>.45 else 'weary' if a=='touch_stone' and q<.55 else 'normal'
  put('koa',*h,wr=w,head=4*p(q,.25,.8),expr=expr,held={'stone_touch':{'arm':'right','point':target}} if q>.7 else None)
  if a=='eye_question':top='HOW DO YOU KNOW?'
  if a=='question_stone':top='WHAT WOULD COUNT AS EVIDENCE?'
 elif a in ['walk_edge','leave_question','fork_walk']:
  start=1320 if a=='leave_question' else 800;direction=-1 if a=='leave_question' else 1;walking('koa',start,direction=direction,carry=a=='walk_edge');cx=1200;width=1740;stone(im,1530 if a=='leave_question' else 1390,t=t)
  if a=='fork_walk':top='3 · WHAT SHOULD A LIFE BE FOR?'
 elif a in ['sky_point','listen_stars','last_stars']:
  cx=1250;width=1740;cy=55;h=np.array([1210.,725.]);w=rest(h);w['right']=mix(normal(h,'right'),[1328,576],p(q,.15,.75));put('koa',*h,wr=w,head=-8*p(q,.1,.6),expr='normal' if a=='last_stars' else 'shocked');stone(im,1550,t=t)
  if a=='sky_point':top='1 · ARE WE ALONE?'
  if a=='listen_stars':
   g=ImageDraw.Draw(im)
   for j in range(3):
    r=40+j*32+12*math.sin(q*math.pi);g.arc((1505-r,520-r,1505+r,520+r),235,310,fill='#67c8d1',width=3)
 elif a in ['empty_cup','cup_return']:
  cx=1180;width=1240;cy=315;h=np.array([1100.,725.]);w=rest(h);c=mix([1150,664],[1162,625],p(q,.10,.7));gr=cupgrip(c);w['right']=gr;put('koa',*h,wr=w,head=-3 if q<.5 else 5,expr='weary' if a=='cup_return' else 'normal',prop=lambda m:cup(m,c),held={'empty_cup_handle':{'arm':'right','point':gr}},occlude=('right',));stone(im,1440,t=t)
  if a=='empty_cup':
   # A patch of water visible far below; a dry cup is limited evidence.
   props.ripple(im,[1560,797],t,42)
 elif a in ['warm_hands','heat_measure']:
  cx=1060;width=1430;cy=240;h=np.array([1040.,735+20*p(q,.2,.7)]);w=rest(h,5);w['left']=mix(normal(h,'left',5),[933,686],p(q,.1,.7));put('koa',*h,wr=w,angle=5,head=5);stone(im,1390,t=t)
  if a=='warm_hands':top='2 · CAN A MACHINE FEEL?'
  else:
   g=ImageDraw.Draw(im)
   for j in range(4):
    y=615-j*22;line(g,[[1348,y],[1348+45*p(q,.1,.9),y]],'#dfb16b',5)
 elif a in ['shadow_play','mirror_face']:
  cx=1390;width=1840;cy=110;h=np.array([1060.,725.]);w=rest(h);spread=15+25*(.5+.5*math.sin(q*math.pi*3));w['left']=h+[-spread,-64];w['right']=h+[spread,-66];put('koa',*h,wr=w,head=4,expr='shocked' if a=='mirror_face' and q<.5 else 'normal');stone(im,2000,t=t)
  if a=='shadow_play' or q<.45:
   g=ImageDraw.Draw(im);x=1740;y=465;wing=55+35*math.sin(q*math.pi*3)
   poly(g,[(x,y+24),(x-27,y-12),(x-105,y-wing),(x-130,y-20),(x-45,y+31),(x,y+48),(x+45,y+31),(x+130,y-20),(x+105,y-wing),(x+27,y-12)],'#59402f',None);g.ellipse((x-12,y-12,x+12,y+30),fill='#59402f')
 elif a=='two_cups':
  cx=1240;width=1610;h=np.array([1020.,725.]);w=rest(h);c=mix([1070,665],[1110,650],p(q,.15,.75));gr=cupgrip(c);w['right']=gr;put('koa',*h,wr=w,head=3,prop=lambda m:cup(m,c),held={'warm_cup':{'arm':'right','point':gr}},occlude=('right',));stone(im,1560,t=t);ledge(im,1520,780);cup(im,[1520,733]);label(im,[1690,425],'“I FEEL WARM.”',48)
  for j in range(3):
   yy=c[1]-64-j*18;xx=c[0]+8*math.sin(t*2+j);line(ImageDraw.Draw(im),[[xx,yy+9],[xx+5,yy-9]],'#e7d0a8',2)
 elif a=='food_path':
  cx=1000;width=1680;walking('koa',700,carry=False);props.basket(im,[680,825],5);props.basket(im,[810,825],5);stone(im,1430,t=t)
 elif a=='friend_invite':
  cx=1300;width=1630;h=np.array([1360.,725.]);w=rest(h);w['left']=mix(normal(h,'left'),[1245,645],p(q,.12,.7));put('nim',*h,wr=w,head=3,expr='relief');put('koa',1100,head=-4*p(q,.3,.8))
  # A repaired primitive tool, grounded on a low stone, establishes an activity.
  ledge(im,1530,813);g=ImageDraw.Draw(im);line(g,[[1490,793],[1580,785]],'#705334',9);poly(g,[[1560,772],[1594,764],[1607,791],[1573,802]],'#8c9a8f','#425449',3)
 elif a=='choice_slates':
  cx=1260;width=1670;stone(im,1470,t=t);h=np.array([1100.,725.]);w=rest(h);w['right']=mix(normal(h,'right'),[1210,650],p(q,.15,.75));put('koa',*h,wr=w,head=5,expr='weary');props.basket(im,[820,825],4);stamp(im,'butterfly',[1660,565+20*math.sin(t)],110,8*math.sin(t));cup(im,[1250,819]);ledge(im,1250,866)
 elif a=='goal_change':
  cx=1450;width=1730;cy=120;stone(im,1930,t=t);props.basket(im,[1050,828],4);cup(im,[1500,828]);g=ImageDraw.Draw(im)
  label(im,[1090,350],'MORE FOOD',48);label(im,[1620,350],'MORE TIME',48)
  v=p(q,.1,.8);line(g,[[940,440],[940+390*(1-.7*v),440]],'#d8b06c',20);line(g,[[1450,440],[1450+390*(.3+.7*v),440]],'#65b8ba',20)
  put('koa',1300,head=-6*p(q,.1,.8),expr='weary')
 elif a=='listen_friend':
  cx=1230;width=1450;kh=np.array([1100.,725.]);nh=np.array([1340.,725.]);pt=kh+[0,6]+(np.array(rig.PACKS['koa']['views']['front']['arms']['right']['socket'])+[0,92])*rig.S;w=rest(nh);w['left']=mix(normal(nh,'left'),pt,p(q,.10,.60));put('koa',*kh,head=-5*p(q,.3,.8),expr='weary');put('nim',*nh,wr=w,head=3,expr='relief',held={'friend_shoulder':{'arm':'left','point':pt}} if q>=.6 else None)
 elif a=='set_cup':
  cx=1190;width=1240;cy=315;h=np.array([1100.,725+45*p(q,.1,.70)]);w=rest(h,5);c=mix([1150,655],[1160,735],p(q,.1,.70));gr=cupgrip(c);w['right']=gr if q<.76 else mix(gr,normal(h,'right',5),p(q,.76,.98));ledge(im,1160,790);put('koa',*h,wr=w,angle=5,head=5,prop=lambda m:cup(m,c),held={'placing_cup':{'arm':'right','point':gr}} if q<.76 else None,occlude=('right',));stone(im,1470,t=t)
 elif a=='choose_walk':
  cx=1290;width=1830;stone(im,850,t=t);ledge(im,1160,790);cup(im,[1160,735]);walking('koa',1110,begin=.12,end=.94);walking('nim',1380,begin=.12,end=.94)
 elif a=='butterfly_follow':
  cx=1260;width=1770;walking('koa',780,begin=.03,end=.94);walking('nim',1190,begin=.03,end=.94);c=np.array([1030+330*p(q,.02,.97),545+40*math.sin(q*math.pi*2)]);stamp(im,'butterfly',c,90,12*math.sin(t*4))
 elif a=='final_pair':
  cx=1270;width=1700;cy=180
  for who,x in [('koa',1050),('nim',1390)]:
   ledge(im,x,836,130);h=np.array([x,813.]);w=rest(h);w['right']=mix(normal(h,'right'),h+[57,-62],p(q,.25,.8));put(who,*h,wr=w,head=-3 if who=='koa' else 3,expr='relief' if who=='nim' else 'normal',feet={'left':[x-65,890],'right':[x+65,890]})
  stamp(im,'butterfly',[1590+25*math.sin(t),520+20*math.sin(t*1.7)],80,10*math.sin(t*4))
 elif a=='alien_possible':
  cx=1200+220*p(q,.1,.9);width=1850;cy=55;top='AN IMAGINED WORLD · NOT A DISCOVERY'
  for j in range(12):
   x=600+j*97;y=700+25*math.sin(t+j);ImageDraw.Draw(im).ellipse((x-3,y-3,x+3,y+3),fill='#7ce3d7')
 elif setting=='space':
  cx=1200;width=2100;cy=0;g=ImageDraw.Draw(im)
  if a=='three_questions':
   for j,(name,txt) in enumerate([('ocean','ARE WE ALONE?'),('ai-stone','CAN IT FEEL?'),('cup','WHAT IS IT FOR?')]):
    c=np.array([530+j*660,520+95*(1-p(q,.06+j*.14,.43+j*.14))]);stamp(im,name,c,415 if name!='cup' else 370);label(im,[c[0],850],txt,49)
  elif a in ['star_depart','planet_compare']:
   if a=='star_depart':
    stamp(im,'ocean',[1200,560],round(170+380*p(q,.08,.9)),8*p(q,.1,.9));label(im,[1200,940],'A POSSIBLE HOME IS NOT A DETECTION',48)
   else:
    for j,name in enumerate(['ocean','red','cloud']):
     yy=590+180*(1-p(q,.05+j*.12,.42+j*.12));stamp(im,name,[550+j*650,yy],520,6*math.sin(t*.15+j));label(im,[550+j*650,930],['OCEAN','CHEMISTRY','BOTH'][j],48)
    label(im,[1200,200],'WHICH ONE HAS LIFE?',63)
  elif a=='signal_travel':
   stamp(im,'ocean',[410,580],300);stamp(im,'cloud',[1970,580],310);line(g,[[620,580],[1760,580]],'#577f94',4);x=620+1140*p(q,.08,.92)
   for j in range(3):g.arc((x-13-j*15,540-j*8,x+13+j*15,620+j*8),275,445,fill='#5fe4ed',width=5)
   label(im,[1200,270],'A MESSAGE TAKES TIME',62);label(im,[1200,950],'ILLUSTRATION · NOT TO SCALE',31)
  elif a=='data_window':
   for j,name in enumerate(['ocean','red','cloud']):stamp(im,name,[550+j*650,570],440)
   x=430+1370*p(q,.08,.92);g.rounded_rectangle((x-125,320,x+125,830),25,outline='#73d8df',width=9);label(im,[1200,970],'SEARCHING ≠ FINDING',58)
  elif a=='brain_network':
   nodes=[np.array([550+(j%5)*260,380+(j//5)*210+25*math.sin(j)]) for j in range(15)]
   for j in range(14):line(g,[nodes[j],nodes[j+1]],'#557580',5)
   pos=q*14;i=min(13,int(pos));spot=mix(nodes[i],nodes[i+1],pos-i);g.ellipse((spot[0]-13,spot[1]-13,spot[0]+13,spot[1]+13),fill='#f5cc76')
   for j,c in enumerate(nodes):g.ellipse((c[0]-22,c[1]-22,c[0]+22,c[1]+22),fill='#69bdc3',outline='#b8ddcf',width=3)
   label(im,[1200,185],'INFORMATION → EXPERIENCE?',57);label(im,[1200,1020],'CONCEPTUAL DIAGRAM',30)
  elif a in ['evidence_return','future_tools']:
   for j,(name,txt) in enumerate([('ocean','EVIDENCE'),('ai-stone','EXPERIENCE'),('cup','VALUES')]):
    yy=540+45*math.sin(p(q,.1,.9)*math.pi+j*.3);stamp(im,name,[530+j*660,yy],400);label(im,[530+j*660,880],txt,56)
   if a=='future_tools':
    for j in range(3):g.arc((430+j*660,320,630+j*660,800),240,300,fill='#e0bd7d',width=5)
  else:raise ValueError(a)
 else:raise ValueError('Unimplemented '+a)
 # Native compositions: feet are above the fixed caption band. A gentle
 # reframe is not represented as a 3D dolly or as the principal animation.
 if setting!='space':width*=1-.022*p(q,.55,.95)
 height=width*9/16;left=min(max(cx-width/2,0),2400-width);cy=min(cy,1200-height);out=im.crop(tuple(round(v) for v in [left,cy,left+width,cy+height])).resize((1280,720),Image.Resampling.LANCZOS)
 if top:ImageDraw.Draw(out).text((35,30),top,font=font(27 if len(top)>35 else 31),fill='#f9e9cc',stroke_width=2,stroke_fill='#25283d')
 if caption:
  i=bisect.bisect_right(CSTART,t)-1
  if i>=0 and t<CUES[i]['end']:
   if len(CR.cache)>7:CR.cache.clear()
   out=Image.alpha_composite(out,CR.raster(CUES[i]['text'])[0])
 if collect:ROWS.extend(rows)
 return out.convert('RGB')

def fingerprint():return hashlib.sha256(Path(__file__).read_bytes()+(B/'rig.py').read_bytes()+(B/'props.py').read_bytes()).hexdigest()
def render(ci):
 ch=next(c for c in T['chapters'] if c['id']==ci);first=round(ch['start']*FPS);last=round(ch['end']*FPS);dst=O/f'chapter-{ci:02d}.mp4';ROWS.clear()
 ff=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','30','-i','-','-an','-c:v','libx264','-threads','2','-preset','fast','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart',str(dst)],stdin=subprocess.PIPE)
 try:
  for i in range(first,last):
   ff.stdin.write(frame(i/FPS).tobytes())
   if (i-first)%600==0:print(f'Chapter {ci}: {i-first}/{last-first}',flush=True)
  ff.stdin.close();assert ff.wait()==0
 except BaseException:ff.stdin.close();ff.wait();raise
 (O/f'chapter-{ci:02d}-motion.json').write_text(json.dumps({'chapter':ci,'actor_frames':ROWS,'first_frame':first,'last_frame_exclusive':last,'source_sha256':fingerprint()}));return str(dst)
def scan():
 (O/'boards').mkdir(exist_ok=True);errors=[]
 for s in T['shots']:
  for q in [.001,.15,.35,.5,.65,.8,.999]:
   try:
    im=frame(s['start']+(s['end']-s['start'])*q,collect=False)
    if q==.5:im.save(O/f"boards/{s['id']}.jpg",quality=88)
   except Exception as e:errors.append([s['id'],s['action'],q,str(e)])
 (O/'pose-scan.json').write_text(json.dumps(errors,indent=2));print(json.dumps(errors,indent=2),flush=True)
 if errors:raise SystemExit(1)
if __name__=='__main__':scan() if len(sys.argv)<2 else render(int(sys.argv[1]))
