from concurrent.futures import ProcessPoolExecutor,as_completed
import os
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
def one(ci):
 import film,json
 trace=film.O/f'chapter-{ci:02d}-motion.json';movie=film.O/f'chapter-{ci:02d}.mp4'
 import scene_patch
 if trace.exists() and movie.exists():
  d=json.loads(trace.read_text())
  if d.get('source_sha256')==film.fingerprint() and (ci!=4 or d.get('scene_patch_sha256')==scene_patch.patch_hash()) and (ci!=5 or d.get('chapter_start_guard_seconds')==.0001):return ci,'reused '+str(movie)
 if ci==4:film.frame=scene_patch.frame
 if ci==5:
  # Rounding a chapter boundary to 30 fps may put its first sample just
  # before the authored cut. Do not flash the old previous-shot branch.
  base=film.frame;start=next(c['start'] for c in film.T['chapters'] if c['id']==ci)
  film.frame=lambda t,caption=True,collect=True:base(max(t,start+.0001),caption,collect)
 result=film.render(ci)
 if ci==4:
  d=json.loads(trace.read_text());d['scene_patch_sha256']=scene_patch.patch_hash();d['repair_scope']='Only shot 04-08: put down the actual AI stone before departing';trace.write_text(json.dumps(d))
 if ci==5:
  d=json.loads(trace.read_text());d['chapter_start_clamped']=True;d['chapter_start_guard_seconds']=.0001;d['boundary_policy']='First rounded frame samples 0.1 ms after the authored cut, beyond the shared lookup endpoint tolerance';trace.write_text(json.dumps(d))
 return ci,result
if __name__=='__main__':
 with ProcessPoolExecutor(max_workers=4) as pool:
  for f in as_completed([pool.submit(one,i) for i in [2,3,4,1,5]]):print('COMPLETED',f.result(),flush=True)
