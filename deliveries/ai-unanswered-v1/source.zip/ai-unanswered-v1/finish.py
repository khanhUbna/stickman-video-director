"""Check the actual drawn chains, master audio and validate the final MP4."""
from pathlib import Path
import subprocess,json,re,hashlib
import numpy as np
import film
B=film.B;O=film.O;T=film.T;FPS=30;D=T['duration']
def run(args):return subprocess.run(args,check=True,capture_output=True)
def measure(p):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(p),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']);return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
def main():
 count=0;rows=[];coverage={s['id']:set() for s in T['shots']};bone=0;stance=[];contacts={};old={}
 for ci in range(1,6):
  d=json.loads((O/f'chapter-{ci:02d}-motion.json').read_text());assert d['source_sha256']==film.fingerprint();assert d['first_frame']==count;count=d['last_frame_exclusive'];rows.extend(d['actor_frames'])
  if ci==4:
   import scene_patch
   assert d.get('scene_patch_sha256')==scene_patch.patch_hash()
  if ci==5:assert d.get('chapter_start_guard_seconds')==.0001
 assert count==round(D*FPS)
 for r in sorted(rows,key=lambda x:(x['t'],x['who'])):
  assert set(r['arms'])==set(r['legs'])=={'left','right'};bone=max(bone,r['bone_error']);coverage[r['shot']].add(r['who']);prior=old.get(r['who']);old[r['who']]=r
  for name,e in r['contacts'].items():contacts[name]=max(contacts.get(name,0),e)
  if prior and prior['shot']==r['shot'] and r['t']-prior['t']<.04:
   for side in ['left','right']:
    if prior['legs'][side]['planted'] and r['legs'][side]['planted']:stance.append(float(np.linalg.norm(np.array(r['legs'][side]['joints'][-1])-prior['legs'][side]['joints'][-1])))
 assert bone<1e-8 and max(stance,default=0)<1e-5;assert max(contacts.values(),default=0)<1e-5
 for s in T['shots']:
  if s['setting'] in ['space','tide']:assert not coverage[s['id']]
  else:assert coverage[s['id']]
 try:film.rig.ik([0,0],[400,0],[80,80],1,'unreachable injection')
 except ValueError:negative=True
 else:raise AssertionError('Unreachable pose accepted')
 pre=measure(B/'audio/mix-unmastered.wav');flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
 master=B/'audio/mix-mastered.wav';run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix-unmastered.wav'),'-af',flt,'-ar','48000','-ac','2',str(master)])
 (O/'concat.txt').write_text(''.join("file '"+str(O/f'chapter-{ci:02d}.mp4')+"'\n" for ci in range(1,6)));mov=O/'3-questions-even-ai-cant-answer.mp4'
 run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(O/'concat.txt'),'-i',str(master),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-t',str(D),'-movflags','+faststart',str(mov)])
 probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(mov)]).stdout);v=next(x for x in probe['streams'] if x['codec_type']=='video');a=next(x for x in probe['streams'] if x['codec_type']=='audio');assert [v['width'],v['height'],v['r_frame_rate'],v['codec_name'],v['pix_fmt']]==[1280,720,'30/1','h264','yuv420p'];assert int(v['nb_frames'])==round(D*FPS);assert abs(float(v['start_time']))<.001;assert abs(float(v['duration'])-float(a['duration']))<.08;assert mov.stat().st_size<95*1024**2
 run(['ffmpeg','-v','error','-i',str(mov),'-f','null','-']);post=measure(mov);assert float(post['input_tp'])<=-.5
 qa={'title':"3 Questions Even AI Can't Answer",'duration_seconds':float(probe['format']['duration']),'dimensions':[1280,720],'fps':30,'frames':int(v['nb_frames']),'full_decode':'pass','audio_video_difference_seconds':abs(float(v['duration'])-float(a['duration'])),'file_bytes':mov.stat().st_size,'sha256':hashlib.sha256(mov.read_bytes()).hexdigest(),'source_fingerprint':film.fingerprint(),'narrative':{'chapters':5,'shots':35,'settings':['ridge','space','tide','cave','dawn'],'old_movie_footage_reused':False,'source_SRT_quoted_or_redistributed':False,'science_scope':'Illustrative possibilities and epistemic distinctions; not a claim that AI can never make discoveries or have experience'},'motion':{'actor_frames':len(rows),'four_drawn_chains_per_actor_frame':True,'max_fixed_bone_error_px':bone,'max_consecutive_planted_foot_drift_px':max(stance,default=0),'authored_contacts_px':contacts,'unreachable_pose_guard':negative,'cast_by_shot':{k:sorted(v) for k,v in coverage.items()}},'captions':{'language':'English','cues':len(film.CUES),'word_coverage':'Exact normalized narration coverage','alignment':'Offline acoustic PocketSphinx; saved original-rate audio','profile':T['caption_profile']},'sound':{'voice':'tts-1 / alloy, speed 1','new_tts_calls':5,'new_tts_estimate_usd':json.loads((B/'audio/voice-ledger.json').read_text())['estimated_usd'],'billing_verified':False,'new_image_calls':6,'image_billing':'not exposed','paid_transcription_calls':0,'score_and_foley':'Original local synthesis; no external music recording','loudness':post},'review':{'renderer':'Established project-local B6-look articulated compositor; installed trusted runtime unchanged','author_visual':'See visual-review.md and actual final-video decoded boards','independent_review':'Not performed','full_real_time_audiovisual_listening':'Not performed; measurements do not establish listening approval','strict_B6_35_subcheck_reference_acceptance':'Not claimed','user_viewing':'Full film available for user review'},'YouTube_upload':False}
 qa['motion']['scoped_scene_patch_sha256']=scene_patch.patch_hash();qa['motion']['scoped_scene_patch']='04-08: AI stone carried, lowered, released and left behind; chapters 1–3 reused; chapter 5 first frame clamped to its authored cut';qa['motion']['chapter_5_start_clamped']=True
 (O/'QA.json').write_text(json.dumps(qa,indent=2));(O/'probe.json').write_text(json.dumps(probe,indent=2));print(json.dumps({k:qa[k] for k in ['duration_seconds','frames','file_bytes','sha256']},indent=2));print('Actor frames:',len(rows),'foot drift:',max(stance,default=0),'LUFS:',post['input_i'],flush=True)
if __name__=='__main__':main()
