from pathlib import Path
import json,zipfile,shutil,hashlib,os,re
B=Path(__file__).resolve().parent;O=B/'output';D=Path('/workspace/stickman-video-director/deliveries/ai-unanswered-v1')
def main():
 qa=json.loads((O/'QA.json').read_text());assert qa['full_decode']=='pass';D.mkdir(parents=True,exist_ok=True)
 names=['README.md','script.txt','story.json','timeline.json','rights.md','reference-study.md','visual-review.md','review-evidence.json','repair-findings.md']
 for name in names:shutil.copy2(B/name,D/name)
 for name in ['3-questions-even-ai-cant-answer.mp4','captions-en.srt','captions-en.vtt','description-en.txt','chapters.txt','QA.json','encoded-storyboard-1.jpg','encoded-storyboard-2.jpg']:shutil.copy2(O/name,D/name)
 files=list(B.glob('*.py'))+list(B.glob('*.json'))+[B/n for n in ['README.md','script.txt','rights.md','reference-study.md','visual-review.md','repair-findings.md','requirements.txt','LICENSE']]
 files += [p for folder in ['characters','art','fonts'] for p in (B/folder).rglob('*') if p.is_file()]
 files += [p for p in (B/'audio').glob('chapter-*') if re.fullmatch(r'chapter-\d\d(?:\.wav|\.txt|-words\.json|-request\.json)',p.name)]
 files += [B/'audio/voice-ledger.json',B/'audio/sound-events.json',O/'pose-scan.json',O/'QA.json',O/'probe.json',O/'captions-en.srt',O/'captions-en.vtt']+list(O.glob('chapter-*-motion.json'))
 secret=os.environ.get('OPENAI_API_KEY','').encode()
 for p in set(files):
  if p.suffix in ['.py','.txt','.json','.md'] and secret and secret in p.read_bytes():raise RuntimeError('Credential scan failed; package stopped')
 with zipfile.ZipFile(D/'source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(set(files)):z.write(p,'ai-unanswered-v1/'+str(p.relative_to(B)))
 assert (D/'source.zip').stat().st_size<95*1024**2
 checkpoint={'state':'Complete exported film with saved narration and decoded evidence','title':qa['title'],'duration_seconds':qa['duration_seconds'],'video_sha256':qa['sha256'],'new_tts_calls':5,'tts_estimate_usd':.08724,'new_image_calls':6,'YouTube_upload':False,'future_corrections':'Reuse saved audio; do not regenerate speech for visual repairs','review_limits':qa['review']};(D/'CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2))
 manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in D.iterdir() if p.is_file() and p.name!='SHA256.json'};(D/'SHA256.json').write_text(json.dumps(manifest,indent=2));print('Source MiB:',round((D/'source.zip').stat().st_size/1024**2,2),'delivery files:',len(manifest)+1,flush=True)
if __name__=='__main__':main()
