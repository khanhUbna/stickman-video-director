"""Original story-specific cutaway animation. Saved speech only; no generation calls."""
from pathlib import Path
from functools import lru_cache
import math,json,bisect,subprocess,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parent;O=B/'output';W,H=1280,720;FPS=30
INK='#163b50';BLUE='#20b5e1';DARK='#0e749b';GOLD='#ffc84d';WHITE='#fffdf4';MINT='#d9f0e4';CORAL='#ed9079'
DATA=json.loads((B/'timeline.json').read_text());C=DATA['cues'];D=DATA['duration'];STARTS=[r['start'] for r in C]
def ease(x):x=max(0,min(1,x));return x*x*(3-2*x)
def lerp(a,b,u):return a+(b-a)*ease(u)
def P(p):return tuple(round(v) for v in p)
def line(g,pts,c=INK,w=5):g.line([P(p) for p in pts],fill=c,width=w,joint='curve')
def ellipse(g,bb,c,outline=None,w=3):g.ellipse(P(bb),fill=c,outline=outline,width=w)
def box(g,bb,c,outline=None,w=3,r=12):g.rounded_rectangle(P(bb),radius=r,fill=c,outline=outline,width=w)
def poly(g,pts,c,outline=None,w=3):
 g.polygon([P(p) for p in pts],fill=c)
 if outline:line(g,pts+[pts[0]],outline,w)
@lru_cache(None)
def font(n):return ImageFont.truetype(str(B/'fonts/DejaVuSans-Bold.ttf'),n)
def txt(g,p,s,n=24,c=INK,anchor='mm'):g.text(P(p),s,font=font(n),fill=c,anchor=anchor)
def arrow(g,a,b,c=INK,w=5):
 a=np.array(a,float);b=np.array(b,float);v=b-a;v/=max(1,np.linalg.norm(v));n=np.array([-v[1],v[0]])
 line(g,[a,b-v*10],c,w);poly(g,[b,b-v*19+n*10,b-v*19-n*10],c)
def pathpoint(path,d):
 ls=[math.dist(a,b) for a,b in zip(path,path[1:])];total=sum(ls);d=d%total
 for a,b,L in zip(path,path[1:],ls):
  if d<=L:
   v=(np.array(b)-a)/L;return np.array(a)+v*d,v
  d-=L
 return np.array(path[-1]),np.array([1,0])
def pipe(g,pts,t,flow=True,w=30,color=BLUE):
 line(g,pts,INK,w+8);line(g,pts,'#c4e4e5',w+2);line(g,pts,color,w-8)
 if flow:
  for d in np.arange(0,sum(math.dist(a,b) for a,b in zip(pts,pts[1:])),68):
   p,v=pathpoint(pts,d+t*95);n=np.array([-v[1],v[0]]);poly(g,[p+v*9,p-v*6+n*5,p-v*6-n*5],'#d0f6ff')
def face(g,x,y,s=1,mood='happy',talk=False,t=0):
 blink=(t%4.7)>.1
 for xx in [x-21*s,x+21*s]:
  if blink:ellipse(g,(xx-8*s,y-12*s,xx+8*s,y+6*s),WHITE,INK,2);ellipse(g,(xx-2*s,y-7*s,xx+4*s,y+3*s),INK)
  else:line(g,[(xx-7*s,y),(xx+7*s,y)],INK,3)
 if talk:ellipse(g,(x-13*s,y+15*s,x+13*s,y+(25+10*abs(math.sin(t*17)))*s),INK)
 else:g.arc(P((x-17*s,y+3*s,x+17*s,y+31*s)),0,180,fill=INK,width=max(2,int(3*s)))
def chain(root,hand,L,pole):
 a=np.array(root,float);b=np.array(hand,float);v=b-a;d=np.linalg.norm(v);v/=max(d,.001);d=min(d,L*1.98)
 mid=(a+b)/2+pole*np.array([-v[1],v[0]])*math.sqrt(max(0,L*L-d*d/4));return [a,mid,b]
@lru_cache(None)
def sprite(expr,h):
 im=Image.open(B/f'art/{expr}.png').convert('RGBA');return im.resize((round(im.width*h/im.height),h),Image.Resampling.LANCZOS)
def drop(im,x,y,t,h=170,expr='normal',pose='talk',u=0,flip=False):
 # y denotes body's bottom; limbs are separate, fixed-length two-bone chains.
 g=ImageDraw.Draw(im);s=h/170;bob=3*s*math.sin(t*3);y+=bob
 spr=sprite(expr,h);sw=spr.width;walk=pose=='walk';wave=math.sin(t*7) if walk else math.sin(t*2.8)*.3
 ellipse(g,(x-64*s,y+49*s,x+65*s,y+65*s),'#c3d6d0')
 for k in [-1,1]:
  root=(x+k*23*s,y-15*s);foot=(x+k*38*s+(wave*15*s*k if walk else 0),y+51*s-(max(0,wave*k)*19*s if walk else 0))
  line(g,chain(root,foot,43*s,k),INK,max(3,round(6*s)));line(g,[foot,(foot[0]+17*s,foot[1]+2*s)],INK,max(4,round(7*s)))
 for k in [-1,1]:
  root=(x+k*sw*.38,y-h*.43)
  if pose=='panic':hand=(x+k*(sw*.6),y-h*.9+math.sin(t*13+k)*8*s)
  elif pose=='point' and k==1:hand=(x+sw*.68,y-h*.65)
  elif pose=='push' and k==1:hand=(x+sw*.68,y-h*.38)
  elif pose=='pressleft' and k==-1:hand=(x-sw*.68,y-h*.38)
  else:hand=(x+k*sw*.68,y-h*.24+wave*22*s*k)
  line(g,chain(root,hand,47*s,k),INK,max(3,round(6*s)));ellipse(g,(hand[0]-6*s,hand[1]-6*s,hand[0]+6*s,hand[1]+6*s),WHITE,INK,max(2,round(2*s)))
 im.alpha_composite(spr,(round(x-sw/2),round(y-h)))
 return ImageDraw.Draw(im)
def pump(g,x,y,t,s=1,on=True,talk=False):
 box(g,(x-88*s,y+62*s,x+88*s,y+98*s),GOLD,INK,4);box(g,(x-60*s,y+95*s,x+60*s,y+130*s),'#7b9699',INK,4)
 ellipse(g,(x-86*s,y-85*s,x+86*s,y+86*s),GOLD,INK,5);ellipse(g,(x-65*s,y-64*s,x+65*s,y+65*s),'#b9e8eb',INK,4)
 a=t*8 if on else 1.2
 for j in range(5):
  z=a+j*math.tau/5;v=np.array([math.cos(z),math.sin(z)]);n=np.array([-v[1],v[0]]);p=np.array([x,y]);poly(g,[p+v*14*s,p+v*53*s+n*15*s,p+v*55*s-n*6*s,p+v*23*s-n*13*s],DARK,INK,2)
 ellipse(g,(x-15*s,y-15*s,x+15*s,y+15*s),GOLD,INK,3)
 box(g,(x+90*s,y-43*s,x+142*s,y+44*s),'#f9edd2',INK,3);ellipse(g,(x+104*s,y-23*s,x+128*s,y+1*s),'#65c785' if on else CORAL,INK,2)
 txt(g,(x,y-112*s),'PUMP',round(24*s));txt(g,(x+116*s,y+23*s),'ON' if on else 'OFF',max(12,round(15*s)))
 if talk:face(g,x,y+43*s,.6,talk=True,t=t)
def tank(g,x,y,t,s=1,level=.7,talk=False):
 for k in [-1,1]:line(g,[(x+k*82*s,y+100*s),(x+k*104*s,y+270*s)],'#6b8b8a',max(3,round(12*s)))
 line(g,[(x-90*s,y+140*s),(x+100*s,y+260*s),(x+90*s,y+140*s),(x-100*s,y+260*s)],'#72948d',max(3,round(7*s)))
 box(g,(x-112*s,y-106*s,x+112*s,y+112*s),WHITE,INK,5,r=max(4,round(24*s)))
 surface=y+97*s-level*185*s
 pts=[(x-100*s,surface)]+[(x+z*s,surface+2*s*math.sin(z*.06+t*4)) for z in range(-100,101,5)]+[(x+100*s,y+98*s),(x-100*s,y+98*s)]
 poly(g,pts,BLUE);line(g,pts[1:-2],'#baf4f9',3)
 box(g,(x-112*s,y-106*s,x+112*s,y+112*s),None,INK,5,r=max(4,round(24*s)))
 line(g,[(x+74*s,y-106*s),(x+74*s,y-132*s),(x+88*s,y-132*s)],INK,5)
 if talk:face(g,x,y+9*s,.95*s,talk=True,t=t)
 return surface
def faucet(g,x,y,t,s=1,flow=True):
 pipe(g,[(x+100*s,y+160*s),(x+100*s,y-20*s),(x+100*s,y-73*s),(x+65*s,y-100*s),(x+12*s,y-100*s),(x,y-76*s),(x,y-53*s)],t,flow,w=max(13,round(27*s)))
 line(g,[(x+100*s,y-25*s),(x+133*s,y-54*s)],'#8aa7ac',max(5,round(13*s)))
 if flow:
  line(g,[(x,y-52*s),(x,y+105*s)],'#5cd5ee',max(4,round(17*s)))
  for j in range(8):
   yy=y-50*s+((t*240+j*20)%(150))*s;ellipse(g,(x-3*s,yy-5*s,x+3*s,yy+6*s),'#e4ffff')
  for j in range(6):
   u=(t*2+j/6)%1;xx=x+(-1 if j%2 else 1)*(9+35*u)*s;yy=y+105*s-35*s*math.sin(u*math.pi);ellipse(g,(xx-3*s,yy-4*s,xx+3*s,yy+4*s),BLUE)
def bathroom(g,t):
 box(g,(65,115,1215,580),'#e9f4f0',INK,3)
 for x in range(70,1220,95):line(g,[(x,120),(x,575)],'#c8dfd8',2)
 for y in range(120,580,95):line(g,[(70,y),(1210,y)],'#c8dfd8',2)
 box(g,(820,140,1115,310),'#bee6ec',INK,4);line(g,[(846,281),(1040,161)],'#efffff',5)
 box(g,(670,465,1180,498),'#b6c9c9',INK,4);poly(g,[(720,498),(1130,498),(1085,567),(765,567)],WHITE,INK,4)
def hills(g,t):
 ellipse(g,(-100,235,800,770),'#bfdcc2');ellipse(g,(480,220,1530,800),'#cfe8bd');box(g,(-10,455,1290,610),'#decea8',r=0)
 for x in [70,170,1070,1180]:
  line(g,[(x,460),(x,320)],'#8d7555',13);ellipse(g,(x-52,245,x+52,365),'#81b999')
 for j in range(3):
  x=(j*490+t*5)%1500-100;ellipse(g,(x,150+j*22,x+140,185+j*22),'#fffdf5')
def reservoir(g,t):
 hills(g,t);poly(g,[(0,360),(330,320),(725,358),(1020,580),(0,580)],'#59c6e6',INK,3)
 for j in range(11):
  x=(j*97+t*15)%740;y=390+(j*37)%150;line(g,[(x,y),(x+45,y+math.sin(t*3+j)*3)],'#bceff4',3)
 box(g,(900,300,1220,520),'#d9e1d6',INK,4);box(g,(880,275,1240,315),CORAL,INK,4);txt(g,(1060,370),'WATER WORKS',23)
def plantroom(g,kind):
 box(g,(45,125,1235,580),'#eaf3e9',INK,3)
 for x in [80,380,680,980]:box(g,(x,150,x+230,230),'#c7e4df',INK,2)
 line(g,[(45,530),(1235,530)],'#8aa9a1',4)
def microbe(g,x,y,r,t,color=CORAL):
 for j in range(8):
  a=j*math.pi/4+t*.3;line(g,[(x+math.cos(a)*r,y+math.sin(a)*r),(x+math.cos(a)*r*1.5,y+math.sin(a)*r*1.5)],color,3)
 ellipse(g,(x-r,y-r,x+r,y+r),color,INK,2);ellipse(g,(x-r*.25,y-r*.2,x+r*.15,y+r*.2),INK)
def filterbox(g,t):
 box(g,(520,190,1110,530),WHITE,INK,4)
 for y,col in [(270,'#d9bf7e'),(340,'#b0a58d'),(420,'#7f938c')]:
  box(g,(530,y,1100,y+64),col,r=0)
  for j in range(25):
   x=540+(j*61)%550;yy=y+8+(j*17)%45;ellipse(g,(x,yy,x+9,yy+5),'#f1e1b7')
 for j in range(15):
  x=550+(j*41)%530;yy=205+(t*95+j*27)%310;line(g,[(x,yy),(x,yy+15)],BLUE,3)
 txt(g,(815,154),'FILTRATION',26)
def shower(g,x,y,t,on=True):
 pipe(g,[(x+75,y+240),(x+75,y),(x,y)],t,on,w=19);ellipse(g,(x-27,y-7,x+27,y+14),'#aac5c8',INK,3)
 if on:
  for j in range(5):
   xx=x+(j-2)*10
   for k in range(6):
    yy=y+20+(t*220+k*31+j*9)%178;line(g,[(xx,yy),(xx-2,yy+11)],BLUE,3)
def washer(g,x,y,t,on=True):
 box(g,(x-95,y-105,x+95,y+115),WHITE,INK,4);box(g,(x-85,y-95,x+85,y-49),'#c4e6e6',INK,2)
 ellipse(g,(x-67,y-38,x+67,y+96),'#a2dce9',INK,4)
 for j in range(3):
  a=t*4+j*2.1 if on else j*2.1;xx=x+35*math.cos(a);yy=y+29+35*math.sin(a);ellipse(g,(xx-20,yy-12,xx+20,yy+12),['#ffc84d','#ed9079','#eefbf7'][j],INK,2)
 ellipse(g,(x+47,y-83,x+65,y-65),'#78bc85' if on else CORAL,INK,2)
def house(g,x,y,s=1):
 box(g,(x-190*s,y-90*s,x+190*s,y+210*s),'#fff0d5',INK,4);poly(g,[(x-215*s,y-90*s),(x,y-240*s),(x+215*s,y-90*s)],CORAL,INK,4)
 for xx in [x-115*s,x+110*s]:box(g,(xx-42*s,y-40*s,xx+42*s,y+45*s),'#aee2e7',INK,3)
 box(g,(x-35*s,y+70*s,x+35*s,y+210*s),'#d4b184',INK,3)
def current(t):return C[max(0,bisect.bisect_right(STARTS,t)-1)]
# A native shot plan; each environment has independently animated mechanisms.
GROUPS=[(1,2,'bath','THE MYSTERY'),(3,5,'boast','THE MYSTERY'),(6,6,'question','THE MYSTERY'),(7,7,'rewind','BACK TO THE SOURCE'),(8,9,'lake','THE RESERVOIR'),(10,10,'intake','THE INTAKE'),(11,13,'sources','DIFFERENT SOURCES'),(14,17,'screen','THE FIRST CHECKPOINT'),(18,19,'plant','LOOKS CAN DECEIVE'),(20,21,'specks','TOO SMALL TO SEE'),(22,22,'floc','A PARTICLE GROUP CHAT'),(23,23,'settle','SETTLING & FILTRATION'),(24,24,'filter','THROUGH THE FILTER'),(25,26,'chlorine','DISINFECTION'),(27,29,'stairs','ONE SMALL PROBLEM'),(30,32,'rotor','MEET THE PUMP'),(33,36,'network','WHO DOES THE WORK?'),(37,37,'systems','MORE THAN ONE DESIGN'),(38,39,'tower','WATER IN WAITING'),(40,41,'rush','MORNING RUSH'),(42,44,'head','THE ANSWER'),(45,48,'team','STORAGE HAS LIMITS'),(49,51,'ground','UNDER YOUR STREET'),(52,53,'home','THE LAST CONNECTION'),(54,55,'full','ALREADY WAITING'),(56,56,'valve','OPEN THE TAP'),(57,59,'contract','EVERY TOOTHBRUSH?'),(60,62,'return','DELIVERY!'),(63,64,'thanks','TEAM EFFORT'),(65,65,'brush','THE CUSTOMER'),(66,66,'drain','NEXT DEPARTMENT')]
def shot(t):
 r=current(t);i=r['id'];gr=next(z for z in GROUPS if z[0]<=i<=z[1]);a=C[gr[0]-1]['start'];return r,gr,t-a
def render_scene(im,t):
 g=ImageDraw.Draw(im);r,gr,u=shot(t);i=r['id'];name=gr[2];talk=r['start']<=t<=r['end'];role=r['role'] if talk else '';expr='surprised' if i in [6,17,20,29,35,40,42,65,66] else 'happy' if i in [8,16,22,32,45,61] else 'normal'
 if name in ['bath','question','return','brush']:
  bathroom(g,t);faucet(g,825,350,t,.72,True)
  if name=='bath':
   pump(g,280,360,t,.8,False,role=='PUMP');txt(g,(285,520),'OFF',24,CORAL)
  elif name=='question':
   g=drop(im,540,465,t,195,'surprised','point');txt(g,(310,230),'PUMP: OFF',29,CORAL);txt(g,(310,278),'TAP: RUNNING',24,DARK)
  elif name=='return':
   g=drop(im,lerp(510,700,u/3),440,t,160,'happy','walk');pump(g,260,355,t,.65,False,role=='PUMP')
  else:
   # Contact is visible: the bristles intercept the droplet, then it falls to drain.
   line(g,[(705,438),(1055,438)],'#e77f68',20)
   for xx in range(730,840,10):line(g,[(xx,438),(xx,400)],WHITE,5)
   fall=ease((t-r['end'])/4.9);g=drop(im,lerp(790,920,fall),lerp(400,555,fall),t,115 if not fall else round(115-45*fall),expr,'panic')
 elif name=='boast':
  plantroom(g,'pump');pipe(g,[(80,430),(450,430),(450,300),(1100,300)],t,False);pump(g,510,350,t,1.35,False,role=='PUMP');tank(g,1075,315,t,.6,.65,role=='TANK');txt(g,(255,210),'ALL ME.',45,DARK)
 elif name in ['rewind','lake','intake']:
  reservoir(g,t)
  if name=='rewind':
   for j in [0,1]:poly(g,[(550+j*100,240),(480+j*100,290),(550+j*100,340)],GOLD,INK,3)
   txt(g,(640,470),'EARLIER...',40,WHITE)
  elif name=='lake':g=drop(im,lerp(260,470,u/5),420+8*math.sin(t*2),t,160,'happy','talk');ellipse(g,(240,465,530,490),'#b5edf5')
  else:
   pipe(g,[(200,470),(500,470),(760,410),(1020,410)],t,w=110);g=drop(im,lerp(270,690,u/4),493,t,100,'surprised','panic');arrow(g,(650,255),(900,335),DARK);txt(g,(755,215),'INTAKE',30)
 elif name=='sources':
  for j,(label,col) in enumerate([('RIVER','#a9d9b7'),('RESERVOIR','#cde5b3'),('GROUNDWATER','#dac5a2')]):
   x=55+j*410;box(g,(x,155,x+375,520),col,INK,3);txt(g,(x+187,190),label,25)
   if j==0:
    for k in range(6):pipe(g,[(x+60,270+k*25),(x+200,310+k*25),(x+320,265+k*25)],t,w=17)
   elif j==1:
    ellipse(g,(x+30,270,x+350,450),'#4cc4e6',INK,3);poly(g,[(x+290,255),(x+340,255),(x+340,460),(x+290,420)],'#819ca0',INK,3)
   else:
    box(g,(x+20,280,x+355,470),'#bda780',r=0);pipe(g,[(x+270,235),(x+270,440),(x+60,440)],t,w=25);txt(g,(x+155,355),'AQUIFER',20,WHITE)
  g=drop(im,650,575,t,85,expr,'point')
 elif name=='screen':
  plantroom(g,'screen');pipe(g,[(80,385),(1170,385)],t,w=180)
  for x in range(650,760,21):line(g,[(x,260),(x,510)],'#6c8b8e',10)
  xx=lerp(420,630,u/4);ellipse(g,(xx-31,330,xx+31,350),'#719c51',INK,2)
  for k in [-1,1]:line(g,[(xx-15,344),(xx-23,358+k*6),(xx-32,358+k*6)],INK,2)
  g=drop(im,lerp(280,850,u/7),433,t,133,'surprised' if i==17 else expr,'walk');txt(g,(1035,260),'LARGE DEBRIS',23);txt(g,(1035,296),'STAYS HERE',23)
 elif name=='plant':
  plantroom(g,'plant');g=drop(im,380,465,t,220,expr,'talk');box(g,(800,210,1100,495),CORAL,INK,5);face(g,950,320,1.4,role=='FILTER',talk=role=='FILTER',t=t);txt(g,(950,450),'QUALITY CONTROL',19,WHITE)
  for j in range(9):microbe(g,630+j%3*30,300+j//3*44,7,t)
 elif name in ['specks','floc']:
  box(g,(65,135,1215,580),'#b9edf1',INK,4)
  center=np.array([820.,360.]);progress=ease(u/5) if name=='floc' else 0
  for j in range(24):
   a=j*2.399;rad=120+70*math.sin(j*1.7);start=np.array([800+rad*1.7*math.cos(a),360+rad*math.sin(a)]);target=center+np.array([math.cos(a),math.sin(a)])*(12+24*(j%4));p=start*(1-progress)+target*progress+np.array([4*math.sin(t*2+j),4*math.cos(t*2+j)])
   ellipse(g,(p[0]-8,p[1]-8,p[0]+8,p[1]+8),['#bc986e',CORAL,'#a8b67b'][j%3],INK,2)
  g=drop(im,300,470,t,205,expr,'point')
  if name=='floc':
   box(g,(660,170,1030,225),WHITE,INK,3);txt(g,(845,197),'24 particles joined',24)
 elif name=='settle':
  dur=r['end']-r['start'];phase=u/max(dur,1)
  if phase<.48:
   box(g,(100,170,1170,540),'#a9e0ec',INK,4);box(g,(108,496,1162,530),'#b99e79',r=0)
   for j in range(16):
    xx=180+(j*61)%900;yy=lerp(240+(j*17)%140,480,u/2.8)
    for k in range(5):ellipse(g,(xx+k*8-5,yy+(k%2)*8-5,xx+k*8+5,yy+(k%2)*8+5),'#ae8a67',INK,1)
   arrow(g,(1060,285),(1060,445),DARK);txt(g,(640,140),'HEAVIER CLUMPS SINK',28)
  else:plantroom(g,'filter');filterbox(g,t);g=drop(im,300,430,t,180,'happy','point')
 elif name=='filter':
  plantroom(g,'filter');filterbox(g,t);g=drop(im,310,460,t,185,expr,'point')
 elif name=='chlorine':
  plantroom(g,'disinfection');box(g,(220,235,1120,520),'#b4e9f1',INK,4);pipe(g,[(130,400),(220,400)],t,w=50);pipe(g,[(1120,400),(1210,400)],t,w=50)
  box(g,(580,142,735,230),'#f8d56c',INK,3);txt(g,(658,175),'CONTROLLED',16);txt(g,(658,204),'DOSE',21);line(g,[(658,230),(658,275)],INK,9)
  for j in range(12):
   x=280+(j*83+t*30)%780;y=300+(j*37)%155;fade=(j+u*1.8)%12
   if fade<5:microbe(g,x,y,11,t)
   else:ellipse(g,(x-4,y-4,x+4,y+4),'#efffff')
  g=drop(im,150,530,t,130,expr,'point');txt(g,(870,182),'CONTACT TIME MATTERS',20,DARK)
 elif name=='stairs':
  hills(g,t);pts=[(520,520),(600,520),(600,440),(680,440),(680,360),(760,360),(760,280),(840,280),(840,200),(980,200)];line(g,pts,INK,10)
  u1=min(1,u/5);xx=lerp(300,540,u1);yy=lerp(470,425,u1) if u<3 else lerp(425,492,(u-3)/1.5)
  g=drop(im,xx,yy,t,180,expr,'walk' if u<3 else 'panic');pump(g,1050,420,t,.7,False,role=='PUMP')
 elif name=='rotor':
  plantroom(g,'rotor');pipe(g,[(70,430),(520,430),(520,230),(1180,230)],t,w=65);pump(g,560,360,t,1.45,True,role=='PUMP');g=drop(im,1030,470,t,180,expr,'point')
  box(g,(110,180,365,265),WHITE,INK,3);txt(g,(238,208),'ENERGY IN',26);arrow(g,(145,242),(330,242),CORAL,5)
 elif name in ['network','systems']:
  hills(g,t);house(g,1030,350,.58);tank(g,690,275,t,.65,.72,role=='TANK');pump(g,220,430,t,.75,True,role=='PUMP')
  pipe(g,[(300,440),(500,440),(500,185),(640,185),(640,230)],t,w=24);pipe(g,[(730,345),(730,540),(1080,540),(1080,455)],t,w=24)
  if name=='systems':
   pipe(g,[(320,455),(430,455),(430,570),(1100,570),(1100,455)],t,w=19);txt(g,(390,280),'DIRECT PUMPING',22);txt(g,(805,140),'WITH STORAGE',22)
  else:g=drop(im,430,490,t,125,expr,'point')
 elif name in ['tower','team']:
  hills(g,t);tank(g,800,290,t,.95,max(.3,.76-u*.012),role=='TANK');pump(g,260,425,t,.75,name=='tower',role=='PUMP');pipe(g,[(345,430),(500,430),(500,180),(730,180),(730,235)],t,name=='tower',w=26);g=drop(im,520,500,t,145,expr,'point')
  if name=='team':txt(g,(1010,550),'REFILL REQUIRED',22,DARK)
 elif name=='rush':
  for j in range(3):box(g,(45+j*410,145,425+j*410,565),'#e4f2ed',INK,3)
  on1=u>.25;on2=u>1.05;on3=u>1.85
  shower(g,180,240,t,on1);shower(g,590,240,t,on2);washer(g,1050,370,t,on3)
  for j,on in enumerate([on1,on2,on3]):txt(g,(235+j*410,185),['SHOWER 1','SHOWER 2','LAUNDRY'][j],23)
  pump(g,500,510,t,.38,False,role=='PUMP');g=drop(im,690,550,t,95,'surprised','panic')
 elif name=='head':
  hills(g,t);level=max(.62,.86-u*.015);surface=tank(g,340,275,t,.9,level,role=='TANK');assert surface<325-53*.9;pipe(g,[(405,365),(405,555),(1060,555),(1060,445)],t,w=30);faucet(g,970,325,t,.9,True);pump(g,130,475,t,.45,False);pipe(g,[(180,475),(210,475),(210,156),(290,156),(290,215)],t,False,w=17)
  if i>=43:
   line(g,[(470,surface),(1185,surface)],'#83babc',3);line(g,[(470,278),(470,95)],'#83babc',1) if False else None
   arrow(g,(655,surface+4),(655,277),CORAL);txt(g,(760,300),'GRAVITY',30,DARK);txt(g,(950,surface-22),'HIGHER WATER LEVEL',20)
  g=drop(im,770,520,t,130,expr,'point')
 elif name=='ground':
  house(g,970,310,.7);box(g,(0,490,1280,590),'#c1a77c',r=0);line(g,[(0,488),(1280,488)],'#758e7c',6);pipe(g,[(40,550),(1140,550)],t,w=45)
  for j in range(30):
   x=(j*131)%1280;y=510+(j*19)%65;ellipse(g,(x,y,x+7,y+3),'#a18967')
  g=drop(im,lerp(170,580,u/7),557,t,90,expr,'walk');txt(g,(310,245),'BELOW THE STREET',30)
 elif name=='home':
  house(g,870,330,.9);box(g,(0,535,1280,595),'#cfb993',r=0);pipe(g,[(40,570),(900,570),(900,420),(1040,420)],t,w=38);pipe(g,[(900,570),(900,590)],t,w=30);g=drop(im,lerp(200,760,u/5),570,t,100,expr,'walk');txt(g,(300,310),'SERVICE CONNECTION',26);arrow(g,(400,360),(730,540),DARK)
 elif name=='full':
  pipe(g,[(70,330),(1190,330)],t,w=250)
  for j in range(6):g=drop(im,160+j*180+8*math.sin(t+j),380,t,100,'normal','talk')
  txt(g,(640,165),'THE PIPES ARE ALREADY FULL',33);txt(g,(640,535),'No restart for every tap.',25,DARK)
 elif name=='valve':
  pipe(g,[(55,370),(1220,370)],t,w=135);angle=lerp(math.pi/2,0,u/1.8);a=np.array([730,370]);v=np.array([math.cos(angle),math.sin(angle)])*68
  ellipse(g,(640,280,820,460),'#d2e8e2',INK,5);line(g,[a-v,a+v],CORAL,14);line(g,[(730,280),(730,220)],INK,10);line(g,[(690,220),(770,220)],'#84a5a9',15)
  g=drop(im,lerp(300,1030,u/4),405,t,123,'happy','walk');txt(g,(640,155),'AN OPEN PATH',32)
 elif name=='contract':
  bathroom(g,t);pump(g,330,360,t,.95,False,role=='PUMP');faucet(g,870,335,t,.78,True)
  box(g,(500,225,720,450),WHITE,INK,3);txt(g,(610,260),'CONTRACT',22)
  for j in range(4):line(g,[(525,300+j*27),(690,300+j*27)],'#9ab6b5',3)
  g=drop(im,570,548,t,120,expr,'point')
 elif name=='thanks':
  plantroom(g,'team');pump(g,230,370,t,.8,False,role=='PUMP');box(g,(530,240,730,480),CORAL,INK,4);face(g,630,340,1.2,talk=role=='FILTER',t=t);txt(g,(630,210),'FILTER',24);tank(g,1040,310,t,.65,.55,role=='TANK')
 elif name=='drain':
  box(g,(40,130,1240,580),'#e8e1d4',INK,4);pipe(g,[(80,250),(580,250),(580,430),(1160,430)],t,w=130,color='#a8bdc0');txt(g,(310,160),'DRAIN',30)
  g=drop(im,lerp(200,720,u/2),lerp(275,440,u/2),t,110,'surprised','panic');face(g,1000,425,1.6,talk=True,t=t)
  arrow(g,(1080,335),(1190,335),INK);txt(g,(1010,530),'TO WASTEWATER TREATMENT',19)
 return gr
def caption_parts(r):
 text=r['text'];words=text.split();parts=[];s=''
 for word in words:
  if font(29).getlength((s+' '+word).strip())>1090 and s:parts.append(s);s=word
  else:s=(s+' '+word).strip()
 if s:parts.append(s)
 return parts
CAP=[]
for r in C:
 parts=caption_parts(r);n=sum(len(x.split()) for x in parts);a=r['start']
 for s in parts:
  b=a+r['duration']*len(s.split())/n;CAP.append({'start':a,'end':b,'text':s,'speaker':r['role'],'cue':r['id']});a=b
def frame(t):
 im=Image.new('RGBA',(W,H),'#fff9ed');gr=render_scene(im,t);g=ImageDraw.Draw(im)
 box(g,(0,0,1280,92),WHITE,r=0);txt(g,(35,32),'WHERE YOUR TAP WATER COMES FROM',22,INK,'lm');txt(g,(35,66),gr[3],17,DARK,'lm')
 txt(g,(1240,47),f'{GROUPS.index(gr)+1:02d} / {len(GROUPS)}',19,'#5f817d','rm')
 line(g,[(35,603),(1245,603)],'#d6e1d6',3);line(g,[(35,603),(35+1210*t/D,603)],DARK,3)
 cue=next((c for c in CAP if c['start']<=t<c['end']),None)
 if cue:
  tw=font(29).getlength(cue['text']);box(g,(640-tw/2-22,632,640+tw/2+22,690),INK,r=16);txt(g,(640,662),cue['text'],29,WHITE)
  txt(g,(640,618),cue['speaker'],13,{'DROP':DARK,'PUMP':'#9b6e19','TANK':'#3e8065','FILTER':'#ab5c4c'}.get(cue['speaker'],DARK))
 return im.convert('RGB')
def render():
 n=math.ceil(D*FPS);p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'picture.mp4')],stdin=subprocess.PIPE)
 for i in range(n):
  p.stdin.write(frame(i/FPS).tobytes())
  if i%300==0:print(f'Frame {i}/{n}',flush=True)
 p.stdin.close();assert p.wait()==0
 (O/'caption-cues.json').write_text(json.dumps(CAP,indent=2));(O/'shots.json').write_text(json.dumps([{'id':j+1,'scene':z[2],'title':z[3],'first_cue':z[0],'last_cue':z[1],'start':C[z[0]-1]['start'],'end':C[z[1]]['start'] if z[1]<len(C) else D} for j,z in enumerate(GROUPS)],indent=2))
if __name__=='__main__':
 if len(sys.argv)>1:
  for j,z in enumerate(GROUPS):frame(C[z[0]-1]['start']+.7).save(O/f'shot-{j+1:02d}.jpg')
 else:render()
