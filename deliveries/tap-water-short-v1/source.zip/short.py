"""Native portrait story layout. All pictures and sound authored for this Short."""
from pathlib import Path
from functools import lru_cache
import math,json,subprocess,wave,re,hashlib,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import drawing as A
B=Path(__file__).resolve().parent;O=B/'output';W,H=1080,1920;FPS=30;D=32;SR=48000
O.mkdir(parents=True,exist_ok=True)
DOC=json.loads((B/'timeline.json').read_text());C=DOC['cues'];INK=A.INK;BLUE=A.BLUE;GOLD=A.GOLD;WHITE=A.WHITE;TEAL=A.DARK
SCENES=[(0,4.65,'off','PUMP OFF.'),(4.65,6.25,'earlier','EARLIER...'),(6.25,12.6,'gravity','GRAVITY TAKES OVER.'),(12.6,15.2,'waiting','WATER IN WAITING.'),(15.2,19.6,'level','THE LEVEL FALLS.'),(19.6,23.3,'refill','BACK TO WORK.'),(23.3,26.5,'team','TEAMWORK.'),(26.5,32,'supervise','STILL SUPERVISING.')]
PARTS={4:["You're switched off."],6:["If you're off,","why is the water","still running?"],43:["Pump filled me earlier.","Now gravity keeps","the water moving."],44:["My water level is higher","than those taps."],45:["You're a giant waiting room","for water."],46:["A useful one.","But my level falls","as water leaves."],47:["Which is why somebody","has to refill you."],48:["There you go.","Teamwork."],5:["I'm supervising."]}
def run(cmd):return subprocess.run(cmd,capture_output=True,check=True)
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def align():
 from pocketsphinx import Decoder
 captions=[];allwords=[]
 for r in C:
  p=B/r['file'];dst=B/f"audio/{r['source_cue']:02d}-16k.wav";run(['ffmpeg','-v','error','-y','-i',str(p),'-ar','16000','-ac','1',str(dst)])
  tokens=re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",r['text']);d=Decoder(samprate=16000,loglevel='ERROR');missing=[w for w in tokens if not d.lookup_word(w.lower())];assert not missing,missing
  d.set_align_text(' '.join(w.lower() for w in tokens))
  with wave.open(str(dst)) as w:data=w.readframes(w.getnframes())
  d.start_utt();d.process_raw(data,full_utt=True);d.end_utt();segs=[s for s in d.seg() if s.word not in ['<sil>','<s>','</s>','[SPEECH]','[NOISE]']];assert len(segs)==len(tokens),(r['source_cue'],len(segs),len(tokens))
  words=[]
  for token,s in zip(tokens,segs):
   assert re.sub(r'\(\d+\)$','',s.word)==token.lower()
   words.append({'word':token,'start':r['start']+s.start_frame/100,'end':min(r['end'],r['start']+(s.end_frame+1)/100)})
  k=0
  for text in PARTS[r['source_cue']]:
   n=len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",text));part=words[k:k+n];k+=n;captions.append({'start':part[0]['start'],'end':min(r['end'],part[-1]['end']+.06),'text':text,'speaker':r['role']})
  assert k==len(words);allwords.extend(words)
 for i in range(len(captions)-1):captions[i]['end']=min(captions[i]['end'],captions[i+1]['start'])
 (O/'caption-cues.json').write_text(json.dumps(captions,indent=2));(O/'words.json').write_text(json.dumps({'method':'offline acoustic forced alignment, no paid API','words':allwords},indent=2))
 return captions
CAP=json.loads((O/'caption-cues.json').read_text()) if (O/'caption-cues.json').exists() else []
def label(g,x,y,text,n=50,c=INK):A.txt(g,(x,y),text,n,c)
def tag(g,x,y,text,color=TEAL):
 width=A.font(31).getlength(text);A.box(g,(x-width/2-22,y-25,x+width/2+22,y+25),WHITE,INK,3);label(g,x,y,text,31,color)
def background(im,t,room=False):
 g=ImageDraw.Draw(im);A.box(g,(0,0,W,H),'#fff9ed',r=0)
 if room:
  A.box(g,(40,390,1000,1260),'#e8f3ef',INK,4)
  for x in range(40,1000,120):A.line(g,[(x,390),(x,1260)],'#d0e4dc',2)
  for y in range(390,1260,120):A.line(g,[(40,y),(1000,y)],'#d0e4dc',2)
 else:
  A.ellipse(g,(-500,850,950,2100),'#d9e9d0');A.ellipse(g,(430,850,1650,2100),'#c8e4ce');A.box(g,(0,1210,W,1310),'#e9d6b6',r=0)
  for j in [0,1]:
   x=(j*570+t*6)%1400-150;A.ellipse(g,(x,370,x+180,420),'#fffef9')
 return g
def level_head(t):return max(.59,.84-(t-6.25)*.018)
def main_frame(t):
 scene=next(z for z in SCENES if z[0]<=t<z[1]);name=scene[2];u=t-scene[0];im=Image.new('RGBA',(W,H));g=background(im,t,name in ['off','supervise'])
 active=next((r for r in C if r['start']<=t<=r['end']),None);role=active['role'] if active else ''
 label(g,510,130,'EVERYDAY, EXPLAINED',28,TEAL)
 if name=='off':
  label(g,510,250,'PUMP OFF.',90);label(g,510,345,'WATER STILL FLOWS?',53,TEAL)
  A.pump(g,250,730,t,1.4,False,role=='PUMP');A.faucet(g,730,690,t,1.28,True)
  A.box(g,(100,930,360,1005),'#f9ddd1',INK,4);label(g,230,968,'OFF',53,'#b4483a')
  g=A.drop(im,520,1120,t,250,'surprised','point');label(g,750,1110,'?',110,'#c8533d')
 elif name=='earlier':
  label(g,510,250,'EARLIER...',74);surface=A.tank(g,740,670,t,1.25,.40+.28*A.ease(u/1.6),role=='TANK')
  A.pipe(g,[(350,1080),(440,1080),(440,470),(650,470),(650,630)],t,True,w=42);A.line(g,[(650,630),(650,max(630,surface))],'#7cdef1',10);A.pump(g,250,1080,t,1.15,True)
  g=A.drop(im,215,690,t,210,'normal','point');tag(g,200,825,'PUMP: ON')
 elif name=='gravity':
  label(g,510,250,'GRAVITY TAKES OVER.',60,TEAL)
  lev=level_head(t);surface=A.tank(g,560,570,t,1.3,lev,role=='TANK');tapout=950-53*1.15;assert surface<tapout
  A.pipe(g,[(645,705),(645,1200),(835,1200),(835,1134)],t,True,w=40);A.faucet(g,720,950,t,1.15,True)
  A.pump(g,190,1115,t,.72,False);tag(g,185,1240,'OFF','#b4483a')
  A.line(g,[(100,surface),(900,surface)],'#84b6b8',4);A.arrow(g,(240,surface+22),(240,tapout-20),'#dc8d51',6);tag(g,250,800,'HIGHER')
  g=A.drop(im,385,1080,t,190,'happy','point');label(g,500,1210,'FLOWING',30,TEAL)
 elif name in ['waiting','level']:
  label(g,510,250,scene[3],67,TEAL);lev=(.69 if name=='waiting' else .69-.047*u);A.tank(g,570,660,t,1.5,lev,role=='TANK')
  A.pipe(g,[(675,810),(675,1240),(880,1240),(880,1100)],t,True,w=36);A.faucet(g,790,960,t,.9,True)
  g=A.drop(im,215,1090,t,220,'happy' if name=='waiting' else 'surprised','point')
  if name=='waiting':
   A.box(g,(100,470,320,540),WHITE,INK,3);label(g,210,505,'WAIT HERE',29)
  else:
   A.arrow(g,(850,570),(850,730),'#dc8d51',7);tag(g,260,620,'LEVEL FALLING')
 elif name in ['refill','team']:
  on=t>=20.4;label(g,510,250,scene[3],75,TEAL);level=.44+.28*A.ease((t-20.4)/6.1);surface=A.tank(g,750,665,t,1.2,level,role=='TANK');A.pipe(g,[(360,1100),(445,1100),(445,470),(680,470),(680,610)],t,on,w=40);A.pump(g,250,1090,t,1.15,on,role=='PUMP')
  if on:A.line(g,[(680,610),(680,max(610,surface))],'#7cdef1',10)
  tag(g,240,1270,'PUMP: ON' if on else 'PUMP: OFF');x=A.lerp(610,492,(t-19.6)/.8) if name=='refill' else 492;g=A.drop(im,x,1147,t,210,'effort' if name=='refill' else 'happy','pressleft' if name=='refill' else 'point')
 else:
  label(g,510,250,'STILL SUPERVISING.',64,TEAL);A.pump(g,250,730,t,1.4,False,role=='PUMP');A.faucet(g,730,690,t,1.28,True)
  g=A.drop(im,520,1120,t,250,'happy','talk');tag(g,230,970,'OFF','#b4483a')
  if t>29:label(g,510,1210,'NOW YOU KNOW WHY.',35,TEAL)
 # Single-line, acoustically timed phrase captions in portrait-safe space.
 cue=next((r for r in CAP if r['start']<=t<r['end']),None)
 if cue:
  words=cue['text'];width=A.font(51).getlength(words);assert width<900,(words,width)
  A.box(g,(510-width/2-25,1380,510+width/2+25,1470),INK,r=22);label(g,510,1425,words,51,WHITE)
  label(g,510,1340,cue['speaker'],24,TEAL)
 A.line(g,[(75,1535),(945,1535)],'#d0ded0',5);A.line(g,[(75,1535),(75+870*t/D,1535)],TEAL,5)
 if name=='supervise' and t>29.5:label(g,510,1600,'More everyday mysteries →',30,TEAL)
 return im.convert('RGB')
def render():
 global CAP
 CAP=align();p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'picture.mp4')],stdin=subprocess.PIPE)
 for i in range(D*FPS):
  p.stdin.write(main_frame(i/FPS).tobytes())
  if i%180==0:print(f'Portrait frame {i}/{D*FPS}',flush=True)
 p.stdin.close();assert p.wait()==0
def audio_finish():
 n=D*SR;rng=np.random.default_rng(18112026);voice=np.zeros(n,np.float32);music=np.zeros(n,np.float32);amb=np.zeros(n,np.float32);fx=np.zeros(n,np.float32);active=np.zeros(n,np.float32)
 def wav(path,x):
  with wave.open(str(path),'wb') as w:w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(x,-.97,.97)*32767).astype('<i2').tobytes())
 for r in C:
  with wave.open(str(B/r['file'])) as w:x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
  x*=min(1.7,.13/max(.001,np.sqrt(np.mean(x*x))));a=round(r['start']*SR);voice[a:a+len(x)]+=x;active[max(0,a-2000):a+len(x)+5000]=1
 t=np.arange(n,dtype=np.float32)/SR;noise=rng.normal(0,1,n).astype(np.float32);water=np.convolve(noise,np.ones(17,np.float32)/17,'same');amb+=.02*water
 motor=((t>=4.65)&(t<6.25))|((t>=20.4)&(t<26.5));amb+=(.008*np.sin(math.tau*118*t)+.004*water)*motor
 for j,at in enumerate(np.arange(0,D,.48)):
  note=[62,69,66,69,59,66,62,66][j%8]+(12 if j//16%2 else 0);f=440*2**((note-69)/12);tt=np.arange(round(.8*SR),dtype=np.float32)/SR;sig=(np.sin(math.tau*f*tt)+.15*np.sin(math.tau*2*f*tt))*np.exp(-tt*7)*np.minimum(1,tt/.009);a=round(at*SR);m=min(len(sig),n-a);music[a:a+m]+=.013*sig[:m]
 events=[]
 for at,kind in [(4.65,'pump_start'),(6.25,'pump_stop'),(15.2,'level_reveal'),(20.4,'pump_start'),(26.5,'pump_stop')]:
  tt=np.arange(round(.1*SR),dtype=np.float32)/SR;a=round(at*SR);sig=rng.normal(0,1,len(tt)).astype(np.float32)*np.exp(-tt*65);fx[a:a+len(sig)]+=.025*sig;events.append({'time':at,'kind':kind,'source':'original synthetic cartoon click'})
 fade=np.minimum(1,(n-1-np.arange(n))/(SR*.35)).astype(np.float32);music*=fade*(1-.5*active);amb*=fade
 for name,x in [('dialogue',voice),('music-original',music),('ambience-original',amb),('foley-original',fx)]:wav(B/f'audio/{name}.wav',x)
 wav(B/'audio/mix.wav',voice+music+amb+fx)
 p=run(['ffmpeg','-hide_banner','-nostats','-i',str(B/'audio/mix.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-f','null','-']);levels=json.loads(re.findall(rb'\{[^{}]+\}',p.stderr)[-1]);flt='loudnorm=I=-16:TP=-1.5:LRA=8:'+':'.join(f'{k}={levels[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
 run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix.wav'),'-af',flt,'-ar',str(SR),'-ac','2',str(B/'audio/master.wav')])
 dst=O/'pump-off-water-still-flows-short.mp4';run(['ffmpeg','-v','error','-y','-i',str(O/'picture.mp4'),'-i',str(B/'audio/master.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(D),'-movflags','+faststart',str(dst)])
 cap=json.loads((O/'caption-cues.json').read_text());(O/'captions-en.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(r['start'])} --> {stamp(r['end'])}\n{r['text']}" for i,r in enumerate(cap))+'\n')
 (O/'captions-vi.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(r['start'])} --> {stamp(r['end'])}\n{r['vi']}" for i,r in enumerate(C))+'\n',encoding='utf-8-sig')
 (O/'sound-rights.json').write_text(json.dumps({'dialogue':'Nine saved native voice clips from water-full-v1. No revoicing or paid API calls.','music':'Original locally composed plucked arrangement','ambience_and_foley':'Original local synthesis; no third-party recordings','events':events,'new_paid_calls':0},indent=2))
 print('Portrait MP4 and subtitle sidecars saved',flush=True)
def qa():
 dst=O/'pump-off-water-still-flows-short.mp4';run(['ffmpeg','-v','error','-i',str(dst),'-f','null','-']);probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(dst)]).stdout);v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio');assert [v['width'],v['height'],v['nb_frames']]==[W,H,str(D*FPS)];assert abs(float(a['duration'])-D)<.05
 raw=run(['ffmpeg','-hide_banner','-nostats','-i',str(dst),'-af','loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-f','null','-']);loud=json.loads(re.findall(rb'\{[^{}]+\}',raw.stderr)[-1]);assert float(loud['input_tp'])<-.5
 out={'title':DOC['title'],'duration':D,'dimensions':[W,H],'fps':FPS,'frames':D*FPS,'full_decode':'pass','audio_video_duration_match':'pass','new_paid_API_calls':0,'caption_alignment':'Offline PocketSphinx acoustic forced alignment','caption_cues':len(json.loads((O/'caption-cues.json').read_text())),'native_portrait':'Separately authored scene positions and paths; not a crop of landscape frames','scientific_scope':'One elevated vented storage example; stored water above tap, pump off during gravity proof; time compressed and not to scale. Not all supplies use this design.','loudness':loud,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size,'review':{'author':'Source and decoded final frame inspection','independent':'not performed','real_time_AV_listening':'not performed'},'youtube_upload':False};(O/'QA.json').write_text(json.dumps(out,indent=2));(O/'shots.json').write_text(json.dumps(SCENES,indent=2));print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':
 mode=sys.argv[1] if len(sys.argv)>1 else 'all'
 if mode=='stills':
  for j,z in enumerate(SCENES):main_frame(z[0]+.7).save(O/f'shot-{j+1:02d}.jpg')
 elif mode=='finish':audio_finish();qa()
 else:render();audio_finish();qa()
