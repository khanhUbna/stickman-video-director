from pathlib import Path
import json,subprocess,hashlib
import numpy as np
from PIL import Image,ImageDraw
import short as S
B=S.B;O=S.O;MOV=O/'pump-off-water-still-flows-short.mp4'
def frame(t):
 p=subprocess.run(['ffmpeg','-v','error','-ss',str(t),'-i',str(MOV),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True);return Image.fromarray(np.frombuffer(p.stdout,np.uint8).reshape((1920,1080,3)))
def main():
 samples=[]
 for phase,f in enumerate([.2,.8]):
  sheet=Image.new('RGB',(1080,1000),'#ffffff');g=ImageDraw.Draw(sheet)
  for j,z in enumerate(S.SCENES):
   t=z[0]+(z[1]-z[0])*f;im=frame(t);im.save(O/f'decoded-{j+1:02d}-{phase+1}.jpg',quality=90);thumb=im.resize((270,480),Image.Resampling.LANCZOS);x=j%4*270;y=j//4*500;sheet.paste(thumb,(x,y));g.text((x+6,y+481),f'{z[2]} @ {t:.2f}s',fill='black');samples.append({'scene':z[2],'time':t})
  sheet.save(O/f'decoded-review-{phase+1}.jpg',quality=94)
 # Actual encoded proof: the stopped impeller stays still while the stream changes.
 a=np.array(frame(.4));b=np.array(frame(.9));diff=np.abs(a.astype(float)-b.astype(float))
 stopped=float(diff[620:830,140:365].mean());water=float(diff[650:815,720:745].mean());assert stopped<2.5,(stopped,water);assert water>.2,(stopped,water)
 for at in [20.33,20.47]:frame(at).crop((315,980,560,1190)).resize((735,630)).save(O/f'switch-contact-{at:.2f}.jpg',quality=95)
 frame(.8).save(O/'cover.jpg',quality=95)
 gravity_times=np.linspace(6.25,12.59,50);head=[950-53*1.15-(570+97*1.3-S.level_head(t)*185*1.3) for t in gravity_times];assert min(head)>0;assert S.level_head(12.59)<S.level_head(6.25)
 cap=json.loads((O/'caption-cues.json').read_text());assert len(cap)==19;assert all(cap[j]['end']<=cap[j+1]['start']+.001 for j in range(len(cap)-1));assert max(S.A.font(51).getlength(r['text']) for r in cap)<900
 q={'sha256':hashlib.sha256(MOV.read_bytes()).hexdigest(),'decoded_samples':samples,'stopped_impeller_mean_pixel_difference':stopped,'flowing_stream_mean_pixel_difference':water,'minimum_schematic_height_head_pixels':min(head),'caption_single_line_width_pass':True,'caption_non_overlap_pass':True,'switch_contact_times':[20.33,20.47],'limits':'Picture comparisons exclude captions; metrics do not establish natural acting, independent review or real-time listening.'};(O/'decoded-motion-checks.json').write_text(json.dumps(q,indent=2));print(json.dumps(q,indent=2),flush=True)
if __name__=='__main__':main()
