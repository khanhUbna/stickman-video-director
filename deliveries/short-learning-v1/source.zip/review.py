from pathlib import Path
import json,subprocess,hashlib
from PIL import Image,ImageDraw
import numpy as np
import film as F
B=F.B;O=F.O;MOV=O/'why-you-forget-what-you-just-learned.mp4'
def frame(t):
 p=subprocess.run(['ffmpeg','-v','error','-ss',str(t),'-i',str(MOV),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True);return Image.fromarray(np.frombuffer(p.stdout,np.uint8).reshape((1280,720,3)))
def main():
 samples=[]
 for phase,f in enumerate([.2,.8]):
  sheet=Image.new('RGB',(960,3*447),'#ffffff');g=ImageDraw.Draw(sheet)
  for j,(name,a,b) in enumerate(F.BOUNDS):
   t=a+(b-a)*f;im=frame(t);im.save(O/f'decoded-{j+1:02d}-{phase+1}.jpg',quality=90);im=im.resize((240,427));x=j%4*240;y=j//4*447;sheet.paste(im,(x,y));g.text((x+4,y+430),f'{name} {t:.2f}s',fill='black');samples.append({'scene':name,'time':t})
  sheet.save(O/f'decoded-review-{phase+1}.jpg',quality=94)
 event=[]
 for name,at in [('pause',F.HIDE),('recheck',F.REOPEN),('hide',F.SECOND_HIDE)]:
  for side,dt in [('before',-.10),('after',.10)]:
   im=frame(at+dt);im.save(O/f'screen-{name}-{side}.jpg',quality=94);event.append({'event':name,'time':at+dt,'side':side})
 frame(3.05).save(O/'cover.jpg',quality=95)
 norm=lambda s:''.join(c.lower() for c in s if c.isalpha());assert norm((B/'script.txt').read_text())==norm(' '.join(c['text'] for c in F.C));assert all(F.C[i]['end']<=F.C[i+1]['start']+.001 for i in range(len(F.C)-1))
 rows=json.loads((O/'motion-picture.json').read_text());feet={side:np.asarray(rows[0]['legs'][side]['joints'][-1]) for side in ['left','right']};drift=max(np.linalg.norm(np.asarray(r['legs'][s]['joints'][-1])-feet[s]) for r in rows for s in feet);assert drift<1e-8
 # Reclassify trace contact from the actual visible hand endpoint, not a near-contact threshold.
 for r in rows:
  error=float(np.linalg.norm(np.asarray(r['arms']['right']['joints'][-1])-F.BUTTON));r['tap_contact']=error<1e-7;r['screen_contact_error']=error if r['tap_contact'] else None
 (O/'motion-picture.json').write_text(json.dumps(rows))
 diffs=[]
 for name,a,b in F.BOUNDS:
  aa=np.array(frame(a+(b-a)*.2))[:850];bb=np.array(frame(a+(b-a)*.8))[:850];diffs.append({'scene':name,'picture_mean_difference':float(np.abs(aa.astype(float)-bb).mean())})
 (O/'decoded-review.json').write_text(json.dumps({'sha256':hashlib.sha256(MOV.read_bytes()).hexdigest(),'samples':samples,'screen_events':event,'caption_coverage':'pass','fixed_foot_max_drift':float(drift),'picture_checks':diffs,'review':'Author inspects decoded before/after frames, source paths and contact evidence; no independent creative review or real-time AV listening claimed'},indent=2));print(json.dumps({'decoded_story_samples':len(samples),'screen_transition_samples':len(event),'fixed_foot_max_drift':drift,'subtitle_text_coverage':'pass'}),flush=True)
if __name__=='__main__':main()
