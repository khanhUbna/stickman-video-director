from pathlib import Path
import json,subprocess,wave,re,math,hashlib
import numpy as np
import film as F
B=F.B;O=F.O;SR=48000;N=round(F.D*SR)
def run(args):return subprocess.run(args,check=True,capture_output=True)
def wav(p,x):
 with wave.open(str(p),'wb') as w:w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(x,-.98,.98)*32767).astype('<i2').tobytes())
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def measure(p):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(p),'-af','loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-f','null','-']);return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
def main():
 rng=np.random.default_rng(181119);voice=np.zeros(N,np.float32);music=np.zeros(N,np.float32);fx=np.zeros(N,np.float32)
 with wave.open(str(B/'audio/voice.wav')) as w:x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
 a=round(.12*SR);voice[a:a+len(x)]=x
 def add(bus,at,sig,gain):
  a=round(at*SR);n=min(len(sig),N-a)
  if n>0:bus[a:a+n]+=sig[:n]*gain
 def pluck(freq,dur=1.):
  t=np.arange(round(SR*dur),dtype=np.float32)/SR;sig=np.zeros(len(t),np.float32)
  for h in range(1,7):sig+=np.sin(math.tau*freq*h*t+rng.uniform(-.06,.06))*np.exp(-t*(3.2+.8*h))/h**1.6
  return sig*np.minimum(1,t/.003)
 for j,at in enumerate(np.arange(.03,F.D-.2,.55)):
  note=[57,64,60,64,53,60,57,60][j%8]+12;add(music,at,pluck(440*2**((note-69)/12),.9),.010)
 events=[]
 for j,at in enumerate(F.STRUM):
  wrong=j<2;chord=[45,52,58 if wrong else 57,60,64]
  for k,m in enumerate(chord):add(fx,at+k*.010,pluck(440*2**((m-69)/12),.23 if wrong else 1.15),.027 if wrong else .023)
  events.append({'time':at,'kind':'muted_wrong_chord' if wrong else 'clear_chord','source':'Original local plucked-string synthesis','reason':'Visible string crossing and outcome, not background decoration'})
 for at,kind in [(F.HIDE,'pause_and_hide'),(F.REOPEN,'recheck_one_step'),(F.SECOND_HIDE,'hide_again')]:
  t=np.arange(round(.065*SR),dtype=np.float32)/SR;sig=rng.normal(0,1,len(t)).astype(np.float32)*np.exp(-t*75);add(fx,at,sig,.027);events.append({'time':at,'kind':kind,'source':'Original local stylized tap synthesis'})
 amb=np.convolve(rng.normal(0,1,N).astype(np.float32),np.ones(29,np.float32)/29,'same')*.004
 fade=np.minimum(1,np.arange(N)/(SR*.025))*np.minimum(1,(N-1-np.arange(N))/(SR*.35))
 for name,stem in [('dialogue',voice),('music-original',music),('foley-original',fx),('ambience-original',amb)]:wav(B/f'audio/{name}.wav',stem*fade)
 wav(B/'audio/mix.wav',(voice+music+fx+amb)*fade)
 pre=measure(B/'audio/mix.wav');flt='loudnorm=I=-16:TP=-1.5:LRA=8:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
 run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix.wav'),'-af',flt,'-ar',str(SR),'-ac','2',str(B/'audio/master.wav')])
 dst=O/'why-you-forget-what-you-just-learned.mp4';run(['ffmpeg','-v','error','-y','-i',str(O/'picture.mp4'),'-i',str(B/'audio/master.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','160k','-t',str(F.D),'-movflags','+faststart',str(dst)])
 (O/'captions-en.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(F.C))+'\n')
 vi=['Bạn đã xem','hết video hướng dẫn.', 'Vậy sao bạn không chơi được','ngay hợp âm đầu tiên?','Nhìn các bước','có thể khiến bạn tưởng','mình đã biết làm.','Nhưng nhận ra một động tác','không giống với','tự thực hiện nó.','Thử thế này:','dừng video lại.','Chơi một hợp âm','mà không nhìn hướng dẫn.','Bí rồi à?','Xem lại đúng bước đó.','Rồi tắt màn hình','và thử lại.','Đừng đo việc học','bằng cảm giác dễ hiểu','khi nghe giải thích.','Hãy xem bạn tự làm được gì','khi phần hướng dẫn','không còn trước mắt.']
 assert len(vi)==len(F.C);(O/'captions-vi.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{vi[i]}" for i,c in enumerate(F.C))+'\n',encoding='utf-8-sig')
 run(['ffmpeg','-v','error','-i',str(dst),'-f','null','-']);pr=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(dst)]).stdout);v=next(x for x in pr['streams'] if x['codec_type']=='video');a=next(x for x in pr['streams'] if x['codec_type']=='audio');assert [v['width'],v['height'],v['nb_frames']]==[720,1280,str(round(F.D*30))];assert abs(float(v['duration'])-float(a['duration']))<.05
 rows=json.loads((O/'motion-picture.json').read_text());assert len(rows)==round(F.D*30)
 errs=[abs(length-target) for r in rows for side,l in r['arms'].items() for length,target in zip(l['lengths'],[64*F.R.S,62*F.R.S])]+[abs(length-80*F.R.S) for r in rows for side,l in r['legs'].items() for length in l['lengths']]
 assert max(errs)<1e-7
 # Classify actual contact from the rendered endpoint, excluding near-contact approach frames.
 contacts=[r for r in rows if np.linalg.norm(np.asarray(r['arms']['right']['joints'][-1])-F.BUTTON)<1e-7]
 assert contacts and max(float(np.linalg.norm(np.asarray(r['arms']['right']['joints'][-1])-F.BUTTON)) for r in contacts)<1e-7
 assert max(r['left_fret_target_error'] for r in rows)<1e-7
 post=measure(dst);assert float(post['input_tp'])<-.5
 cost=json.loads((B/'audio/request.json').read_text());qa={'title':F.T['title'],'duration':float(v['duration']),'dimensions':[720,1280],'fps':30,'frames':len(rows),'full_decode':'pass','audio_video_duration_match':'pass','caption_alignment':'Offline PocketSphinx acoustic forced alignment','caption_profile':F.T['caption_profile'],'motion':{'max_bone_length_error':max(errs),'screen_contact_frames':len(contacts),'maximum_screen_contact_error':max(r['screen_contact_error'] for r in contacts),'left_fret_target_error':max(r['left_fret_target_error'] for r in rows),'fixed_foot_support':'Both feet remain at [819,1045], [886,1045]; torso lean/weight transfer and prop contacts animate independently of camera','shots':len(F.BOUNDS)},'sound':{'voice':'Native tts-1 alloy, speed 1; one saved response','new_tts_calls':1,'estimated_tts_usd':cost['estimated_usd'],'new_image_calls':1,'image_billing':'Not exposed','music_and_foley':'Original local synthesis; no third-party recordings','loudness':post},'visual_scope':'User-supplied prior channel frame and existing green-vest identity/action extension. No assertion of canonical B6 35-subcheck or independent acceptance.','review':{'author':'Source poses and decoded final frame review','independent':'not performed','real_time_AV_listening':'not performed'},'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size,'youtube_upload':False};(O/'QA.json').write_text(json.dumps(qa,indent=2));(O/'sound-rights.json').write_text(json.dumps({'events':events,'music':'Original additive plucked arrangement, no copied song','ambience':'Original low-level synthetic room air','dialogue':'OpenAI native Alloy, saved file retained; no picture-driven revoicing','art':'Existing channel protagonist and one new generated painted set, source reference and prompt retained in chat','font':'Archivo Black, included OFL'},indent=2));print(json.dumps(qa,indent=2),flush=True)
if __name__=='__main__':main()
