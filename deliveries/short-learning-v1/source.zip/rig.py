"""Story-specific articulated action extension for the established painted B6 cast.

The installed standing-only B6 runtime remains untouched. This new local renderer
implements fixed-length two-bone legs, swing/stance gait, sitting and rising. Its
own geometry/contact evidence is reported separately; no installed B6 approval
or independent creative acceptance is inferred.
"""
from pathlib import Path
from functools import lru_cache
import json,math,sys,subprocess,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
from caption_renderer import CaptionRenderer
B=Path(__file__).resolve().parent;W,H=720,1280;WORLD=1500;FPS=30
T=json.loads((B/'timeline.json').read_text());D=T['duration'];INK='#202936';S=1.45
P=B/'characters/protagonist';PACK=json.loads((P/'package.json').read_text())
def ease(x):x=max(0.,min(1.,x));return x*x*(3-2*x)
def mix(a,b,u):return np.asarray(a,float)*(1-u)+np.asarray(b,float)*u
def env(t,keys):
 if t<=keys[0][0]:return keys[0][1]
 for (a,x),(b,y) in zip(keys,keys[1:]):
  if t<=b:return x+(y-x)*ease((t-a)/(b-a))
 return keys[-1][1]
def rotate(p,a):
 a=math.radians(a);x,y=p;return np.array([math.cos(a)*x-math.sin(a)*y,math.sin(a)*x+math.cos(a)*y])
def ip(p):return tuple(round(float(v)) for v in p)
def line(g,pts,fill=INK,width=7):g.line([ip(p) for p in pts],fill=fill,width=round(width),joint='curve')
def curve(points,n=35):
 p=np.asarray(points,float);return [((1-t)**3*p[0]+3*(1-t)**2*t*p[1]+3*(1-t)*t*t*p[2]+t**3*p[3]).tolist() for t in np.linspace(0,1,n)]
def polygon(g,pts,fill,outline='#56483f',width=3):
 g.polygon([ip(p) for p in pts],fill=fill);line(g,pts+[pts[0]],outline,width)
FONT=str(B/'fonts/ArchivoBlack.ttf')
def font(n):return ImageFont.truetype(FONT,n)

def room(night=False):
 """Original continuous living room, separate wall/window/furniture regions."""
 im=Image.new('RGBA',(WORLD,H),'#d9c5aa');g=ImageDraw.Draw(im)
 # Wall paint: local, stable pigment texture; no animated noise overlays.
 a=np.asarray(im).copy();rng=np.random.default_rng(9021)
 grain=rng.normal(0,1.4,(H,WORLD,1));a[:,:,:3]=np.clip(a[:,:,:3]+grain,0,255).astype('uint8');im=Image.fromarray(a);g=ImageDraw.Draw(im)
 g.rectangle((0,975,WORLD,H),fill='#b88960');g.rectangle((0,964,WORLD,982),fill='#856854')
 for y in [1010,1070,1140,1230]:g.line((0,y,WORLD,y+12),fill='#9c7155',width=2)
 for x in [0,290,620,1010,1330]:g.line((x,985,x+60,1280),fill='#a87c59',width=2)
 # Entry and hall.
 polygon(g,[(90,325),(350,316),(350,975),(92,974)],'#8f9d90','#5d6357',7)
 polygon(g,[(113,345),(329,338),(327,950),(112,950)],'#aab6a2','#626d61',3)
 g.rounded_rectangle((135,378,305,650),12,outline='#7b8c78',width=3)
 g.ellipse((294,695,308,709),fill='#d3b66e',outline='#6a5b41',width=2)
 # Coatrack and bag make tomorrow's work visually present.
 g.line((410,600,410,994),fill='#6b5c4d',width=9);line(g,[(375,643),(410,665),(447,630)],'#6b5c4d',7)
 g.rounded_rectangle((366,692,443,805),13,fill='#6d7d86',outline='#384b55',width=4)
 g.arc((382,676,428,721),180,360,fill='#384b55',width=6)
 # Deep window with quiet, independently moving curtain in frame().
 polygon(g,[(524,320),(920,318),(920,716),(524,718)],'#8a7058','#6d594b',6)
 g.rectangle((539,336,905,700),fill='#27384b' if night else '#b9d4d9')
 if night:
  g.ellipse((810,362,846,398),fill='#f2e8b6')
  for x,y in [(580,367),(698,386),(873,463),(630,465),(758,355)]:g.ellipse((x,y,x+3,y+3),fill='#ece4c2')
 else:
  g.ellipse((803,368,865,430),fill='#f1d49a')
  for x,y in [(570,402),(740,460)]:g.ellipse((x,y,x+110,y+24),fill='#e7e5d7')
 for x,h in [(548,102),(609,140),(680,80),(746,120),(837,159)]:g.rectangle((x,700-h,x+61,700),fill='#626f7c' if night else '#90a2a0')
 g.rectangle((713,334,727,704),fill='#9b8061');g.rectangle((537,504,908,515),fill='#9b8061')
 g.rectangle((506,710,938,731),fill='#8b6b50')
 # Painting and wall clock, legible at the wide and medium compositions.
 polygon(g,[(1010,355),(1231,352),(1234,522),(1008,524)],'#f0e5cb','#8c7156',6)
 polygon(g,[(1026,502),(1106,418),(1160,458),(1215,403),(1214,506)],'#83947a','#83947a',1)
 g.ellipse((1147,373,1179,405),fill='#dcb76c')
 g.ellipse((1280,350,1400,470),fill='#eee4d0',outline='#795f4e',width=6)
 # Sofa: varied irregular contours, soft cushions, visible seat support.
 polygon(g,[(828,727),(841,681),(873,664),(1298,667),(1332,700),(1337,921),(830,925)],'#b47864','#795649',5)
 for x in [858,1080]:
  g.rounded_rectangle((x,694,x+205,867),23,fill='#c18b71',outline='#9b6c57',width=3)
  g.arc((x+25,710,x+184,831),0,170,fill='#b47b63',width=2)
 g.rounded_rectangle((826,864,1342,936),25,fill='#d1a084',outline='#795649',width=5)
 g.line((1080,881,1080,932),fill='#a27560',width=3)
 g.rounded_rectangle((798,785,851,957),24,fill='#b78169',outline='#795649',width=5)
 g.rounded_rectangle((1318,785,1371,957),24,fill='#b78169',outline='#795649',width=5)
 for x in [835,1320]:polygon(g,[(x,947),(x+22,947),(x+18,1005),(x+3,1005)],'#685346','#685346',2)
 # Large rug and side table. No desk or kitchen repeat.
 g.ellipse((445,994,1410,1192),fill='#9b9e88',outline='#788471',width=4)
 g.ellipse((474,1011,1380,1172),outline='#c0bda2',width=3)
 for x in [1129,1241]:line(g,[(x,853),(x-8 if x<1200 else x+8,1000)],'#735640',7)
 polygon(g,[(1105,829),(1266,829),(1283,858),(1092,858)],'#c9a16e','#735640',4)
 # A warm floor lamp and plant add depth without stealing attention.
 line(g,[(1455,546),(1455,986)],'#786651',7);g.ellipse((1415,978,1490,994),fill='#786651')
 polygon(g,[(1415,451),(1497,451),(1520,557),(1390,557)],'#ead5a2','#9e8863',4)
 g.ellipse((1410,548,1506,565),fill='#efdba9')
 g.rounded_rectangle((460,875,538,1000),12,fill='#b07d58',outline='#775b47',width=3)
 for x,y,r in [(477,830,-20),(514,806,20),(482,773,-28),(524,747,22)]:
  line(g,[(500,892),(x,y)],'#5c7351',5);g.ellipse((x-25,y-25,x+25,y+25),fill='#7e9063',outline='#5c7351',width=2)
 # Subtle static material grain is spatially attached to the wall/floor.
 if night:
  veil=Image.new('RGBA',im.size,(22,35,60,45));im=Image.alpha_composite(im,veil)
 return im

def guitar_asset():
 im=Image.new('RGBA',(500,400));g=ImageDraw.Draw(im);o=np.array([315.,265.])
 def q(p):return (o+np.asarray(p)).tolist()
 shape=[]
 for pts in [[[-8,-75],[-57,-103],[-87,-50],[-66,-17]],[[-66,-17],[-35,10],[-100,28],[-74,67]],[[-74,67],[-35,116],[50,111],[76,63]],[[76,63],[101,22],[51,0],[61,-29]],[[61,-29],[80,-72],[23,-96],[-8,-75]]]:shape+=curve([q(p) for p in pts])
 polygon(g,shape,'#c5904d','#4d4037',5)
 inner=[(o+(np.array(p)-o)*.91).tolist() for p in shape];line(g,inner,'#e3b976',2)
 polygon(g,[q(p) for p in [[-49,-57],[-199,-182],[-219,-166],[-66,-32]]],'#75513b','#4d4037',4)
 polygon(g,[q(p) for p in [[-200,-184],[-235,-207],[-251,-193],[-221,-162]]],'#bc8f55','#4d4037',4)
 for k in range(3):
  c=q([-239+k*9,-197+k*8]);g.ellipse((c[0]-5,c[1]-5,c[0]+5,c[1]+5),fill='#ddd2af',outline='#665640',width=2)
  c=q([-228+k*9,-207+k*8]);g.ellipse((c[0]-5,c[1]-5,c[0]+5,c[1]+5),fill='#ddd2af',outline='#665640',width=2)
 g.ellipse((o[0]-31,o[1]-41,o[0]+29,o[1]+19),fill='#483a31',outline='#e1bf7c',width=5)
 polygon(g,[q(p) for p in [[18,-20],[49,3],[30,37],[-2,14]]],'#846045','#846045',1)
 line(g,[q([-13,49]),q([20,20])],'#493a31',9)
 for k in range(6):
  d=(k-2.5)*1.6;line(g,[q([-230+d,-189-d]),q([7+d,37-d])],'#e7d6ab',1)
 for k in range(8):
  a=mix([-196,-174],[-57,-46],k/8);v=np.array([5.,-5.]);line(g,[q(a-v),q(a+v)],'#c5ac7a',1)
 # Wood pigment follows the instrument, not the screen.
 rng=np.random.default_rng(222)
 for j in range(32):
  x=float(rng.uniform(-58,55));y=float(rng.uniform(30,65));line(g,[q([x,y]),q([x+10,y+7])],'#b17b42',1)
 return im

DAY=room(False);NIGHT=room(True);GUITAR=guitar_asset()
DAY.save(B/'art/living-room-day.png');NIGHT.save(B/'art/living-room-night.png');GUITAR.save(B/'art/guitar.png')

@lru_cache(maxsize=100)
def sprite(view,part,variant='normal'):
 v=PACK['views'][view];a=v['sprites'][part]
 if part=='head' and variant=='worried':a=PACK['views']['front']['sprites']['heads']['worried']
 im=Image.open(P/a['path']).convert('RGBA');m=np.array(a['image_to_local'])
 scale=m[0,0]*S
 im=im.resize((round(im.width*scale),round(im.height*scale)),Image.Resampling.LANCZOS)
 offset=np.array([m[0,2],m[1,2]+92])*S
 return im,offset

def transformed(im,center,source_center,scale=1.,angle=0):
 # Transform on a small transparent tile, not a frame-sized affine warp.
 if scale!=1:
  im=im.resize((max(1,round(im.width*scale)),max(1,round(im.height*scale))),Image.Resampling.LANCZOS);source_center=np.asarray(source_center)*scale
 else:source_center=np.asarray(source_center)
 mid=np.array(im.size)/2
 rr=im.rotate(-angle,resample=Image.Resampling.BICUBIC,expand=True)
 c=np.asarray(center)+rotate(mid-source_center,angle)-np.array(rr.size)/2
 return rr,ip(c)
def composite(im,layer,pos):im.alpha_composite(layer,pos)
def draw_sprite(im,view,part,hip,angle,variant='normal'):
 spr,off=sprite(view,part,variant)
 pivot=-off
 layer,pos=transformed(spr,hip,pivot,angle=angle)
 composite(im,layer,pos)

def ik(root,target,lengths,pole,name):
 root=np.asarray(root,float);target=np.asarray(target,float);v=target-root;d=float(np.linalg.norm(v));a,b=lengths
 if not abs(a-b)+.01<d<a+b-.01:raise ValueError(f'{name}: unreachable d={d:.2f} reach={a+b:.2f}')
 unit=v/d;along=(a*a-b*b+d*d)/(2*d);height=math.sqrt(max(0,a*a-along*along));joint=root+unit*along+pole*np.array([-unit[1],unit[0]])*height
 return np.array([root,joint,target])

def gait(x,travel,side,direction=1):
 stride=190.;p=(abs(travel)/stride+(0 if side=='left' else .5))%1
 if p<.6:
  dx=stride*(.3-p);y=1045.;planted=True
 else:
  u=(p-.6)/.4;dx=-stride*.3+stride*.6*ease(u);y=1045.-32*math.sin(math.pi*u);planted=False
 return np.array([x+direction*dx, y]),planted

def guitar(im,center,angle=0,scale=1):
 layer,pos=transformed(GUITAR,center,[315,265],scale,angle);composite(im,layer,pos)
 def grip(p):return np.asarray(center)+rotate(np.asarray(p)*scale,angle)
 return {'left':grip([-185,-157]),'right':grip([0,-10])}

def phone(im,center,angle=0,face=True):
 tile=Image.new('RGBA',(72,114));g=ImageDraw.Draw(tile)
 g.rounded_rectangle((7,4,64,109),10,fill='#26313b',outline='#111d28',width=4)
 if face:
  g.rounded_rectangle((12,13,59,99),5,fill='#9fc3ce');g.rectangle((16,27,55,51),fill='#d7ab7f');g.rectangle((16,61,55,85),fill='#7b9e91');g.line((27,19,44,19),fill='#243b46',width=3)
 else:
  g.rounded_rectangle((14,13,30,35),4,fill='#52606a');g.ellipse((18,17,26,25),fill='#0d1822')
 layer,pos=transformed(tile,center,[36,57],.67,angle);composite(im,layer,pos)

def shadow(im,x,y=1047,width=155):
 tile=Image.new('RGBA',(width+40,42));ImageDraw.Draw(tile).ellipse((20,10,width+20,29),fill=(32,34,32,65));tile=tile.filter(ImageFilter.GaussianBlur(7));im.alpha_composite(tile,(round(x-width/2-20),round(y-20)))

RECORDS=[]
def actor(im,hip,view='front',angle=0,head_angle=0,expression='normal',feet=None,wrists=None,walk=None,guitar_pose=None,phone_pose=None,record=False,t=0):
 hip=np.asarray(hip,float);torso=hip+[0,8];v=PACK['views'][view];wrists=dict(wrists or {});chains={};legchains={};supports={}
 def pt(p):return torso+rotate((np.asarray(p)+[0,92])*S,angle)
 for side,leg in v['legs'].items():
  root=hip+np.array([leg['hip'][0]*S,0.])
  if walk is not None:target,plant=gait(hip[0],walk[0],side,walk[1])
  else:target=np.asarray(feet[side] if feet is not None else [hip[0]+(-31 if side=='left' else 36),1045.]);plant=True
  legpole=1 if walk is not None and walk[1]<0 else -1
  legchains[side]=ik(root,target,(80*S,80*S),legpole,'leg:'+side);supports[side]=plant
 for side,a in v['arms'].items():
  root=pt(a['socket']);rest=pt([a['socket'][0]+(-15 if side=='left' else 15),a['socket'][1]+112])
  target=np.asarray(wrists.get(side,rest));pole=-1
  chains[side]=ik(root,target,(64*S,62*S),pole,'arm:'+side)
 # Pressure-varying single ink chains, owned by one actor. No duplicate limbs.
 g=ImageDraw.Draw(im)
 for side,ch in legchains.items():
  line(g,ch,INK,8)
  ankle=ch[-1];toe=-1 if walk is not None and walk[1]<0 else 1;line(g,[ankle+[-4*toe,0],ankle+[17*toe,0]],INK,9)
 for side,ch in chains.items():line(g,ch,INK,8)
 draw_sprite(im,view,'body',torso,angle)
 # The unchanged garment overlays only the real sleeve roots.
 for side,ch in chains.items():
  # Draw from the true sleeve outlet, replacing the root hidden by the shirt.
  outlet=pt(v['arms'][side]['exit_center']);line(ImageDraw.Draw(im),[outlet,ch[1],ch[2]],INK,8)
 # Supported instrument before the foreground wrists/hands.
 if guitar_pose is not None:guitar(im,**guitar_pose)
 if phone_pose is not None:phone(im,**phone_pose)
 g=ImageDraw.Draw(im)
 for side,ch in chains.items():
  # Forearm owns the contact to the visible hand; far guitar arm ends at neck.
  line(g,[mix(ch[1],ch[2],.35),ch[2]],INK,8)
  x,y=ch[-1];g.ellipse((x-7,y-7,x+7,y+7),fill=INK)
 # Head pivots about its actual neck, preserving body overlap while nodding.
 spr,off=sprite(view,'head',expression)
 neck_local=np.array([0.,-158.])*S;neck=torso+rotate(neck_local,angle)
 pivot=neck_local-off
 layer,pos=transformed(spr,neck,pivot,angle=angle+head_angle);composite(im,layer,pos)
 # Tiny eyelid blink is a local face gesture, not a replacement identity.
 if record:
  row={'time':round(t,4),'hip':hip.tolist(),'view':view,'legs':{},'arms':{},'guitar':guitar_pose is not None,'phone':phone_pose is not None}
  for side,ch in legchains.items():row['legs'][side]={'joints':ch.tolist(),'planted':supports[side],'lengths':[float(np.linalg.norm(ch[1]-ch[0])),float(np.linalg.norm(ch[2]-ch[1]))]}
  for side,ch in chains.items():row['arms'][side]={'joints':ch.tolist(),'lengths':[float(np.linalg.norm(ch[1]-ch[0])),float(np.linalg.norm(ch[2]-ch[1]))]}
  if guitar_pose is not None:
   grips={s:np.asarray(guitar_pose['center'])+rotate(np.asarray(p)*guitar_pose.get('scale',1),guitar_pose.get('angle',0)) for s,p in {'left':[-185,-157],'right':[0,-10]}.items()}
   row['grip_errors']={s:float(np.linalg.norm(chains[s][-1]-p)) for s,p in grips.items()}
  RECORDS.append(row)
 return chains

def clock(g,t):
 center=np.array([1340.,410.]);hour=env(t,[(0,18),(6.3,18),(9.0,23.3),(17.3,23.3),(17.65,18.2),(D,18.4)])
 for a,l,w in [(hour/12*360-90,29,5),(hour%1*360-90,43,3)]:
  rad=math.radians(a);line(g,[center,center+[math.cos(rad)*l,math.sin(rad)*l]],'#514c47',w)
 for k in range(12):
  a=2*math.pi*k/12;x,y=center+np.array([math.sin(a),-math.cos(a)])*49;g.ellipse((x-2,y-2,x+2,y+2),fill='#795f4e')

def setdressing(im,t):
 g=ImageDraw.Draw(im);clock(g,t)
 # Curtain tip has a separate gentle air path, independent of camera and actor.
 dx=3*math.sin(t*.7)
 polygon(g,[(513,306),(552,306),(558+dx,729),(513+dx,751)],'#e3d0ab','#ad9475',2)
 polygon(g,[(893,306),(934,306),(941-dx,750),(897-dx,728)],'#e3d0ab','#ad9475',2)
 for x in [520,532,904,917]:line(g,[(x,320),(x+dx,710)],'#c3ad89',2)
 # Stand, always present. The same physical instrument leaves it at pickup.
 line(g,[(655,936),(645,1038)],'#4b4f49',6);line(g,[(655,936),(685,1038)],'#4b4f49',6)
 line(g,[(643,938),(682,938)],'#4b4f49',6)
 # Table phone remains after actual release.
 if t>=20.46:phone(im,[1164,833],angle=84,face=False)

SHOT_BOUNDS=[('enter',0,3.25),('shoes',3.25,4.25),('phone',4.25,5.38),('sit',5.38,6.55),('scroll',6.55,8.12),('late',8.12,9.68),('untouched',9.68,12.05),('regret',12.05,14.8),('rise',14.8,17.65),('next_evening',17.65,19.0),('phone_down',19.0,20.65),('walk_to_guitar',20.65,21.9),('pickup',21.9,23.15),('play',23.15,26.8),('chosen_evening',26.8,D)]
def shot(t):return next(s for s,a,b in SHOT_BOUNDS if a<=t<b+1e-8)

def frame(t,captions=True,record=False):
 sid=shot(t);night=6.6<t<17.65;im=(NIGHT if night else DAY).copy();setdressing(im,t)
 if sid=='shoes':
  # A separately authored shoe close-up. Shoe arcs settle on a fixed floor.
  floor=im.crop((200,775,920,1280)).resize((720,1280),Image.Resampling.LANCZOS);g=ImageDraw.Draw(floor);u=ease((t-3.25)/.7)
  for k in [0,1]:
   x=225+k*200;y=760-200*math.sin(math.pi*u)+100*u
   tile=Image.new('RGBA',(170,85));gg=ImageDraw.Draw(tile);gg.rounded_rectangle((10,22,150,72),18,fill='#79644f',outline='#3e403a',width=6);gg.polygon([(10,50),(10,9),(74,10),(99,44)],fill='#8d785d',outline='#3e403a');gg.line((13,69,152,69),fill='#d4c6a8',width=7)
   rr,pos=transformed(tile,[x,y],[85,42],1,(-25+50*k)*(1-u));floor.alpha_composite(rr,pos)
  out=floor
 else:
  guitar_on_stand=t<22.12
  if guitar_on_stand:guitar(im,[665,860],angle=50,scale=.7)
  view='three_quarter';hip=np.array([900.,817.]);angle=0.;head=0.;expr='normal';feet=None;walk=None;gp=None;pp=None;wrists={}
  if sid=='enter':
   u=ease(t/3.25);x=290+610*u;travel=x-290;hip=np.array([x,835.-3*math.sin(abs(travel)/190*math.pi*2)**2]);walk=(travel,1)
   swing=math.sin(abs(travel)/190*math.pi*2)
   for s,sgn in [('left',1),('right',-1)]:wrists[s]=hip+np.array([(-80 if s=='left' else 100)+sgn*24*swing,-9+sgn*8*swing])
   head=2.;cam=env(t,[(0,0),(.35,30),(2.8,535),(3.25,540)])
  elif sid in ['phone','sit','scroll','late','regret','rise']:
   cam=570.;u=ease((t-5.38)/1.17)
   hip=np.array([950-50*u,817+83*u]);angle=env(t,[(4.25,0),(5.0,5),(5.38,8),(5.75,16),(6.55,3),(8.12,6),(9.68,-3),(12.05,8),(14.8,11),(15.2,18),(16.7,2),(17.65,0)])
   if sid=='phone':hip=np.array([950.,817.]);u=0
   if sid=='rise':
    u=1-ease((t-15.25)/1.65);hip=np.array([950-50*u,817+83*u])
   feet={'left':[919,1045],'right':[986,1045]}
   phonecenter=hip+np.array([70,-123.]);phoneangle=-8
   if sid=='phone':phonecenter=mix(hip+[110,-20],hip+[70,-123],ease((t-4.25)/1.13))
   if sid=='late':phonecenter+=np.array([0,28*ease((t-8.12)/1.56)])
   if sid=='regret':phonecenter=hip+np.array([80,-82]);expr='worried';view='front';head=-5
   if sid=='rise':phonecenter=hip+np.array([80,-82+40*ease((t-15.25)/1.65)])
   pp={'center':phonecenter,'angle':phoneangle};wrists['right']=phonecenter+np.array([12,20])
   wr=hip+rotate([-85,-25],angle)
   if sid=='scroll':
    scroll=(1+math.sin((t-6.55)*10))/2;wr=phonecenter+[-20,10-12*scroll]
   wrists['left']=wr
   head=head+env(t,[(4.25,2),(5.38,8),(8.12,10),(8.7,-6),(9.68,-4),(12.05,4),(14.8,6),(17.65,0)])
   if sid=='late':cam=env(t,[(8.12,570),(9.1,950),(9.68,950)])
  elif sid=='untouched':
   # Instrument detail, with intact empty stand and late-night setting.
   cam=330.;hip=None
  elif sid=='next_evening':
   u=ease((t-17.65)/1.35);x=650+250*u;hip=np.array([x,835.]);walk=(x-650,1);cam=440+130*u
   pp={'center':hip+[95,-44.],'angle':0};wrists['right']=np.asarray(pp['center'])+[12,20]
   wrists['left']=hip+[-103,-10];head=1
  elif sid=='phone_down':
   u=ease((t-19)/1.46);hip=np.array([900+70*u,835+12*u]);feet={'left':[869,1045],'right':[936,1045]};cam=env(t,[(19,570),(19.8,670),(20.65,670)]);angle=12*u
   pp={'center':mix([995,791],[1164,833],u),'angle':84*u,'face':t<20.15}
   wrists['right']=np.asarray(pp['center'])+[12*(1-u),20*(1-u)]
   if t>=20.46:
    pp=None;wrists['right']=mix([1164,833],[1035,800],ease((t-20.46)/.19))
   wrists['left']=hip+rotate([-85,-25],angle)
  elif sid=='walk_to_guitar':
   u=ease((t-20.65)/1.25);x=970-320*u;hip=np.array([x,835.]);walk=(970-x,-1);cam=670-310*u;view='front'
   swing=math.sin(abs(970-x)/190*math.pi*2)
   wrists={'left':hip+[-104+20*swing,-15],'right':hip+[105-20*swing,-10]}
  elif sid=='pickup':
   cam=330.;view='front';u=ease((t-22.12)/1.03);hip=np.array([650.,env(t,[(21.9,835),(22.12,875),(23.15,817)])]);head=-8*(1-u)
   angle=env(t,[(21.9,0),(22.12,20),(22.7,20),(23.15,0)])
   gp={'center':mix([665,860],[685,795],u),'angle':50*(1-u),'scale':.7+.3*u}
   targets={s:np.asarray(gp['center'])+rotate(np.asarray(p)*gp['scale'],gp['angle']) for s,p in {'left':[-185,-157],'right':[0,-10]}.items()}
   for s in targets:
    rest=hip+[-101 if s=='left' else 101,-9]
    wrists[s]=mix(rest,targets[s],ease((t-21.9)/.22)) if t<22.12 else targets[s]
   if t<22.12:gp=None
  elif sid in ['play','chosen_evening']:
   cam=330. if sid=='play' else env(t,[(26.8,330),(29.8,290),(D,290)])
   view='front';pulse=math.sin((t-23.2)/.58*2*math.pi);hip=np.array([650+3*pulse,817-2*max(0,pulse)]);head=3*pulse;angle=1.2*pulse
   # Brief imperfect-note reaction, then recovery into the same performance.
   surprise=math.exp(-((t-24.58)/.18)**2);head-=12*surprise
   gp={'center':hip+[35,-40],'angle':1.5*pulse,'scale':1.}
   wrists={s:np.asarray(gp['center'])+rotate(np.asarray(p),gp['angle']) for s,p in {'left':[-185,-157],'right':[0,-10]}.items()}
   # The strum hand actually crosses the string area at each audible event.
   at=min(T['strums'],key=lambda a:abs(a-t));stroke=env(t-at,[(-.15,-21),(-.025,-16),(.025,16),(.19,21),(.3,-21)])
   wrists['right']+=rotate([0,stroke],gp['angle'])
   feet={'left':[619,1045],'right':[686,1045]}
  else:raise ValueError(sid)
  if hip is not None:
   shadow(im,hip[0]);actor(im,hip,view,angle,head,expr,feet,wrists,walk,gp,pp,record,t)
  # Warm practical spill, fixed to the actual lamp rather than following actor.
  cam=max(0,min(WORLD-576,cam))
  out=im.crop((round(cam),180,round(cam)+576,1204)).resize((720,1280),Image.Resampling.LANCZOS)
  if sid=='untouched':
   # A motivated close view of the untouched instrument, not a generic icon.
   out=im.crop((425,300,965,1260)).resize((720,1280),Image.Resampling.LANCZOS)
 if captions:
  cue=next((c for c in CUES if c['start']<=t<c['end']),None)
  if cue is not None:out=Image.alpha_composite(out,CR.raster(cue['text'])[0])
 return out.convert('RGB')

CUES=json.loads((B/'captions.json').read_text());CR=CaptionRenderer(B,'9:16',W,H,T['caption_profile'])

def render(start=0,end=None,name='picture.mp4',record=True):
 end=D if end is None else end;n=round((end-start)*FPS);output=B/'output'/name
 cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(output)]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 try:
  for i in range(n):
   t=start+i/FPS;p.stdin.write(frame(t,True,record).tobytes())
   if i%150==0:print(f'Rendered {i}/{n}, t={t:.2f}',flush=True)
  p.stdin.close();code=p.wait();assert code==0,code
 except BaseException:
  p.stdin.close();p.wait();raise
 if record:(B/'output'/('motion-'+Path(name).stem+'.json')).write_text(json.dumps(RECORDS))
 print('Saved',output,flush=True)
 return output

if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='stills':
  for t in [1.7,4.8,5.9,7.3,8.8,10.7,13.0,15.8,18.3,19.9,21.3,22.5,23.8,24.58,29.0]:frame(t,True,True).save(B/f'output/still-{t:.2f}.png')
  print('Saved story/action stills.')
 elif len(sys.argv)>1 and sys.argv[1]=='stress':render(19,27,'action-stress.mp4')
 else:render()
