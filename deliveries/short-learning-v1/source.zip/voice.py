from pathlib import Path
import os,json,urllib.request,urllib.error,subprocess,hashlib,wave
B=Path(__file__).resolve().parent;text=(B/'script.txt').read_text().strip();raw=B/'audio/voice-api.wav';rec=B/'audio/request.json';dst=B/'audio/voice.wav'
if not raw.exists():
 if rec.exists():raise SystemExit('A speech request was already attempted; no automatic paid retry.')
 rec.write_text(json.dumps({'model':'tts-1','voice':'alloy','speed':1,'characters':len(text),'estimated_usd':len(text)*.000015,'state':'attempted','automatic_retry':False,'authorization':'User requested next new English Short in the established psychology channel; estimated TTS cost announced before call'},indent=2))
 req=urllib.request.Request('https://api.openai.com/v1/audio/speech',data=json.dumps({'model':'tts-1','voice':'alloy','speed':1,'input':text,'response_format':'wav'}).encode(),headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=180) as r:raw.write_bytes(r.read())
 except urllib.error.HTTPError as e:raise SystemExit(f'Speech HTTP {e.code}; no retry and no credential logging.') from None
 d=json.loads(rec.read_text());d['state']='saved';d['sha256']=hashlib.sha256(raw.read_bytes()).hexdigest();rec.write_text(json.dumps(d,indent=2))
if not dst.exists():subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-ar','48000','-ac','1',str(dst)],check=True)
with wave.open(str(dst)) as w:duration=w.getnframes()/w.getframerate()
print(json.dumps({'seconds':duration,'characters':len(text),'estimated_usd':len(text)*.000015,'native_speech_saved':True}),flush=True)
