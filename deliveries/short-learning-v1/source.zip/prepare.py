from pathlib import Path
import json,re,wave,subprocess,math
from pocketsphinx import Decoder
from caption_renderer import CaptionRenderer,default_profile
B=Path(__file__).resolve().parent
subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/'audio/voice.wav'),'-ar','16000','-ac','1',str(B/'audio/voice-16k.wav')],check=True)
tokens=re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",(B/'script.txt').read_text());d=Decoder(samprate=16000,loglevel='ERROR');missing=[t for t in tokens if not d.lookup_word(t.lower())];assert not missing,missing;d.set_align_text(' '.join(t.lower() for t in tokens))
with wave.open(str(B/'audio/voice-16k.wav')) as w:data=w.readframes(w.getnframes())
d.start_utt();d.process_raw(data,full_utt=True);d.end_utt();seg=[s for s in d.seg() if s.word not in ['<sil>','<s>','</s>','[SPEECH]','[NOISE]']];assert len(seg)==len(tokens)
words=[]
for token,s in zip(tokens,seg):
 assert re.sub(r'\(\d+\)$','',s.word)==token.lower()
 words.append({'word':token,'start':.12+s.start_frame/100,'end':.12+(s.end_frame+1)/100})
(B/'words.json').write_text(json.dumps({'method':'Offline acoustic forced alignment; no paid transcription','words':words},indent=2))
def at(phrase):
 ts=re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",phrase.lower());all=[w['word'].lower() for w in words]
 for i in range(len(all)-len(ts)+1):
  if all[i:i+len(ts)]==ts:return words[i]['start']
 raise ValueError(phrase)
with wave.open(str(B/'audio/voice.wav')) as w:native=w.getnframes()/w.getframerate()
duration=math.ceil((native+.12+1.0)*30)/30
phases={'watch':0,'recognize':at('Watching the steps'),'contrast':at('But recognizing'),'pause':at('pause the video'),'trial':at('Play one chord'),'stuck':at('Stuck'),'check':at('Check that one step'),'hide':at('Then hide'),'retry':at('and try again'),'measure':at("Don't measure"),'show':at('See what you can do')}
phrases=['You watched','the whole tutorial.',"So why can't you play",'the first chord?','Watching the steps','can feel like','knowing them.','But recognizing a move',"isn't the same",'as doing it.','Try this:','pause the video.','Play one chord','without looking.','Stuck?','Check that one step.','Then hide the screen','and try again.',"Don't measure learning",'by how easy','the explanation feels.','See what you can do','when the explanation','is gone.']
norm=lambda s:re.sub('[^a-z]','',s.lower());k=0;cues=[]
for phrase in phrases:
 start=words[k]['start'];acc=''
 while acc!=norm(phrase):
  w=words[k];k+=1;acc+=norm(w['word']);assert norm(phrase).startswith(acc),(phrase,acc)
 cues.append({'start':start,'end':w['end']+.10,'text':phrase})
assert k==len(words)
for i in range(len(cues)-1):cues[i]['end']=min(cues[i]['end'],cues[i+1]['start'])
profile=default_profile('9:16',720,1280,'archivo-black');cr=CaptionRenderer(B,'9:16',720,1280,profile)
for c in cues:cr.raster(c['text'])
(B/'captions.json').write_text(json.dumps(cues,indent=2));phases['end']=duration
strums=[at('first chord')+.28,phases['trial']+.55,phases['retry']+.55,phases['measure']+.65,phases['show']+.3,phases['show']+1.2]
(B/'timeline.json').write_text(json.dumps({'title':'Why You Forget What You Just Learned','duration':duration,'fps':30,'native_speech_duration':native,'voice_offset':.12,'caption_profile':profile,'phases':phases,'strums':strums,'cast':'Existing gray-haired green-vest protagonist, user-supplied screenshot reference','reference_scope':'Continue the supplied prior channel character/look using the existing local action extension; no claim of canonical B6 sample equivalence'},indent=2));print(json.dumps({'duration':duration,'phases':phases,'strums':strums},indent=2),flush=True)
