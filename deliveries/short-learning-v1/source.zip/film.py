"""New story using the user's existing green-vest identity and tested action rig."""
from pathlib import Path
import json,math,subprocess,sys
from functools import lru_cache
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import rig as R
from caption_renderer import CaptionRenderer
B=Path(__file__).resolve().parent;O=B/'output';W,H=720,1280;FPS=30
O.mkdir(parents=True,exist_ok=True)
T=json.loads((B/'timeline.json').read_text());D=T['duration'];P=T['phases'];STRUM=T['strums'];C=json.loads((B/'captions.json').read_text());CR=CaptionRenderer(B,'9:16',W,H,T['caption_profile'])
BG=Image.open(B/'art/practice-room.png').convert('RGBA').resize((2275,1280),Image.Resampling.LANCZOS)
PHONE=np.array([1080.,650.]);BUTTON=PHONE+[0,80];HIDE=P['pause']+.24;REOPEN=P['check']+.24;SECOND_HIDE=P['hide']+.24
BOUNDS=[('watch',0,max(.7,STRUM[0]-.25)),('forgot',max(.7,STRUM[0]-.25),P['recognize']),('recognition',P['recognize'],P['contrast']),('cant_do',P['contrast'],P['pause']-.55),('pause',P['pause']-.55,P['trial']),('trial',P['trial'],P['stuck']),('stuck',P['stuck'],P['check']),('check',P['check'],P['hide']),('hide',P['hide'],P['retry']),('retry',P['retry'],P['measure']),('practice',P['measure'],P['show']),('result',P['show'],D)]
def screen_on(t):return t<HIDE or REOPEN<=t<SECOND_HIDE
def phone(im,t):
 tile=Image.new('RGBA',(140,230));g=ImageDraw.Draw(tile);g.rounded_rectangle((8,5,132,225),16,fill='#333e43',outline='#1b252e',width=5);g.rounded_rectangle((18,22,122,207),8,fill='#b7d0cc' if screen_on(t) else '#26303a');g.line((54,13,84,13),fill='#c2c3ac',width=3)
 if screen_on(t):
  # Original guitar-only tutorial, with no copied creator/video.
  layer,pos=R.transformed(R.GUITAR,[88,139],[315,265],.25,0);tile.alpha_composite(layer,pos);g=ImageDraw.Draw(tile)
  g.rounded_rectangle((24,28,116,90),4,fill='#efe2bf',outline='#6c6451',width=2)
  for x in [31,46,61,76,91,106]:g.line((x,31,x,87),fill='#86785d',width=1)
  for y in [32,51,70,88]:g.line((27,y,113,y),fill='#86785d',width=2)
  for x,y in [(91,42),(61,61),(76,61)]:g.ellipse((x-4,y-4,x+4,y+4),fill='#325e59')
  if REOPEN<=t<SECOND_HIDE:g.ellipse((68,53,84,69),outline='#d39a35',width=3)
  g.line((29,179,111,179),fill='#e9e2c9',width=3);g.line((29,179,29+round((t%2.5)/2.5*82),179),fill='#bf8554',width=3)
  for x in [62,75]:g.rounded_rectangle((x,187,x+5,200),2,fill='#33464b')
 layer,pos=R.transformed(tile,PHONE,[70,115]);im.alpha_composite(layer,pos)
def stage(im,t):
 g=ImageDraw.Draw(im)
 # Stand and cradle are independently authored layers with a fixed screen contact.
 R.line(g,[(1080,765),(1080,1047)],'#65584c',7);R.line(g,[(1080,1015),(1035,1047)],'#65584c',6);R.line(g,[(1080,1015),(1125,1047)],'#65584c',6);R.line(g,[(1015,751),(1145,751)],'#65584c',6)
 phone(im,t)
 # A subtle, separate plant-shadow shimmer; never the actor's source of motion.
 if t>P['show']:
  g.arc((350+2*math.sin(t),840,560+2*math.sin(t),1120),190,260,fill='#b99a6c',width=3)
def phase(t):return next(n for n,a,b in BOUNDS if a<=t<b+1e-7)
def tap_envelope(t,start):
 u=t-start
 return R.env(u,[(-.55,0),(-.10,1),(.26,1),(.75,0)])
TRACE=[]
def draw_actor(im,t,record=False):
 sid=phase(t);last=t>=P['measure'];pulse=math.sin(t*2.8)
 hip=np.array([850.+(7*pulse if last else 0),817.+(2*math.sin(t*2) if last else 0)])
 lean=R.env(t,[(0,0),(STRUM[0]-.2,3),(STRUM[0]+.2,-5),(P['recognize'],0),(P['pause']-.55,0),(P['pause'],6),(P['pause']+.3,6),(P['trial'],0),(P['check']-.3,0),(P['check'],6),(P['hide']+.4,6),(P['retry'],0),(D,0)])
 head=3*pulse if last else R.env(t,[(0,7),(STRUM[0]-.3,7),(STRUM[0]+.22,-12),(P['recognize'],5),(P['trial'],9),(P['stuck'],-13),(P['check'],8),(P['retry'],8),(P['measure'],-2),(D,-2)])
 if sid=='watch':head+=3*math.sin(t*5)
 expr='worried' if sid in ['forgot','cant_do','trial','stuck'] else 'normal'
 gp={'center':hip+[35,-40],'angle':1.2*pulse if last else 0,'scale':1.}
 grips={s:np.array(gp['center'])+R.rotate(p,gp['angle']) for s,p in {'left':[-185,-157],'right':[0,-10]}.items()}
 wrists=dict(grips)
 # The left hand changes one local fret position after checking the missed step.
 fret=14*R.ease((t-P['check'])/1.2)
 if sid=='cant_do':fret+=7*math.sin((t-P['contrast'])*4)
 wrists['left']+=R.rotate([fret*.75,fret*.65],gp['angle'])
 nearest=min(STRUM,key=lambda x:abs(t-x));stroke=R.env(t-nearest,[(-.20,-22),(-.04,-18),(.04,18),(.19,22),(.35,-22)])
 if sid in ['forgot','trial','retry','practice','result']:wrists['right']+=R.rotate([0,stroke],gp['angle'])
 if sid=='cant_do':wrists['right']+=R.rotate([8*math.sin(t*3),-29+12*math.sin(t*4)],gp['angle'])
 taps=[P['pause'],P['check'],P['hide']];touch=max(tap_envelope(t,x) for x in taps)
 wrists['right']=R.mix(wrists['right'],BUTTON,touch)
 # Strap supplies body support while the right hand leaves the strings.
 g=ImageDraw.Draw(im);R.line(g,[hip+[-58,-207],gp['center']+[55,63]],'#70543c',7)
 R.shadow(im,hip[0]);chains=R.actor(im,hip,view='front',angle=lean,head_angle=head,expression=expr,feet={'left':[819,1045],'right':[886,1045]},wrists=wrists,guitar_pose=gp,t=t,record=record)
 if record:
  row=R.RECORDS[-1];row.update({'phase':sid,'screen_on':screen_on(t),'tap_contact':touch>=1-1e-12,'screen_contact_error':float(np.linalg.norm(chains['right'][-1]-BUTTON)) if touch>=1-1e-12 else None,'left_fret_target_error':float(np.linalg.norm(chains['left'][-1]-wrists['left'])),'right_string_offset':stroke,'camera_is_actor_motion':False});TRACE.append(row)
def camera(t,sid):
 if sid in ['recognition','check','pause','hide']:return (950,430,250)
 if sid in ['cant_do','retry']:return (650,500,360)
 if sid in ['forgot','stuck']:return (645,300,450)
 if sid=='result':return (R.env(t,[(P['show'],610),(D,490)]),155,600)
 return (610,180,576)
def frame(t,caption=True,record=False):
 im=BG.copy();stage(im,t);draw_actor(im,t,record);sid=phase(t);x,y,w=camera(t,sid);h=w*16/9;out=im.crop((round(x),round(y),round(x+w),round(y+h))).resize((W,H),Image.Resampling.LANCZOS)
 # No fictitious brain diagram or explanatory slide; the physical test is the payoff.
 if caption:
  c=next((c for c in C if c['start']<=t<c['end']),None)
  if c:out=Image.alpha_composite(out,CR.raster(c['text'])[0])
 return out.convert('RGB')
def render(start=0,end=None,name='picture.mp4'):
 end=D if end is None else end;n=round((end-start)*FPS);p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','720x1280','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(O/name)],stdin=subprocess.PIPE)
 for i in range(n):
  t=start+i/FPS;p.stdin.write(frame(t,True,True).tobytes())
  if i%150==0:print(f'Frames {i}/{n}',flush=True)
 p.stdin.close();assert p.wait()==0;(O/f'motion-{Path(name).stem}.json').write_text(json.dumps(TRACE));print('Saved',name,flush=True)
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='stills':
  for j,(n,a,b) in enumerate(BOUNDS):frame((a+b)/2,True,True).save(O/f'shot-{j+1:02d}-{n}.jpg')
 elif len(sys.argv)>1 and sys.argv[1]=='stress':render(max(0,P['pause']-.7),P['retry']+.7,'action-stress.mp4')
 else:render()
