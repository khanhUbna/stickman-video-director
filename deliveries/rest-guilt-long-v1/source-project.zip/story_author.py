"""Original story, English narration and Vietnamese reading translation."""
from pathlib import Path
import json,re
B=Path(__file__).resolve().parent
DATA=[
('The break that never starts',[
('living','rest_sit',"You've been waiting to sit down all day. Finally. Dinner's done. Nobody needs you.","Bạn đã mong được ngồi xuống suốt cả ngày. Cuối cùng cũng được nghỉ. Ăn tối xong rồi. Chẳng ai đang cần bạn."),
('living','notice_shirt',"Then you notice a shirt on the floor. Apparently, you're not allowed to relax until that's folded.","Rồi bạn nhìn thấy chiếc áo dưới sàn. Có vẻ bạn chưa được phép thư giãn cho đến khi gấp nó xong."),
('living','shirt_pickup',"Fine. One shirt. You're already standing, so you might as well check the laundry.","Được thôi. Một chiếc áo. Đã đứng dậy rồi thì tiện thể kiểm tra chỗ quần áo luôn."),
('laundry','fold',"And the laundry has friends. Suddenly, your break has a waiting list.","Mà đống quần áo còn có cả đồng bọn. Bỗng nhiên, giờ nghỉ của bạn phải xếp hàng chờ."),
('kitchen','wipe',"You wipe the counter. Reply to a message. Find another thing that will only take a minute.","Bạn lau bàn bếp. Trả lời một tin nhắn. Rồi tìm thấy một việc nữa chỉ mất có một phút thôi."),
('living','clock',"An hour later, you're more tired. And somehow, you still haven't earned the couch.","Một tiếng sau, bạn còn mệt hơn. Và chẳng hiểu sao, bạn vẫn chưa thấy mình xứng đáng được nằm nghỉ."),
('living','rest_still',"Yesterday, you needed a break. Today, you have one. Why does taking it feel like doing something wrong?",
"Hôm qua, bạn cần được nghỉ. Hôm nay, bạn có thời gian. Tại sao nghỉ ngơi lại có cảm giác như đang làm điều sai trái?"),
]),
('Why one more thing never works',[
('laundry','list_insert',"Notice the rule you're following: rest comes after everything is finished. Sounds reasonable. Until you meet everything.","Hãy để ý quy tắc bạn đang làm theo: chỉ nghỉ khi mọi việc xong xuôi. Nghe hợp lý. Cho đến khi bạn gặp chữ mọi việc."),
('kitchen','dishes',"Dishes come back. Messages arrive. You finish one task, and three others remember your address.","Bát đĩa lại bẩn. Tin nhắn lại đến. Bạn xong một việc thì ba việc khác chợt nhớ ra địa chỉ nhà bạn."),
('office','email',"Some things really are urgent. Others just become visible the moment you stop moving.","Có những việc thực sự khẩn cấp. Những việc khác chỉ đập vào mắt đúng lúc bạn ngừng tay."),
('living','rest_alarm',"But when every unfinished thing feels like a reason to stand up, the finish line keeps moving.","Nhưng nếu mọi việc chưa xong đều trở thành lý do để đứng dậy, thì vạch đích sẽ cứ lùi mãi."),
('laundry','fold',"Doing one more chore can quiet that uncomfortable feeling for a moment. That relief is convincing.","Làm thêm một việc nhà có thể khiến cảm giác bứt rứt dịu xuống trong chốc lát. Sự nhẹ nhõm ấy rất có sức thuyết phục."),
('entry','walk',"It can teach you to answer discomfort with another task, even when what you need is a pause.","Nó có thể khiến bạn quen đáp lại sự bứt rứt bằng một công việc khác, ngay cả lúc điều bạn cần là tạm dừng."),
('living','rest_still',"So the problem may be the entry requirement. You've made a normal human need depend on an impossible ending.","Vậy vấn đề có thể nằm ở điều kiện để được nghỉ. Bạn đã bắt một nhu cầu bình thường phải chờ một cái kết không thể đạt tới."),
]),
('When being useful becomes being worthy',[
('office','notebook',"Where did that rule come from? There isn't one answer. Look at what gets rewarded around you.","Quy tắc ấy đến từ đâu? Không có một đáp án duy nhất. Hãy nhìn những điều thường được khen thưởng xung quanh bạn."),
('office','close_laptop',"A finished project gets noticed. An extra shift gets thanked. Sitting quietly rarely gets an employee award.","Một dự án hoàn thành thì được ghi nhận. Làm thêm một ca thì được cảm ơn. Ngồi yên nghỉ ngơi hiếm khi nhận được giải nhân viên xuất sắc."),
('street','walk',"If being useful keeps bringing approval, you may start measuring yourself by how much you get done.","Nếu sự hữu ích liên tục mang lại lời khen, bạn có thể bắt đầu đánh giá bản thân bằng lượng việc mình hoàn thành."),
('living','phone_pickup',"Then you open your phone. Someone has run five miles before breakfast. Someone else has launched a business.","Rồi bạn mở điện thoại. Có người chạy năm dặm trước bữa sáng. Có người vừa mở một công ty."),
('living','comparison',"You were feeling pretty good about washing a fork. Your ordinary evening is now competing with everybody's best moment.","Bạn vừa còn khá hài lòng vì rửa được cái nĩa. Giờ thì buổi tối bình thường của bạn phải thi với khoảnh khắc đẹp nhất của tất cả mọi người."),
('living','phone_place',"Even rest can turn into homework. Read something useful. Meditate correctly. Come back as a better employee.","Ngay cả nghỉ ngơi cũng có thể biến thành bài tập: đọc thứ gì hữu ích, thiền cho đúng, rồi quay lại làm một nhân viên tốt hơn."),
('park','sit_bench',"But a walk can just be a walk. You don't have to turn every peaceful moment into a promotion strategy.","Nhưng đi dạo có thể đơn giản chỉ là đi dạo. Bạn không cần biến mọi khoảnh khắc bình yên thành chiến lược thăng tiến."),
]),
('A real responsibility or a moving target?',[
('kitchen','cook',"Now, an important distinction. Sometimes you cannot simply stop. A child needs dinner. A bill needs paying.","Nhưng cần phân biệt rõ. Đôi khi bạn không thể cứ thế dừng lại. Con cần ăn tối. Hóa đơn cần được thanh toán."),
('office','deadline_insert',"A real deadline has consequences. Pressure isn't always something you invented. You may genuinely need more help or time.","Một hạn chót thật sự có hậu quả. Áp lực không phải lúc nào cũng do bạn tưởng tượng. Có thể bạn thực sự cần thêm người giúp hoặc thêm thời gian."),
('entry','bag',"So don't ask, am I lazy? Ask, what actually needs me tonight, and what can safely wait?",
"Vì vậy, đừng hỏi mình có lười không. Hãy hỏi: tối nay việc gì thật sự cần mình, và việc gì có thể yên tâm để sau?"),
('laundry','shirt_insert',"A damp load that needs hanging is different from a dry shirt that offends you by existing on a chair.","Một mẻ đồ ướt cần phơi khác với chiếc áo khô khiến bạn khó chịu chỉ vì nó đang nằm trên ghế."),
('living','rest_alarm',"And feeling guilty doesn't settle that question. Guilt is a feeling, not a complete inventory of your responsibilities.","Cảm thấy có lỗi không giải đáp được câu hỏi ấy. Tội lỗi là một cảm xúc, không phải bản kiểm kê đầy đủ các trách nhiệm của bạn."),
('hobby','book',"You can care about your life without putting every unfinished part of it in charge of your evening.","Bạn có thể quan tâm đến cuộc sống của mình mà không trao quyền điều khiển cả buổi tối cho mọi việc còn dang dở."),
]),
('Give the evening an actual ending',[
('office','notebook',"Try a smaller experiment tonight. Before you rest, write down the thing you're afraid you'll forget.","Tối nay hãy thử một thay đổi nhỏ hơn. Trước khi nghỉ, ghi lại việc mà bạn sợ mình sẽ quên."),
('office','plan_insert',"Make it specific. Not, fix my whole life. Try, tomorrow after breakfast, pay the electricity bill.","Viết thật cụ thể. Đừng ghi: sửa lại cả cuộc đời. Hãy thử: sáng mai, sau bữa sáng, thanh toán tiền điện."),
('office','close_laptop',"This isn't a guarantee you'll switch off instantly. It's a way to leave the task somewhere besides your head.","Điều này không bảo đảm bạn sẽ ngừng nghĩ ngay lập tức. Nó chỉ giúp bạn để công việc ở một nơi khác ngoài đầu mình."),
('living','phone_place',"Then choose what this break is for. A chapter. Some music. Twenty quiet minutes. It doesn't have to improve you.","Rồi chọn xem bạn muốn nghỉ bằng cách nào: đọc một chương, nghe nhạc, hoặc yên tĩnh hai mươi phút. Nó không cần phải nâng cấp con người bạn."),
('kitchen','pour',"You can tell someone you're unavailable for a while, if your situation allows. A boundary works better when people know it exists.","Nếu hoàn cảnh cho phép, bạn có thể nói với người khác rằng mình sẽ nghỉ một lúc. Ranh giới sẽ rõ hơn khi mọi người biết nó tồn tại."),
('living','rest_book',"And when the guilty feeling appears, notice it before obeying it. Is there a real problem, or the familiar demand to do more?",
"Khi cảm giác có lỗi xuất hiện, hãy nhận ra nó trước khi làm theo. Có vấn đề thực sự nào không, hay chỉ là lời thúc giục quen thuộc rằng phải làm thêm?"),
('living','reach_return',"If something genuinely needs you, respond. If it can wait, try staying seated without first winning an argument with yourself.","Nếu có việc thật sự cần bạn, hãy giải quyết. Nếu việc đó có thể chờ, hãy thử ngồi lại mà không cần tranh luận thắng chính mình trước."),
]),
('The shirt can wait',[
('living','rest_alarm',"The first evening might feel awkward. You may look at the clock. You may still think about that shirt.","Buổi tối đầu tiên có thể hơi khó chịu. Bạn có thể nhìn đồng hồ. Bạn vẫn có thể nghĩ đến chiếc áo ấy."),
('laundry','shirt_insert',"Leaving it for tomorrow isn't proof you've stopped caring. It's one dry shirt. It has survived worse.","Để mai làm không chứng minh rằng bạn đã ngừng quan tâm. Chỉ là một chiếc áo khô thôi. Nó từng sống sót qua chuyện tệ hơn rồi."),
('living','rest_book',"Tonight, you read a few pages. Not to become impressive. Because you wanted to find out what happened next.","Tối nay, bạn đọc vài trang. Không phải để trở nên giỏi giang. Mà vì bạn muốn biết câu chuyện tiếp theo xảy ra điều gì."),
('living','rest_ending',"The room isn't perfect. Tomorrow still has work in it. For once, neither of those things gets to cancel tonight.","Căn phòng chưa hoàn hảo. Ngày mai vẫn còn công việc. Nhưng lần này, cả hai điều đó đều không được phép xóa mất buổi tối nay."),
('living','ending_insert',"The shirt can wait. You don't have to disappear until the to-do list does.","Chiếc áo có thể chờ. Bạn không cần phải biến mất cho đến khi danh sách việc cần làm cũng biến mất."),
])]
chapters=[]
for ci,(title,rows) in enumerate(DATA,1):
 beats=[{'id':f'{ci:02d}-{i:02d}','setting':setting,'action':action,'text':en,'vi':vi,'continuity':'Deliberate scene/time cuts; one new narrative function per beat; preserve visible prop contact and grounded support within each shot.'} for i,(setting,action,en,vi) in enumerate(rows,1)]
 chapters.append({'id':ci,'title':title,'text':'\n\n'.join(b['text'] for b in beats),'beats':beats})
story={'title':'Why You Feel Guilty When You Rest','channel':'Psychology Facts','language':'English','ratio':'16:9','dimensions':[1280,720],'voice':{'model':'tts-1','voice':'alloy','speed':1},'chapters':chapters,'scope':'Original everyday-psychology story. Possible influences, not universal causes or diagnosis. Practical experiments, not guaranteed treatment. Real constraints and responsibilities are explicitly distinguished.'}
(B/'story.json').write_text(json.dumps(story,ensure_ascii=False,indent=2))
for lang,field in [('en','text'),('vi','vi')]:
 (B/f'script-{lang}.txt').write_text(story['title']+'\n\n'+'\n\n'.join(f"{c['id']}. {c['title']}\n\n"+'\n\n'.join(b[field] for b in c['beats']) for c in chapters))
print(json.dumps({'words':sum(len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",c['text'])) for c in chapters),'beats':sum(len(c['beats']) for c in chapters),'characters':sum(len(c['text']) for c in chapters),'tts_usd_estimate':sum(len(c['text']) for c in chapters)*15/1e6},indent=2))
