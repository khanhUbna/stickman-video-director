"""Offline word alignment, exact transcript coverage, per-chapter checkpoints."""
from pathlib import Path
import json,subprocess,re,wave,hashlib
from pocketsphinx import Decoder
B=Path(__file__).resolve().parent;story=json.loads((B/'story.json').read_text())
for chapter in story['chapters']:
 ci=chapter['id'];dst=B/f'audio/chapter-{ci:02d}-words.json'
 if dst.exists():print(f'Reuse alignment {ci}',flush=True);continue
 source=B/f'audio/chapter-{ci:02d}.wav';audio=B/f'audio/chapter-{ci:02d}-16k.wav'
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(source),'-ar','16000','-ac','1',str(audio)],check=True)
 tokens=re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",chapter['text']);decoder=Decoder(samprate=16000,loglevel='ERROR')
 missing=sorted({w.lower() for w in tokens if not decoder.lookup_word(w.lower())})
 if missing:raise RuntimeError('Missing offline dictionary words: '+str(missing))
 decoder.set_align_text(' '.join(w.lower() for w in tokens))
 with wave.open(str(audio)) as w:data=w.readframes(w.getnframes())
 decoder.start_utt();decoder.process_raw(data,full_utt=True);decoder.end_utt()
 segments=[s for s in decoder.seg() if s.word not in ('<sil>','<s>','</s>','[SPEECH]','[NOISE]')]
 assert len(segments)==len(tokens),(ci,len(segments),len(tokens))
 words=[]
 for token,s in zip(tokens,segments):
  assert re.sub(r'\(\d+\)$','',s.word)==token.lower(),(token,s.word)
  words.append({'word':token,'start':round(s.start_frame/100,3),'end':round((s.end_frame+1)/100,3)})
 dst.write_text(json.dumps({'method':'Offline PocketSphinx acoustic forced alignment','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'words':words},indent=2));print(f'Chapter {ci}: {len(words)} words acoustically aligned',flush=True)
