"""Package the checked new film and portable source, with no secret values."""
from pathlib import Path
import json,hashlib,zipfile,shutil,ast,re
B=Path(__file__).resolve().parent;O=B/'output';DEST=Path('/workspace/stickman-video-director/deliveries/rest-guilt-long-v1')
def main():
 movie=O/'why-you-feel-guilty-when-you-rest.mp4';qa=json.loads((O/'QA.json').read_text());review=json.loads((O/'decoded-review.json').read_text());h=hashlib.sha256(movie.read_bytes()).hexdigest()
 assert qa['sha256']==review['sha256']==h
 assert json.loads((O/'voice-presence-checks.json').read_text())['all_spoken_blocks_present']
 assert qa['full_decode']=='pass' and qa['narrative']['shots']==39
 for p in B.glob('*.py'):ast.parse(p.read_text())
 files=[]
 for p in B.iterdir():
  if p.is_file() and p.suffix in ['.py','.md','.json','.txt']:files.append(p)
 files.append(B/'LICENSE')
 for folder in ['characters','fonts','research']:
  files.extend(p for p in (B/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
 files.extend(p for p in (B/'art').iterdir() if p.is_file() and (p.name.startswith(('painted-','environment-atlas-','head-relieved','thumbnail-master')) or p.name=='guitar.png'))
 files.extend(p for p in (B/'audio').iterdir() if p.is_file() and ((p.name.startswith('chapter-') and p.suffix in ['.wav','.json'] and not p.name.endswith('-16k.wav')) or p.name in ['voice-ledger.json','sound-events.json']))
 files.extend(O/n for n in ['QA.json','decoded-review.json','voice-presence-checks.json','contact-preview-checks.json'])
 # Request checkpoints contain model/voice/character counts only. Refuse any literal API credential.
 for p in files:
  if p.suffix in ['.py','.json','.md','.txt']:
   assert not re.search(r'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}',p.read_text(errors='replace')),f'Unexpected secret-like literal in {p.name}'
 with zipfile.ZipFile(O/'source-project.zip','w',zipfile.ZIP_DEFLATED,6) as z:
  for p in files:z.write(p,p.relative_to(B))
 with zipfile.ZipFile(O/'source-project.zip') as z:assert z.testzip() is None
 assert (O/'source-project.zip').stat().st_size<95*1024**2
 DEST.mkdir(parents=True,exist_ok=True)
 for name in [movie.name,'thumbnail.jpg','captions-en.srt','captions-en.vtt','captions-vi.srt','chapters.txt','QA.json','decoded-review.json','voice-presence-checks.json','encoded-storyboard-1.jpg','encoded-storyboard-2.jpg','action-preview.mp4','source-project.zip']:
  shutil.copy2(O/name,DEST/name)
 for name in ['README.md','rights.json','script-en.txt','script-vi.txt','upload-title.txt','upload-description.txt','upload-settings.txt','editorial-notes.md','visual-review.md','repair-notes.md']:
  shutil.copy2(B/name,DEST/name)
 manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in DEST.iterdir() if p.is_file() and p.name!='manifest.json'}
 (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2))
 print(json.dumps({'delivery':str(DEST),'duration':qa['duration_seconds'],'MP4_MiB':round(movie.stat().st_size/1024**2,2),'source_MiB':round((O/'source-project.zip').stat().st_size/1024**2,2),'files':len(manifest),'secret_literal_scan':'pass'},indent=2),flush=True)
if __name__=='__main__':main()
