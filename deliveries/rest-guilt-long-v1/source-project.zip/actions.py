"""Story-specific physical acting and prop inserts; no slide-show footage."""
from pathlib import Path
import math
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import rig,props
import sets_new as sets
from rig import actor,ease,mix,rotate,poly,line,ip
B=Path(__file__).resolve().parent
FONT=str(B/'fonts/ArchivoBlack.ttf')
INSERTS={'clock','list_insert','deadline_insert','shirt_insert','plan_insert','ending_insert'}
REST={'rest_sit','notice_shirt','rest_still','rest_alarm','rest_book','reach_return','rest_ending'}
def on(q,a,b):return ease((q-a)/(b-a))
def txt(g,xy,s,n=24,c='#4b574d'):g.text(xy,s,font=ImageFont.truetype(FONT,n),fill=c)
def shirt(im,center,scale=1,fold=0,angle=0):
 tile=Image.new('RGBA',(150,108));g=ImageDraw.Draw(tile)
 # One actual garment, whose right panel folds over the center seam.
 w=50*(1-fold*.60);pts=[(75-w,12),(56-w,19),(18,45),(35,67),(52,55),(51,98),(112-fold*32,98),(110-fold*27,55),(128-fold*38,65),(143-fold*40,44),(111-fold*24,19),(99-fold*20,12)]
 poly(g,pts,'#9a99b3','#51556b',3);g.arc((59,4,94,34),0,180,fill='#51556b',width=3)
 if fold>.2:line(g,[(83,28),(83,92)],'#777e9a',2)
 rr,pos=rig.transformed(tile,center,[75,54],scale,angle);im.alpha_composite(rr,pos)

def insert(im,s,q,elapsed):
 a=s['action'];g=ImageDraw.Draw(im)
 if a=='clock':
  im=im.filter(ImageFilter.GaussianBlur(2));g=ImageDraw.Draw(im);cx,cy=635,280;r=181
  g.ellipse((cx-r,cy-r,cx+r,cy+r),fill='#f4e7c9',outline='#795e49',width=9)
  # Exactly one hour passes on this physical clock.
  h=19+on(q,.12,.77)
  for angle,length,width in [(h/12*math.tau,87,9),(h%1*math.tau,139,6)]:line(g,[(cx,cy),(cx+math.sin(angle)*length,cy-math.cos(angle)*length)],'#594f46',width)
  for k in range(12):
   angle=k/12*math.tau;line(g,[(cx+math.sin(angle)*155,cy-math.cos(angle)*155),(cx+math.sin(angle)*166,cy-math.cos(angle)*166)],'#795e49',4)
  return im
 if a=='shirt_insert':
  # Real chair/detail view; the foreground garment stays after the reaction.
  g.rounded_rectangle((445,240,835,455),35,fill='#bc886f',outline='#78594a',width=7)
  g.rounded_rectangle((430,430,850,500),20,fill='#d2a486',outline='#78594a',width=6)
  for x in [460,815]:line(g,[(x,500),(x,587)],'#745b45',9)
  shirt(im,[650,330],1.5,angle=3*math.sin(q*math.pi))
  return im
 if a=='ending_insert':
  shirt(im,[855,424],.68,angle=16)
  # Pull attention from the uncompleted garment to the person enjoying the book.
  hip=np.array([610.,480.]);bc=hip+[0,-35]
  actor(im,hip,head_angle=4,feet={'left':[625,590],'right':[678,590]},wrists={'left':bc+[-48,17],'right':bc+[48,17]},prop_draw=lambda m:props.book(m,bc,1,.5),held={'book_left':{'arm':'left','point':bc+[-48,17]},'book_right':{'arm':'right','point':bc+[48,17]}})
  # This is a real actor shot. Return geometry through the common path below instead.
  return im
 # Paper lies on a table, with perspective and a contact shadow.
 g.polygon([(340,149),(897,164),(960,554),(290,537)],fill=(55,39,26,65))
 poly(g,[(335,135),(884,149),(939,532),(290,516)],'#f2e7c9','#82674e',4)
 if a=='list_insert':
  txt(g,(388,180),'BEFORE I REST',34)
  rows=['Fold laundry','Wash dishes','Reply to email','Clean the fridge','One more thing...']
  for i,text in enumerate(rows):
   yy=245+i*47;show=on(q,.04+i*.13,.18+i*.13)
   if show>.02:
    g.rectangle((365,yy+5,387,yy+27),outline='#6d7d6e',width=3)
    txt(g,(410,yy),text,26)
    if i<2 and q>.24+i*.13:line(g,[(367,yy+17),(375,yy+24),(390,yy+2)],'#6b8a6d',4)
 elif a=='deadline_insert':
  txt(g,(385,183),'TONIGHT',36)
  txt(g,(375,265),'Dinner',30);txt(g,(375,315),'Important deadline',30)
  txt(g,(375,413),'Real needs deserve time.',24,'#766653')
 elif a=='plan_insert':
  txt(g,(385,180),'TOMORROW',36)
  txt(g,(365,260),'After breakfast:',29)
  text='Pay electricity bill.';n=round(on(q,.20,.65)*len(text));txt(g,(365,315),text[:n],29)
  if q>.70:line(g,[(364,367),(856,367)],'#b7a88c',2);txt(g,(365,410),'Written down. Not forgotten.',23,'#766653')
 return im

def stage(t,s,legacy,collect=True):
 a=s['action'];q=max(0,min(.999999,(t-s['start'])/(s['end']-s['start'])));elapsed=t-s['start'];scene=s['setting'];chapter=s['chapter']
 if a not in REST|INSERTS|{'shirt_pickup','fold','comparison','sit_bench'}:
  im,rows=legacy(t,s,collect)
  if a=='email':
   g=ImageDraw.Draw(im);g.rounded_rectangle((835,245,1065,340),7,fill='#f2e7ce',outline='#7d846d',width=2)
   txt(g,(852,267),'One last reply...',18);txt(g,(852,302),'Sent' if q>.65 else 'Typing',18,'#6a846e')
  return im,rows
 im=sets.background(scene,True).copy();sets.moving_world(im,scene,elapsed,True);g=ImageDraw.Draw(im)
 if a in INSERTS and a!='ending_insert':return insert(im,s,q,elapsed),[]
 if a=='ending_insert':a='rest_ending'
 x=650.;hip=np.array([x,418.]);angle=0.;head=0.;feet={'left':[625,590],'right':[678,590]};wr={};held={};pd=None;expr='worried';post=[]
 if a in REST:
  seat=on(q,.03,.61) if a=='rest_sit' else 1.
  # Perception precedes a supported rise in the opening shirt beat.
  if a=='notice_shirt':seat=1-on(q,.49,.94)
  hip=np.array([650-40*seat,418+62*seat]);angle=5*math.sin(math.pi*on(q,.03,.61)) if a=='rest_sit' else 0
  wr={'left':mix([580,412],[545,462],seat),'right':mix([722,412],[712,459],seat)}
  head=4
  expr='relieved' if a in ['rest_sit','rest_book','rest_ending'] else 'worried'
  if chapter==1:shirt(im,[591,578],.43,angle=-7)
  elif chapter>=4:shirt(im,[855,424],.68,angle=16)
  if a=='notice_shirt':head=-3-11*on(q,.08,.30);expr='worried'
  if a=='rest_alarm':
   # A lean toward getting up, then a return; fixed soles, no sliding torso.
   u=math.sin(math.pi*on(q,.12,.86))**2;hip[1]-=10*u;angle=9*u;head=3+5*u
   wr['right']=mix(wr['right'],[726,438],u)
  if a in ['rest_book','rest_ending','reach_return']:
   bc=np.array([610.,445.]);left=bc+[-48,17];right=bc+[48,17]
   wr={'left':left,'right':right};head=6
   pd=lambda m,bc=bc:props.book(m,bc,1,on(q,.28,.62))
   held={'book_left':{'arm':'left','point':left},'book_right':{'arm':'right','point':right}}
   if a=='reach_return':
    u=math.sin(math.pi*on(q,.08,.83))**2;angle=10*u;head=6+5*u;wr['right']=mix(right,[716,468],u)
    held.pop('book_right');expr='worried' if q<.70 else 'relieved'
    if q>.84:held['book_right']={'arm':'right','point':right}
  if a=='rest_book' and chapter==5:expr='worried' if q>.28 else 'relieved'
  if a=='rest_ending':head=6-8*on(q,.62,.90)
 elif a=='shirt_pickup':
  acquire=on(q,.28,.49);lift=on(q,.50,.91);bend=on(q,.06,.40)*(1-lift)
  hip[1]+=107*bend;angle=-59*bend;head=8*bend
  center=mix([591,578],[600,388],lift);grip=center+[0,-13]
  normal=hip+rotate([-68,-6],angle);wr['left']=mix(normal,grip,acquire);wr['right']=hip+rotate([72,-6],angle)
  pd=lambda m,center=center,lift=lift:shirt(m,center,.43+.13*lift,angle=-7+7*lift)
  if acquire>1-1e-8:held={'shirt_grip':{'arm':'left','point':grip}}
 elif a=='fold':
  sets.table(g,635,440,350);u=on(q,.13,.80);angle=5*math.sin(math.pi*u);head=9
  center=np.array([686.,420.]);left=center+np.array([18-75,45-54])*.72;right=center+np.array([143-40*u-75,44-54])*.72
  wr={'left':left,'right':right};pd=lambda m,center=center,u=u:shirt(m,center,.72,fold=u)
  # Garment's corner itself follows the fold, not an independently sliding hand.
  held={'fabric_left':{'arm':'left','point':left},'fabric_fold':{'arm':'right','point':right}}
  for i in range(3):
   g.rounded_rectangle((840,424-10*i,902,434-10*i),3,fill=['#c1ac86','#94a497','#a497b1'][i],outline='#756952',width=2)
 elif a=='comparison':
  hip=np.array([610.,480.]);feet={'left':[625,590],'right':[678,590]};head=7
  pc=hip+[60,-85];grip=pc+rotate([12,19],-7);wr={'right':grip,'left':hip+[-65,-10]};pd=lambda m:props.phone(m,pc,-7,scroll=q*3);held={'phone_grip':{'arm':'right','point':grip}}
  # An enlarged view of the phone's feed, not extra unregistered actors.
  g.rounded_rectangle((94,85,400,535),25,fill='#273b43',outline='#162b35',width=6)
  g.rounded_rectangle((110,108,384,510),9,fill='#e6ddc9')
  upper=on(q,.04,.36);lower=on(q,.40,.72)
  g.rectangle((130,150,364,278),fill='#aebfac');txt(g,(146,169),'6:00 AM',25)
  txt(g,(144,213),'5 MILES',31,'#4c6958')
  if lower>.01:
   g.rectangle((130,310,364,448),fill='#c6b398');txt(g,(144,330),'NEW BUSINESS',22);txt(g,(144,376),'LAUNCHED',28,'#665b48')
  # A washed fork rests where it was put, rather than becoming another infographic.
  line(g,[(978,420),(983,447)],'#d4d7c4',4)
  for xx in [972,978,984]:line(g,[(xx,411),(xx+3,425)],'#d4d7c4',2)
 elif a=='sit_bench':
  hip=np.array([980.,480.]);feet={'left':[958,590],'right':[1014,590]};head=-3+2*on(q,.15,.7);expr='normal'
  wr={'left':hip+[-73,-15],'right':hip+[74,-18]}
 rows=[actor(im,hip,angle=angle,head_angle=head,expression=expr,feet=feet,wrists=wr,prop_draw=pd,held=held)]
 return im,rows
