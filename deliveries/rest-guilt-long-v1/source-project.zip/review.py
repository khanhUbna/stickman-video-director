"""Final-MP4 frame/caption and decoded speech checks; no invented listening."""
from pathlib import Path
import json,hashlib,subprocess,wave,re
import numpy as np
from PIL import Image,ImageDraw
import film
B=Path(__file__).resolve().parent;O=B/'output';MOV=O/'why-you-feel-guilty-when-you-rest.mp4'
def decoded(t):
 r=subprocess.run(['ffmpeg','-v','error','-ss',str(t),'-i',str(MOV),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True)
 return Image.fromarray(np.frombuffer(r.stdout,np.uint8).reshape(720,1280,3))
def read(p):
 with wave.open(str(B/'audio'/p)) as w:return np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
def main():
 qa=json.loads((O/'QA.json').read_text());sha=hashlib.sha256(MOV.read_bytes()).hexdigest();assert qa['sha256']==sha
 samples=[]
 for phase,f in enumerate([.19,.79],1):
  board=Image.new('RGB',(1280,2050),'#efe6d1');g=ImageDraw.Draw(board)
  for i,s in enumerate(film.SHOTS):
   t=s['start']+(s['end']-s['start'])*f;im=decoded(t);im.save(O/f"decoded-{s['id']}-{phase}.jpg",quality=91);im.thumbnail((320,180));x=i%4*320;y=i//4*205;board.paste(im,(x,y));g.text((x+5,y+183),s['id']+' '+s['action'],fill='#253b3d');samples.append({'shot':s['id'],'action':s['action'],'time':t})
  board.save(O/f'encoded-storyboard-{phase}.jpg',quality=93)
 norm=lambda s:re.sub('[^a-z]','',s.lower())
 assert norm(' '.join(c['text'] for c in film.CUES))==norm(' '.join(s['text'] for s in film.SHOTS))
 assert all(c['start']<c['end'] for c in film.CUES)
 assert all(film.CUES[i]['end']<=film.CUES[i+1]['start']+.001 for i in range(len(film.CUES)-1))
 for c in film.CUES:film.CR.raster(c['text']);film.CR.cache.clear()
 # Every narrated block is checked in decoded final audio, not just the source.
 raw=subprocess.run(['ffmpeg','-v','error','-i',str(MOV),'-vn','-ar','48000','-ac','1','-f','f32le','-'],capture_output=True,check=True)
 encoded=np.frombuffer(raw.stdout,'<f4');voice=read('voice-assembled.wav');bg=read('music-original.wav')+read('room-original.wav')+read('foley-original.wav');audio=[]
 for s in film.SHOTS:
  a=round(s['start']*48000);b=min(round(s['end']*48000),len(voice),len(encoded));v=voice[a:b];e=encoded[a:b]
  corr=float(np.corrcoef(v,e)[0,1]);rms=lambda z:float(np.sqrt(np.mean(z*z)))
  db=20*np.log10(max(1e-9,rms(v))/max(1e-9,rms(bg[a:b])));assert corr>.80,(s['id'],corr)
  audio.append({'shot':s['id'],'correlation':corr,'voice_above_background_db':float(db)})
 (O/'voice-presence-checks.json').write_text(json.dumps({'all_spoken_blocks_present':True,'spoken_blocks':len(audio),'minimum_correlation':min(x['correlation'] for x in audio),'segments':audio,'scope':'Signal presence/mix checks, not subjective listening or intelligibility approval.'},indent=2))
 # Final-derived original-rate excerpt retained for checking the highest-risk contact.
 subprocess.run(['ffmpeg','-v','error','-y','-ss','8','-i',str(MOV),'-t','12','-c:v','libx264','-preset','fast','-crf','20','-c:a','aac','-b:a','128k','-movflags','+faststart',str(O/'action-preview.mp4')],check=True)
 details=[]
 for sid,f,name in [('01-02',.88,'supported-rise'),('01-03',.49,'shirt-acquisition'),('01-03',.90,'shirt-lift'),('01-04',.75,'fold-contact'),('03-03',.96,'landed-walk'),('05-04',.72,'phone-placement'),('05-04',.79,'phone-release'),('05-07',.38,'tempted-reach'),('05-07',.90,'return-to-book'),('06-04',.78,'ending')]:
  s=next(s for s in film.SHOTS if s['id']==sid);t=s['start']+(s['end']-s['start'])*f;decoded(t).save(O/f'detail-{name}.jpg',quality=94);details.append({'shot':sid,'time':t,'name':name})
 report={'sha256':sha,'source_fingerprint':film.fingerprint(),'decoded_samples':samples,'details':details,'caption_order_and_coverage':'pass','caption_fit_and_non_overlap':'pass','native_thumbnail_bytes':(O/'thumbnail.jpg').stat().st_size,'review_scope':'Author source and exact encoded frame inspection plus technical signal/geometry checks. Independent creative review, continuous human watch and real-time agent AV listening are not claimed.'}
 (O/'decoded-review.json').write_text(json.dumps(report,indent=2));print(json.dumps({'decoded_shot_samples':len(samples),'contact_details':len(details),'speech_blocks_present':len(audio),'minimum_audio_correlation':min(x['correlation'] for x in audio),'caption_coverage':'exact'},indent=2),flush=True)
if __name__=='__main__':main()
