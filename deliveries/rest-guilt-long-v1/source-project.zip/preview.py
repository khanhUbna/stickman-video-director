"""Real encoded stress sequence of bend/acquisition/rise/fold at native speed."""
from pathlib import Path
import subprocess,json,hashlib
import film
B=Path(__file__).parent;first=round(8*30);last=round(20*30)
p=B/'output/contact-preview-picture.mp4'
proc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','30','-i','-','-an','-c:v','libx264','-crf','20','-preset','veryfast','-pix_fmt','yuv420p',str(p)],stdin=subprocess.PIPE)
rows=[]
for i in range(first,last):
 im,r=film.frame(i/30);proc.stdin.write(im.tobytes());rows.extend(r)
proc.stdin.close();assert proc.wait()==0
subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True)
(B/'output/contact-preview-checks.json').write_text(json.dumps({'frames':last-first,'actor_frames':len(rows),'maximum_fixed_bone_error':max(r['bone_error'] for r in rows),'maximum_grip_error':max((v for r in rows for v in r['contacts'].values()),default=0),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'review':'Technical and source/decoded-frame author checks; not independent creative approval or real-time AV listening.'},indent=2))
print('Stress preview encoded, fully decoded, contact chains checked.',flush=True)
