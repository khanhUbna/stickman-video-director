"""Local encoder workers, not delegated agents or external API calls."""
from concurrent.futures import ProcessPoolExecutor,as_completed
import os,json
from pathlib import Path
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
def one(ci):
 from film import render
 return ci,render(ci)
if __name__=='__main__':
 ids=[c['id'] for c in json.loads((Path(__file__).parent/'timeline.json').read_text())['chapters']]
 with ProcessPoolExecutor(max_workers=4) as pool:
  for f in as_completed([pool.submit(one,i) for i in ids]):
   ci,path=f.result();print('COMPLETED CHAPTER',ci,path,flush=True)
