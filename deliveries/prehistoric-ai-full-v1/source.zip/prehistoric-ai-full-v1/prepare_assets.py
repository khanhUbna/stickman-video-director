from pathlib import Path
from PIL import Image
import json,hashlib,shutil
B=Path(__file__).resolve().parent
sources={'forest':'exec-7ab1dbbe-1996-473e-a212-7aad2421d66d.png','yard':'exec-99e977a9-6ef5-48b3-bdc8-b2cac5d5783d.png','storm':'exec-41c83f78-5c53-4b7c-9d65-f120c243571b.png','extras':'exec-a06a96f3-706f-497a-94f0-116a9e13da56.png'}
for name,p in sources.items():shutil.copy2(Path('/workspace/generated_images')/p,B/f'art/{name}.png')
im=Image.open(B/'art/extras.png').convert('RGBA');w,h=im.size
for who,name,col,row in [('tuk','shocked',0,0),('tuk','smile',1,0),('nim','relief',0,1),('ai','stone',1,1)]:
 tile=im.crop((col*w//2,row*h//2,(col+1)*w//2,(row+1)*h//2));bb=tile.getchannel('A').point(lambda a:255 if a>96 else 0).getbbox();tile=tile.crop((max(0,bb[0]-8),max(0,bb[1]-8),min(tile.width,bb[2]+8),min(tile.height,bb[3]+8)))
 if who=='ai':tile.save(B/'art/ai-stone.png');continue
 dst=B/f'characters/{who}/{name}.png';tile.save(dst);p=B/f'characters/{who}/package.json';data=json.loads(p.read_text());s=182/tile.width
 data['views']['front']['sprites'].setdefault('heads',{})[name]={'path':dst.name,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'image_to_local':[[s,0,-91],[0,s,-244-tile.height*s],[0,0,1]]};p.write_text(json.dumps(data,indent=2))
(B/'art/generation-ledger.json').write_text(json.dumps({'new_calls':4,'files':sources,'rights':'Generated production assets; no third-party channel imagery or audio copied.'},indent=2))
