"""Story-specific painted prehistoric stage, articulated fixed-length cast.

Approved hook is concatenated unchanged. This file authors the NEW 56 scenes.
It is a project-local compositor, not a claim of installed B6 reference acceptance.
"""
from pathlib import Path
import json,math,sys,subprocess,hashlib,bisect
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import rig
from rig import actor,ease,mix,rotate,line,poly
from caption_renderer import CaptionRenderer
B=Path(__file__).resolve().parent;T=json.loads((B/'timeline.json').read_text());FPS=30
WORLD=(2400,1200);INK=rig.INK
BG={k:Image.open(B/f'art/{k}.png').convert('RGBA').resize(WORLD,Image.Resampling.LANCZOS) for k in ['camp','forest','yard','storm']}
AI=Image.open(B/'art/ai-stone.png').convert('RGBA');AI.thumbnail((200,270),Image.Resampling.LANCZOS)
CUES=json.loads((B/'captions.json').read_text());CSTART=[c['start'] for c in CUES]
CR=CaptionRenderer(B,'16:9',1280,720,T['caption_profile']);ROWS=[]
def font(n):return ImageFont.truetype(str(B/'fonts/ArchivoBlack.ttf'),n)
def p(q,a=0,b=1):return ease((q-a)/(b-a))
def normal(h,side,angle=0):return np.asarray(h)+rotate([-66 if side=='left' else 70,-14],angle)
def basket(im,c,fill=0,scale=1):
 g=ImageDraw.Draw(im);x,y=c;w=55*scale;h=54*scale
 g.arc((x-w*.8,y-h*1.3,x+w*.8,y+h*.1),180,360,fill='#5f4027',width=round(7*scale))
 poly(g,[(x-w,y-h*.38),(x+w,y-h*.38),(x+w*.76,y+h*.65),(x-w*.76,y+h*.65)],'#b68043','#583c28',4)
 for j in range(5):
  yy=y-h*.25+j*h*.18;line(g,[(x-w*.9,yy),(x+w*.9,yy)],'#684a2b',2)
 for j in range(-3,4):line(g,[(x+j*w*.24,y-h*.3),(x+j*w*.19,y+h*.58)],'#d0a36d',2)
 if fill:
  for j in range(6):
   xx=x+(j%3-1)*w*.46;yy=y-h*.35-(j//3)*h*.21;g.ellipse((xx-12*scale,yy-11*scale,xx+12*scale,yy+11*scale),fill=['#aa422d','#c38932','#7d983d'][j%3],outline='#513d27',width=2)
def bowl(im,c,amount=0):
 g=ImageDraw.Draw(im);x,y=c;g.pieslice((x-48,y-21,x+48,y+36),0,180,fill='#b77f48',outline='#583c28',width=4);g.ellipse((x-48,y-18,x+48,y+13),fill='#d1a572',outline='#583c28',width=4)
 for j in range(amount):
  xx=x-24+(j%3)*24;yy=y-5-(j//3)*8;g.ellipse((xx-10,yy-8,xx+10,yy+7),fill='#a84d2b',outline='#65371f',width=2)
def berry(im,c,r=13):
 g=ImageDraw.Draw(im);x,y=c;g.ellipse((x-r,y-r,x+r,y+r),fill='#ad3d37',outline='#573222',width=3);line(g,[(x,y-r),(x+3,y-r-9)],'#62532a',3)
def fish(im,c,angle=0,scale=1):
 g=ImageDraw.Draw(im);c=np.array(c);pts=[[-35,0],[-18,-14],[15,-12],[29,0],[15,13],[-18,13]];pts=[c+rotate(np.array(v)*scale,angle) for v in pts];poly(g,pts,'#a4b5a0','#3e574e',3);poly(g,[c+rotate(np.array(v)*scale,angle) for v in [[-30,0],[-47,-14],[-47,15]]],'#829884','#3e574e',3);x,y=c+rotate([17*scale,-3*scale],angle);g.ellipse((x-3,y-3,x+3,y+3),fill=INK)
def bundle(im,c,scale=1):
 g=ImageDraw.Draw(im);x,y=c
 for j in range(3):
  yy=y+(j-1)*12*scale;line(g,[(x-49*scale,yy-7),(x+49*scale,yy+7)],'#68492d',round(12*scale));line(g,[(x-43*scale,yy-9),(x+41*scale,yy+5)],'#a47a4c',3)
 line(g,[(x-8*scale,y-23*scale),(x-12*scale,y+22*scale)],'#d9bc85',5);line(g,[(x+9*scale,y-21*scale),(x+5*scale,y+24*scale)],'#d9bc85',5)
def slate(im,c,n=0,angle=0,blank=False):
 tile=Image.new('RGBA',(180,145));g=ImageDraw.Draw(tile);poly(g,[(10,18),(155,7),(173,120),(20,139)],'#c8a178','#694c36',5)
 if not blank:
  for j in range(min(n,15)):
   x=31+(j%5)*25;y=37+(j//5)*30;line(g,[(x,y),(x-5,y+19)],'#644936',4)
 rr,pos=rig.transformed(tile,c,[90,72],1,angle);im.alpha_composite(rr,pos)
def stone(im,c):im.alpha_composite(AI,(round(c[0]-AI.width/2),round(c[1]-AI.height)))
def board(im,n=8,rule=True):
 g=ImageDraw.Draw(im);poly(g,[(1580,480),(1870,470),(1890,700),(1590,710)],'#c8a176','#674c35',5)
 if rule:g.text((1611,500),'TASKS',font=font(29),fill='#654c38')
 for j in range(min(n,18)):
  x=1620+(j%6)*39;y=554+j//6*40;line(g,[(x,y),(x-6,y+24)],'#67503b',4)
def stool(im,x,y=832):
 g=ImageDraw.Draw(im);g.ellipse((x-55,y-13,x+55,y+18),fill='#9b714b',outline='#553e2c',width=4)
 for dx in [-35,35]:line(g,[(x+dx,y+12),(x+dx*1.1,890)],'#634a32',10)
def patch(im,q,storm=False):
 g=ImageDraw.Draw(im);end=mix([1830,350],[1940,305],p(q,.15,.8));line(g,[[1770,365],end,[2110,320]],'#d2b67d',7)
 for j in range(7):line(g,[end+[-25+j*15,0],end+[-15+j*15,62]],'#b39a5a',9)
def ripple(im,c,t,r=35):
 g=ImageDraw.Draw(im);x,y=c;rr=r+12*math.sin(t*3);g.arc((x-rr,y-rr*.22,x+rr,y+rr*.22),0,350,fill='#c8d8c5',width=3)
def ambience(im,setting,t,q):
 g=ImageDraw.Draw(im)
 if setting in ['river','forest']:
  for j in range(6):ripple(im,(1010+j*120,720+(j%3)*7),t+j,30)
 if setting=='camp':
  for dx,c,h in [(-12,'#d7782d',43),(7,'#efa94c',60),(22,'#f2c868',34)]:
   x=505+dx;y=745;hh=h+6*math.sin(t*4+dx);poly(g,[(x-16,y),(x-7,y-hh*.5),(x+4,y-hh),(x+18,y)],c,c,1)
 if setting=='storm':
  for j in range(63):
   x=(j*173+t*230)%2450;y=(j*89+t*500)%1180;line(g,[(x,y),(x-15,y+35)],(181,202,214,105),2)
  for j in range(10):ripple(im,(850+j*90,740+(j%3)*10),t+j,42)

def frame(t,caption=True,collect=True):
 s=next(s for s in T['shots'] if s['start']<=t<s['end']+.000001);q=(t-s['start'])/(s['end']-s['start']);a=s['action'];setting=s['setting'];im=BG['forest' if setting in ['forest','river'] else 'yard' if setting in ['yard','store'] else setting].copy();ambience(im,setting,t,q);rows=[];center=1200.;width=1500.;cy=180.;labels=[]
 if setting=='storm':
  water=Image.new('RGBA',WORLD);wg=ImageDraw.Draw(water);yy=870-25*p(q,.05,.85) if a=='rising_water' else 840
  edge=[(x,yy+8*math.sin(x*.015+t*2)) for x in range(0,2401,40)];poly(wg,edge+[(2400,960),(0,960)],(84,119,136,92),None);im.alpha_composite(water)
 def put(who,x,y=725,wr=None,angle=0,head=0,expr='normal',feet=None,walk=None,prop=None,held=None,occlude=()):
  r=actor(im,[x,y],who=who,angle=angle,head_angle=head,expression=expr,feet=feet,walk=walk,wrists=wr,prop_draw=prop,held=held,occlude_forearms=occlude);rows.append({'t':round(t,5),'shot':s['id'],'action':a,**r});return r
 def rest(h,angle=0):return {side:normal(h,side,angle) for side in ['left','right']}
 def walk(who,start=850,distance=312.5,direction=1,load=False,expr='normal'):
  d=distance*p(q,.04,.93);x=start+direction*d;y=rig.walking_hip_y(x,d,direction,who);h=np.array([x,y]);sw=math.sin(d/125*math.pi*2);wr={'left':h+[-67+15*sw,-14],'right':h+[70-15*sw,-14]};prop=None;held=None
  if load:
   c=h+[0,-35];wr={'left':c+[-42,-8],'right':c+[42,-8]};prop=lambda m:basket(m,c,3);held={side+'_basket':{'arm':side,'point':v} for side,v in wr.items()}
  return put(who,x,y,wr,head=2,expr=expr,walk=(d,direction),prop=prop,held=held)
 def foodpair(giver='tuk',receiver='koa',empty=False):
  nonlocal center,width
  center=1350;width=1500;lh=np.array([1200.,725.]);rh=np.array([1440.,725.]);cc=mix([1320,657],[1250,650],p(q,.15,.83));gr=cc+[31,0];rc=cc+[-31,0];w1=rest(lh);w2=rest(rh);w1['right']=mix(normal(lh,'right'),rc,p(q,.06,.30));w2['left']=gr if q<.55 else mix(gr,normal(rh,'left'),p(q,.55,.91))
  put(giver,*rh,wr=w2,head=-3*p(q,.4,.9),held={'bowl_giver':{'arm':'left','point':gr}} if q<.55 else None);put(receiver,*lh,wr=w1,expr='weary' if empty else 'normal',prop=lambda m:bowl(m,cc,0 if empty else 4),held={'bowl_receiver':{'arm':'right','point':rc}} if q>.3 else None,occlude=('right',))
  if not empty and q>.6:berry(im,[1390,825],8)
 if a=='empty_basket':
  center=850;h=np.array([850.,750+22*p(q,.3,.75)]);c=h+[50,-10];wr=rest(h,8);wr['right']=c+[0,-45];put('koa',*h,wr=wr,angle=8,head=8,expr='weary',prop=lambda m:basket(m,c,0),held={'empty_basket':{'arm':'right','point':wr['right']}});berry(im,[1060,856],6)
 elif a in ['fish_escape','fishing']:
  center=1430;h=np.array([1390.,740+25*p(q,.15,.75)]);w=rest(h,10);gr=np.array([1460.,655+30*p(q,.25,.75)]);w['right']=gr
  put('nim' if a=='fishing' else 'koa',*h,wr=w,angle=10,head=5,expr='normal' if a=='fishing' else 'shocked',held={'fishing_pole':{'arm':'right','point':gr}})
  tip=gr+rotate([185,0],-30+20*p(q,.2,.8));line(ImageDraw.Draw(im),[gr,tip],'#69482d',7);fc=mix(tip+[20,160],tip+[12,52],p(q,.2,.7));line(ImageDraw.Draw(im),[tip,fc],'#d8c597',2)
  if a=='fish_escape':fc=fc+np.array([170*p(q,.6,.9),130*p(q,.6,.9)]);fish(im,fc,30+80*p(q,.5,.9));ripple(im,fc+[0,15],t)
  else:fish(im,fc,-20);basket(im,[1580,838],3 if q>.78 else 0)
 elif a=='fruit_pick':
  center=760;h=np.array([760.,725.]);target=np.array([861.,590.]);wr=rest(h);wr['right']=mix(normal(h,'right'),target,p(q,.31,.57));fruit=mix(target,[830,692],p(q,.60,.93));wr['right']=fruit if q>=.60 else wr['right']
  if q<.29:
   d=312.5*p(q,.01,.29);x=447.5+d;y=rig.walking_hip_y(x,d,1,'nim');hh=np.array([x,y]);sw=math.sin(d/125*2*math.pi);put('nim',x,y,wr={'left':hh+[-67+15*sw,-14],'right':hh+[70-15*sw,-14]},walk=(d,1),head=-4,expr='relief' if s['chapter']>=6 else 'normal')
  else:put('nim',*h,wr=wr,head=-5+7*p(q,.4,.9),expr='relief' if s['chapter']>=6 else 'normal',feet={'left':[735,890],'right':[797.5,890]},held={'picked_fruit':{'arm':'right','point':fruit}} if q>=.60 else None)
  berry(im,target if q<.60 else fruit);basket(im,[875,827],4 if q>.94 else 2)
  line(ImageDraw.Draw(im),[[865,540],[861,575]],'#6c542b',8)
 elif a in ['last_portion','share_food']:
  center=1260;width=1730;put('koa',1050,head=4,expr='weary' if a=='last_portion' else 'normal');h=np.array([1320.,725+30*p(q,.1,.8)]);w=rest(h,8);w['left']=mix(normal(h,'left',8),[1248,706],p(q,.1,.8));put('tuk',*h,wr=w,angle=8);bowl(im,[1240,727],1 if a=='last_portion' else 6);bowl(im,[1430,800],0 if q<.55 else 2);put('nim',1550,head=-5,expr='relief' if a=='share_food' else 'normal')
 elif a in ['discover','ask_stone','sort_stones']:
  center=960;stone(im,[1140,810]);h=np.array([940.,725+35*p(q,.18,.65)]);w=rest(h,8);w['right']=mix(normal(h,'right',8),[1060,668],p(q,.15,.75))
  branch=mix([1035,682],[1060,625],p(q,.20,.8))
  if a=='discover':w['right']=branch
  put('koa',*h,wr=w,angle=8,head=5,expr='shocked' if a=='discover' else 'normal',held={'fallen_branch':{'arm':'right','point':branch}} if a=='discover' else None);g=ImageDraw.Draw(im)
  if a=='discover':
   line(g,[branch+[-80,-15],branch+[90,10]],'#715030',13);line(g,[branch,branch+[30,-48]],'#715030',8)
  elif a=='sort_stones':
   for j in range(7):x=1080+j*31;y=835-(j%2)*16*p(q,.15,.8);g.ellipse((x-10,y-7,x+10,y+8),fill='#776d55',outline=INK,width=2)
  else:
   for j in range(3):r=24+j*15+9*p(q,.2,.9);g.arc((1140-r,644-r*.5,1140+r,644+r*.5),210,325,fill='#4ec6d2',width=3)
 elif a=='map_ground':
  center=1220;width=1670;h=np.array([1080.,790.]);w=rest(h,12);end=mix([1170,766],[1186,803],p(q,.14,.85));w['right']=end;put('nim',*h,wr=w,angle=12,head=7);line(ImageDraw.Draw(im),[end,end+[45,23]],'#785537',5);put('koa',1400,head=6,wr={'left':[1300,710],'right':[1470,710]})
  g=ImageDraw.Draw(im)
  for j in range(round(18*p(q,.1,.95))):
   x=1100+j*13;y=837+17*math.sin(j*.4);line(g,[(x,y),(x+9,y+3)],'#775733',3)
  for xx in [1110,1290]:poly(g,[(xx,827),(xx-13,802),(xx+15,803)],'#78904c','#566936',2)
 elif a in ['weave','repair_rope','repair_tool']:
  center=1100;h=np.array([1100.,765.]);ang=9;cyy=706+4*math.sin(q*math.pi*4);left=np.array([1060.,cyy]);right=np.array([1161.,cyy-5]);put('koa' if a=='weave' else 'nim',*h,wr={'left':left,'right':right},angle=ang,head=6,expr='relief' if a=='repair_tool' else 'normal',held={'work_left':{'arm':'left','point':left},'work_right':{'arm':'right','point':right}})
  g=ImageDraw.Draw(im);line(g,[left,right],'#d5ba80',6)
  if a=='weave':basket(im,[1110,761],0,.83)
  elif a=='repair_rope':
   for j in range(3):g.arc((1085+j*6,715,1144+j*6,772),0,350,fill='#ba9b5e',width=4)
  else:line(g,[[1050,763],[1180,761]],'#725330',9);poly(g,[[1160,744],[1190,737],[1205,765],[1170,776]],'#969d88','#485346',4)
 elif a in ['dry_food','safe_food','inspect_roof']:
  center=720;width=1440;h=np.array([650.,725.]);w=rest(h);target=np.array([747.,631+40*p(q,.1,.8)]);w['right']=target;put('nim',*h,wr=w,head=-2,expr='relief' if a!='dry_food' else 'normal');basket(im,[780,774],4);basket(im,[925,774],4);basket(im,[480,774],3)
  if a=='dry_food':
   fish(im,target+[25,35],90);line(ImageDraw.Draw(im),[target+[25,-30],target+[25,18]],'#d0b277',3)
  else:patch(im,1);put('koa',1010,head=-5,expr='normal')
 elif a in ['sit_rest','final_rest','rest_food']:
  center=1250 if setting=='camp' else 1390;width=1740 if a=='final_rest' else 1500;xs=[1050,1330,1610] if a=='final_rest' else [1250 if setting=='camp' else 1390]
  for j,x in enumerate(xs):
   who=['koa','nim','tuk'][j];h=np.array([x,790+23*p(q,.05,.75)]);stool(im,x);w=rest(h,2);w['right']=mix(normal(h,'right',2),h+[37,-84],p(q,.2,.75));put(who,*h,wr=w,angle=2,head=-3+3*math.sin(q*math.pi),expr='relief' if who=='nim' else 'smile' if who=='tuk' else 'normal',feet={'left':[x-65,890],'right':[x+65,890]});
   if setting=='camp':berry(im,w['right'],10)
  if setting=='river':ripple(im,[1540,748],t,65)
 elif a=='basket_stack':
  center=1200;h=np.array([1130.,725+25*p(q,.25,.8)]);c=mix([1170,670],[1210,704],p(q,.15,.85));left=c+[-41,-9];right=c+[41,-9];put('koa',*h,wr={'left':left,'right':right},angle=6,prop=lambda m:basket(m,c,0),held={'stack_left':{'arm':'left','point':left},'stack_right':{'arm':'right','point':right}});basket(im,[1330,827],0);basket(im,[1330,765],0)
 elif a in ['point_schedule','supervise','tally','erase_tally','machine_answer','count_need']:
  center=1510;width=1660;count=round(3+12*p(q,.1,.9));board(im,0 if a=='erase_tally' and q>.65 else 3 if a=='count_need' else count);h=np.array([1510.,725.]);w=rest(h);target=mix([1580,650],[1610,610],p(q,.15,.8));w['right']=target;put('tuk' if a in ['point_schedule','supervise','tally'] else 'koa',*h,wr=w,head=-3,expr='shocked' if a=='machine_answer' else 'normal');
  if a=='erase_tally':
   g=ImageDraw.Draw(im);x=1582+230*p(q,.22,.8);g.ellipse((x-22,580,x+22,658),fill='#d3af7c');put('tuk',1840,head=-5,expr='shocked')
  elif a=='count_need':
   for j in range(3):basket(im,[1770+j*90,815],3)
  elif a=='machine_answer':stone(im,[1260,810])
  elif a=='supervise':put('nim',1860,head=6,expr='normal')
 elif a=='chop':
  center=1250;u=p(q,.12,.42);v=p(q,.42,.65);rec=p(q,.65,.93);hy=725+52*v-52*rec;ang=-4*u+32*v-26*rec;h=np.array([1150.,hy]);gr=mix([1180,670],[1167,639],u);gr=mix(gr,[1180,765],v);gr=mix(gr,[1180,670],rec);aa=-70-50*u+160*v-110*rec;axis=rotate([1,0],aa);left=gr-axis*7;right=gr+axis*7;put('koa',*h,wr={'left':left,'right':right},angle=ang,head=4,held={'axe_l':{'arm':'left','point':left},'axe_r':{'arm':'right','point':right}});tip=gr+axis*110;g=ImageDraw.Draw(im);line(g,[gr-axis*22,tip],'#785532',8);perp=rotate([0,1],aa);poly(g,[tip+axis*10+perp*20,tip-axis*16+perp*24,tip-axis*26-perp*18,tip+axis*9-perp*13],'#8d9893','#46504a',4)
  for side in [-1,1]:bundle(im,[1252+side*24*p(q,.65,.82),853],.55)
 elif a=='count_baskets':
  center=1230;width=1770;put('tuk',1280,wr={'left':[1190,655],'right':[1360,648]},head=5);slate(im,[1392,650],12);put('koa',990,head=-3);basket(im,[1100,818],5);basket(im,[1490,818],2)
 elif a in ['exchange_token','carry_basket','tired_walk','leave_bundle']:
  center=1180;width=1660
  if a=='leave_bundle':
   h=np.array([1120.,725+45*p(q,.1,.8)]);c=mix([1160,680],[1220,780],p(q,.12,.8));w=rest(h,10);w['right']=c+[-5,-15];put('koa',*h,wr=w,angle=10,head=5,held={'bundle':{'arm':'right','point':w['right']}});bundle(im,c);put('nim',1500,head=-4)
  else:
   walk('koa',850,312.5,1,a=='carry_basket','weary' if a=='tired_walk' else 'normal')
   if a=='exchange_token':
    put('tuk',1440,head=3,wr={'left':[1350,660],'right':[1510,710]});slate(im,[1360,659],5);bundle(im,[1280,825],.5)
 elif a in ['blocked_food','empty_bowl','offer_food']:
  foodpair('koa' if a=='offer_food' and s['chapter']==4 else 'tuk','nim' if a in ['empty_bowl','offer_food'] else 'koa',a!='offer_food');
  if a=='blocked_food':board(im,12);slate(im,[1530,685],2)
  if a=='offer_food' and s['chapter']==4:put('tuk',1750,head=-5,wr={'left':[1650,640],'right':[1820,710]})
 elif a in ['roof_notice','roof_repair']:
  center=1790;width=1190;h=np.array([1740.,725+22*p(q,.15,.8)]);w=rest(h);hand=np.array([1810.,636+45*p(q,.15,.8)]);w['right']=hand;w['left']=h+[-35,-60];put('nim',*h,wr=w,head=-7,held={'repair_rope':{'arm':'right','point':hand}});line(ImageDraw.Draw(im),[[1840,430],hand],'#d5bd81',6)
  if a=='roof_repair':patch(im,q)
  else:
   for j in range(4):x=1850+j*11;y=490+(q*400+j*70)%310;line(ImageDraw.Draw(im),[(x,y),(x,y+12)],'#7b9dad',3)
 elif a=='rising_water':
  center=1300;width=1880;put('tuk',1500,head=7,wr={'left':[1410,647],'right':[1570,713]});slate(im,[1400,647],15);put('koa',1110,expr='shocked',head=-4);basket(im,[1240,813],4);ripple(im,[1260,800],t,92)
 elif a=='rescue_basket' and s['chapter']==4:
  center=1270;width=1750;walk('nim',800,312.5,1,False,'normal');fc=np.array([1510+20*p(q,.1,.9),819.]);basket(im,fc,5);ripple(im,fc+[0,35],t,70)
 elif a in ['rescue_basket','stuck_rope','shared_pull']:
  center=1390;width=1850 if a=='shared_pull' else 1560;u=p(q,.12,.88);rescue=a=='rescue_basket';pull=a=='shared_pull';h=np.array([1190.,751+20*math.sin(u*math.pi)]);ang=-8*u if not rescue else 12*(1-u);hand=mix([1235,680],[1230,655],u);left=hand+[-18,8];right=hand+[12,-4];put('nim' if rescue else 'koa',*h,wr={'left':left,'right':right},angle=ang,head=3,held={'rope_l':{'arm':'left','point':left},'rope_r':{'arm':'right','point':right}})
  fc=mix([1530,819],[1375,777],u) if rescue or pull else np.array([1530.,819.]);g=ImageDraw.Draw(im)
  if not pull:line(g,[left,right,fc+[-40,-20]],'#d7bc83',7)
  basket(im,fc,5);ripple(im,fc+[0,35],t,70)
  if pull:
   rope=[left,right,fc+[-40,-20]]
   for who,x in [('nim',910),('tuk',650)]:
    hh=np.array([x,751+20*math.sin(u*math.pi)]);pt=mix(hh+[35,-65],hh+[30,-100],u);put(who,*hh,wr={'left':pt+[-18,8],'right':pt+[12,-4]},angle=-8*u,head=4,held={'shared_rope_left':{'arm':'left','point':pt+[-18,8]},'shared_rope_right':{'arm':'right','point':pt+[12,-4]}});rope=[pt+[-18,8],pt+[12,-4]]+rope
   line(g,rope,'#d7bc83',7)
   for point in rope[:-1]:g.ellipse((point[0]-5,point[1]-5,point[0]+5,point[1]+5),fill=INK)
  elif not rescue:put('tuk',1800,head=5,expr='shocked');slate(im,[1870,693],14)
 elif a=='drop_board':
  center=1320;h=np.array([1320.,725+26*p(q,.2,.8)]);w=rest(h,6);hand=mix([1390,660],[1415,753],p(q,.15,.75));w['right']=hand;put('tuk',*h,wr=w,angle=6,head=8,expr='shocked');c=hand+[29,18] if q<.73 else mix(hand+[29,18],[1450,854],p(q,.73,.93));slate(im,c,15,35*p(q,.1,.9));ripple(im,[1350,874],t,80)
 elif a in ['confront','council','set_boundary','look_machine']:
  center=1220;width=1940;kh=np.array([950.,725.]);w=rest(kh);hand=mix(normal(kh,'right'),[1047,652],p(q,.1,.8));w['right']=hand
  if a=='council':
   center=1060;width=1740
   for who,x in [('koa',760),('nim',1050),('tuk',1370)]:
    stool(im,x);put(who,x,813,head=-3 if who!='koa' else 3,expr='relief' if who=='nim' else 'smile' if who=='tuk' else 'normal',feet={'left':[x-65,890],'right':[x+65,890]})
   gg=ImageDraw.Draw(im)
   for j in range(7):
    xx=1060+(j-3)*21;yy=960+15*math.cos(j);gg.ellipse((xx-18,yy-8,xx+18,yy+10),fill='#8c8273',outline=INK,width=3)
   for j,col in enumerate(['#d87a30','#f2aa43','#f3ca65']):
    xx=1040+j*18;hh=45+12*math.sin(t*4+j);poly(gg,[(xx-19,957),(xx,957-hh),(xx+18,957)],col,col,1)
  else:
   put('koa',*kh,wr=w,head=3,expr='shocked' if a=='confront' else 'normal',prop=(lambda m:bowl(m,hand+[25,10],0)) if a=='confront' else None);put('nim',1490,head=-4,expr='relief' if s['chapter']>=6 else 'normal');put('tuk',1790,head=-5,expr='shocked' if a=='confront' else 'smile' if s['chapter']>=6 else 'normal')
  if a=='set_boundary':
   for j in range(5):berry(im,[1040+j*48,833]);
   line(ImageDraw.Draw(im),[[1030,866],[1030+240*p(q,.2,.85),866]],'#ddd0a5',6)
  if a=='council':bowl(im,[1220,850],0)
 elif a=='skip_stone':
  center=1390;h=np.array([1350.,725.]);w=rest(h);gr=mix([1410,640],[1462,690],p(q,.1,.50));w['right']=gr;put('koa',*h,wr=w,angle=4*p(q,.1,.5),head=4);g=ImageDraw.Draw(im)
  c=gr if q<.5 else mix(gr,[1655,782],p(q,.5,.8))+[0,-54*math.sin(p(q,.5,.8)*math.pi)];g.ellipse((c[0]-8,c[1]-5,c[0]+8,c[1]+5),fill='#777d69',outline=INK,width=2)
  if q>.8:ripple(im,[1655,782],t,35+40*p(q,.8,1))
 elif a in ['tuk_idea','raise_board','lower_board']:
  center=1390;width=1850;put('koa',950,head=4*p(q,.3,.8),expr='shocked' if a=='raise_board' else 'normal');put('nim',1230,head=5*p(q,.3,.8),expr='normal' if a=='raise_board' else 'relief');h=np.array([1620.,725.+70*p(q,.1,.75) if a=='lower_board' else 725.]);w=rest(h);cc=mix([1690,700],[1680,638],p(q,.12,.75)) if a=='raise_board' else mix([1680,638],[1700,750],p(q,.1,.75)) if a=='lower_board' else np.array([1690.,700.]);w['right']=cc+[-22,0]
  if a=='lower_board':
   stool(im,1700)
   if q>.78:w['right']=mix(cc+[-22,0],normal(h,'right'),p(q,.78,.99))
  put('tuk',*h,wr=w,head=-5+9*p(q,.3,.8),expr='shocked' if a=='lower_board' and q<.6 else 'smile',feet={'left':[1575,890],'right':[1665,890]} if a=='lower_board' else None,prop=lambda m:slate(m,cc,0,blank=True),held={'blank_stone':{'arm':'right','point':cc+[-22,0]}} if a!='lower_board' or q<=.78 else None)
 else:raise ValueError('Unimplemented action '+a)
 # Small deliberate lens change follows the action; no portrait crop or stretch.
 if a in ['empty_basket','fruit_pick','weave','repair_rope','repair_tool','drop_board','skip_stone','empty_bowl','offer_food','discover','ask_stone']:width=min(width,1230);cy=320
 if a in ['roof_notice','roof_repair']:width=1190;cy=320
 if a not in ['shared_pull','council','confront','final_rest']:width*=1-.035*p(q,.45,.95)
 height=width*9/16;cx=min(max(center-width/2,0),2400-width);cam=(cx,cy,cx+width,cy+height);out=im.crop(tuple(round(v) for v in cam)).resize((1280,720),Image.Resampling.LANCZOS)
 if s['id']=='01-01' and q<.45:ImageDraw.Draw(out).text((34,30),'BEFORE THE MACHINE',font=font(25),fill='#fff3db',stroke_width=2,stroke_fill='#553e2c')
 if caption:
  idx=bisect.bisect_right(CSTART,t)-1
  if idx>=0 and t<CUES[idx]['end']:
   if len(CR.cache)>7:CR.cache.clear()
   out=Image.alpha_composite(out,CR.raster(CUES[idx]['text'])[0])
 if collect:ROWS.extend(rows)
 return out.convert('RGB')

def render(ci):
 ch=next(c for c in T['chapters'] if c['id']==ci);first=round(ch['start']*FPS);last=round(ch['end']*FPS);dst=B/f'output/chapter-{ci:02d}.mp4';ROWS.clear()
 ff=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','30','-i','-','-an','-c:v','libx264','-threads','2','-preset','fast','-crf','22','-pix_fmt','yuv420p','-movflags','+faststart',str(dst)],stdin=subprocess.PIPE)
 try:
  for i in range(first,last):
   ff.stdin.write(frame(i/FPS).tobytes())
   if (i-first)%450==0:print(f'Chapter {ci}: {i-first}/{last-first}',flush=True)
  ff.stdin.close();assert ff.wait()==0
 except BaseException:
  ff.stdin.close();ff.wait();raise
 trace={'chapter':ci,'actor_frames':ROWS,'frame_count':last-first,'first_frame':first,'last_frame_exclusive':last,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()+ (B/'rig.py').read_bytes()).hexdigest()};(B/f'output/chapter-{ci:02d}-motion.json').write_text(json.dumps(trace));return str(dst)
def scan():
 errors=[];(B/'output/boards').mkdir(exist_ok=True)
 for s in T['shots']:
  for q in np.linspace(.001,.999,17):
   try:
    im=frame(s['start']+(s['end']-s['start'])*q,collect=False)
    if abs(q-.5)<.01:im.save(B/f"output/boards/{s['id']}.jpg",quality=86)
   except Exception as e:errors.append([s['id'],s['action'],round(float(q),3),str(e)])
 (B/'output/pose-scan.json').write_text(json.dumps(errors,indent=2));print(json.dumps(errors,indent=2),flush=True)
 if errors:raise SystemExit(1)
if __name__=='__main__':scan() if len(sys.argv)<2 else render(int(sys.argv[1]))
