"""Original fictional prehistoric social-satire episode; approved hook reused once."""
from pathlib import Path
import json,re
B=Path(__file__).resolve().parent
CHAPTERS=[
('Before the machine',[
('forest','empty_basket','Koa had never wanted to change the world. He wanted dinner. Lately, even that had become difficult.'),
('river','fish_escape','The river gave them fish on one day and nothing on the next. A successful morning could become an empty evening.'),
('forest','fruit_pick','Nim knew which trees ripened first. But knowing where food grew was different from getting everyone there before it spoiled.'),
('camp','last_portion','One night, Tuk divided the last meal into smaller and smaller pieces. Koa watched his portion disappear before anyone touched it.'),
('forest','discover','The next morning, he found something half buried beneath a fallen branch. It had one blue eye and absolutely no mouth.'),
('forest','ask_stone','Koa asked whether it knew where the food was. The eye lit up. First, the machine wanted to know what they already knew.'),
('river','map_ground','Nim marked the trees, the river and the muddy paths. Koa added where he had wasted most of yesterday walking.'),
('forest','sort_stones','The machine compared their trips, the changing weather and the food they kept throwing away. Then it offered a different plan.'),
('forest','carry_basket','For the first time, the tribe walked out knowing who would gather what, and where they would meet afterward.')]),
('Enough, for a while',[
('forest','fruit_pick','They reached the ripe fruit before the birds. They gathered what they could carry, instead of bringing home things nobody could use.'),
('river','fishing','Nim chose a safer stretch of river. The machine suggested the order of the trips. Neither could have done it alone.'),
('yard','weave','Koa made stronger baskets. Suddenly, less of their dinner arrived on the ground behind him. That was an improvement everyone understood.'),
('store','dry_food','They dried some food, covered some food and finally stopped storing everything directly where the rain could reach it.'),
('camp','share_food','A week later, the same serving stone held more than enough. Nobody needed to pretend they were not hungry anymore.'),
('river','sit_rest','After eating, Koa sat beside the water. There was nothing urgent to do. He was beginning to like this machine.'),
('yard','basket_stack','But more food needed more baskets. More baskets needed more fiber. More storage needed more wood. Useful work had not disappeared.'),
('camp','point_schedule','Someone had to decide what came first. Tuk volunteered. He was organized, serious, and very pleased to have a stone to point at.'),
('yard','tally','The machine suggested recording completed tasks. Tuk loved the idea. At last, helping the tribe could be turned into a number.')]),
('The first performance review',[
('yard','chop','At first, the marks were harmless. Carry wood, earn a mark. Fill a basket, earn a mark. Everyone could see the progress.'),
('store','count_baskets','Soon, people began comparing their marks. Tuk gave the biggest portions to the highest numbers. He called it fair.'),
('camp','exchange_token','Koa discovered that bringing back small bundles earned more marks than bringing one large bundle. So he made more trips.'),
('forest','carry_basket','His legs worked harder. The village got the same amount of wood. His score, however, was excellent.'),
('yard','supervise','Tuk added a schedule, then a minimum, then another meeting about why some people were falling behind the minimum.'),
('camp','blocked_food','The serving stone became a checkpoint. Before dinner, you showed your marks. Being hungry was no longer the only requirement.'),
('yard','tally','The machine displayed rising numbers. Tuk stood a little taller. The tribe was clearly becoming more efficient. Just look at the board.'),
('river','tired_walk','Koa stopped sitting by the river. There was always another mark he could earn before the food was divided.'),
('camp','look_machine','The machine had not threatened anyone. Somehow, its suggestions had become rules nobody remembered agreeing to.')]),
('The work that did not count',[
('store','roof_notice','Then Nim noticed water dripping through the storage roof. Another storm would soak the food they had worked so hard to save.'),
('yard','repair_rope','He spent the morning fixing a support, replacing a rope and moving the driest baskets farther from the opening.'),
('store','roof_repair','It was slow, awkward work. By sunset, the roof held. The food stayed dry. Nim had not completed a single assigned task.'),
('camp','empty_bowl','At dinner, Tuk checked his marks and handed him an empty bowl. Repairs were not on today\'s list.'),
('camp','offer_food','Koa looked from the full store to Nim\'s empty hands. He split his own portion. Tuk reminded him that sharing confused the records.'),
('yard','rain_notice','Before Koa could answer, the wind changed. The first drops struck the schedule. Across the clearing, Nim looked toward the river.'),
('storm','rising_water','The shallow stream was climbing over its banks. Water was heading toward the food. Tuk called for everyone to finish their assigned bundles.'),
('storm','leave_bundle','Koa put his bundle down. For once, he was willing to lose the mark. Nim was already running toward the store.'),
('storm','rescue_basket','The machine still had a plan. The weather had a different one. And dinner was about to float away.')]),
('When the numbers got wet',[
('storm','rescue_basket','Nim grabbed the nearest basket before the current caught it. Koa followed him toward the higher ground.'),
('storm','carry_basket','They moved the food first. Then the dry fiber. Then the tools they would need to repair what the water broke.'),
('storm','stuck_rope','A heavy basket caught on a rope. Koa pulled. Nothing moved. Behind him, Tuk was still holding the schedule.'),
('storm','drop_board','Then the water reached Tuk\'s feet. He looked at the marks, looked at the food, and finally put the board down.'),
('storm','shared_pull','With three people pulling, the basket came free. They dragged it onto the bank, soaked, exhausted, and very much alive.'),
('store','safe_food','By morning, the food was safe. The roof Nim had repaired was still standing. His score was still zero.'),
('camp','confront','Koa carried the empty bowl to the machine. He asked why the person who had saved dinner had been refused dinner.'),
('camp','machine_answer','The answer was uncomfortable. The system had counted the assigned tasks. Those were the marks Tuk had asked it to track.'),
('camp','erase_tally','They had wanted a way to stop going hungry. Somewhere along the way, they had started protecting the score instead of the food.')]),
('How much is enough?',[
('camp','council','That evening, nobody stood behind the serving stone. They sat around the fire, with the empty bowl between them.'),
('camp','offer_food','Before discussing anything, Tuk filled Nim\'s bowl. It was a small decision. The machine had not needed to make it.'),
('camp','set_boundary','Koa asked for a new plan. Enough food for everyone. A reserve for bad weather. And some part of the day that remained their own.'),
('camp','count_need','The machine asked how much was enough. This time, they answered together, using the people they actually needed to feed.'),
('store','inspect_roof','Nim added protecting the store. Koa added carrying useful loads. Tuk admitted that another meeting would not make the roof stronger.'),
('camp','erase_tally','They kept the useful records. They removed the rule that turned every completed task into a competition for dinner.'),
('yard','lower_board','Tuk lowered the schedule. The list was shorter now. Some days would still be difficult. At least the list could change when life did.'),
('forest','fruit_pick','The next morning, they gathered what they needed and stopped. Koa waited for someone to announce another task. Nobody did.'),
('river','sit_rest','He walked to the river and sat down. The machine had helped them find time. They were going to decide what belonged in it.')]),
('One unscheduled afternoon',[
('yard','repair_tool','Nim repaired a tool because it needed repairing, not because a mark was waiting at the end of it.'),
('river','skip_stone','Koa tried skipping stones. Most of them sank immediately. For once, being bad at something was not a problem that required a system.'),
('forest','carry_basket','There would be work tomorrow. Hunger had not become impossible. The tribe had simply stopped mistaking endless work for a good plan.'),
('camp','rest_food','The blue eye still watched the clearing. It could compare routes, count baskets and warn them when supplies were running low.'),
('camp','look_machine','But a better answer depended on a better question. More marks had been easy to measure. A life worth living required the people living it.'),
('camp','tuk_idea','Tuk glanced at the others enjoying the afternoon. An idea crossed his face. Perhaps the machine could help them use this time more efficiently.'),
('camp','raise_board','He picked up a blank stone. Koa stopped chewing. Nim stopped working. Very slowly, everyone turned toward Tuk.'),
('camp','lower_board','Tuk looked at the stone. Then at their faces. He put it down, took a piece of food, and sat beside them.'),
('camp','final_rest','For once, the schedule was empty. Nobody needed to fill it. And the tribe had finally found something the machine could not choose for them.')])]

def build():
 chapters=[];texts=[]
 drops={1:8,2:0,3:8,4:5,5:1,6:6,7:2}
 for ci,(name,rows) in enumerate(CHAPTERS,1):
  rows=[r for j,r in enumerate(rows) if j!=drops[ci]]
  beats=[{'id':f'{ci:02d}-{j:02d}','setting':s,'action':a,'text':t,'primary_information':'A concrete action and visible consequence in the fictional story'} for j,(s,a,t) in enumerate(rows,1)]
  text='\n\n'.join(b['text'] for b in beats);chapters.append({'id':ci,'title':name,'text':text,'beats':beats});texts.append(text);(B/f'audio/chapter-{ci:02d}.txt').write_text(text+'\n')
 story={'title':'Cavemen Asked AI for More Food. It Gave Them Jobs.','language':'English','ratio':'16:9','dimensions':[1280,720],'fps':30,'intro':'18-second user-reviewed opening reused once, not regenerated','chapters':chapters,'genre':'Fictional Stone Age/AI social satire; not factual prehistory or a prediction about all AI','visual_direction':'New natural/resource/work/storm settings; new actions and consequences; no looping of the preview or talking presenter filler'}
 intro=' '.join(c['text'] for c in json.loads((B/'intro-captions.json').read_text()))
 (B/'story.json').write_text(json.dumps(story,indent=2));(B/'script.txt').write_text(intro+'\n\n'+'\n\n'.join(texts)+'\n')
 words=len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?",' '.join(texts)));chars=sum(len(c['text']) for c in chapters)
 print(json.dumps({'new_chapters':len(chapters),'new_shots':sum(len(c['beats']) for c in chapters),'new_words':words,'new_characters':chars,'estimated_new_tts_usd':chars*15/1e6,'estimated_total_minutes_at_175wpm':words/175+.3},indent=2))
if __name__=='__main__':build()
