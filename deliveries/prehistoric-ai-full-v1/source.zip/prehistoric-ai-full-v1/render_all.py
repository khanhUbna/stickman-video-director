"""Parallel local chapter encodes; no delegated agents or network requests."""
from concurrent.futures import ProcessPoolExecutor,as_completed
import os
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
def one(ci):
 from film import render,B
 import hashlib,json
 trace=B/f'output/chapter-{ci:02d}-motion.json';movie=B/f'output/chapter-{ci:02d}.mp4';fp=hashlib.sha256((B/'film.py').read_bytes()+(B/'rig.py').read_bytes()).hexdigest()
 if trace.exists() and movie.exists() and json.loads(trace.read_text()).get('source_sha256')==fp:return ci,str(movie)+' (saved chapter reused)'
 return ci,render(ci)
if __name__=='__main__':
 with ProcessPoolExecutor(max_workers=4) as pool:
  futures=[pool.submit(one,i) for i in [5,1,3,6,2,4,7]]
  for f in as_completed(futures):
   ci,path=f.result();print('COMPLETED CHAPTER',ci,path,flush=True)
