"""Verify rendered geometry, master original sound and mux the complete film."""
from pathlib import Path
import json,hashlib,subprocess,re
import numpy as np
import film
B=Path(__file__).resolve().parent;O=B/'output';T=film.T;FPS=30;D=T['duration']
def run(args):return subprocess.run(args,check=True,capture_output=True)
def measure(path):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(path),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-']);return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
def main():
 fp=hashlib.sha256((B/'film.py').read_bytes()+(B/'rig.py').read_bytes()).hexdigest();count=540;rows=[];bone=0;stance=[];contacts={};coverage={s['id']:set() for s in T['shots']};prev={}
 for ci in range(1,8):
  d=json.loads((O/f'chapter-{ci:02d}-motion.json').read_text());assert d['source_sha256']==fp,('stale render',ci);assert d['first_frame']==count;count=d['last_frame_exclusive'];rows.extend(d['actor_frames'])
 assert count==round(D*FPS)
 for r in sorted(rows,key=lambda x:(x['t'],x['who'])):
  assert set(r['arms'])==set(r['legs'])=={'left','right'};bone=max(bone,r['bone_error']);coverage[r['shot']].add(r['who']);old=prev.get(r['who']);prev[r['who']]=r
  for name,e in r['contacts'].items():contacts[name]=max(contacts.get(name,0),e)
  if old and old['shot']==r['shot'] and r['t']-old['t']<.04:
   for side in ['left','right']:
    if old['legs'][side]['planted'] and r['legs'][side]['planted']:stance.append(float(np.linalg.norm(np.array(r['legs'][side]['joints'][-1])-old['legs'][side]['joints'][-1])))
 assert bone<1e-8;assert max(stance,default=0)<1e-5,max(stance);assert max(contacts.values(),default=0)<1e-5
 assert all(coverage.values())
 try:film.rig.ik([0,0],[400,0],[80,80],1,'unreachable injection')
 except ValueError:negative=True
 else:raise AssertionError('Reach guard failed')
 pre=measure(B/'audio/mix-unmastered.wav');flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
 master=B/'audio/mix-mastered.wav';run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix-unmastered.wav'),'-af',flt,'-ar','48000','-ac','2',str(master)])
 # The approved preview has AAC priming. Remux its picture losslessly first:
 # otherwise concat's unused audio stream shifts all video by ~21 ms.
 run(['ffmpeg','-v','error','-y','-i',str(O/'intro-approved.mp4'),'-map','0:v:0','-an','-c:v','copy',str(O/'intro-picture.mp4')])
 files=[O/'intro-picture.mp4']+[O/f'chapter-{i:02d}.mp4' for i in range(1,8)];(O/'concat.txt').write_text(''.join("file '"+str(p)+"'\n" for p in files));movie=O/'cavemen-ai-food-jobs.mp4'
 run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(O/'concat.txt'),'-i',str(master),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-t',str(D),'-movflags','+faststart',str(movie)])
 probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)]).stdout);v=next(x for x in probe['streams'] if x['codec_type']=='video');a=next(x for x in probe['streams'] if x['codec_type']=='audio')
 assert [v['width'],v['height'],v['r_frame_rate'],v['codec_name'],v['pix_fmt']]==[1280,720,'30/1','h264','yuv420p'];assert int(v['nb_frames'])==round(D*FPS);assert abs(float(v['duration'])-float(a['duration']))<.08;assert movie.stat().st_size<95*1024**2
 run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-']);post=measure(movie);assert float(post['input_tp'])<=-.5
 def intro_pixels(path):
  data=run(['ffmpeg','-v','error','-i',str(path),'-t','18','-an','-f','framemd5','-']).stdout.decode();return [r.split(',')[-1].strip() for r in data.splitlines() if not r.startswith('#')]
 approved=intro_pixels(O/'intro-approved.mp4');actual=intro_pixels(movie);assert len(approved)==540 and approved==actual,'Approved hook picture changed'
 ledger=json.loads((B/'audio/voice-ledger.json').read_text());qa={'title':json.loads((B/'story.json').read_text())['title'],'duration_seconds':float(probe['format']['duration']),'dimensions':[1280,720],'fps':30,'frames':int(v['nb_frames']),'full_decode':'pass','audio_video_difference_seconds':abs(float(v['duration'])-float(a['duration'])),'file_bytes':movie.stat().st_size,'sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'source_sha256':fp,'story':{'new_shots':len(T['shots']),'new_action_families':len(set(s['action'] for s in T['shots'])),'settings':sorted(set(s['setting'] for s in T['shots'])),'approved_hook_reused_seconds':18,'hook_looped':False},'motion':{'actor_frames':len(rows),'four_drawn_chains_per_actor_frame':True,'max_fixed_bone_error_px':bone,'max_consecutive_planted_foot_drift_px':max(stance,default=0),'authored_grip_errors_px':contacts,'unreachable_target_guard':negative,'cast_coverage':{k:sorted(v) for k,v in coverage.items()}},'captions':{'language':'English','cues':len(film.CUES),'coverage':'Exact normalized script tokens; approved intro cues retained','timing':'Offline acoustic forced alignment, actual chapter audio offsets','profile':T['caption_profile']},'sound':{'voice':'OpenAI tts-1 / alloy, speed 1','new_tts_calls':7,'tts_estimate_usd':ledger['estimated_usd'],'account_billing_verified':False,'new_image_generation_calls':4,'image_cost_not_exposed':True,'paid_transcription_calls':0,'music_and_Foley':'Original local synthesis; no external music recording','loudness':post},'review':{'renderer':'Project-local articulated extension; installed B6 runtime unchanged','author_visual_evidence':'See visual-review.md and decoded final-video boards','independent_creative_review':'Unavailable; not claimed','full_real_time_AV_listening_by_agent':'Not performed; automated audio measurements are not listening review','installed_B6_35_subcheck_reference_acceptance':'Not claimed','user_review':'Full-film viewing remains for user'},'YouTube_upload':False}
 qa['story']['approved_hook_decoded_frame_hashes_match']=True
 (O/'QA.json').write_text(json.dumps(qa,indent=2));(O/'probe.json').write_text(json.dumps(probe,indent=2));print(json.dumps({k:qa[k] for k in ['duration_seconds','frames','file_bytes','sha256']},indent=2));print('Motion max errors:',bone,max(stance,default=0),'LUFS:',post['input_i'],flush=True)
if __name__=='__main__':main()
