"""Package only the authorized film and reproducible source; never credentials."""
from pathlib import Path
import json,hashlib,zipfile,shutil,os,re
B=Path(__file__).resolve().parent;O=B/'output';DEST=Path('/workspace/stickman-video-director/deliveries/prehistoric-ai-full-v1')
def main():
 qa=json.loads((O/'QA.json').read_text());assert qa['full_decode']=='pass';DEST.mkdir(parents=True,exist_ok=True)
 files=[B/'README.md',B/'rights.md',B/'visual-review.md',B/'repair-findings.md',B/'script.txt',B/'story.json',B/'timeline.json',B/'review-evidence.json']
 files += [O/n for n in ['cavemen-ai-food-jobs.mp4','captions-en.srt','captions-en.vtt','chapters.txt','description-en.txt','QA.json','encoded-storyboard-1.jpg','encoded-storyboard-2.jpg']]
 for p in files:shutil.copy2(p,DEST/p.name)
 source=list(B.glob('*.py'))+list(B.glob('*.json'))+[B/n for n in ['script.txt','README.md','rights.md','visual-review.md','repair-findings.md','LICENSE','requirements.txt']]
 source += [p for folder in ['characters','art','fonts'] for p in (B/folder).rglob('*') if p.is_file()]
 source += [B/'audio/intro-approved.wav',B/'audio/voice-ledger.json',B/'audio/sound-events.json',O/'intro-approved.mp4',O/'pose-scan.json',O/'pose-scan-rejected-v1.json']
 source += [p for p in (B/'audio').glob('chapter-*') if re.fullmatch(r'chapter-\d\d(?:\.wav|\.txt|-words\.json|-request\.json)',p.name)]
 source += list(O.glob('chapter-*-motion.json'))
 source += [O/n for n in ['captions-en.srt','captions-en.vtt','chapters.txt','description-en.txt','QA.json','probe.json']]
 secret=os.environ.get('OPENAI_API_KEY','').encode()
 for p in set(source):
  if p.suffix in ['.json','.py','.txt','.md']:
   data=p.read_bytes()
   if secret and secret in data:raise RuntimeError('Credential detected; packaging stopped')
 archive=DEST/'source.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(set(source)):z.write(p,'prehistoric-ai-full-v1/'+str(p.relative_to(B)))
 assert archive.stat().st_size<95*1024**2
 manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in DEST.iterdir() if p.is_file() and p.name!='SHA256.json'};(DEST/'SHA256.json').write_text(json.dumps(manifest,indent=2))
 checkpoint={'state':'Full film exported, locally checked, branch-delivery package prepared','video':str((DEST/'cavemen-ai-food-jobs.mp4').relative_to(DEST.parent.parent)),'duration_seconds':qa['duration_seconds'],'new_tts_calls':7,'tts_estimate_usd':.10086,'new_image_calls':4,'YouTube_upload':False,'existing_audio':'Reuse saved speech for any visual corrections','review_limits':qa['review']};(DEST/'CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2));print('Delivery files:',len(manifest)+2,'source MiB:',round(archive.stat().st_size/1024**2,2),flush=True)
if __name__=='__main__':main()
