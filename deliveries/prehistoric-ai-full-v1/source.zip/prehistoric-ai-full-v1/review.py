"""Extract review evidence exclusively from the final encoded MP4."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,hashlib
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parent;O=B/'output';E=O/'review';E.mkdir(exist_ok=True);T=json.loads((B/'timeline.json').read_text());MOV=O/'cavemen-ai-food-jobs.mp4'
def one(item):
 sid,at,name=item;dst=E/f'{name}.jpg';subprocess.run(['ffmpeg','-v','error','-y','-ss',str(at),'-i',str(MOV),'-frames:v','1','-q:v','2',str(dst)],check=True,capture_output=True);return {'shot':sid,'time':round(at,4),'file':str(dst.relative_to(B))}
def main():
 specs=[('intro',3.0,'intro-ask'),('intro',8,'intro-food'),('intro',13.4,'intro-block')]
 specs.extend((s['id'],s['start']+(s['end']-s['start'])*.58,'shot-'+s['id']) for s in T['shots'])
 detail=[('01-03','fruit-walk'),('02-06','basket-lift'),('03-01','axe-strike'),('04-05','bowl-share'),('04-03','roof-repair'),('05-04','shared-rope'),('06-01','fire-council'),('07-07','board-release')]
 for sid,name in detail:
  s=next(s for s in T['shots'] if s['id']==sid)
  for q in [.10,.35,.65,.95]:specs.append((sid,s['start']+(s['end']-s['start'])*q,f'{name}-{q:.2f}'))
 with ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(one,specs))
 normal=[r for r in records if '/shot-' in r['file']]
 for page in range(2):
  selected=normal[page*28:(page+1)*28];board=Image.new('RGB',(1280,7*205),'#28221c');g=ImageDraw.Draw(board)
  for j,r in enumerate(selected):
   img=Image.open(B/r['file']);img.thumbnail((320,180));x=j%4*320;y=j//4*205;board.paste(img,(x,y));s=next(s for s in T['shots'] if s['id']==r['shot']);g.text((x+4,y+183),r['shot']+' '+s['action'],fill='white')
  board.save(O/f'encoded-storyboard-{page+1}.jpg',quality=92)
 for sid,name in detail:
  selected=[r for r in records if name in r['file']];board=Image.new('RGB',(1280,720))
  for j,r in enumerate(selected):board.paste(Image.open(B/r['file']).resize((640,360)),(j%2*640,j//2*360))
  board.save(E/f'{name}-sequence.jpg',quality=92)
 (B/'review-evidence.json').write_text(json.dumps({'movie_sha256':hashlib.sha256(MOV.read_bytes()).hexdigest(),'source':'Decoded final MP4, not source render stills','frames':records,'limits':'Frame sequences do not constitute independent creative review or real-time audiovisual listening.'},indent=2));print('Decoded evidence frames:',len(records),flush=True)
if __name__=='__main__':main()
