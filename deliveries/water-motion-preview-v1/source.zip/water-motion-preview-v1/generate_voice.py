"""Authorized chapter-level native alloy; save immediately; never retry/revoice."""
from pathlib import Path
import os,json,urllib.request,urllib.error,subprocess,hashlib,wave
B=Path(__file__).resolve().parent;story=json.loads((B/'story.json').read_text());ledger=[]
for chapter in story['chapters']:
 ci=chapter['id'];text=chapter['text'];dst=B/f'audio/chapter-{ci:02d}.wav';raw=B/f'audio/chapter-{ci:02d}-api.wav';request_record=B/f'audio/chapter-{ci:02d}-request.json'
 if dst.exists():print(f'Reuse chapter {ci}',flush=True)
 else:
  if raw.exists():print(f'Normalize saved response for chapter {ci}',flush=True)
  else:
   if request_record.exists():raise SystemExit(f'Chapter {ci} already attempted without a saved response; no automatic paid retry.')
   request_record.write_text(json.dumps({'model':'tts-1','voice':'alloy','characters':len(text),'estimated_usd':len(text)*15/1e6,'speed':1,'state':'attempted','authorization':'User requested a 15-second moving water-supply proof; one new short English narration, estimate below USD 0.005 announced before call','automatic_retry':False},indent=2))
   req=urllib.request.Request('https://api.openai.com/v1/audio/speech',data=json.dumps({'model':'tts-1','voice':'alloy','input':text,'response_format':'wav','speed':1}).encode(),headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'application/json'})
   try:
    with urllib.request.urlopen(req,timeout=180) as r:raw.write_bytes(r.read())
   except urllib.error.HTTPError as e:raise SystemExit(f'Speech HTTP {e.code}; no retry and no key logging.')
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-ar','48000','-ac','1','-c:a','pcm_s16le',str(dst)],check=True)
  doc=json.loads(request_record.read_text());doc['state']='saved';doc['sha256']=hashlib.sha256(dst.read_bytes()).hexdigest();request_record.write_text(json.dumps(doc,indent=2))
 with wave.open(str(dst)) as w:duration=w.getnframes()/w.getframerate()
 ledger.append({'chapter':ci,'path':str(dst.relative_to(B)),'characters':len(text),'duration':duration,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'estimated_usd':len(text)*15/1e6})
 (B/'audio/voice-ledger.json').write_text(json.dumps({'model':'tts-1','voice':'alloy','speed':1,'chapters':ledger,'estimated_usd':sum(x['estimated_usd'] for x in ledger),'billing_verified':False,'new_paid_transcription_calls':0},indent=2))
 print(f'Chapter {ci}: saved {duration:.2f}s native speech',flush=True)
