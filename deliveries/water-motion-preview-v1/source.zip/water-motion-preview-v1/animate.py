"""15-second continuous hydraulic cutaway. Fixed camera; every mechanism local.

Illustrative water-volume model, not an engineering design or CFD solution.
Generated mascot expressions are layered over original animated vector mechanisms.
"""
from pathlib import Path
from functools import lru_cache
import json,math,subprocess,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
B=Path(__file__).resolve().parent;O=B/'output';S=2;W=1280;H=720;FPS=30;D=15.;INK='#16374d';BLUE='#189ed2';PALE='#e7f7fb'
F=str(B/'fonts/DejaVuSans-Bold.ttf')
WORDS=json.loads((B/'audio/chapter-01-words.json').read_text())['words'];OFFSET=.18
STOP=next(w['start'] for w in WORDS if w['word'].lower()=='stops')+OFFSET
OPEN=next(w['start'] for w in WORDS if w['word'].lower()=='then')+OFFSET-.48
DT=1/600;TIMES=np.arange(0,D+DT,DT);V=[];IN=[];OUT=[];SPIN=[];WALK=[];volume=.30;angle=0;travel=0
def ease(x):x=max(0.,min(1.,float(x)));return x*x*(3-2*x)
def ramp(t,a,b):return ease((t-a)/(b-a))
def motor(t):return ramp(t,.58,.85)*(1-ramp(t,STOP,STOP+.45))
def valve(t):return ramp(t,OPEN,OPEN+.40)
def interpolate(a,t):return float(np.interp(t,TIMES,a))
for t in TIMES:
 head=335-(350-156*volume);qin=.135*motor(t);qout=.029*valve(t)*math.sqrt(max(0,head)/80)
 V.append(volume);IN.append(qin);OUT.append(qout);SPIN.append(angle);WALK.append(travel)
 volume+=(qin-qout)*DT;angle+=2*math.pi*2.8*motor(t)*DT;travel+=145*valve(t)*math.sqrt(max(0,head)/80)*DT
V=np.array(V);IN=np.array(IN);OUT=np.array(OUT);SPIN=np.array(SPIN);WALK=np.array(WALK)
def st(t):
 v=interpolate(V,t);return {'level':v,'surface':350-156*v,'qin':interpolate(IN,t),'qout':interpolate(OUT,t),'angle':interpolate(SPIN,t),'travel':interpolate(WALK,t),'motor':motor(t),'valve':valve(t),'head':335-(350-156*v)}
def xy(p):return tuple(round(float(x)*S) for x in p)
def box(p):return tuple(round(float(x)*S) for x in p)
def line(g,points,fill=INK,width=4):g.line([xy(p) for p in points],fill=fill,width=max(1,round(width*S)),joint='curve')
def ellipse(g,rect,fill,outline=None,width=1):g.ellipse(box(rect),fill=fill,outline=outline,width=round(width*S))
def rect(g,bb,fill,outline=None,width=1,radius=0):
 if radius:g.rounded_rectangle(box(bb),radius*S,fill=fill,outline=outline,width=round(width*S))
 else:g.rectangle(box(bb),fill=fill,outline=outline,width=round(width*S))
def poly(g,pts,fill,outline=INK,width=3):
 g.polygon([xy(p) for p in pts],fill=fill)
 if outline:line(g,pts+[pts[0]],outline,width)
@lru_cache(maxsize=30)
def font(n):return ImageFont.truetype(F,round(n*S))
def text(g,pos,words,n=22,fill=INK,anchor='mm'):g.text(xy(pos),words,font=font(n),fill=fill,anchor=anchor)
def rotate(p,a):
 x,y=p;return np.array([x*math.cos(a)-y*math.sin(a),x*math.sin(a)+y*math.cos(a)])
def ik(root,target,length=45,pole=1):
 root=np.array(root,float);target=np.array(target,float);v=target-root;d=np.linalg.norm(v)
 if not .001<d<2*length-.001:raise ValueError(f'Unreachable mascot limb {d}')
 along=v/d;mid=(root+target)/2;elbow=mid+pole*np.array([-along[1],along[0]])*math.sqrt(length*length-d*d/4);return np.array([root,elbow,target])
def curve(points,steps=30):
 a,b,c,d=map(np.array,points);return [((1-u)**3*a+3*(1-u)**2*u*b+3*(1-u)*u*u*c+u**3*d).tolist() for u in np.linspace(0,1,steps)]
P0=[(145,389),(145,440),(292,440)]
P1=[(394,435),(465,435),(465,165),(625,165),(625,196)]
P2=[(735,354),(735,575),(1110,575),(1110,390)]
P3=curve([(1110,390),(1110,335),(1110,300),(1080,300)],18)+curve([(1080,300),(1040,300),(1040,310),(1040,335)],18)[1:]
def along(path,d):
 p=np.asarray(path,float);lens=np.linalg.norm(np.diff(p,axis=0),axis=1);d=float(d)%float(sum(lens))
 for i,L in enumerate(lens):
  if d<=L:return p[i]+(p[i+1]-p[i])*d/L,(p[i+1]-p[i])/L
  d-=L
 return p[-1],np.array([0.,1.])
def pipe(g,path,travel,active=True):
 line(g,path,INK,28);line(g,path,'#d4e5e6',21);line(g,path,'#269fd0',15);line(g,[(x-2,y-2) for x,y in path],'#77d8eb',3)
 if active:
  total=sum(np.linalg.norm(np.array(b)-a) for a,b in zip(path,path[1:]))
  for d in np.arange(0,total,63):
   c,v=along(path,d+travel);n=np.array([-v[1],v[0]]);poly(g,[c+v*8,c-v*5+n*4,c-v*5-n*4],'#e7fcff',None)
@lru_cache(maxsize=4)
def mascot_sprite(name):
 im=Image.open(B/f'art/{name}.png').convert('RGBA');scale=128/im.height;im=im.resize((round(im.width*scale*S),128*S),Image.Resampling.LANCZOS);return im
def mascot(im,t,state):
 press=ramp(t,.1,.55)*(1-ramp(t,.85,1.45));recoil=ramp(t,STOP+.3,STOP+.65)*(1-ramp(t,STOP+1.2,STOP+1.8));joy=ramp(t,6.8,7.5)
 center=np.array([210+9*press-9*recoil,470+7*press-4*recoil+2*math.sin(t*2)*joy]);expr='effort' if .18<t<1.35 else 'surprised' if STOP+.25<t<6.8 else 'happy' if t>=6.8 else 'normal';spr=mascot_sprite(expr);sw=spr.width/S
 # Feet are pinned while the droplet leans into the physical switch.
 hips=[center+[-20,57],center+[20,57]];feet=[np.array([190.,604.]),np.array([240.,604.])];legchains=[ik(a,b,45,1 if j==0 else -1) for j,(a,b) in enumerate(zip(hips,feet))]
 shoulders={'left':center+[-sw*.40,19],'right':center+[sw*.40,19]};wr={'left':center+[-65,49],'right':center+[66,45]};button=np.array([278.,422.]);wr['right']=wr['right']*(1-press)+button*press
 if recoil>.01:
  wr['left']=wr['left']*(1-recoil)+(center+[-64,-22])*recoil;wr['right']=wr['right']*(1-recoil)+(center+[66,-20])*recoil
 if joy>0:
  wr['right']=wr['right']*(1-joy)+(center+[70,-10-5*math.sin(t*3)])*joy
 arms={side:ik(root,wr[side],48,1 if side=='left' else -1) for side,root in shoulders.items()}
 g=ImageDraw.Draw(im);ellipse(g,(165,605,263,621),'#d0c4a3')
 for ch in legchains:
  line(g,ch,INK,6);x,y=ch[-1];rect(g,(x-10,y-2,x+12,y+8),INK,radius=5)
 for ch in arms.values():line(g,ch,INK,6)
 im.alpha_composite(spr,xy(center-np.array([sw/2,64])))
 for ch in arms.values():
  x,y=ch[-1];ellipse(g,(x-7,y-7,x+7,y+7),'#f9fcf3',INK,3)
 if .55<t<.85:assert np.linalg.norm(arms['right'][-1]-button)<1e-8
 return {'body':center.tolist(),'expression':expr,'feet':[p.tolist() for p in feet],'right_hand':arms['right'][-1].tolist(),'switch':button.tolist(),'press':press,'max_bone_error':max(abs(np.linalg.norm(ch[1]-ch[0])-L) for ch,L in [(c,45) for c in legchains]+[(c,48) for c in arms.values()])}
def background():
 im=Image.new('RGBA',(W*S,H*S),'#fff9eb');g=ImageDraw.Draw(im)
 rect(g,(0,95,1280,625),'#eef9f5');ellipse(g,(-160,300,700,880),'#d8ebcf');ellipse(g,(500,320,1500,850),'#e2edd5');rect(g,(0,550,1280,625),'#e8d8b7');line(g,[(0,550),(1280,550)],'#9cb884',3)
 for j in range(36):
  x=(j*107)%1280;y=566+(j*19)%48;ellipse(g,(x,y,x+4,y+2),'#c6b28d')
 # A cutaway kitchen; supply and drain are visibly distinct.
 rect(g,(910,126,1258,620),'#fff1d8',INK,4,14);rect(g,(1010,150,1230,245),'#caeef5',INK,3,8);line(g,[(1120,150),(1120,245)],'#fffdfa',6);line(g,[(1010,197),(1230,197)],'#fffdfa',6)
 rect(g,(928,444,1240,616),'#efd0a0',INK,4,4);line(g,[(928,486),(1240,486)],'#a37e50',2);line(g,[(1180,486),(1180,616)],'#a37e50',2)
 text(g,(1130,595),'SUPPLY CUTAWAY',12,'#6d725f')
 # Tower cross-braces hold the tank above the tap.
 for a,b in [((595,355),(570,608)),((755,355),(780,608)),((590,430),(768,565)),((763,430),(578,565))]:line(g,[a,b],'#697f82',10)
 rect(g,(551,608,800,620),'#798f89',INK,3,4)
 text(g,(640,38),'WHY YOUR TAP STILL RUNS',34);text(g,(640,76),'One example: an elevated storage tank',18,'#536f76')
 return im
BACKGROUND=background();TRACE=[]
RANGES=[(0,7,'A pump pushes water into a tank.'),(7,11,'Then the pump stops.'),(11,18,'So why does the tap still run?'),(18,26,'Because the water is higher than your tap.'),(26,30,'Gravity keeps it moving.')]
CUES=[{'start':WORDS[i]['start']+OFFSET,'end':WORDS[j-1]['end']+OFFSET+.12,'text':s} for i,j,s in RANGES]
def frame(t,collect=True):
 z=st(t);im=BACKGROUND.copy();g=ImageDraw.Draw(im)
 # Reservoir contains already-treated water; this sample is not a raw-water
 # intake bypassing treatment. Pump and gravity supply are separate stages.
 rect(g,(35,344,245,417),'#f9ffff',INK,5,8);sy=369+interpolate(np.cumsum(IN)*DT,t)*13;rect(g,(43,sy,237,408),BLUE,radius=3);text(g,(138,310),'TREATED WATER',20);text(g,(138,333),'from the treatment plant',13,'#536f76')
 line(g,[(65,417),(65,540)],'#75888b',7);line(g,[(217,417),(217,540)],'#75888b',7)
 # Drain is gray and independent. The blue supply is painted over its crossing.
 line(g,[(1084,464),(1084,514),(1230,514)],'#798286',13);line(g,[(1084,464),(1084,514),(1230,514)],'#c0c9c9',7);text(g,(1225,535),'DRAIN',12,'#697575',anchor='rm')
 pipe(g,P0,z['angle']*18,z['motor']>.03);pipe(g,P1,z['angle']*18,z['motor']>.03);pipe(g,P2,z['travel'],z['valve']>.02)
 # An inline non-return valve prevents reverse flow through a stopped pump.
 ellipse(g,(452,329,478,355),'#fff4cb',INK,3);line(g,[(458,347),(472,337)],'#c28a2e',4)
 # Working centrifugal impeller, fixed casing and actual axle rotation.
 rect(g,(291,480,398,501),'#f3bd55',INK,4,6);rect(g,(307,500,382,544),'#a6b4b1',INK,4,5);ellipse(g,(291,386,399,494),'#f6c65a',INK,6);ellipse(g,(301,396,389,484),'#c9edf0',INK,3)
 for j in range(6):
  a=z['angle']+j*math.pi/3;c=np.array([345.,440.]);pts=[c+rotate(v,a) for v in [(9,-8),(32,-18),(36,-7),(20,9)]];poly(g,pts,'#2d7f9c',INK,2)
 ellipse(g,(333,428,357,452),'#ffe099',INK,3)
 on=z['motor']>.03;rect(g,(261,405,295,438),'#e2e5dc',INK,3,5);ellipse(g,(269,412,287,430),'#55c96c' if on else '#db8274',INK,2)
 text(g,(346,358),'PUMP',23);text(g,(346,382),'ON' if on else 'OFF',20,'#23834e' if on else '#b14b40')
 # Transparent water tank. Surface follows the volume balance model.
 rect(g,(575,180,775,365),'#f9ffff',INK,6,18);inside=(588,193,762,351);water=Image.new('RGBA',im.size);wg=ImageDraw.Draw(water);surface=z['surface'];wave=[(x,surface+2.1*math.sin(x*.065+t*4)) for x in np.linspace(588,762,60)];poly(wg,wave+[(762,351),(588,351)],'#24afe0',None)
 mask=Image.new('L',im.size);mg=ImageDraw.Draw(mask);mg.rounded_rectangle(box(inside),radius=8*S,fill=255);water.putalpha(Image.composite(water.getchannel('A'),Image.new('L',im.size),mask));im.alpha_composite(water)
 g=ImageDraw.Draw(im);line(g,wave,'#bcf4fc',3)
 for j in range(7):
  xx=605+j*21;yy=surface+15+(j*17+t*14)%(max(18,335-surface));ellipse(g,(xx-2,yy-2,xx+2,yy+2),'#9ce7f6')
 rect(g,(575,180,775,365),None,INK,6,18);line(g,[(596,202),(596,330)],'#d7eef0',5);text(g,(675,132),'STORAGE TANK',23)
 # Vent keeps the headspace at atmospheric pressure. The low outlet is
 # explicitly open into the stored water, rather than behind a closed wall.
 line(g,[(748,181),(748,157)],INK,11);line(g,[(748,181),(748,157)],'#b9ced0',6);poly(g,[(737,156),(748,149),(759,156)],'#9eb7bd',INK,2)
 pipe(g,[(735,339),(735,384)],z['travel'],z['valve']>.02)
 if z['motor']>.03:
  width=5+5*z['motor'];line(g,[(625,194),(625,surface)],'#4ec7e8',width)
  for j in range(3):
   yy=197+(t*112+j*15)%(max(8,surface-196));ellipse(g,(622,yy-3,628,yy+3),'#c7f4fb')
 # Sink bowl and the actual curved faucet; supply connects at the stem,
 # not under the falling stream. All pipe arrows follow the same path.
 rect(g,(930,401,1240,423),'#acbec2',INK,5,7);poly(g,[(950,423),(1217,423),(1182,478),(984,478)],'#e9f3f2',INK,4);ellipse(g,(975,421,1195,455),'#d6e8e9',INK,3);ellipse(g,(1075,454,1093,468),'#52666b',INK,2)
 pipe(g,P3,z['travel']+65,z['valve']>.02);rect(g,(1090,384,1132,399),'#d5e2e2',INK,3,5)
 lever=np.array([1110.,365.]);end=lever+rotate([28,0],-math.pi*.40*z['valve']);line(g,[lever,end],'#7a939b',10);line(g,[lever,end],'#d3e6e8',5);ellipse(g,(1104,359,1116,371),'#9fb5b7',INK,2)
 text(g,(1090,265),'YOUR TAP',23);text(g,(1190,366),'OPEN' if z['valve']>.95 else 'CLOSED',14,'#1681a3' if z['valve']>.95 else '#697477')
 if z['valve']>.01:
  w=3+5*math.sqrt(z['qout']/.029);points=[]
  for yy in np.linspace(335,438,30):points.append((1040-w/2+1.2*math.sin(yy*.18-t*11),yy))
  for yy in np.linspace(438,335,30):points.append((1040+w/2+1.2*math.sin(yy*.18-t*11+1),yy))
  poly(g,points,'#36bbeb',None);line(g,[(1040,337),(1040,433)],'#b3f2fa',2)
  for j in range(7):
   yy=335+(t*250+j*15)%100;ellipse(g,(1038,yy-4,1042,yy+4),'#ecffff')
  for j in range(6):
   u=(t*2.7+j/6)%1;xx=1040+(j%2*2-1)*(8+21*u);yy=438-23*math.sin(math.pi*u)+9*u;ellipse(g,(xx-2,yy-3,xx+2,yy+3),'#43b9df')
  line(g,[(1043,440),(1082,460)],'#73cfdf',3)
 # Height bracket appears on the explanatory word, above the caption area.
 if t>=6.4:
  x=839;line(g,[(x,surface),(x,335)],'#5c8f9a',3);line(g,[(x-7,surface),(x+7,surface)],'#5c8f9a',3);line(g,[(x-7,335),(x+7,335)],'#5c8f9a',3);text(g,(x+2,359),'HEIGHT',15,'#437a86')
  for j in range(4):
   yy=surface+(335-surface)*(j+.5)/4;poly(g,[(866,yy+6),(861,yy-2),(871,yy-2)],'#52a1b5',None)
 m=mascot(im,t,z)
 cue=next((c for c in CUES if c['start']<=t<c['end']),None)
 words=cue['text'] if cue else 'PUMP OFF · WATER STILL FLOWS' if t>=10.0 else ''
 if words:
  bb=g.textbbox((0,0),words,font=font(29));tw=(bb[2]-bb[0])/S;rect(g,(640-tw/2-22,650,640+tw/2+22,700),'#153b52',radius=16);text(g,(640,675),words,29,'#fffef3')
 if collect:TRACE.append({'time':t,**z,'mascot':m})
 return im.convert('RGB').resize((1280,720),Image.Resampling.LANCZOS)
def render():
 TRACE.clear();f=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'picture.mp4')],stdin=subprocess.PIPE)
 try:
  for i in range(450):
   f.stdin.write(frame(i/FPS).tobytes())
   if i%90==0:print('Frames',i,'/450',flush=True)
  f.stdin.close();assert f.wait()==0
 except BaseException:f.stdin.close();f.wait();raise
 (O/'motion.json').write_text(json.dumps(TRACE));print('Picture and actual state trace saved.',flush=True)
if __name__=='__main__':
 if len(__import__('sys').argv)>1:
  for t in [0,.6,1.5,2.7,3.6,5,7,10,14.5]:frame(t,False).save(O/f'frame-{t:.1f}.png')
  print('Pose and mechanism samples saved.')
 else:render()
