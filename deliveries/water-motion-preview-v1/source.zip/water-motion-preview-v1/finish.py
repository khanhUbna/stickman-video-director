"""Original motion-linked audio, final mux, physical and media checks."""
from pathlib import Path
import json,subprocess,hashlib,wave,re,math
import numpy as np
import animate as A
B=A.B;O=A.O;SR=48000;N=15*SR
def run(args):return subprocess.run(args,check=True,capture_output=True)
def write(path,a):
 with wave.open(str(B/path),'wb') as w:w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(a,-.98,.98)*32767).astype('<i2').tobytes())
def audio():
 with wave.open(str(B/'audio/chapter-01.wav')) as w:
  assert w.getframerate()==SR and w.getnchannels()==1;voice=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
 assert len(voice)/SR+A.OFFSET<15
 t=np.arange(N,dtype=np.float32)/SR;rng=np.random.default_rng(151117);noise=rng.normal(0,1,N).astype(np.float32);low=np.convolve(noise,np.ones(17,np.float32)/17,mode='same')
 mix=np.zeros(N,np.float32);k=round(A.OFFSET*SR);mix[k:k+len(voice)]+=.95*voice
 mot=np.interp(t,A.TIMES,[A.motor(x) for x in A.TIMES]);tap=np.interp(t,A.TIMES,A.OUT)/max(A.OUT)
 mix+=(.010*np.sin(2*np.pi*118*t)+.004*np.sin(2*np.pi*236*t)+.006*low)*mot.astype(np.float32)
 mix+=low*.019*tap.astype(np.float32)
 # Quiet, original light plucked arrangement; no library song or recording.
 for j,at in enumerate(np.arange(0,14.4,.8)):
  note=[62,69,66,69,59,66,62,66][j%8];f=440*2**((note-69)/12);tt=np.arange(round(.9*SR),dtype=np.float32)/SR;sig=(np.sin(2*np.pi*f*tt)+.17*np.sin(4*np.pi*f*tt))*np.exp(-tt*7)*np.minimum(1,tt/.009);off=round(at*SR);n=min(len(sig),N-off);mix[off:off+n]+=.009*sig[:n]
 events=[]
 for at,kind in [(.55,'switch_press'),(A.STOP+.4,'pump_stop')]:
  tt=np.arange(round(.065*SR),dtype=np.float32)/SR;sig=rng.normal(0,1,len(tt)).astype(np.float32)*np.exp(-tt*80);off=round(at*SR);mix[off:off+len(sig)]+=.035*sig;events.append({'time':at,'kind':kind})
 for j,at in enumerate([1.15,1.72,2.25,2.8]):
  tt=np.arange(round(.12*SR),dtype=np.float32)/SR;sig=np.sin(2*np.pi*(1100*tt-1800*tt*tt))*np.exp(-tt*35);off=round(at*SR);mix[off:off+len(sig)]+=.012*sig;events.append({'time':at,'kind':'tank_water_drop'})
 fade=np.minimum(1,(N-1-np.arange(N))/(SR*.35)).astype(np.float32);mix*=fade;write('audio/mix-original.wav',mix);(B/'audio/sound-events.json').write_text(json.dumps({'music':'Original local additive plucked arrangement','continuous_foley':['motor tied to impeller speed','water flow tied to modeled outlet flow'],'events':events},indent=2))
def measure(p):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(p),'-af','loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-f','null','-']);return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def main():
 rows=json.loads((O/'motion.json').read_text());assert len(rows)==450
 assert max(r['mascot']['max_bone_error'] for r in rows)<1e-8
 assert all(r['head']>0 and r['qout']>=0 and .05<r['level']<.95 for r in rows)
 after=[r for r in rows if r['time']>A.STOP+.6];assert all(r['motor']==0 for r in after);assert all(r['qout']>0 for r in after)
 peak=int(np.argmax(A.V));mass_error=float(np.max(np.abs(np.diff(A.V)-(A.IN[:-1]-A.OUT[:-1])*A.DT)));assert mass_error<1e-10
 assert A.V[peak]>A.V[0]+.15 and A.V[-1]<A.V[peak]-.1
 source=' '.join(c['text'] for c in A.CUES);norm=lambda s:re.sub('[^a-z]','',s.lower());assert norm(source)==norm((B/'script.txt').read_text())
 audio();pre=measure(B/'audio/mix-original.wav');flt='loudnorm=I=-16:TP=-1.5:LRA=8:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
 run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix-original.wav'),'-af',flt,'-ar','48000','-ac','2',str(B/'audio/mix-mastered.wav')])
 movie=O/'water-motion-preview-15s.mp4';run(['ffmpeg','-v','error','-y','-i',str(O/'picture.mp4'),'-i',str(B/'audio/mix-mastered.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-t','15','-movflags','+faststart',str(movie)])
 run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-']);probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)]).stdout);v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio');assert [v['width'],v['height'],v['r_frame_rate'],v['nb_frames']]==[1280,720,'30/1','450'];assert abs(float(v['duration'])-15)<.001;assert abs(float(a['duration'])-15)<.03
 post=measure(movie);assert float(post['input_tp'])<-.5
 (O/'captions-en.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(A.CUES))+'\n')
 vi=['Máy bơm đẩy nước lên bể chứa.','Sau đó, máy bơm dừng lại.','Vậy tại sao vòi vẫn chảy?','Vì mực nước trong bể cao hơn vòi.','Trọng lực giữ cho nước tiếp tục chảy.'];(O/'captions-vi.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{vi[i]}" for i,c in enumerate(A.CUES))+'\n',encoding='utf-8-sig')
 qa={'title':'Why Your Tap Still Runs','duration_seconds':15,'dimensions':[1280,720],'fps':30,'frames':450,'full_decode':'pass','sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'file_bytes':movie.stat().st_size,'motion':{'camera':'Fixed across all 15 seconds; no global pan/zoom as substitute for mechanism animation','local_actions':['mascot touches physical motor switch','impeller accelerates, turns, decelerates and stops','inlet flow markers stop with pump','tank volume rises then declines from the modeled net flow','tap lever physically attached to the faucet rotates open','outlet flow continues after pump stops','falling stream and splash droplets move','mascot body, knees, arms and expressions change'],'volume_balance_max_error':mass_error,'initial_tank_fraction':float(A.V[0]),'maximum_tank_fraction':float(max(A.V)),'final_tank_fraction':float(A.V[-1]),'motor_fully_stopped_after':A.STOP+.45,'positive_flow_with_motor_stopped':True,'water_surface_above_faucet_entire_clip':True,'maximum_mascot_bone_error':max(r['mascot']['max_bone_error'] for r in rows)},'science_scope':'Simplified illustrative elevated, vented tank supplied with already-treated water; filled distribution pipe, non-return inlet valve, open tap, positive height head. No claim all homes use this arrangement. No scale or engineering/CFD accuracy claimed.','sound':{'voice':'OpenAI tts-1 / alloy, speed 1','native_speech_seconds':len(__import__('wave').open(str(B/'audio/chapter-01.wav')).readframes(99999999))/(48000*2),'new_tts_calls':1,'estimated_tts_usd':.00228,'billing_verified':False,'new_image_calls':1,'image_billing':'not exposed','music_and_foley':'Original local synthesis','loudness':post},'review':{'author_visual':'See decoded-review.jpg and README','independent_review':'Not performed','real_time_AV_listening':'Not performed','user_decision':'Requested 15-second preview only; full episode not authorized'},'YouTube_upload':False}
 (O/'QA.json').write_text(json.dumps(qa,indent=2));(O/'probe.json').write_text(json.dumps(probe,indent=2));print(json.dumps({'seconds':15,'frames':450,'MiB':round(movie.stat().st_size/1024**2,2),'peak_tank':max(A.V),'final_tank':A.V[-1],'LUFS':post['input_i']},indent=2),flush=True)
if __name__=='__main__':main()
