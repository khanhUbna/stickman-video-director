"""Single native alloy request, saved immediately, no retries or key logging."""
from pathlib import Path
import os,json,urllib.request,urllib.error,subprocess,wave,hashlib
B=Path(__file__).resolve().parent;text=(B/'script.txt').read_text().strip();dst=B/'audio/voice.wav';raw=B/'audio/voice-api.wav';record=B/'audio/request.json'
if not dst.exists():
 if not raw.exists():
  if record.exists():raise SystemExit('Request was already attempted. No automatic paid retry.')
  record.write_text(json.dumps({'model':'tts-1','voice':'alloy','characters':len(text),'speed':1,'estimated_usd':len(text)*15/1e6,'state':'attempted','authorization':'User requested a new prehistoric B6 preview; art/voice scope announced before calls','automatic_retry':False},indent=2))
  req=urllib.request.Request('https://api.openai.com/v1/audio/speech',data=json.dumps({'model':'tts-1','voice':'alloy','input':text,'response_format':'wav','speed':1}).encode(),headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'application/json'})
  try:
   with urllib.request.urlopen(req,timeout=120) as r:raw.write_bytes(r.read())
  except urllib.error.HTTPError as e:raise SystemExit('Speech HTTP '+str(e.code)+'; no retry.')
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-ar','48000','-ac','1','-c:a','pcm_s16le',str(dst)],check=True)
 d=json.loads(record.read_text());d.update(state='saved',sha256=hashlib.sha256(dst.read_bytes()).hexdigest());record.write_text(json.dumps(d,indent=2))
with wave.open(str(dst)) as w:dur=w.getnframes()/w.getframerate()
print(json.dumps({'duration':dur,'characters':len(text),'estimate_usd':len(text)*15/1e6}))
