from pathlib import Path
import json,re,math
from caption_renderer import default_profile,CaptionRenderer
B=Path(__file__).resolve().parent;OFFSET=.3;PAUSES=[(4.1,1.25),(7.0,3.7)];D=18.;FPS=30
def shifted(t):return t+OFFSET+sum(d for a,d in PAUSES if t>=a)
words=json.loads((B/'words.json').read_text())['words']
for w in words:w['start']=shifted(w['start']);w['end']=shifted(w['end'])
phrases=['The tribe asked','the machine one question:','how do we stop','going hungry?','Seven days later,','everyone had enough food.','Thirty days later,','nobody was allowed','to stop working.']
norm=lambda s:re.sub('[^a-z]','',s.lower());i=0;cues=[]
for text in phrases:
 start=words[i]['start'];acc=''
 while acc!=norm(text):
  w=words[i];i+=1;acc+=norm(w['word']);assert norm(text).startswith(acc)
 cues.append({'start':start,'end':w['end'],'text':text})
assert i==len(words)
for i,c in enumerate(cues):c['end']=min(c['end']+.10,cues[i+1]['start'] if i+1<len(cues) else D)
profile=default_profile('16:9',1280,720,'archivo-black');profile.update(font_size=39,stroke=3,side=55,baseline=683,band=[635,711],native_layout_reason='Native landscape preview, principal hands/food/face above 610, feet at 630 or legitimate medium-view crop; semantic single line below the action field.')
cr=CaptionRenderer(B,'16:9',1280,720,profile)
for c in cues:cr.raster(c['text'])
T={'duration':D,'fps':FPS,'width':1280,'height':720,'voice_offset':OFFSET,'silent_holds':PAUSES,'caption_profile':profile,'shots':[{'id':'ask','start':0,'end':5.4,'action':'Koa walks to the AI, supports weight and gestures from stomach to the actual glowing eye'},{'id':'food','start':5.4,'end':11.3,'action':'Giver approach, shared meat grip, release, Koa lifts the food toward his face'},{'id':'blocked','start':11.3,'end':14.6,'action':'Supervisor raises stop palm before the reaching hand; Koa recoils with changed expression'},{'id':'work','start':14.6,'end':18,'action':'Wider camp reveal: supervisor points to the work schedule and Nim chops a log, which visibly splits'}]}
(B/'timeline.json').write_text(json.dumps(T,indent=2));(B/'captions.json').write_text(json.dumps(cues,indent=2));(B/'words-timeline.json').write_text(json.dumps({'method':'Offline forced alignment plus explicit authored silent holds; original speech rate unchanged','words':words},indent=2))
def stamp(t,sep=','):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}{sep}{ms%1000:03}'
(B/'output/captions-en.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(cues))+'\n')
(B/'output/captions-en.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f"{stamp(c['start'],'.')} --> {stamp(c['end'],'.')}\n{c['text']}" for c in cues)+'\n')
print('18-second preview; aligned captions and physical-action holds prepared.')
