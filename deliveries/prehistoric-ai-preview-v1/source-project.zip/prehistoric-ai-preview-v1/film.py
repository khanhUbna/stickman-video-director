"""New B6-look prehistoric cast, native landscape preview; stop before full film."""
from pathlib import Path
import json,math,bisect,subprocess,sys,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFilter,ImageFont
import rig
from rig import actor,ease,mix,rotate,line,poly,ip
from caption_renderer import CaptionRenderer
B=Path(__file__).resolve().parent;T=json.loads((B/'timeline.json').read_text());D=T['duration'];FPS=30;WORLD=(2400,1200)
CAMP=Image.open(B/'art/camp.png').convert('RGBA').resize(WORLD,Image.Resampling.LANCZOS)
CUES=json.loads((B/'captions.json').read_text());CR=CaptionRenderer(B,'16:9',1280,720,T['caption_profile']);FONT=str(B/'fonts/ArchivoBlack.ttf');RECORDS=[]
EYE=np.array([1217.,617.]);FOOD_PICKUP=7.2;AXE_HIT=16.45
def font(n):return ImageFont.truetype(FONT,n)
def u(t,a,b):return ease((t-a)/(b-a))
def env(t,keys):
 if t<=keys[0][0]:return keys[0][1]
 for (a,x),(b,y) in zip(keys,keys[1:]):
  if t<=b:return x+(y-x)*u(t,a,b)
 return keys[-1][1]
def normal(hip,side,angle=0):return np.asarray(hip)+rotate([-66 if side=='left' else 70,-14],angle)

def drumstick(im,center,angle=0):
 tile=Image.new('RGBA',(100,130));g=ImageDraw.Draw(tile)
 # The physical bone grip is at +/-8, +35 relative to the meat center.
 g.rounded_rectangle((43,54,57,116),6,fill='#e8d6ac',outline='#5a3b29',width=3)
 g.ellipse((35,104,53,124),fill='#ead9b1',outline='#5a3b29',width=3);g.ellipse((48,104,66,124),fill='#ead9b1',outline='#5a3b29',width=3)
 pts=[(30,12),(57,7),(78,22),(83,46),(71,69),(53,78),(30,70),(15,54),(17,30)]
 poly(g,pts,'#ab6435','#583521',4);g.arc((26,17,69,63),190,310,fill='#d18a4c',width=4);line(g,[(35,30),(42,26)],'#dca066',3)
 rr,pos=rig.transformed(tile,center,[50,47],1,angle);im.alpha_composite(rr,pos)
def bone_pointer(im,a,b):
 g=ImageDraw.Draw(im);line(g,[a,b],'#d6c19a',8)
 for p in [a,b]:x,y=p;g.ellipse((x-5,y-5,x+5,y+5),fill='#e3d1aa',outline='#806a4e',width=2)
def palm(im,p):
 g=ImageDraw.Draw(im);x,y=p;g.ellipse((x-7,y-11,x+7,y+9),fill=rig.INK)
 for j in range(4):line(g,[(x-6+j*4,y-6),(x-7+j*4,y-18+(j%2)*2)],rig.INK,3)
def schedule(im,t):
 g=ImageDraw.Draw(im);x=1855;y=360
 # The AI's new rule, shown as a carved physical sign in this fictional world.
 g.text((x,y),'WORK FIRST',font=font(30),fill='#624732',stroke_width=1)
 for j in range(3):
  yy=y+61+j*47;g.rectangle((x+1,yy,x+26,yy+23),outline='#7b583b',width=3)
  line(g,[(x+45,yy+11),(x+258,yy+11)],'#7b583b',3)
  if t>15.8+j*.25:line(g,[(x+5,yy+11),(x+11,yy+18),(x+22,yy+4)],'#376d70',3)
def fire(im,t):
 # Independent local fire motion tied to the visible stone ring.
 g=ImageDraw.Draw(im);x=505;y=745
 for dx,c,h in [(-15,'#d67529',51),(4,'#eda642',66),(21,'#f1bb5e',43)]:
  hh=h+7*math.sin(t*4+dx);poly(g,[(x+dx-16,y),(x+dx-8,y-hh*.45),(x+dx+5,y-hh),(x+dx+12,y-hh*.3),(x+dx+19,y)],c,c,1)
def ambience(im,t):
 fire(im,t)
 glow=Image.new('RGBA',im.size);g=ImageDraw.Draw(glow);pulse=.5+.5*math.sin(t*3)
 r=23+5*pulse;g.ellipse((EYE[0]-r,EYE[1]-r*.75,EYE[0]+r,EYE[1]+r*.75),fill=(48,224,232,round(50+55*pulse)))
 glow=glow.filter(ImageFilter.GaussianBlur(10));im.alpha_composite(glow)
 if 2.8<t<4.5:
  g=ImageDraw.Draw(im);p=math.sin((t-2.8)*math.pi/1.7)
  for j in range(3):
   yy=EYE[1]+22+j*9;line(g,[(EYE[0]-25*p,yy),(EYE[0]+25*p,yy)],(80,215,219,round(180*p)),3)
def crop(im,camera):
 x,y,w,h=camera;assert x>=0 and y>=0 and x+w<=WORLD[0]+.01 and y+h<=WORLD[1]+.01
 assert abs(w/h-16/9)<.001
 return im.crop((round(x),round(y),round(x+w),round(y+h))).resize((1280,720),Image.Resampling.LANCZOS)
def record(t,sid,rows):
 for r in rows:RECORDS.append({'time':round(t,5),'shot':sid,**r})

def frame(t,caption=True,collect=True):
 im=CAMP.copy();ambience(im,t);rows=[];extra=[]
 if t<5.4:
  sid='ask';cam=(260+18*u(t,0,2.6),260,1280,720);distance=312.5*u(t,0,2.35);x=762.5+distance
  hip=np.array([x,rig.walking_hip_y(x,distance,1,'koa','front')]);sw=math.sin(distance/125*2*math.pi)
  wr={'left':hip+[-67+15*sw,-14],'right':hip+[70-15*sw,-14]};walk=(distance,1) if t<2.35 else None
  feet=None if walk else {'left':[x-25,890],'right':[x+37.5,890]}
  if t>=2.35:
   a=u(t,2.35,3.5);wr['left']=mix(hip+[-67,-14],hip+[-23,-64],a);wr['right']=mix(hip+[70,-14],EYE+[-14,7],a)
  rows.append(actor(im,hip,who='koa',wrists=wr,walk=walk,feet=feet,angle=0,head_angle=4*u(t,2.1,3.5)))
 elif t<11.3:
  sid='food';cam=(1270,280,1110,624.375)
  kh=np.array([1510.,725.]);th=np.array([1740.,725.]);ka=4*u(t,5.8,6.9)*(1-u(t,7.2,9.2));ta=-3*u(t,5.5,6.5)*(1-u(t,7.2,8))
  base=mix([1688.,615.],[1648.,615.],u(t,5.6,6.6));fc=mix(base,[1580.,590.],u(t,7.2,9.2))
  receive=fc+[-8,35];giver=fc+[8,35]
  kw={'left':normal(kh,'left',ka),'right':mix(normal(kh,'right',ka),receive,u(t,6.1,6.9))}
  tw={'right':normal(th,'right',ta),'left':giver if t<7.2 else mix([1656,650],normal(th,'left',ta),u(t,7.2,7.8))}
  kp={};tp={}
  if t>=6.9:kp['meat_receiver']={'arm':'right','point':receive}
  if t<7.2:tp['meat_giver']={'arm':'left','point':giver}
  # One world-space food transform serves both actors. Composite between
  # body and forearm layers, rather than independent duplicate meat sprites.
  rows.append(actor(im,th,who='tuk',angle=ta,head_angle=-2,wrists=tw,held=tp))
  rows.append(actor(im,kh,who='koa',angle=ka,head_angle=-3*u(t,7.3,9.0),wrists=kw,held=kp,prop_draw=lambda m,fc=fc:drumstick(m,fc),occlude_forearms=('right',)))
  # Giver fingertips stay visible during the short shared grip interval.
  if t<7.2:
   g=ImageDraw.Draw(im);x,y=tw['left'];g.ellipse((x-5,y-5,x+5,y+5),fill=rig.INK)
 elif t<14.6:
  sid='blocked';cam=(1270,280,1110,624.375);schedule(im,t)
  recoil=u(t,13.45,14.3);kh=np.array([1510-14*recoil,725.]);th=np.array([1740.,725.]);ka=-4*recoil
  first_food=kh+[-43,-69];left_grip=first_food+rotate([8,35],-8)
  reach=mix(normal(kh,'right',ka),[1604.,644.],u(t,11.45,12.55));reach=mix(reach,normal(kh,'right',ka),recoil)
  stop=mix(normal(th,'left'),[1626.,632.],u(t,12.15,12.65));point=mix(normal(th,'right'),[1815.,642.],u(t,13.2,14.6))
  rows.append(actor(im,th,who='tuk',wrists={'left':stop,'right':point},head_angle=-3))
  rows.append(actor(im,kh,who='koa',angle=ka,head_angle=-6*recoil,expression='shocked' if t>=12.65 else 'normal',feet={'left':[1485,890],'right':[1538,890]},wrists={'left':left_grip,'right':reach},held={'first_portion':{'arm':'left','point':left_grip}},prop_draw=lambda m,fc=first_food:drumstick(m,fc,-8),occlude_forearms=('left',)))
  palm(im,stop)
  pointer_angle=env(t,[(11.3,75),(13.2,75),(14.6,-49.31)])
  bone_pointer(im,point,point+rotate([141.11,0],pointer_angle))
 else:
  sid='work';cam=(900,180,1500,843.75);schedule(im,t)
  # The two foreground roles keep their physical food and stop state across
  # the wider reveal; the new worker and log enter the composition.
  kh=np.array([1496.,725.]);th=np.array([1740.,725.]);fc=kh+[-43,-69];kg=fc+rotate([8,35],-8)
  rows.append(actor(im,kh,who='koa',angle=-4,head_angle=-4,expression='weary',feet={'left':[1485,890],'right':[1538,890]},wrists={'left':kg,'right':normal(kh,'right',-4)},held={'first_portion':{'arm':'left','point':kg}},prop_draw=lambda m,fc=fc:drumstick(m,fc,-8),occlude_forearms=('left',)))
  point=np.array([1815.,642.]);rows.append(actor(im,th,who='tuk',head_angle=-2,wrists={'left':[1626,632],'right':point}));palm(im,[1626,632]);bone_pointer(im,point,point+rotate([141.11,0],-49.31))
  # One deliberate backswing -> downstroke -> split -> recovery, not a loop.
  nh=np.array([2150.,env(t,[(14.6,725),(15.45,728),(16.45,780),(17.3,737),(18,725)])])
  angle=env(t,[(14.6,2),(15.45,-4),(16.45,30),(17.3,8),(18,2)])
  grip=np.array([env(t,[(14.6,2180),(15.45,2167),(16.45,2180),(17.3,2180),(18,2180)]),env(t,[(14.6,670),(15.45,639),(16.45,765),(17.3,685),(18,670)])])
  aa=env(t,[(14.6,-70),(15.45,-120),(16.45,40),(17.3,-50),(18,-70)])
  axis=rotate([1,0],aa);left=grip-axis*7;right=grip+axis*7;tip=grip+axis*110
  g=ImageDraw.Draw(im);split=u(t,16.45,16.75)
  for side in [-1,1]:
   xx=2252+side*(18+24*split);poly(g,[(xx-30,835),(xx+30,835),(xx+33,870),(xx-33,870)],'#9b6e3f','#5f472d',3);g.ellipse((xx-30,835,xx+30,852),fill='#caa16b',outline='#74532f',width=3)
  rows.append(actor(im,nh,who='nim',angle=angle,head_angle=5,wrists={'left':left,'right':right},held={'axe_left':{'arm':'left','point':left},'axe_right':{'arm':'right','point':right}}))
  g=ImageDraw.Draw(im);line(g,[grip-axis*22,tip],'#785532',8);perp=rotate([0,1],aa)
  poly(g,[tip+axis*10+perp*20,tip-axis*16+perp*24,tip-axis*26-perp*18,tip+axis*9-perp*13],'#8d9893','#46504a',4)
  # Redraw the actual two grips over the wooden shaft.
  for p in [left,right]:x,y=p;g.ellipse((x-5,y-5,x+5,y+5),fill=rig.INK)
  if 16.45<t<16.85:
   v=(t-16.45)/.4
   for j in range(3):
    x=2252+(j-1)*42*v;y=834-30*math.sin(math.pi*v)-j*4;poly(g,[(x-3,y),(x+4,y-5),(x+7,y+2)],'#d1a36b','#8d633c',1)
 out=crop(im,cam)
 g=ImageDraw.Draw(out)
 if t<2.0:g.text((35,29),'DAY 1',font=font(27),fill='#fff1d5',stroke_width=2,stroke_fill='#543a27')
 elif 5.4<=t<7.05:g.text((35,29),'DAY 7',font=font(27),fill='#fff1d5',stroke_width=2,stroke_fill='#543a27')
 elif 11.3<=t<13.2:g.text((35,29),'DAY 30',font=font(27),fill='#fff1d5',stroke_width=2,stroke_fill='#543a27')
 if caption:
  c=next((c for c in CUES if c['start']<=t<c['end']),None)
  if c:out=Image.alpha_composite(out,CR.raster(c['text'])[0])
 if collect:record(t,sid,rows)
 return out.convert('RGB')

def render():
 p=B/'output/picture.mp4';proc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(p)],stdin=subprocess.PIPE)
 try:
  for i in range(round(D*FPS)):
   proc.stdin.write(frame(i/FPS,True,True).tobytes())
   if i%150==0:print(f'Rendered {i}/{round(D*FPS)} frames',flush=True)
  proc.stdin.close();assert proc.wait()==0
 except BaseException:
  proc.stdin.close();proc.wait();raise
 (B/'output/motion.json').write_text(json.dumps(RECORDS));print('Preview picture and actual-chain trace saved.',flush=True)
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='stills':
  errors=[]
  for t in [0,1.2,2.35,3.5,5.7,6.9,7.15,7.35,8.8,10.2,11.8,12.6,13.2,13.8,14.7,15.5,16.45,16.8,17.8]:
   try:frame(t).save(B/f'output/still-{t:.2f}.png')
   except Exception as e:errors.append([t,str(e)])
  print(json.dumps(errors,indent=2),flush=True)
 else:render()
