"""Original sound, native-rate speech reuse, full decode and preview QA."""
from pathlib import Path
import json,wave,math,re,subprocess,hashlib
import numpy as np
B=Path(__file__).resolve().parent;O=B/'output';T=json.loads((B/'timeline.json').read_text());SR=48000;D=T['duration'];N=round(D*SR)
def run(args):return subprocess.run(args,check=True,capture_output=True)
def save(name,a):
 with wave.open(str(B/name),'wb') as w:w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(a,-.98,.98)*32767).astype('<i2').tobytes())
def add(bus,at,note,gain=1):
 k=round(at*SR);nn=min(len(note),N-k)
 if nn>0:bus[k:k+nn]+=note[:nn]*gain
def pluck(f,length=.55):
 t=np.arange(round(length*SR))/SR
 return (np.sin(2*np.pi*f*t)+.18*np.sin(4*np.pi*f*t))*np.exp(-t*8)*np.minimum(1,t/.006)
with wave.open(str(B/'audio/voice.wav')) as w:
 assert w.getframerate()==SR;voice=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
narr=np.zeros(N);a=0
def shifted(t):return t+T['voice_offset']+sum(d for at,d in T['silent_holds'] if t>=at)
for b,pad in T['silent_holds']+[[len(voice)/SR,0]]:
 seg=voice[round(a*SR):round(b*SR)];k=round(shifted(a)*SR);narr[k:k+len(seg)]=seg;a=b
save('audio/narration-timeline.wav',narr)
music=np.zeros(N);fx=np.zeros(N);rng=np.random.default_rng(881403);events=[]
for i,at in enumerate(np.arange(.05,D-.2,.42)):
 chord=[57,60,64] if at<5.4 else [60,64,67] if at<11.3 else [52,55,59]
 note=chord[[0,2,1,2][i%4]];add(music,at,pluck(440*2**((note-69)/12)),.035 if at<11.3 else .028)
def tap(at,kind='wood',gain=.06):
 t=np.arange(round(SR*.16))/SR;noise=rng.normal(0,1,len(t));noise=np.convolve(noise,np.ones(9)/9,mode='same')
 note=(.45*np.sin(2*np.pi*(110 if kind=='step' else 240)*t)+.3*noise)*np.exp(-t*35)*np.minimum(1,t/.002)
 add(fx,at,note,gain);events.append({'time':round(at,4),'kind':kind,'source':'Original local additive and seeded noise synthesis'})
rows=json.loads((O/'motion.json').read_text());last={}
for r in rows:
 who=r['who'];old=last.get(who);last[who]=r
 if old is None or old['shot']!=r['shot'] or r['time']-old['time']>.04:continue
 if r['shot']=='ask' and r['time']<2.4:
  for side in ['left','right']:
   if not old['legs'][side]['planted'] and r['legs'][side]['planted']:tap(r['time'],'step',.065)
t=np.arange(round(SR*.33))/SR;chirp=np.sin(2*np.pi*(600*t+330*t*t))*np.sin(np.pi*t/.33)**2
add(fx,4.26,chirp,.035);events.append({'time':4.26,'kind':'AI_response','source':'Original synthesized short two-tone/curved-frequency response'})
tap(6.9,'food_handoff',.025);tap(14.6,'bone_pointer_on_schedule',.025);tap(16.45,'stone_axe_wood_contact',.13)
for at in [12.28,12.47]:
 tt=np.arange(round(SR*.15))/SR;n=rng.normal(0,1,len(tt));n=np.convolve(n,np.ones(14)/14,mode='same');add(fx,at,n*np.sin(np.pi*tt/.15)**2,.025)
 events.append({'time':at,'kind':'arm_swish','source':'Original filtered noise; no invented palm-impact sound'})
room=rng.normal(0,.003,N);room=np.convolve(room,np.ones(80)/80,mode='same')
fade=np.minimum(1,np.arange(N)/(SR*.12))*np.minimum(1,(N-1-np.arange(N))/(SR*.4))
save('audio/music-original.wav',music*fade);save('audio/foley-original.wav',fx*fade);save('audio/room-original.wav',room*fade);save('audio/mix-unmastered.wav',(narr*.94+music+fx+room)*fade)
(B/'audio/sound-events.json').write_text(json.dumps(events,indent=2))
def measure(p):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(p),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'])
 return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
pre=measure(B/'audio/mix-unmastered.wav');flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix-unmastered.wav'),'-af',flt,'-ar',str(SR),'-ac','2',str(B/'audio/mix-mastered.wav')])
movie=O/'cavemen-ai-food-jobs-preview.mp4';run(['ffmpeg','-v','error','-y','-i',str(O/'picture.mp4'),'-i',str(B/'audio/mix-mastered.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','160k','-t',str(D),'-movflags','+faststart',str(movie)])
probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)]).stdout);run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-']);post=measure(movie)
v=next(s for s in probe['streams'] if s['codec_type']=='video');aud=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert [v['width'],v['height'],v['r_frame_rate'],v['nb_frames']]==[1280,720,'30/1','540'];assert abs(float(v['duration'])-float(aud['duration']))<.08
bone=max(r['bone_error'] for r in rows);stance=[];contacts={};previous={};inventory={}
for r in rows:
 assert set(r['arms'])==set(r['legs'])=={'left','right'};inventory.setdefault(r['shot'],set()).add(r['who'])
 for key,err in r['contacts'].items():contacts[key]=max(contacts.get(key,0),err)
 old=previous.get(r['who']);previous[r['who']]=r
 if old is None or old['shot']!=r['shot'] or r['time']-old['time']>.04:continue
 for side in ['left','right']:
  if old['legs'][side]['planted'] and r['legs'][side]['planted']:stance.append(float(np.linalg.norm(np.asarray(old['legs'][side]['joints'][-1])-r['legs'][side]['joints'][-1])))
assert max(stance,default=0)<1e-6,max(stance);assert max(contacts.values())<1e-6
from rig import ik
try:ik([0,0],[500,0],[70,70],1,'negative reach test')
except ValueError:negative=True
else:raise AssertionError('Unreachable target accepted')
sha=hashlib.sha256(movie.read_bytes()).hexdigest();request=json.loads((B/'audio/request.json').read_text())
qa={'title':'Cavemen Asked AI for More Food. It Gave Them Jobs.','stage':'preview_for_user_review_only','full_episode_proposed_minutes':[6,8],'full_episode_rendered':False,'duration_seconds':float(probe['format']['duration']),'dimensions':[1280,720],'fps':30,'frames':int(v['nb_frames']),'full_decode':'pass','audio_video_duration_difference_seconds':abs(float(v['duration'])-float(aud['duration'])),'sha256':sha,'motion':{'renderer':'New-cast fitting in existing project-local articulated action extension; installed B6 runtime unchanged','actor_frames_checked':len(rows),'four_control_chains_per_actor_frame':True,'maximum_fixed_bone_error_pixels':bone,'maximum_consecutive_planted_foot_drift_pixels':max(stance,default=0),'maximum_authored_prop_grip_errors_pixels':contacts,'unreachable_target_negative_test':negative,'cast_by_shot':{k:sorted(v) for k,v in inventory.items()},'views':'Fitted front artwork only; no fabricated continuous turn','costume':'Generated white cartoon torsos with fully covering hide loincloths, dark stick limbs and bare stylized feet'},'audio':{'model':'tts-1','voice':'alloy','new_requests':1,'native_voice_seconds':len(voice)/SR,'speed':1,'estimated_speech_usd':request['estimated_usd'],'estimated_rate_basis':'Previously documented USD 15/million characters; account bill not independently verified','new_paid_transcription_requests':0,'original_music_and_Foley':True,'loudness':post},'art':{'image_generation_requests':3,'purpose':['three-character head/body atlas','prehistoric camp','Koa shocked/weary facial variants'],'image_generation_cost':'Not exposed by this tool; no invented estimate','historical_claim':'Fictional Stone Age/AI thought experiment'},'captions':{'language':'English','cues':len(json.loads((B/'captions.json').read_text())),'single_line':True,'profile':T['caption_profile']},'review':{'technical':'Complete decode, all-frame actual drawn-chain and authored-grip checks','author_visual':'Source and final decoded frames; recorded in README','independent_creative_review':'not available','real_time_AV_listening_by_agent':'not performed; loudness/decode checks are separate','installed_B6_35_subcheck_reference_acceptance':'not claimed for this local extension','user_approval':'pending; do not produce the full episode automatically'},'YouTube_upload':False}
(O/'QA.json').write_text(json.dumps(qa,indent=2)+'\n');(O/'probe.json').write_text(json.dumps(probe,indent=2));print(json.dumps({'duration':qa['duration_seconds'],'frames':qa['frames'],'actor_frames':len(rows),'bone_error':bone,'planted_foot_drift':max(stance),'LUFS':post['input_i'],'true_peak':post['input_tp'],'size_MB':round(movie.stat().st_size/1e6,2)},indent=2),flush=True)
