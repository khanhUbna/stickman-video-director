# Local action repairs

- The inherited standing-only rig did not establish walking or sitting. Authored a separate local fixed-bone action extension; did not alter or relabel the installed trusted runtime.
- The initial phone placement target exceeded arm reach at approximately 19.67–20.4 seconds. Restaged the pelvis/forward reach, fixed the feet and moved the camera to preserve a readable hand/table contact; did not stretch the arm.
- Initial sitting/rising foot targets followed the hips. Replaced them with fixed world-space floor contacts while the pelvis moves backward/down and forward/up.
- Corrected knee and toe direction for leftward travel.
- Kept the instrument on its stand until grip acquisition at 22.12 seconds, then drove the actual instrument and both hand targets from its single transform.
- Changed Foley from provisional footstep times to rendered swing-to-stance times. Kept the final action excerpt derived from the final MP4.
- Moved the fretting grip farther along the actual neck and staged a supported torso lean during pickup, making the left arm more legible beside the instrument/head. Re-rendered the full film and repeated checks after this change.

Final mechanical results are in QA.json. No claim of independent creative acceptance or installed B6 reference equivalence is made.
