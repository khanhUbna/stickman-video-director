"""Original music/Foley and offline-aligned captions. No network requests."""
from pathlib import Path
import json,re,wave,math,hashlib
import numpy as np
from caption_renderer import CaptionRenderer,default_profile
B=Path(__file__).resolve().parent;SR=48000
OFFSET=.35;PAUSES=[(14.2,.6),(16.2,.9),(20.1,.9)]
def shifted(t): return t+OFFSET+sum(d for a,d in PAUSES if t>=a)
def write(p,x):
 with wave.open(str(B/p),'wb') as w:w.setparams((1,2,SR,0,'NONE','not compressed'));w.writeframes((np.clip(x,-.99,.99)*32767).astype('<i2').tobytes())
with wave.open(str(B/'audio/voice.wav')) as w:
 rate=w.getframerate();voice=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
import subprocess
subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/'audio/voice.wav'),'-ar',str(SR),'-ac','1',str(B/'audio/voice-48k.wav')],check=True)
with wave.open(str(B/'audio/voice-48k.wav')) as w:voice=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
dur=math.ceil((len(voice)/SR+OFFSET+sum(d for a,d in PAUSES)+1.5)*30)/30
N=round(dur*SR);narration=np.zeros(N);a=0
for b,pad in PAUSES+[(len(voice)/SR,0)]:
 src=voice[round(a*SR):round(b*SR)];start=round(shifted(a)*SR);narration[start:start+len(src)]=src;a=b
write('audio/narration.wav',narration)
words=json.loads((B/'words.json').read_text())['words']
for w in words:w['start']=round(shifted(w['start']),3);w['end']=round(shifted(w['end']),3)
(B/'words-timeline.json').write_text(json.dumps({'method':'Offline PocketSphinx alignment, shifted only by explicitly authored silent holds','voice_offset':OFFSET,'inserted_silence':PAUSES,'words':words},indent=2))
phrases=['You waited all day','for this evening.',"Now you're home.",'Shoes off.','Phone out.','Just five minutes.','Then you look up.',"It's almost bedtime.",'The guitar','you wanted to play',"hasn't moved.",'Your evening became','a waiting room','for tomorrow.','Try changing','just the beginning.','Tomorrow,','before you open','a feed,','put your phone down','and pick up','the guitar.','Play one song.','Badly,','if you have to.',"You don't have to",'make your evening','productive.','Give yourself','one moment','you actually chose.']
norm=lambda s:re.sub('[^a-z]','',s.lower());wi=0;cues=[]
for phrase in phrases:
 st=words[wi]['start'];acc=''
 while acc!=norm(phrase):
  w=words[wi];wi+=1;acc+=norm(w['word']);assert norm(phrase).startswith(acc),(phrase,acc)
 cues.append({'start':st,'end':w['end'],'text':phrase})
assert wi==len(words)
for i,c in enumerate(cues):c['end']=min(c['end']+.13,cues[i+1]['start'] if i+1<len(cues) else dur)
profile=default_profile('9:16',720,1280,'archivo-black');cr=CaptionRenderer(B,'9:16',720,1280,profile)
for c in cues:cr.raster(c['text'])
(B/'captions.json').write_text(json.dumps(cues,indent=2))
def stamp(t,sep=','):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}{sep}{ms%1000:03}'
(B/'output/captions-en.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(cues))+'\n')
(B/'output/captions-en.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f"{stamp(c['start'],'.')} --> {stamp(c['end'],'.')}\n{c['text']}" for c in cues)+'\n')
rng=np.random.default_rng(20261116);music=np.zeros(N);fx=np.zeros(N)
def add(bus,at,note,gain=1):
 k=round(at*SR);nn=min(len(note),len(bus)-k)
 if nn>0:bus[k:k+nn]+=note[:nn]*gain
def pluck(freq,d=.9):
 t=np.arange(round(d*SR))/SR
 return (np.sin(2*np.pi*freq*t)+.28*np.sin(4*np.pi*freq*t)+.08*np.sin(6*np.pi*freq*t))*np.exp(-t*5)*np.minimum(1,t/.006)
chords=[[57,60,64],[53,57,60],[60,64,67],[55,59,62]]
for i,at in enumerate(np.arange(.04,dur-.4,.43)):
 chord=chords[int(at/3.44)%4];note=chord[[0,2,1,2][i%4]]
 add(music,at,pluck(440*2**((note-69)/12)),.027 if at<23 else .010)
for at in np.arange(.04,dur,3.44):
 note=chords[int(at/3.44)%4][0]-12;add(music,at,pluck(440*2**((note-69)/12),1.4),.026)
events=[]
def tap(at,kind='step',amp=.07):
 d=.12 if kind=='step' else .07;t=np.arange(round(d*SR))/SR
 noise=rng.normal(0,1,len(t));noise=np.convolve(noise,np.ones(9)/9,mode='same')
 note=(noise*.3+np.sin(2*np.pi*(110 if kind=='step' else 640)*t)*.5)*np.exp(-t*(35 if kind=='step' else 70))*np.minimum(1,t/.002)
 add(fx,at,note,amp);events.append({'time':round(at,3),'kind':kind,'source':'Original seeded additive/filtered-noise synthesis'})
motion=B/'output/motion-picture.json'
if motion.exists():
 rows=json.loads(motion.read_text());steps=[]
 for a,b in zip(rows,rows[1:]):
  if b['time']-a['time']>.04:continue
  if not any(lo<=b['time']<hi for lo,hi in [(0,3.25),(17.65,19),(20.65,21.9)]):continue
  for side in ['left','right']:
   if not a['legs'][side]['planted'] and b['legs'][side]['planted']:steps.append(b['time'])
else:steps=[] # No placeholder steps: rerun after actual motion exists.
for t in steps:tap(t)
tap(3.96,'shoe',.09);tap(4.37,'pickup',.055);tap(6.48,'seat',.08);tap(20.46,'phone_on_wood',.12);tap(22.14,'guitar_pickup',.055)
strums=[23.2,23.78,24.36,25.05,25.64,26.22,26.8,27.38,27.96,28.54,29.12,29.7,30.28,30.86,31.44,32.02]
for j,at in enumerate(strums):
 chord=[52,57,61 if j==2 else 60,64,69] if j<5 else [48,55,60,64,67]
 for k,m in enumerate(chord):add(fx,at+k*.012,pluck(440*2**((m-69)/12),1.1),.024)
 events.append({'time':at,'kind':'guitar_strum','imperfect_note':j==2,'source':'Original synthesized strings; no third-party melody'})
fade=np.minimum(1,np.arange(N)/(SR*.08))*np.minimum(1,(N-1-np.arange(N))/(SR*.65))
room=np.convolve(rng.normal(0,1,N),np.ones(100)/100,mode='same')*.001
write('audio/music-original.wav',music*fade);write('audio/foley-original.wav',fx*fade);write('audio/room-original.wav',room*fade)
write('audio/mix-unmastered.wav',(narration*.9+music+fx+room)*fade)
(B/'audio/sound-events.json').write_text(json.dumps(events,indent=2))
(B/'timeline.json').write_text(json.dumps({'duration':dur,'fps':30,'voice_offset':OFFSET,'native_speech_duration':len(voice)/SR,'inserted_silence':PAUSES,'strums':strums,'caption_profile':profile},indent=2))
print(json.dumps({'duration':dur,'words':wi,'cues':len(cues),'speech_rate_unchanged':True,'all_caption_rasters_fit':True}))
