from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json,zipfile,shutil,hashlib,os
B=Path(__file__).resolve().parent;R=Path('/workspace/stickman-video-director');O=B/'output';D=R/'deliveries/short-free-time-v1';v=O/'why-your-free-time-doesnt-feel-like-yours.mp4'
times=[.5,1.7,3.7,4.8,6.5,8.9,10.7,13.,16.1,18.3,20.46,21.4,22.13,22.65,23.8,24.6,29.,31.8]
font=ImageFont.truetype(str(B/'fonts/ArchivoBlack.ttf'),17);board=Image.new('RGB',(720,6*454),'#233039');g=ImageDraw.Draw(board)
for k,t in enumerate(times):
 p=O/f'encoded-{t:.2f}.png';subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(v),'-frames:v','1',str(p)],check=True)
 im=Image.open(p);im.thumbnail((240,427));x=k%3*240;y=k//3*454;board.paste(im,(x,y));g.text((x+8,y+429),f'{t:.2f}s',font=font,fill='white')
board.save(O/'encoded-storyboard.jpg',quality=92)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(v),'-ss','19','-t','8','-c:v','libx264','-crf','18','-c:a','aac',str(O/'actions-with-sound.mp4')],check=True)
for name in ['why-your-free-time-doesnt-feel-like-yours.mp4','captions-en.srt','captions-en.vtt','QA.json','encoded-storyboard.jpg','actions-with-sound.mp4']:shutil.copy2(O/name,D/name)
for name in ['README.md','description.txt','script.txt','rights.json','checkpoint.json']:shutil.copy2(B/name,D/name)
shutil.copy2(B/'audio/cost.json',D/'cost.json')
with zipfile.ZipFile(D/'source-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in B.rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts:continue
  rel=p.relative_to(B)
  if rel.parts[0]=='output' and p.name not in ['QA.json','motion-picture.json','probe.json']:continue
  z.write(p,str(Path('short-free-time-v1')/rel))
# Check new text/code and archived text for accidental credentials, without logging any values.
secret=os.environ.get('OPENAI_API_KEY','')
for p in D.iterdir():
 if p.suffix in ['.md','.json','.txt','.srt','.vtt'] and secret and secret.encode() in p.read_bytes():raise RuntimeError('Secret scan failed')
with zipfile.ZipFile(D/'source-project.zip') as z:
 for name in z.namelist():
  if Path(name).suffix in ['.py','.md','.txt','.json'] and secret and secret.encode() in z.read(name):raise RuntimeError('Archived secret scan failed')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in D.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'}
(D/'SHA256SUMS.txt').write_text(''.join(f'{h}  {n}\n' for n,h in sorted(manifest.items())))
print('Final delivery refreshed; credential scan clean; checksums saved.')
