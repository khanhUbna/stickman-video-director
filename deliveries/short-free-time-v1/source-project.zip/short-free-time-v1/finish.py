"""Master original sound, mux, decode and verify the deliverable."""
from pathlib import Path
import json,subprocess,re,hashlib,math
import numpy as np
B=Path(__file__).resolve().parent;O=B/'output';T=json.loads((B/'timeline.json').read_text());D=T['duration']
def run(args):return subprocess.run(args,check=True,capture_output=True)
def measure(p):
 r=run(['ffmpeg','-hide_banner','-nostats','-i',str(p),'-af','loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json','-f','null','-'])
 return json.loads(re.findall(rb'\{[^{}]+\}',r.stderr)[-1])
pre=measure(B/'audio/mix-unmastered.wav')
flt='loudnorm=I=-16:TP=-1.5:LRA=9:'+':'.join(f'{k}={pre[v]}' for k,v in [('measured_I','input_i'),('measured_TP','input_tp'),('measured_LRA','input_lra'),('measured_thresh','input_thresh'),('offset','target_offset')])+':linear=true'
run(['ffmpeg','-v','error','-y','-i',str(B/'audio/mix-unmastered.wav'),'-af',flt,'-ar','48000','-ac','2',str(B/'audio/mix-mastered.wav')])
movie=O/'why-your-free-time-doesnt-feel-like-yours.mp4'
run(['ffmpeg','-v','error','-y','-i',str(O/'picture.mp4'),'-i',str(B/'audio/mix-mastered.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(D),'-movflags','+faststart',str(movie)])
probe=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)]).stdout)
run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-'])
post=measure(movie)
v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],v['codec_name'],v['pix_fmt'])==(720,1280,'30/1','h264','yuv420p')
assert abs(float(probe['format']['duration'])-D)<.08
assert abs(float(a['duration'])-float(v['duration']))<.08
rows=json.loads((O/'motion-picture.json').read_text());max_bone=0;stance=[];grips=[]
def shot(t):
 import film
 return film.shot(t)
for r in rows:
 assert set(r['arms'])==set(r['legs'])=={'left','right'}
 for s in ['left','right']:
  for values,expected in [(r['arms'][s]['lengths'],[64*1.45,62*1.45]),(r['legs'][s]['lengths'],[80*1.45,80*1.45])]:max_bone=max(max_bone,max(abs(x-y) for x,y in zip(values,expected)))
 if 'grip_errors' in r:grips.append(r['grip_errors'])
for p,r in zip(rows,rows[1:]):
 if r['time']-p['time']>.04 or shot(r['time'])!=shot(p['time']):continue
 for s in ['left','right']:
  if p['legs'][s]['planted'] and r['legs'][s]['planted']:
   error=float(np.linalg.norm(np.asarray(p['legs'][s]['joints'][-1])-r['legs'][s]['joints'][-1]));stance.append(error)
assert max_bone<1e-8,max_bone
assert max(stance,default=0)<1e-6,max(stance)
assert max(g['left'] for g in grips)<1e-6
assert max(g['right'] for g in grips)<=21.0001 # strum traverses the actual string area
from film import ik
try:ik([0,0],[500,0],[90,90],1,'negative-test')
except ValueError:negative=True
else:raise AssertionError('Unreachable target was not rejected')
coverage={sid:[round(min(r['time'] for r in rows if shot(r['time'])==sid),3),round(max(r['time'] for r in rows if shot(r['time'])==sid),3)] for sid in sorted(set(shot(r['time']) for r in rows))}
qa={'title':"Why Your Free Time Doesn't Feel Like Yours",'duration_seconds':float(probe['format']['duration']),'dimensions':[720,1280],'fps':30,'frames':int(v['nb_frames']),'video_codec':v['codec_name'],'audio_codec':a['codec_name'],'full_decode':'pass','audio_video_duration_difference_seconds':abs(float(a['duration'])-float(v['duration'])),'loudness':post,'motion':{'renderer':'New project-local fixed-bone action extension; installed standing-only runtime was not modified or certified','actor_frames_checked':len(rows),'limbs_per_actor_frame':4,'maximum_fixed_bone_error_pixels':max_bone,'maximum_consecutive_planted_foot_drift_pixels':max(stance,default=0),'guitar_fret_grip_max_error_pixels':max(g['left'] for g in grips),'guitar_strum_traversal_max_pixels':max(g['right'] for g in grips),'unreachable_target_negative_test':negative,'shot_coverage':coverage},'captions':{'language':'en','cues':len(json.loads((B/'captions.json').read_text())),'single_line':True,'profile':T['caption_profile'],'timing':'Offline acoustic alignment plus recorded silent holds; no paid transcription'},'voice':{'model':'tts-1','voice':'alloy','new_calls':1,'native_recording_seconds':T['native_speech_duration'],'speed':1,'silent_holds_added':True,'source_sha256':hashlib.sha256((B/'audio/voice.wav').read_bytes()).hexdigest()},'new_image_API_calls':0,'YouTube_upload':False,'review':{'author_decoded_frame_review':'Recorded separately in README; not an independent creative acceptance','independent_creative_review':'not available','real_time_AV_listening':'not performed by the agent; automated sound/decode measurements are separate','user_approval':'pending user viewing','installed_B6_35_subcheck_acceptance':'not claimed for the new project-local action extension'},'sha256':hashlib.sha256(movie.read_bytes()).hexdigest()}
(O/'QA.json').write_text(json.dumps(qa,indent=2)+'\n');(O/'probe.json').write_text(json.dumps(probe,indent=2))
print(json.dumps({k:qa[k] for k in ['duration_seconds','dimensions','frames','full_decode']}));print('LUFS',post['input_i'],'TP',post['input_tp']);print('Actor frames',len(rows),'bone error',max_bone,'planted foot drift',max(stance))
