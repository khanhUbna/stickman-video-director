"""One authorized native-rate speech call; no retry and no secret logging."""
from pathlib import Path
import os,json,urllib.request,urllib.error,wave,hashlib
B=Path(__file__).resolve().parent
text=(B/'script.txt').read_text().strip()
dst=B/'audio/voice.wav'
if dst.exists():
    print('Reusing saved speech; no API call.')
else:
    payload=json.dumps({'model':'tts-1','voice':'alloy','input':text,'response_format':'wav','speed':1}).encode()
    req=urllib.request.Request('https://api.openai.com/v1/audio/speech',data=payload,headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY'],'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=120) as r: data=r.read()
    except urllib.error.HTTPError as e:
        raise SystemExit('Speech request failed; HTTP '+str(e.code)+'. No retry.')
    dst.write_bytes(data)
    (B/'audio/cost.json').write_text(json.dumps({'model':'tts-1','voice':'alloy','characters':len(text),'estimated_usd':len(text)*15/1e6,'estimate_basis':'Prior documented $15 per million characters; account bill not independently verified','authorization':'User requested complete new Short; single-call estimated cost announced before execution','automatic_retries':False},indent=2))
with wave.open(str(dst)) as w: duration=w.getnframes()/w.getframerate()
print(json.dumps({'duration':duration,'characters':len(text),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()}))
